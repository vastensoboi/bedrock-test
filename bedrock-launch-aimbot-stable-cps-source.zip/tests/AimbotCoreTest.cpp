#include "../app/src/main/cpp/aim_combat.h"
#include <vector>
#include <cassert>
#include <iostream>
#include <algorithm>
using namespace kulich_aim;
struct Memory {
 static constexpr A root=0x200000;std::vector<unsigned char> bytes=std::vector<unsigned char>(0x80000);A next=root+0x10000;unsigned reads=0;
 A alloc(size_t n){A p=next;next=(next+n+7)&~A(7);assert(next-root<bytes.size());return p;}
 template<class T> void put(A p,T v){assert(p>=root&&p-root+sizeof v<=bytes.size());std::memcpy(bytes.data()+p-root,&v,sizeof v);}
 bool operator()(A p,void* out,size_t n){reads++;if(p<root||p-root>bytes.size()||n>bytes.size()-(p-root))return false;std::memcpy(out,bytes.data()+p-root,n);return true;}
};
struct Storage{A pool=0,sparse=0,pages=0;std::array<A,2> data{};unsigned stride=0;};
Storage storage(Memory& m,unsigned stride){
 Storage s;s.pool=m.alloc(104);s.stride=stride;A sparseVector=m.alloc(8);s.sparse=m.alloc(8192);
 std::fill(m.bytes.begin()+s.sparse-Memory::root,m.bytes.begin()+s.sparse-Memory::root+8192,255);
 m.put(s.pool+8,sparseVector);m.put(s.pool+16,sparseVector+8);m.put(sparseVector,s.sparse);
 s.pages=m.alloc(16);m.put(s.pool+80,s.pages);m.put(s.pool+88,s.pages+16);m.put(s.pool+96,s.pages+16);
 for(unsigned i=0;i<2;i++){s.data[i]=m.alloc(128*stride);m.put(s.pages+i*8,s.data[i]);}return s;
}
A bind(Memory& m,const Storage& s,uint32_t id,unsigned index){m.put(s.sparse+(id&2047)*4,(id&0xfffc0000U)|index);return s.data[index>>7]+(index&127)*s.stride;}
void near(double a,double b,double eps=.001){assert(std::abs(a-b)<eps);}
Box box(float x,float y,float z){return {{x-.3f,y,z-.3f},{x+.3f,y+1.8f,z+.3f},.6f,1.8f};}
int main(){
 Angles aim{};
 assert(angles({0,0,0},{0,0,3},0,aim));near(aim.pitch,0);near(aim.yaw,0);
 assert(angles({0,0,0},{3,0,0},0,aim));near(aim.yaw,-90);
 assert(angles({0,0,0},{0,0,-3},179,aim));near(aim.yaw,180);
 assert(angles({0,0,0},{0,0,-3},-179,aim));near(aim.yaw,-180);
 assert(angles({0,0,0},{0,5,0},17,aim));near(aim.pitch,-89.9);near(aim.yaw,17);
 assert(!angles({0,0,0},{0,0,0},0,aim));assert(!angles({NAN,0,0},{0,0,1},0,aim));assert(!angles({0,0,0},{0,0,1},INFINITY,aim));
 TurnClock clock;near(clock.allowance(1000,180),9);near(clock.allowance(1050,180),9);near(clock.allowance(1050,180),0);
 near(clock.allowance(2050,180),18);near(clock.allowance(2000,180),0);clock.reset();near(clock.allowance(3000,60),3);
 assert(clock.allowance(3050,NAN)==0&&clock.allowance(3050,-1)==0);
 Angles step{};assert(turnToward({0,0},{0,180},9,step));near(angleGap({0,0},step),9);
 assert(turnToward({0,179},{0,-179},1,step));near(step.yaw,180);
 assert(turnToward({0,0},{30,40},5,step));near(step.pitch,3);near(step.yaw,4);near(angleGap({0,0},step),5);
 assert(turnToward({10,20},{11,22},9,step));near(step.pitch,11);near(step.yaw,22); // no overshoot
 assert(turnToward({10,20},{-30,-150},0,step));near(step.pitch,10);near(step.yaw,20);
 assert(!turnToward({NAN,0},{0,0},9,step)&&!turnToward({0,0},{0,0},-1,step));
 // Moving targets and wrap crossings never create an unbounded snap.
 Angles moving{};for(int i=0;i<1000;i++){Angles desired{float(40*std::sin(i*.2)),float(std::remainder(i*13.0,360.0))},next{};
  assert(turnToward(moving,desired,9,next)&&angleGap(moving,next)<9.001);moving=next;}
 auto a=box(0,0,0),b=box(0,0,3);assert(valid(a));near(point(b,true).y,1.62);near(point(b,false).y,.9);
 assert(angles(point(a,true),point(b,true),0,aim));near(aim.pitch,0);
 assert(angles(point(a,true),point(b,false),0,aim));assert(aim.pitch>10);
 Box bad=a;bad.hi[0]=NAN;assert(!valid(bad));bad=a;bad.hi[1]=bad.lo[1];assert(!valid(bad));
 Memory m;constexpr A base=0x10000000,registry=Memory::root+0x1000,self=Memory::root+0x3000,one=Memory::root+0x5000,two=Memory::root+0x7000;
 constexpr uint32_t localId=0x40001,oneId=0x40002,twoId=0x40003;
 auto owners=storage(m,8),shapes=storage(m,32),rotations=storage(m,16),heads=storage(m,8);
 A buckets=m.alloc(64),nodes=m.alloc(128);for(int i=0;i<8;i++)m.put<int64_t>(buckets+i*8,-1);
 std::array<uint32_t,4> keys{OWNER,SHAPE,ROTATION,HEAD};std::array<A,4> pools{owners.pool,shapes.pool,rotations.pool,heads.pool};
 for(int i=0;i<4;i++){
  int64_t previous=-1;m(buckets+(keys[i]&7)*8,&previous,8);m.put(nodes+i*32,previous);m.put(nodes+i*32+8,keys[i]);m.put(nodes+i*32+16,pools[i]);m.put<int64_t>(buckets+(keys[i]&7)*8,i);
 }
 m.put(registry+96,buckets);m.put(registry+104,buckets+64);m.put(registry+120,nodes);m.put(registry+128,nodes+128);
 A entityPages=m.alloc(8),entitySparse=m.alloc(8192);std::fill(m.bytes.begin()+entitySparse-Memory::root,m.bytes.begin()+entitySparse-Memory::root+8192,255);
 m.put(registry+216,entityPages);m.put(registry+224,entityPages+8);m.put(entityPages,entitySparse);
 for(uint32_t id:{localId,oneId,twoId})m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|(id&2047));
 auto add=[&](A address,uint32_t id,unsigned ownerIndex,unsigned shapeIndex,bool local,Box value){
  m.put(address,base+(local?0x139f6ea0ULL:0x139f76b0ULL));m.put(address+8,registry|0xb400000000000000ULL);m.put(address+16,registry+40);m.put(address+24,id);
  m.put(bind(m,owners,id,ownerIndex),address|0xb400000000000000ULL);
  A shape=bind(m,shapes,id,shapeIndex);m.put(address+560,shape);m.put(shape,value);
  if(local){A rot=bind(m,rotations,id,0);m.put(address+568,rot);m.put(rot,Angles{0,0});bind(m,heads,id,0);}
 };
 add(self,localId,0,5,true,a);add(one,oneId,129,7,false,b);add(two,twoId,130,130,false,box(0,0,5));
 auto v=view(m,registry);assert(v.owners==owners.pool&&v.shapes==shapes.pool&&v.rotations==rotations.pool&&v.heads==heads.pool);
 Actor local{},target{};assert(actor(m,base,v,self,true,local));assert(component(m,owners.pool,oneId,8)==owners.data[1]+8);
 auto before=m.bytes;Lock lock;unsigned checked=0;assert(acquire(m,base,v,local,6,lock,target,checked));assert(target.address==one&&lock.entity==oneId&&checked==256&&m.bytes==before);
 m.put(component(m,shapes.pool,twoId,32),box(0,0,1));assert(retain(m,base,v,local,6,lock,target)&&target.address==one); // sticky, never switches just because another player moved closer
 m.put<unsigned char>(one+617,1);assert(!retain(m,base,v,local,6,lock,target)&&lock.actor==0);
 assert(acquire(m,base,v,local,6,lock,target,checked)&&target.address==two);
 m.put(two+24,twoId+0x40000U);assert(!retain(m,base,v,local,6,lock,target));m.put(two+24,twoId);
 m.put(two+8,registry+0x200);assert(!actor(m,base,v,two,false,target));m.put(two+8,registry);
 A shape=component(m,shapes.pool,twoId,32);m.put(two+560,shape+8);assert(!actor(m,base,v,two,false,target));m.put(two+560,shape);
 m.put(shape,box(0,0,13));assert(!acquire(m,base,v,local,6,lock,target,checked));
 m.put(shape,box(0,0,1));m.put(two,base+0x13cf56e8ULL);assert(!acquire(m,base,v,local,6,lock,target,checked)); // generic actors/mobs are not players
 m.put(two,base+0x139f76b0ULL);m.put(shape,bad);assert(!acquire(m,base,v,local,6,lock,target,checked));
 m.put(shape,box(0,0,1));m.put(component(m,rotations.pool,localId,16),Angles{0,NAN});assert(!actor(m,base,v,self,true,local));
 // Corrupt chains and missing payloads fail without any write or unbounded walk.
 m.put(nodes+3*32,int64_t(3));unsigned reads=m.reads;assert(pool(m,registry,0x12345671U)==0&&m.reads-reads<70);
 // Bind only the active input camera, including its entity generation and
 // native allocation tags. A stale camera or a render-only camera cannot turn.
 constexpr A cameraRoot=Memory::root+0x9000;constexpr uint32_t cameraId=0x40004;
 auto cameras=storage(m,280),direct=storage(m,20),active=storage(m,1),input=storage(m,1);
 A cb=m.alloc(64),cn=m.alloc(128);for(int i=0;i<8;i++)m.put<int64_t>(cb+i*8,-1);
 std::array<uint32_t,4> ck{CAMERA,DIRECT_LOOK,ACTIVE_CAMERA,INPUT_CAMERA};
 std::array<A,4> cp{cameras.pool,direct.pool,active.pool,input.pool};
 for(int i=0;i<4;i++){int64_t prev=-1;m(cb+(ck[i]&7)*8,&prev,8);m.put(cn+i*32,prev);m.put(cn+i*32+8,ck[i]);m.put(cn+i*32+16,cp[i]);m.put<int64_t>(cb+(ck[i]&7)*8,i);}
 m.put(cameraRoot+96,cb);m.put(cameraRoot+104,cb+64);m.put(cameraRoot+120,cn);m.put(cameraRoot+128,cn+128);
 m.put(cameraRoot+216,entityPages);m.put(cameraRoot+224,entityPages+8);m.put(entitySparse+(cameraId&2047)*4,(cameraId&0xfffc0000U)|4);
 A cam=bind(m,cameras,cameraId,129),look=bind(m,direct,cameraId,130);bind(m,active,cameraId,0);bind(m,input,cameraId,0);
 m.put(cam+40,std::array<float,4>{0,0,0,1});DirectLook d{0,0,0,-1.5708f,1.5708f};m.put(look,d);
 constexpr A tag=0xb400000000000000ULL;m.put(cameras.pages+8,cameras.data[1]|tag);m.put(direct.pages+8,direct.data[1]|tag);
 CameraContext context{cameraRoot|tag,cameraRoot+40,cameraId,0,1,{}};CameraBinding binding{};
 before=m.bytes;assert(cameraBinding(m,context,binding)&&binding.camera==(cam|tag)&&binding.direct==(look|tag)&&m.bytes==before);
 context.present=0;assert(!cameraBinding(m,context,binding));context.present=1;
 context.entity+=0x40000U;assert(!cameraBinding(m,context,binding));context.entity=cameraId;
 context.storage+=8;assert(!cameraBinding(m,context,binding));context.storage=cameraRoot+40;
 m.put(input.sparse+(cameraId&2047)*4,0xffffffffU);assert(!cameraBinding(m,context,binding));bind(m,input,cameraId,0);
 m.put(cam+40,std::array<float,4>{0,0,0,0});assert(!cameraBinding(m,context,binding));m.put(cam+40,std::array<float,4>{0,0,0,1});
 d.maxPitch=NAN;m.put(look,d);assert(!cameraBinding(m,context,binding));d.maxPitch=1.5708f;
 constexpr double rad=3.14159265358979323846/180.0;
 // Independent projection oracle: the actual native system's sin/cos calls
 // and quaternion->forward transform, rather than the old Actor pose model.
 auto orientation=[&](DirectLook look){
  double p=look.pitch*.5,y=(look.yaw+look.pendingYaw)*.5;
  double x=std::sin(p)*std::cos(y),qy=std::cos(p)*std::sin(y),z=-std::sin(p)*std::sin(y),w=std::cos(p)*std::cos(y);
  Vec forward{-2*(x*z+qy*w),2*(x*w-qy*z),-1+2*(x*x+qy*qy)};
  Angles out{};assert(angles({0,0,0},forward,0,out));return out;
 };
 auto fromPose=[&](Angles pose){return DirectLook{float((180-pose.yaw)*rad),float(-pose.pitch*rad),0,-1.5708f,1.5708f};};
 auto submit=[&](DirectLook& look,Angles inputDelta){look.pitch+=float(inputDelta.pitch*rad);look.pendingYaw-=float(inputDelta.yaw*rad);};
 auto consume=[](DirectLook& look){look.yaw=float(std::remainder(double(look.yaw)+look.pendingYaw,2*3.14159265358979323846));look.pendingYaw=0;};
 for(float pitch:{-80.f,-45.f,0.f,30.f,80.f})for(float yaw:{-179.f,-90.f,0.f,90.f,179.f}){
  d=fromPose({pitch,yaw});Angles measured{};assert(cameraPose(d,measured));assert(angleGap(measured,orientation(d))<.0001);
 }
 Angles value{},delta{};d=fromPose({0,179});assert(cameraInput({0,-179},9,.05,.10,d,value,delta));
 assert(delta.yaw>0&&delta.yaw<2);near(delta.pitch,0);
 // A target below the crosshair requires a NEGATIVE native pitch input.
 d=fromPose({0,0});assert(cameraInput({30,0},9,.05,.10,d,value,delta));assert(delta.pitch<0);submit(d,delta);
 assert(orientation(d).pitch>0&&angleGap(value,orientation(d))<.0001);
 d=fromPose({0,0});assert(cameraInput({-30,0},9,.05,.10,d,value,delta));assert(delta.pitch>0);submit(d,delta);assert(orientation(d).pitch<0);
 assert(!cameraInput({NAN,0},9,.05,.10,d,value,delta));assert(!cameraInput({0,0},9,NAN,.10,d,value,delta));
 assert(!cameraInput({0,0},9,.05,0,d,value,delta));assert(!cameraInput({0,0},9,.15,.10,d,value,delta));
 // Native pitch limits and smoothing strength apply in camera coordinates.
 d=fromPose({-86,0});d.maxPitch=1.51f;assert(cameraInput({-89,0},9,.05,.10,d,value,delta));assert(delta.pitch>.5&&delta.pitch<.6);
 d=fromPose({0,0});Angles slow{},fast{};
 assert(cameraInput({0,10},9,.05,.20,d,slow,delta));assert(cameraInput({0,10},9,.05,.04,d,fast,delta));assert(slow.yaw<fast.yaw);
 assert(cameraInput({0,10},0,0,.10,d,value,delta));near(delta.pitch,0);near(delta.yaw,0);
 // Repeated input ticks before a rendered camera update must not reuse stale
 // Actor angles or add an already-pending yaw correction a second time.
 for(Angles goal:std::array<Angles,4>{{{-20,-175},{45,90},{-70,-90},{0,0}}}){
  d=fromPose({10,170});double previousError=angleGap(orientation(d),goal);
  for(int i=0;i<150;i++){
   auto previous=orientation(d);assert(cameraInput(goal,9,.05,.10,d,value,delta));submit(d,delta);
   if(i%3==2)consume(d);
   auto actual=orientation(d);double error=angleGap(actual,goal);
   assert(angleGap(previous,actual)<=9.001&&error<=previousError+.0001);previousError=error;
  }
  assert(angleGap(orientation(d),goal)<.121);
 }
 // At different distances and heights the ray ends at the selected head or
 // torso point, rather than merely moving pitch up/down in a relative loop.
 auto selfBox=box(0,0,0);Vec eye=point(selfBox,true);
 near(aimPoint(box(0,0,3),true).y,1.62);near(aimPoint(box(0,0,3),false).y,1.08);
 for(bool head:{true,false})for(float height:{-2.f,0.f,2.f}){
  Box targetBox=box(2,height,3);Angles goal{};assert(angles(eye,aimPoint(targetBox,head),0,goal));
  d=fromPose({-65,90});
  for(int i=0;i<160;i++){assert(cameraInput(goal,9,.05,.10,d,value,delta));submit(d,delta);consume(d);}
  assert(angleGap(orientation(d),goal)<.121);
 }
 // Reaching a stationary point stops tiny corrections. A new point or moving
 // player resumes smoothly; sampling at 20/40/60 Hz converges consistently.
 for(double dt:{.05,.025,1.0/60}){
  d=fromPose({10,170});Angles goal{-20,-175};
  for(int i=0;i<int(2/dt);i++){
   Angles previous=orientation(d);assert(cameraInput(goal,180*dt,dt,.10,d,value,delta));submit(d,delta);consume(d);
   assert(angleGap(previous,orientation(d))<=180*dt+.001);
  }
  assert(angleGap(orientation(d),goal)<.121);assert(cameraInput(goal,180*dt,dt,.10,d,value,delta));near(delta.pitch,0);near(delta.yaw,0);
 }
 // Sharp mode reaches the point in one native input update, including wrap,
 // reversed pitch, pending input, limits and mode changes.
 for(Angles goal:std::array<Angles,4>{{{-20,-175},{45,90},{-70,-90},{0,0}}}){
  d=fromPose({10,170});assert(cameraSnap(goal,d,value,delta));submit(d,delta);
  assert(angleGap(orientation(d),goal)<.001);
  assert(cameraSnap(goal,d,value,delta));near(delta.pitch,0);near(delta.yaw,0);consume(d);
  assert(cameraInput(goal,9,.05,.10,d,value,delta));near(delta.pitch,0);near(delta.yaw,0);
 }
 d=fromPose({0,0});d.minPitch=-.5f;assert(cameraSnap({80,90},d,value,delta));near(value.pitch,.5/rad);
 assert(!cameraSnap({NAN,0},d,value,delta));
 AimDeadzone zone;assert(zone.hold(.1)&&zone.hold(.2)&&!zone.hold(.3));zone.reset();assert(!zone.hold(.2));
 AimRamp ramp;near(ramp.scale(1,1,1000),.25);near(ramp.scale(1,1,1180),1);near(ramp.scale(2,2,1200),.25);
 assert(prefer(true,4,25,18,9,true));assert(!prefer(true,18,1,4,25,true));
 assert(!prefer(false,4,9.5,18,10,true));assert(prefer(false,NAN,5,NAN,10,true));assert(prefer(true,5,25,NAN,9,true));
 // Exact attribute layout and end-to-end ranking with real HP vs distance.
 auto attrs=storage(m,88);A expanded=m.alloc(160);
 for(int i=0;i<8;i++)m.put<int64_t>(buckets+i*8,-1);
 std::array<uint32_t,5> ak{OWNER,SHAPE,ROTATION,HEAD,0xfd3b0613U};
 std::array<A,5> ap{owners.pool,shapes.pool,rotations.pool,heads.pool,attrs.pool};
 for(int i=0;i<5;i++){int64_t prev=-1;m(buckets+(ak[i]&7)*8,&prev,8);m.put(expanded+i*32,prev);m.put(expanded+i*32+8,ak[i]);m.put(expanded+i*32+16,ap[i]);m.put<int64_t>(buckets+(ak[i]&7)*8,i);}
 m.put(registry+120,expanded);m.put(registry+128,expanded+160);
 auto attribute=[&](uint32_t id,int index,float hp){A obj=bind(m,attrs,id,index),ids=m.alloc(4),records=m.alloc(136);m.put(ids,uint32_t(7));m.put(obj,ids);m.put(obj+8,ids+4);m.put(obj+24,records);m.put(obj+32,records+136);m.put(records+124,hp);return records;};
 A hp1=attribute(oneId,0,18),hp2=attribute(twoId,1,4);
 auto reader=[&](A address,void* out,size_t size){if(address==base+0x141d8f4cULL&&size==4){uint32_t id=7;std::memcpy(out,&id,4);return true;}return m(address,out,size);};
 near(health(reader,base,registry,twoId),4);m.put(hp2+124,NAN);assert(!std::isfinite(health(reader,base,registry,twoId)));m.put(hp2+124,4.f);
 m.put<unsigned char>(one+617,0);m.put(two,base+0x139f76b0ULL);m.put(component(m,shapes.pool,oneId,32),box(0,0,3));m.put(component(m,shapes.pool,twoId,32),box(0,0,5));
 m.put(component(m,rotations.pool,localId,16),Angles{});v=view(m,registry);assert(actor(m,base,v,self,true,local));
 assert(acquire(reader,base,v,local,6,lock,target,checked,false)&&target.entity==oneId);
 assert(acquire(reader,base,v,local,6,lock,target,checked,true)&&target.entity==twoId);
 m.put(hp2+124,0.f);assert(acquire(reader,base,v,local,6,lock,target,checked,true)&&target.entity==oneId);
 m.put(hp1+124,NAN);m.put(hp2+124,NAN);assert(acquire(reader,base,v,local,6,lock,target,checked,true)&&target.entity==oneId);
 // Every requested rate uses fractional deadlines on a 20 Hz source.
 for(int rate=10;rate<=20;rate++){
  ClickClock clicks;int count=0;
  for(int ms=0;ms<10000;ms+=50)if(clicks.due(ms,rate))count++;
  assert(std::abs(count-rate*10)<=1);
  assert(clicks.due(20000,rate));assert(!clicks.due(20000,rate));
  clicks.reset();assert(clicks.due(0,rate));assert(!clicks.due(1,rate));
 }
 AxisStabilizer axes;auto held=axes.apply(1,1,true,{0,0},{.1f,30});near(held.pitch,0);near(held.yaw,30);
 held=axes.apply(1,1,true,{0,0},{.2f,40});near(held.pitch,0);held=axes.apply(1,1,true,{0,0},{.4f,40});near(held.pitch,.4);
 held=axes.apply(2,2,false,{0,0},{.2f,40});near(held.pitch,.2);
 Vec hit{};float forward[4]{0,1,0,0};assert(rayHit({0,1.62,0},forward,box(0,0,2.5),3,hit));
 near(hit.z,2.2);assert(!rayHit({0,1.62,0},forward,box(0,0,4),3,hit));assert(!rayHit({0,1.62,0},forward,box(2,0,2.5),3,hit));
 float backwards[4]{0,0,0,1};assert(!rayHit({0,1.62,0},backwards,box(0,0,2.5),3,hit));
 float invalid[4]{NAN,0,0,1};assert(!rayHit({0,1.62,0},invalid,box(0,0,2.5),3,hit));
 // Reject the old interaction entry and bind only attack at virtual slot 16.
 A mode=m.alloc(208);m.put(mode,base+0x13d227d0ULL);m.put(mode+8,self|tag);
 bool oldSlotOnly=false,corruptAttack=false;
 auto attackRead=[&](A address,void* out,size_t size){
  if(size==8&&(address==base+0x13d227d0ULL+128||address==base+0x13d22900ULL+128)){
   A fn=oldSlotOnly||corruptAttack?base+0x1009c5e4ULL:base+(address==base+0x13d227d0ULL+128?ATTACK:ATTACK_SURVIVAL);
   std::memcpy(out,&fn,8);return true;
  }
  return m(address,out,size);
 };
 assert(attackBinding(attackRead,base,mode|tag,self)==base+ATTACK);
 oldSlotOnly=true;assert(!attackBinding(attackRead,base,mode|tag,self));oldSlotOnly=false;
 m.put(mode,base+0x13d22900ULL);assert(attackBinding(attackRead,base,mode|tag,self)==base+ATTACK_SURVIVAL);
 corruptAttack=true;assert(!attackBinding(attackRead,base,mode|tag,self));corruptAttack=false;
 m.put(mode+8,two);assert(!attackBinding(attackRead,base,mode|tag,self));m.put(mode+8,self);
 m.put(mode,base+123);assert(!attackBinding(attackRead,base,mode|tag,self));
 float impact[3]{1,2,3};bool dispatched=false;
 auto attack=[&](void* owner,void* victim,const float* position){
  assert(reinterpret_cast<A>(owner)==(mode|tag)&&reinterpret_cast<A>(victim)==(two|tag)&&position==impact);
  dispatched=true;return true;
 };
 assert(dispatchAttack(attack,reinterpret_cast<void*>(mode|tag),reinterpret_cast<void*>(two|tag),impact)&&dispatched);
 for(int rate=1;rate<=30;rate++){
  ClickClock clock;int total=0;
  for(int ms=0;ms<10000;ms+=50){int n=clock.take(ms,rate);assert(n>=0&&n<=2);total+=n;}
  assert(std::abs(total-rate*10)<=1);assert(clock.take(30000,rate)==1);assert(clock.take(30000,rate)==0);
 }
 A data=m.alloc(16),items=m.alloc(48),item=m.alloc(48),vt=m.alloc(32),fn=m.alloc(8);
 m.put(two+320,data);m.put(data,items);m.put(data+8,items+48);m.put(items+32,item);m.put(item,vt);m.put(vt+24,fn);
 m.put(fn,uint32_t(0x52800080));m.put(fn+4,uint32_t(0xd65f03c0));
 std::array<unsigned char,24> tagString{};tagString[0]=12;std::memcpy(tagString.data()+1,"Player",6);m.put(item+16,tagString);
 char tagName[385]{};assert(targetName(m,two,tagName,sizeof tagName)&&std::string(tagName)=="Player");
 m.put(fn,uint32_t(0));assert(!targetName(m,two,tagName,sizeof tagName));
 // A delayed rendered view misses a moving target; pending sharp view hits.
 d=fromPose({0,-90});assert(rayHitView({0,1.62,0},d,box(2.5,0,0),3,hit));
 assert(!rayHit({0,1.62,0},forward,box(2.5,0,0),3,hit));
 d=fromPose({0,0});assert(rayHitView({0,1.62,0},d,box(0,0,4.5),5,hit));
 assert(!rayHitView({0,1.62,0},d,box(0,0,4.5),3,hit));
 assert(rayHitView({0,1.62,0},d,box(0,0,0),1,hit)); // overlapping close target
 assert(ClickClock{}.take(0,0)==1);AttemptMeter countMeter;countMeter.add(1000);assert(countMeter.rate(1000)==1&&countMeter.rate(2000)==0);
 std::vector<int> order;int freshPosition=0;
 afterPlayerUpdate(self|tag,[&](A value){assert(value==(self|tag));freshPosition=1;order.push_back(1);},
  [&](A value){assert(value==(self|tag)&&freshPosition==1);order.push_back(2);},
  [&](A value){assert(value==(self|tag)&&freshPosition==1);order.push_back(3);});
 assert((order==std::vector<int>{1,2,3}));
 std::cout<<"PASS: aim geometry/ECS guards, active camera identity/MTE, native quaternion pitch sign, pending-yaw feedback, smoothing and speed bounds, stationary head/torso convergence at different heights and rates\n";
}
