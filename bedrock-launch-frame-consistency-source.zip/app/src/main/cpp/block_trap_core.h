#pragma once
#include "aim_core.h"
#include <algorithm>
#include <array>
#include <vector>

// Pure planning only. The caller must read a fresh player list, validate each
// target/support block and the held item, then use the game's placement API.
// This file never reads memory, writes rotations or emits a placement itself.
namespace kulich_trap {
using kulich_aim::A;
using kulich_aim::Actor;
using kulich_aim::Box;
using kulich_aim::Vec;
constexpr double MAX_TARGET_RANGE=5.0;
constexpr size_t MAX_PROPOSALS=64,MAX_PLAYERS=128;
struct Cell {int32_t x=0,y=0,z=0;};
static_assert(sizeof(Cell)==12,"Native BlockPos-compatible coordinates");
inline bool operator==(Cell a,Cell b){return a.x==b.x&&a.y==b.y&&a.z==b.z;}
inline bool operator!=(Cell a,Cell b){return !(a==b);}
inline bool valid(Cell c){return std::abs(double(c.x))<=32000000&&std::abs(double(c.y))<=32000000&&std::abs(double(c.z))<=32000000;}
inline bool valid(Vec v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z)&&std::abs(v.x)<=32000000&&std::abs(v.y)<=32000000&&std::abs(v.z)<=32000000;}
inline bool valid(const Actor& actor){return actor.address>=4096&&(actor.entity&0x3ffffU)!=0x3ffffU&&kulich_aim::valid(actor.box);}
inline double distance2(Vec a,Vec b){return (a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)+(a.z-b.z)*(a.z-b.z);}

// A positive-volume overlap is forbidden; exactly touching a cell boundary is
// allowed. Check the complete AABB, not only the player's floored centre.
inline bool intersects(Cell cell,const Box& box){
 if(!valid(cell)||!kulich_aim::valid(box))return true;
 return double(cell.x)+1>box.lo[0]&&double(cell.x)<box.hi[0]&&
        double(cell.y)+1>box.lo[1]&&double(cell.y)<box.hi[1]&&
        double(cell.z)+1>box.lo[2]&&double(cell.z)<box.hi[2];
}
struct Support {Cell block{};uint8_t face=255;};
// Bedrock face normals are DOWN0, UP1, NORTH2, SOUTH3, WEST4, EAST5.
// Each returned face points OUT of the support and into the intended target.
inline std::array<Support,6> supports(Cell target){
 if(!valid(target))return {};
 return {{{{target.x,target.y-1,target.z},1},
          {{target.x-1,target.y,target.z},5},
          {{target.x+1,target.y,target.z},4},
          {{target.x,target.y,target.z-1},3},
          {{target.x,target.y,target.z+1},2},
          {{target.x,target.y+1,target.z},0}}};
}
inline Cell normal(uint8_t face){
 constexpr Cell values[]={{0,-1,0},{0,1,0},{0,0,-1},{0,0,1},{-1,0,0},{1,0,0}};
 return face<6?values[face]:Cell{};
}
inline Cell destination(Support support){
 if(support.face>=6||!valid(support.block))return {INT32_MIN,INT32_MIN,INT32_MIN};
 Cell n=normal(support.face);return {support.block.x+n.x,support.block.y+n.y,support.block.z+n.z};
}
inline Vec hitPoint(Support support){
 if(support.face>=6||!valid(support.block))return {NAN,NAN,NAN};
 Cell n=normal(support.face);
 return {support.block.x+.5+n.x*.5,support.block.y+.5+n.y*.5,support.block.z+.5+n.z*.5};
}
inline bool reachable(Vec eye,Support support,double maximum){
 if(!valid(eye)||!std::isfinite(maximum)||maximum<=0||maximum>6)return false;
 Vec hit=hitPoint(support);return valid(hit)&&distance2(eye,hit)<=maximum*maximum;
}

struct TargetLock {
 A address=0;uint32_t entity=0xffffffffU;
 void reset(){address=0;entity=0xffffffffU;}
};
// Friend/identity decisions remain with the caller. A false or unknown decision
// must be returned as false. A still-valid target is retained even if a second
// player becomes closer; loss, a friend change or entity reuse clears the lock.
template<class Allowed>
bool chooseTarget(const Actor& local,const std::vector<Actor>& players,double range,
                  TargetLock& lock,Actor& out,Allowed allowed){
 out={};
 if(!valid(local)||players.size()>MAX_PLAYERS||!std::isfinite(range)||range<=0||range>MAX_TARGET_RANGE){lock.reset();return false;}
 auto eligible=[&](const Actor& candidate){
  return valid(candidate)&&candidate.address!=local.address&&candidate.entity!=local.entity&&
   kulich_aim::distance2(local.box,candidate.box)<=range*range&&allowed(candidate);
 };
 for(const auto& player:players)if(player.address==lock.address&&player.entity==lock.entity&&eligible(player)){out=player;return true;}
 lock.reset();bool found=false;double best=range*range;
 for(const auto& player:players){
  if(!eligible(player))continue;
  double d=kulich_aim::distance2(local.box,player.box);
  if(found&&(d>best||(d==best&&player.entity>=out.entity)))continue;
  out=player;best=d;found=true;
 }
 if(found)lock={out.address,out.entity};
 return found;
}

// Build cardinal columns around every X/Z cell occupied by the target, then a
// roof. Normal standing players have 13 proposals: four columns at foot/head/
// roof-support heights plus one roof cell. The upper supports let the native
// placement API attach that roof without ever placing into the player's body.
// The native caller still decides which proposals are empty and anchored.
inline std::vector<Cell> proposals(const Actor& local,const Actor& target,
                                  const std::vector<Actor>& players,size_t limit=MAX_PROPOSALS){
 std::vector<Cell> result;
 if(!valid(local)||!valid(target)||local.address==target.address||local.entity==target.entity||
    players.size()>MAX_PLAYERS||!limit)return result;
 for(const auto& player:players)if(!valid(player))return result;
 int32_t left=int32_t(std::floor(target.box.lo[0])),right=int32_t(std::ceil(target.box.hi[0]))-1;
 int32_t north=int32_t(std::floor(target.box.lo[2])),south=int32_t(std::ceil(target.box.hi[2]))-1;
 int32_t foot=int32_t(std::floor(target.box.lo[1])),roof=int32_t(std::ceil(target.box.hi[1]));
 // Existing shape validation limits the player to <=4 blocks in each axis;
 // this separate integer guard also bounds all loops at grid boundaries.
 if(right<left||right-left>4||south<north||south-north>4||roof<foot||roof-foot>5)return result;
 auto append=[&](Cell cell){
  if(!valid(cell)||intersects(cell,local.box)||intersects(cell,target.box))return;
  for(const auto& player:players)if(intersects(cell,player.box))return;
  if(std::find(result.begin(),result.end(),cell)==result.end())result.push_back(cell);
 };
 for(int32_t y=foot;y<=roof;y++){
  for(int32_t z=north;z<=south;z++){append({left-1,y,z});append({right+1,y,z});}
  for(int32_t x=left;x<=right;x++){append({x,y,north-1});append({x,y,south+1});}
 }
 for(int32_t z=north;z<=south;z++)for(int32_t x=left;x<=right;x++)append({x,roof,z});
 Vec eye=kulich_aim::point(local.box,true);
 std::sort(result.begin(),result.end(),[&](Cell a,Cell b){
  if(a.y!=b.y)return a.y<b.y; // anchor the lower layer before upper layers.
  double da=distance2(eye,{a.x+.5,a.y+.5,a.z+.5}),db=distance2(eye,{b.x+.5,b.y+.5,b.z+.5});
  if(da!=db)return da<db;
  if(a.x!=b.x)return a.x<b.x;
  return a.z<b.z;
 });
 result.resize(std::min(result.size(),std::min(limit,MAX_PROPOSALS)));return result;
}
inline int clampInterval(int ticks){return std::max(2,std::min(10,ticks));}
class Cadence {
 int remaining=0,setting=0;
public:
 void reset(){remaining=setting=0;}
 bool due(int ticks){
  ticks=clampInterval(ticks);if(setting!=ticks){remaining=0;setting=ticks;}
  if(remaining){--remaining;return false;}
  remaining=ticks-1;return true;
 }
};
}
