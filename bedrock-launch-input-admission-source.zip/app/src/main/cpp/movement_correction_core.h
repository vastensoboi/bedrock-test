#pragma once
#include "aim_core.h"
#include "movement_history_core.h"
#include "movement_input_core.h"
#include <sstream>
#include <string>
#include <iomanip>

namespace kulich_correction {
using namespace kulich_aim;
constexpr A CLIENT=0x1388fe70ULL,HANDLER=0x1394afc0ULL,LEGACY=0x1394b878ULL;
constexpr A CORRECT_PACKET=0x13b143e0ULL,HANDLE=0xa2eaf70ULL;
constexpr A MOVE_PACKET=0x13b95ce0ULL,MOVE_HANDLE=0xa300578ULL;
constexpr uint32_t RUNTIME_ID=0xfc0dbbb5U;
constexpr unsigned SLOT=204;
enum class Kind {Prediction,MovePlayer};
inline int packetId(Kind kind){return kind==Kind::Prediction?161:19;}
struct Payload {
 bool available=false,hasVehicleAngularVelocity=false;
 std::array<float,3> position{},delta{};std::array<float,2> rotation{};
 float vehicleAngularVelocity=0;uint64_t inputTick=0;uint8_t ground=0,context=0;
 kulich_rewind::Window history{};
 kulich_input::Comparison submitted{};
};
template<class Read>bool readPayload(Read& read,A packet,Payload& out){
 out={};packet=plain(packet);Payload value{};uint8_t present=0;
 if(!read(packet+48,value.position.data(),12)||!read(packet+60,value.delta.data(),12)||
    !read(packet+88,&value.inputTick,8)||!read(packet+96,&value.ground,1)||!read(packet+97,&value.context,1)||
    value.ground>1||value.context>1)return false;
 for(float item:value.position)if(!std::isfinite(item)||std::abs(item)>32000000.f)return false;
 // A world-diameter bound rejects malformed values, not ordinary speeds.
 for(float item:value.delta)if(!std::isfinite(item)||std::abs(item)>64000000.f)return false;
 // Rotation/angular velocity are serialized and applied only for Vehicle.
 // Unused Player storage and an absent optional float are not observations.
 if(value.context==1){
  if(!read(packet+72,value.rotation.data(),8)||!read(packet+84,&present,1)||present>1)return false;
  for(float item:value.rotation)if(!std::isfinite(item))return false;
  value.hasVehicleAngularVelocity=present==1;
  if(present&&(!read(packet+80,&value.vehicleAngularVelocity,4)||!std::isfinite(value.vehicleAngularVelocity)))return false;
 }
 value.available=true;out=value;return true;
}
inline bool same(const Payload& a,const Payload& b){
 return a.available&&b.available&&a.hasVehicleAngularVelocity==b.hasVehicleAngularVelocity&&
  !std::memcmp(a.position.data(),b.position.data(),12)&&!std::memcmp(a.delta.data(),b.delta.data(),12)&&
  !std::memcmp(a.rotation.data(),b.rotation.data(),8)&&a.inputTick==b.inputTick&&a.ground==b.ground&&a.context==b.context&&
  (!a.hasVehicleAngularVelocity||!std::memcmp(&a.vehicleAngularVelocity,&b.vehicleAngularVelocity,4));
}
inline void describePayload(std::ostream& out,const Payload& value){
 if(!value.available){out<<"payload=unavailable";return;}
 out<<std::setprecision(std::numeric_limits<float>::max_digits10)<<"payload=valid context="<<(value.context==0?"Player":"Vehicle")
  <<"("<<unsigned(value.context)<<") inputTick="<<value.inputTick
  <<" serverPosAtInputTick=("<<value.position[0]<<","<<value.position[1]<<","<<value.position[2]<<")"
  <<" serverDeltaAtInputTick=("<<value.delta[0]<<","<<value.delta[1]<<","<<value.delta[2]<<")"
  <<" onGround="<<unsigned(value.ground);
 if(value.context==1){
  out<<" rotation=("<<value.rotation[0]<<","<<value.rotation[1]<<") vehicleAngularVelocity=";
  if(value.hasVehicleAngularVelocity)out<<value.vehicleAngularVelocity;else out<<"absent";
 }else out<<" vehicleFields=not-applicable";
 out<<" "<<kulich_rewind::describe(value.history);
 kulich_input::describe(out,value.submitted);
}
struct Binding {A client=0,registry=0,actor=0;uint32_t entity=0xffffffffU;uint64_t runtimeId=0;uint8_t mode=255;};
inline bool same(const Binding& a,const Binding& b){return a.client==b.client&&a.registry==b.registry&&a.actor==b.actor&&a.entity==b.entity&&a.runtimeId==b.runtimeId&&a.mode==b.mode;}
template<class Read>bool resolve(Read& read,A base,A client,A handler,A packet,Binding& out,Kind packetKind=Kind::Prediction){
 out={};client=plain(client);handler=plain(handler);packet=plain(packet);
 if(!base||client<4096||handler<4096||packet<4096||pointer(read,client)!=base+CLIENT)return false;
 A kind=pointer(read,handler);
 if((kind!=base+HANDLER&&kind!=base+LEGACY)||pointer(read,handler+88)!=client)return false;
 if(packetKind==Kind::MovePlayer&&kind!=base+LEGACY)return false;
 if(pointer(read,packet)!=base+(packetKind==Kind::Prediction?CORRECT_PACKET:MOVE_PACKET))return false;
 A weak[3]{};if(!read(client+576,weak,sizeof weak)||plain(weak[0])<4096||plain(weak[1])<4096)return false;
 A registry=plain(weak[0]);uint32_t entity=uint32_t(weak[2]);
 uint64_t runtimeId=0;uint8_t mode=255;
 // Remote MovePlayer traffic is common. Reject a nonmatching runtime ID
 // before reading the owner's shape/rotation graph or doing a second pass.
 if(packetKind==Kind::MovePlayer){
  A value=component(read,pool(read,registry,RUNTIME_ID),entity,8);uint64_t receivedId=0;
  if(!value||!read(value,&runtimeId,8)||!runtimeId||!read(packet+48,&receivedId,8)||receivedId!=runtimeId||!read(packet+80,&mode,1))return false;
 }
 auto v=view(read,registry);A owner=component(read,v.owners,entity,8);Actor actor{};
 if(!owner||!kulich_aim::actor(read,base,v,pointer(read,owner),true,actor)||actor.entity!=entity||pointer(read,actor.address+3240)!=client)return false;
 out={client,registry,actor.address,entity,runtimeId,mode};return true;
}
template<class Read>bool capture(Read& read,A base,A client,A handler,A packet,Binding& out,Kind kind=Kind::Prediction,Payload* payload=nullptr){
 Binding first{},second{};Payload firstPayload{},secondPayload{};out={};if(payload)*payload={};
 if(!resolve(read,base,client,handler,packet,first,kind))return false;
 bool wanted=payload&&kind==Kind::Prediction;
 bool firstValid=wanted&&readPayload(read,packet,firstPayload);
 if(!resolve(read,base,client,handler,packet,second,kind)||!same(first,second))return false;
 bool secondValid=wanted&&readPayload(read,packet,secondPayload);
 // A missing, malformed or changing payload does not discard the verified
 // receive event. Padding and absent optional storage are not compared.
 if(firstValid&&secondValid&&same(firstPayload,secondPayload)){
  *payload=firstPayload;
  payload->history=kulich_rewind::sample(read,first.registry,first.entity,payload->inputTick,payload->context);
  Binding afterHistory{};Payload afterHistoryPayload{};
  if(!resolve(read,base,client,handler,packet,afterHistory,kind)||!same(first,afterHistory)||
     !readPayload(read,packet,afterHistoryPayload)||!same(firstPayload,afterHistoryPayload))payload->history={};
 }
 out=first;return true;
}
// Observation errors cannot prevent the native handler from receiving its
// original raw (possibly allocation-tagged) arguments exactly once.
template<class Observe,class Original>void forward(Observe observe,Original original,void* handler,void* network,void* packet){
 try{observe();}catch(...){}
 original(handler,network,packet);
}
struct Event {uint64_t sequence=0;int64_t when=-1;bool timer=false;int hundredths=100;Kind kind=Kind::Prediction;uint8_t mode=255;uint32_t entity=0xffffffffU;uint64_t runtimeId=0;Payload payload{};};
struct Book {
 std::array<Event,16> events{};size_t next=0,size=0;uint64_t on=0,off=0,prediction=0,moves=0,payloadUnavailable=0;
 Event lastOn{},lastOff{};
 // These totals describe one verified local actor/history binding. Cumulative
 // totals and event sequence survive rebinding; retained payloads and ages do
 // not, so a local world cannot inherit the previous server's correction ring.
 bool bound=false;kulich_input::Key key{};A actorTagged=0;
 uint64_t observationSession=0,sessionOn=0,sessionOff=0,sessionPrediction=0,sessionMoves=0,sessionPayloadUnavailable=0;
 uint64_t sessionStartOn=0,sessionStartOff=0,sessionStartPrediction=0,sessionStartMoves=0,sessionStartPayloadUnavailable=0;
 void retire(){
  bound=false;key={};actorTagged=0;events={};next=size=0;lastOn={};lastOff={};
  sessionStartOn=on;sessionStartOff=off;sessionStartPrediction=prediction;
  sessionStartMoves=moves;sessionStartPayloadUnavailable=payloadUnavailable;
  sessionOn=sessionOff=sessionPrediction=sessionMoves=sessionPayloadUnavailable=0;
 }
 bool bind(const kulich_input::Key& candidate,A taggedActor){
  if(candidate.client<4096||candidate.registry<4096||candidate.actor<4096||plain(candidate.history)<4096||
     candidate.client!=plain(candidate.client)||candidate.registry!=plain(candidate.registry)||candidate.actor!=plain(candidate.actor)||
     (candidate.client&7)||(candidate.registry&7)||(candidate.actor&7)||(plain(candidate.history)&7)||
     (candidate.entity&0x3ffffU)==0x3ffffU||plain(taggedActor)!=candidate.actor)return false;
  if(bound&&kulich_input::same(key,candidate)&&actorTagged==taggedActor)return false;
  retire();key=candidate;actorTagged=taggedActor;bound=true;++observationSession;
  return true;
 }
 void add(int64_t when,bool timer,int factor,Kind kind=Kind::Prediction,uint8_t mode=255,uint32_t entity=0xffffffffU,uint64_t runtimeId=0,const Payload& payload={}){
  Event event{on+off+1,when,timer,factor<100?100:factor>200?200:factor,kind,mode,entity,runtimeId,payload};
  if(timer){++on;lastOn=event;}else{++off;lastOff=event;}
  if(kind==Kind::Prediction){++prediction;if(!payload.available)++payloadUnavailable;}else ++moves;
  if(bound){
   if(timer)++sessionOn;else ++sessionOff;
   if(kind==Kind::Prediction){++sessionPrediction;if(!payload.available)++sessionPayloadUnavailable;}else ++sessionMoves;
  }
  events[next]=event;next=(next+1)%events.size();if(size<events.size())++size;
 }
};
inline int64_t age(int64_t now,const Event& value){return value.when<0||now<value.when?-1:now-value.when;}
inline std::string describe(const Book& book,int64_t now){
 std::ostringstream out;out<<"received="<<book.on+book.off<<" timerOn="<<book.on<<" timerOff="<<book.off
  <<" predictionPackets="<<book.prediction<<" ownMovePlayerPackets="<<book.moves<<" payloadUnavailable="<<book.payloadUnavailable
  <<" observationSession="<<book.observationSession<<" observationBound="<<book.bound
  <<" sessionReceived="<<book.sessionOn+book.sessionOff<<" sessionTimerOn="<<book.sessionOn<<" sessionTimerOff="<<book.sessionOff
  <<" sessionPredictionPackets="<<book.sessionPrediction<<" sessionOwnMovePlayerPackets="<<book.sessionMoves
  <<" sessionPayloadUnavailable="<<book.sessionPayloadUnavailable
  <<" sessionStartReceived="<<book.sessionStartOn+book.sessionStartOff
  <<" lastOnAgeMs="<<age(now,book.lastOn)<<" lastOnPacket="<<(book.lastOn.sequence?packetId(book.lastOn.kind):0)
  <<" lastOnMultiplierHundredths="<<book.lastOn.hundredths
  <<" lastOnEntity="<<book.lastOn.entity
  <<" lastOnRawMode="<<(book.lastOn.sequence&&book.lastOn.kind==Kind::MovePlayer?std::to_string(unsigned(book.lastOn.mode)):"unavailable")
  <<" lastOnRuntimeId="<<book.lastOn.runtimeId
  <<" lastOffAgeMs="<<age(now,book.lastOff)<<" lastOffPacket="<<(book.lastOff.sequence?packetId(book.lastOff.kind):0)<<" lastOffEntity="<<book.lastOff.entity
  <<" lastOffRawMode="<<(book.lastOff.sequence&&book.lastOff.kind==Kind::MovePlayer?std::to_string(unsigned(book.lastOff.mode)):"unavailable")
  <<" lastOffRuntimeId="<<book.lastOff.runtimeId<<" retained="<<book.size;
 if(book.lastOn.sequence&&book.lastOn.kind==Kind::Prediction){out<<"\n  lastOnPayload ";describePayload(out,book.lastOn.payload);}
 if(book.lastOff.sequence&&book.lastOff.kind==Kind::Prediction){out<<"\n  lastOffPayload ";describePayload(out,book.lastOff.payload);}
 for(size_t i=0;i<book.size;++i){const auto& event=book.events[(book.next+book.events.size()-book.size+i)%book.events.size()];
  out<<"\n  seq="<<event.sequence<<" packet="<<packetId(event.kind)<<" receivedAgeMs="<<age(now,event)<<" timerActive="<<event.timer<<" multiplierHundredths="<<event.hundredths;
  out<<" entity="<<event.entity;
  if(event.kind==Kind::MovePlayer)out<<" rawMode="<<unsigned(event.mode)<<" ownRuntimeId="<<event.runtimeId;
  else{out<<" ";describePayload(out,event.payload);}
 }
 return out.str();
}
void prepare(uint64_t base,uint64_t client);
std::string report();
}
