cmake_minimum_required(VERSION 3.22.1)
project(kulichbridge LANGUAGES CXX ASM)
add_library(kulichbridge SHARED fast_exp.cpp transaction_action.cpp transaction_trace.cpp transaction_response.S)
target_compile_features(kulichbridge PRIVATE cxx_std_17)
target_compile_options(kulichbridge PRIVATE
    $<$<COMPILE_LANGUAGE:CXX>:-Wall>
    $<$<COMPILE_LANGUAGE:CXX>:-Wextra>
    $<$<COMPILE_LANGUAGE:CXX>:-Werror>
    $<$<COMPILE_LANGUAGE:CXX>:-mbranch-protection=standard>)
