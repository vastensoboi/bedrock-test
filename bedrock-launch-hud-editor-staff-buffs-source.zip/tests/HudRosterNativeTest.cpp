#include "../app/src/main/cpp/hud_roster_core.h"
#include <cassert>
#include <iostream>
using namespace kulich_hud;
struct Memory {
 static constexpr A root=0x200000,base=0x10000000;std::vector<unsigned char> bytes=std::vector<unsigned char>(0x20000);bool change=false;A map=0;unsigned headers=0;
 template<class T>void put(A p,T v){assert(p>=root&&p-root+sizeof v<=bytes.size());std::memcpy(bytes.data()+p-root,&v,sizeof v);}
 bool operator()(A p,void* out,size_t n){if(p<root||p-root>bytes.size()||n>bytes.size()-(p-root))return false;std::memcpy(out,bytes.data()+p-root,n);if(change&&p==map&&n==32&&++headers%2==0)static_cast<unsigned char*>(out)[24]^=1;return true;}
 void name(A p,const char* text){std::array<unsigned char,24> value{};size_t n=std::strlen(text);assert(n<=22);value[0]=static_cast<unsigned char>(n*2);std::memcpy(value.data()+1,text,n);put(p,value);}
};
int main(){
 Memory m;A player=Memory::root+0x1000,client=Memory::root+0x3000,level=Memory::root+0x5000,map=Memory::root+0x7000,a=Memory::root+0x8000,b=Memory::root+0x8100;m.map=map;
 m.name(player+0xb28,"Alice");m.put(client+416,level|0xb400000000000000ULL);m.put(level,Memory::base+0x13e0a0f8ULL);m.put(level+1192,map);
 m.put(map,std::array<A,4>{Memory::root+0x9000,2,a,2});m.put(a,b);m.put(b,A(0));m.name(a+80,"Alice");m.name(b+80,"Moderator1");
 std::vector<std::string> names;auto before=m.bytes;
 assert(globalRoster(m,Memory::base,client,player,names)&&names.size()==2&&names[1]=="Moderator1"&&before==m.bytes); // staff can be far away, no Actor is needed
 assert(encodeRoster(names)=="416c696365;4d6f64657261746f7231");
 m.put(a,A(0));m.put(map+24,A(1));assert(globalRoster(m,Memory::base,client,player,names)&&names.size()==1); // actual roster removal
 m.put(a,b);m.put(map+24,A(2));m.put(b,a);assert(!levelRoster(m,Memory::base,level,"Alice",names));m.put(b,A(0));
 assert(!levelRoster(m,Memory::base,level,"OtherWorld",names));m.put(level,Memory::base+7);assert(!globalRoster(m,Memory::base,client,player,names));m.put(level,Memory::base+0x13e0a0f8ULL);
 m.change=true;assert(!levelRoster(m,Memory::base,level,"Alice",names));m.change=false;
 m.put(map+24,A(1025));assert(!levelRoster(m,Memory::base,level,"Alice",names));m.put(map+24,A(2));
 m.name(b+80,"");assert(!levelRoster(m,Memory::base,level,"Alice",names));
 std::cout<<"PASS: RTTI-bound global roster discovery, UUID-map names, far-away staff, roster removal, session membership, readonly/cycle/count/concurrency guards\n";
}
