package dev.custom.bedrockgui;

import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.function.Consumer;

/** Bounded, read-only structural probe. It never invokes game functions. */
public final class EngineMemoryProbe {
    public interface Reader { boolean read(long address, byte[] destination, int count) throws IOException; }
    public static final class Region {
        final long start, end, offset;final boolean readable, writable;final String path;
        public Region(long start, long end, long offset, boolean readable, boolean writable, String path) {
            this.start=start;this.end=end;this.offset=offset;this.readable=readable;this.writable=writable;this.path=path;
        }
        public static Region parse(String line) {
            String[] fields=line.trim().split("\\s+",6);
            if(fields.length<5)throw new IllegalArgumentException("Invalid maps entry");
            String[] range=fields[0].split("-",2);
            long start=Long.parseUnsignedLong(range[0],16),end=Long.parseUnsignedLong(range[1],16);
            if(start<0||end<=start)throw new IllegalArgumentException("Invalid maps range");
            return new Region(start,end,Long.parseUnsignedLong(fields[2],16),fields[1].charAt(0)=='r',
                    fields[1].charAt(1)=='w',fields.length==6?fields[5]:"");
        }
    }
    private static final class Type {
        final String name;final int bytes, toTop;
        Type(String name,int bytes,int toTop){this.name=name;this.bytes=bytes;this.toTop=toTop;}
    }
    private static final class Node {
        final long address;final Type type;
        Node(long address,Type type){this.address=address;this.type=type;}
    }
    public static final class Result {
        public final Map<String,Integer> candidates=new LinkedHashMap<>();
        public int reads, readFailures, links, verifiedPlayers;
        public boolean limited;
        public long verifiedClient;
        public String hand="Предмет в руке пока не определён.";
        public String summary(){return "Кандидаты объектов: "+candidates+". Чтений: "+reads+
                ", ошибок чтения: "+readFailures+". Проверенных связей с игроком: "+verifiedPlayers+
                (limited?". Достигнут лимит проверки.":".");}
    }
    private final List<Region> regions;
    private final Reader reader;
    private final Consumer<String> log;
    private final Map<Long,Type> types=new HashMap<>();
    private final Set<Long> visited=new HashSet<>(),objects=new HashSet<>();
    private final Map<Long,Node> recognized=new HashMap<>();
    private final ArrayDeque<Node> queue=new ArrayDeque<>();
    private final Result result=new Result();
    private long deadline;
    public EngineMemoryProbe(List<Region> regions,Reader reader,long base,Consumer<String> log) {
        this.regions=new ArrayList<>(regions);this.regions.sort(Comparator.comparingLong(r->r.start));
        this.reader=reader;this.log=log;
        type(base,0x1388fe70L,"ClientInstance",3648,0);
        type(base,0x13890c20L,"ClientInstance",3648,-24);
        type(base,0x13890c38L,"ClientInstance",3648,-32);
        type(base,0x13890c78L,"ClientInstance",3648,-96);
        type(base,0x13890ce0L,"ClientInstance",3648,-104);
        type(base,0x13890d18L,"ClientInstance",3648,-112);
        type(base,0x1389f8b8L,"MinecraftGame",7664,0);
        type(base,0x139f6ea0L,"LocalPlayer",4304,0);
        type(base,0x13d227d0L,"GameMode",16,0);
        type(base,0x13d22900L,"SurvivalMode",16,0);
        type(base,0x13d43520L,"PlayerInventory",8,0);
        type(base,0x13d42b08L,"Inventory",8,0);
        type(base,0x13d95ff8L,"ItemStack",8,0);
        type(base,0x13d9eb70L,"ExperiencePotionItem",8,0);
    }
    private void type(long base,long offset,String name,int size,int toTop){types.put(base+offset,new Type(name,size,toTop));}
    public static long untag(long value){return value&0x00ffffffffffffffL;}
    private Region containing(long address,int count) {
        int low=0,high=regions.size()-1;
        while(low<=high){int mid=(low+high)>>>1;Region r=regions.get(mid);
            if(address<r.start)high=mid-1;else if(address>=r.end)low=mid+1;
            else return r.readable&&count>=0&&count<=r.end-address?r:null;
        }
        return null;
    }
    private boolean read(long address,byte[] data,int size)throws IOException {
        if(result.reads>=20000||System.nanoTime()>deadline){result.limited=true;return false;}
        if(containing(address,size)==null)return false;
        result.reads++;
        try {if(reader.read(address,data,size))return true;}
        catch(IOException error){result.readFailures++;return false;}
        result.readFailures++;return false;
    }
    private Node inspect(long tagged)throws IOException {
        long address=untag(tagged);
        if(address==0||(address&7)!=0)return null;
        Node cached=recognized.get(address);if(cached!=null)return cached;
        Region region=containing(address,8);
        if(region==null||!region.writable)return null;
        if(!visited.add(address))return null;
        if(visited.size()>30000){result.limited=true;return null;}
        byte[] bytes=new byte[8];if(!read(address,bytes,8))return null;
        Type type=types.get(untag(ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).getLong()));
        if(type==null)return null;
        long object=address+type.toTop;
        if(object<=0||containing(object,8)==null)return null;
        if(objects.size()>=64&&!objects.contains(object)){result.limited=true;return null;}
        Node node=new Node(object,new Type(type.name,type.bytes,0));
        recognized.put(address,node);recognized.put(object,node);
        if(objects.size()<64&&objects.add(object)) {
            result.candidates.merge(type.name,1,Integer::sum);queue.add(node);
            log.accept("Candidate "+type.name+" at 0x"+Long.toHexString(object));
        }
        return node;
    }
    private void clientTree(Node game,byte[] snapshot)throws IOException {
        // This exact-build layout is supported by the allocation/insertion code
        // at 0x9cdd280..0x9cdd4d8: root +0x980, 72-byte nodes, key +32,
        // interface pointers +40/+48 and owning ClientInstance pointer +56.
        long root=untag(ByteBuffer.wrap(snapshot).order(ByteOrder.LITTLE_ENDIAN).getLong(0x980));
        log.accept("Client tree root at MinecraftGame+0x980: 0x"+Long.toHexString(root));
        if(root==0)return;
        ArrayDeque<Long> pending=new ArrayDeque<>();Set<Long> seen=new HashSet<>();pending.add(root);
        while(!pending.isEmpty()&&!result.limited){
            long address=pending.remove();if(address==0||!seen.add(address))continue;
            if(seen.size()>64){result.limited=true;break;}
            Region mapping=containing(address,72);if(mapping==null||!mapping.writable)continue;
            byte[] data=new byte[72];if(!read(address,data,data.length))continue;
            if((data[24]&255)>1){log.accept("Client tree node rejected: invalid color");continue;}
            ByteBuffer values=ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
            boolean valid=false;
            for(int offset:new int[]{40,48,56}){
                long pointer=values.getLong(offset);Node client=inspect(pointer);
                if(client!=null&&client.type.name.equals("ClientInstance")){
                    valid=true;
                    if(result.links<96){result.links++;log.accept("Client tree key="+(data[32]&255)+
                            " node+"+offset+" -> ClientInstance at 0x"+Long.toHexString(client.address));}
                }
            }
            if(!valid){log.accept("Client tree node rejected: no matching ClientInstance vptr");continue;}
            long left=untag(values.getLong(0)),right=untag(values.getLong(8));
            if(left!=0)pending.add(left);if(right!=0)pending.add(right);
        }
    }
    private ByteBuffer values(long address,int size)throws IOException {
        byte[] bytes=new byte[size];
        return read(address,bytes,size)?ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN):null;
    }
    private long pointer(long address)throws IOException {
        ByteBuffer bytes=values(address,8);return bytes==null?0:untag(bytes.getLong());
    }
    private long vectorCount(long begin,long end,int stride,int maximum) {
        if(begin==0||(begin&7)!=0||end<begin||(end-begin)%stride!=0)return -1;
        long count=(end-begin)/stride;
        return count<=maximum&&containing(begin,(int)(end-begin))!=null?count:-1;
    }
    /** Exact-build sparse-set generation check; never accepts a reused entity index. */
    private long sparseIndex(long pagesAddress,long entity)throws IOException {
        ByteBuffer vector=values(pagesAddress,16);if(vector==null)return -1;
        long begin=untag(vector.getLong()),end=untag(vector.getLong());
        long count=vectorCount(begin,end,8,128),pageIndex=(entity>>>11)&127;
        if(count<=pageIndex)return -1;
        long page=pointer(begin+pageIndex*8);if(page==0)return -1;
        ByteBuffer entry=values(page+(entity&0x7ff)*4,4);if(entry==null)return -1;
        long packed=Integer.toUnsignedLong(entry.getInt());
        if((packed^(entity&0xfffc0000L))>0x3fffeL)return -1;
        return packed&0x3ffffL;
    }
    private long componentPool(long registry,long key)throws IOException {
        // EntityContext stores registry+40. Its hash map has bucket begin/end
        // at +56/+64 and 32-byte node begin/end at +80/+88.
        ByteBuffer header=values(registry+96,40);if(header==null)return 0;
        long buckets=untag(header.getLong(0)),bucketEnd=untag(header.getLong(8));
        long nodes=untag(header.getLong(24)),nodeEnd=untag(header.getLong(32));
        long bucketCount=vectorCount(buckets,bucketEnd,8,4096);
        long nodeCount=vectorCount(nodes,nodeEnd,32,4096);
        if(bucketCount<=0||(bucketCount&(bucketCount-1))!=0||nodeCount<=0)return 0;
        ByteBuffer first=values(buckets+(key&(bucketCount-1))*8,8);if(first==null)return 0;
        long index=first.getLong();Set<Long> seen=new HashSet<>();
        while(index!=-1&&!result.limited){
            if(index<0||index>=nodeCount||!seen.add(index)||seen.size()>64)return 0;
            ByteBuffer node=values(nodes+index*32,32);if(node==null)return 0;
            if(Integer.toUnsignedLong(node.getInt(8))==key){
                long pool=untag(node.getLong(16));Region region=containing(pool,88);
                return region!=null&&region.writable?pool:0;
            }
            index=node.getLong(0);
        }
        return 0;
    }
    private void entityPlayer(Node client,byte[] snapshot)throws IOException {
        // Client virtual slot 31 at 0x9b7f610 resolves the weak entity at +576.
        // 0x1346904c validates its generation; 0xaf67fb0 requires component
        // 0xacb47b38; 0xfdb3b58 obtains the Actor pointer from 0x85b93800.
        ByteBuffer weak=ByteBuffer.wrap(snapshot).order(ByteOrder.LITTLE_ENDIAN);
        long registry=untag(weak.getLong(576)),control=untag(weak.getLong(584));
        long entity=Integer.toUnsignedLong(weak.getInt(592));
        log.accept("Entity reference: registry=0x"+Long.toHexString(registry)+
                " id=0x"+Long.toHexString(entity));
        if(registry==0||control==0||(entity&0x3ffff)==0x3ffff){
            log.accept("Player binding: no active entity reference");return;
        }
        long index=sparseIndex(registry+216,entity);
        ByteBuffer count=values(registry+280,8);
        if(index<0||count==null||index>=count.getLong()){
            log.accept("Player binding: registry generation is not current");return;
        }
        long marker=componentPool(registry,0xacb47b38L);
        if(marker==0||sparseIndex(marker+8,entity)<0){
            log.accept("Player binding: local-player component not found");return;
        }
        long owner=componentPool(registry,0x85b93800L);
        long packed=owner==0?-1:sparseIndex(owner+8,entity);
        if(packed<0){log.accept("Player binding: actor component not found");return;}
        long payloads=pointer(owner+80);
        long page=payloads==0?0:pointer(payloads+(packed>>>7)*8);
        long address=page==0?0:pointer(page+(packed&127)*8);
        if(address==0){log.accept("Player binding: actor payload is empty");return;}
        Type type=types.get(pointer(address));
        if(type==null||!type.name.equals("LocalPlayer")||type.toTop!=0){
            log.accept("Player binding: payload is not a matching LocalPlayer");return;
        }
        // The exact LocalPlayer constructor stores its client at +3240.
        if(pointer(address+3240)!=client.address){
            log.accept("Player binding: client back-reference does not match");return;
        }
        ByteBuffer current=values(client.address+576,24);
        if(current==null||current.getLong(0)!=weak.getLong(576)||
                current.getLong(8)!=weak.getLong(584)||current.getInt(16)!=weak.getInt(592)||
                sparseIndex(registry+216,entity)!=index||sparseIndex(owner+8,entity)!=packed){
            log.accept("Player binding: entity changed during the probe; retry in world");return;
        }
        Node player=inspect(address);
        if(player!=null){
            result.verifiedPlayers++;result.verifiedClient=client.address;
            log.accept("Player binding verified: ClientInstance -> entity registry -> LocalPlayer at 0x"+
                    Long.toHexString(address)+"; matching client back-reference");
            heldItem(client,player,weak);
        }
    }
    private void heldItem(Node client,Node player,ByteBuffer entity)throws IOException {
        // Player getter 0x10202190: inventory +1424, selected slot +16,
        // suspended flag +176, container +184. Container slot 8 (0x10084910)
        // indexes 152-byte ItemStacks in the vector at +320/+328.
        long proxy=pointer(player.address+1424);
        Type proxyType=types.get(pointer(proxy));
        if(proxyType==null||!proxyType.name.equals("PlayerInventory"))return;
        ByteBuffer state=values(proxy,192);if(state==null)return;
        int slot=state.getInt(16);
        if(slot<0||slot>8||state.get(176)!=0)return;
        long inventory=untag(state.getLong(184));Type inventoryType=types.get(pointer(inventory));
        if(inventoryType==null||!inventoryType.name.equals("Inventory"))return;
        ByteBuffer vector=values(inventory+320,16);if(vector==null)return;
        long begin=untag(vector.getLong(0)),end=untag(vector.getLong(8));
        long count=vectorCount(begin,end,152,256);if(count<9||slot>=count)return;
        long stack=begin+slot*152;ByteBuffer item=values(stack,40);if(item==null)return;
        Type stackType=types.get(untag(item.getLong(0)));
        if(stackType==null||!stackType.name.equals("ItemStack"))return;
        int amount=item.get(34)&255;
        // ItemStack's weak item handle is followed by its native code at
        // 0x10770e0c..0x10770e18: stack+8 -> handle -> Item.
        long handle=untag(item.getLong(8)),object=handle==0?0:pointer(handle);
        if(amount>0&&object==0)return;
        Type itemType=object==0?null:types.get(pointer(object));
        ByteBuffer current=values(proxy,192),currentVector=values(inventory+320,16),currentItem=values(stack,40);
        ByteBuffer currentEntity=values(client.address+576,24);
        if(current==null||currentVector==null||currentItem==null||
                currentEntity==null||currentEntity.getLong(0)!=entity.getLong(576)||
                currentEntity.getLong(8)!=entity.getLong(584)||currentEntity.getInt(16)!=entity.getInt(592)||
                pointer(player.address+1424)!=proxy||pointer(player.address+3240)!=client.address||
                current.getInt(16)!=slot||current.get(176)!=0||current.getLong(184)!=state.getLong(184)||
                !Arrays.equals(vector.array(),currentVector.array())||!Arrays.equals(item.array(),currentItem.array())||
                (handle!=0&&pointer(handle)!=object)){
            log.accept("Held item: snapshot changed; retry");return;
        }
        String name=amount==0||object==0?"пусто":
                itemType!=null&&itemType.name.equals("ExperiencePotionItem")?"пузырьки опыта ×"+amount:
                "другой предмет ×"+amount+" (название пока не определяется)";
        result.hand="Слот "+(slot+1)+". В руке: "+name+".";
        log.accept("Held item: slot="+slot+" count="+amount+" stack=0x"+Long.toHexString(stack)+
                " item=0x"+Long.toHexString(object)+" type="+(itemType==null?"unknown":itemType.name));
        log.accept(result.hand);
    }
    public Result scan(long start,long end)throws IOException {
        if(end<start||end-start>4*1024*1024L)throw new IllegalArgumentException("Probe range exceeds 4 MiB");
        deadline=System.nanoTime()+4_000_000_000L;
        byte[] buffer=new byte[4096];
        for(long at=start;at<end&&!result.limited;){
            int count=(int)Math.min(buffer.length,end-at);
            if(read(at,buffer,count)){
                ByteBuffer values=ByteBuffer.wrap(buffer,0,count).order(ByteOrder.LITTLE_ENDIAN);
                while(values.remaining()>=8&&!result.limited)inspect(values.getLong());
            }
            at+=count;
        }
        while(!queue.isEmpty()&&!result.limited){
            Node node=queue.remove();byte[] bytes=new byte[node.type.bytes];
            if(!read(node.address,bytes,bytes.length))continue;
            if(node.type.name.equals("MinecraftGame"))clientTree(node,bytes);
            if(node.type.name.equals("ClientInstance"))entityPlayer(node,bytes);
            ByteBuffer values=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
            while(values.remaining()>=8&&!result.limited){
                int offset=values.position();Node child=inspect(values.getLong());
                if(child!=null&&result.links<96){result.links++;
                    log.accept("Link "+node.type.name+"+0x"+Integer.toHexString(offset)+" -> "+child.type.name+
                            " at 0x"+Long.toHexString(child.address));}
            }
        }
        log.accept(result.summary());return result;
    }
}
