#pragma once
#include <string>
#include <set>
namespace kulich_aim {
// Compare the verified raw Player name, never a substring of a decorated tag.
inline std::string friendKey(const char* name){
 if(!name)return {};
 std::string key;
 for(const unsigned char* p=reinterpret_cast<const unsigned char*>(name);*p;p++){
  unsigned char c=*p;if(key.size()>=16)return {};
  if(c>='A'&&c<='Z')c=static_cast<unsigned char>(c-'A'+'a');
  if(!((c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'))return {};
  key.push_back(static_cast<char>(c));
 }
 return key;
}
class FriendPolicy {
 std::set<std::string> names;
public:
 enum Decision{Enemy,Friend,Unknown};
 bool replace(const std::string& encoded){
  if(encoded.size()>2176)return false;
  std::set<std::string> next;size_t start=0;
  while(start<encoded.size()){
   size_t end=encoded.find('\n',start);if(end==std::string::npos)end=encoded.size();
   std::string row=encoded.substr(start,end-start),key=friendKey(row.c_str());
   if(row.find('\0')!=std::string::npos||key.empty()||next.size()>=128)return false;
   next.insert(key);start=end+1;
  }
  names.swap(next);return true;
 }
 bool empty()const{return names.empty();}
 size_t size()const{return names.size();}
 Decision check(const char* rawName)const{
  if(names.empty())return Enemy;
  std::string key=friendKey(rawName);if(key.empty())return Unknown;
  return names.count(key)?Friend:Enemy;
 }
};
}
