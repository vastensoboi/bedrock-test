#pragma once
#include "world_collision_core.h"
#include <array>

// Exact supplied 1.26.60.4 ARM64 image. Query only on the game thread after
// the caller has validated its live local player and dimension/BlockSource.
namespace kulich_block_query {
using A=uint64_t;
using kulich_world_collision::plain;
constexpr A GET_BLOCK=0x10371248ULL,BLOCK_TABLE=0x13dfc0a8ULL,AIR_TABLE=0x13dfda38ULL;
// Conservative exact-type list for ordinary, noninteractive cube supports.
// Unknown types (including containers, slabs, plants and fluids) are skipped.
constexpr std::array<A,12> INERT_TABLES{{0x13e4f530ULL,0x13ddec18ULL,0x13db7a28ULL,
 0x13ddb3a0ULL,0x13dcd2e8ULL,0x13dfa648ULL,0x13dbe6f8ULL,0x13db9cc0ULL,
 0x13dbcd00ULL,0x13db6928ULL,0x13dda660ULL,0x13dde398ULL}};
struct Position {int32_t x=0,y=0,z=0;};
static_assert(sizeof(Position)==12,"Native BlockPos ABI");
enum class Result {Unavailable,Air,Block};
struct Cell {A block=0,type=0;Result result=Result::Unavailable;};
template<class Read>A rawPointer(Read& read,A at){A value=0;return read(plain(at),&value,sizeof value)?value:0;}
inline bool valid(Position p){return p.x>=-32000000&&p.x<=32000000&&p.y>=-32000000&&p.y<=32000000&&p.z>=-32000000&&p.z<=32000000;}
struct Profile {A offset;uint32_t words[8];};
constexpr Profile profiles[]={
 {GET_BLOCK,{0xd10103ffU,0xa9017bfdU,0xa90257f6U,0xa9034ff4U,0x910043fdU,0xd53bd056U,0xf94016c8U,0xf90007e8U}},
 {0x109f3fd4ULL,{0xf9403400U,0xf9400008U,0xf9405501U,0xd61f0020U,0x9101e000U,0x1411fcdbU,0x9101e000U,0x1411fcdbU}},
 {0x10a1115cULL,{0xa9be7bfdU,0xf9000bf3U,0x910003fdU,0xaa0003f3U,0x97fc3f88U,0x90019f68U,0x9128e108U,0xaa1303e0U}}
};
template<class Read>bool profile(Read& read,A base){
 if(!base)return false;
 for(const auto& p:profiles){uint32_t code[8]{};if(!read(base+p.offset,code,sizeof code)||std::memcmp(code,p.words,sizeof code))return false;}
 return true;
}
template<class Read>bool source(Read& read,A base,A taggedSource,Position p){
 if(!valid(p)||!kulich_world_collision::sourceBinding(read,base,taggedSource))return false;
 A table=plain(rawPointer(read,taggedSource));int16_t maximum=0,minimum=0;
 return plain(rawPointer(read,table+16))==base+GET_BLOCK&&
  read(plain(taggedSource)+64,&maximum,sizeof maximum)&&read(plain(taggedSource)+66,&minimum,sizeof minimum)&&
  minimum<maximum&&p.y>=minimum&&p.y<maximum;
}
// getBlock returns a Block state. Its native wrapper at109f3fd4 accesses the
// polymorphic BlockType at+104. AirBlock derives BlockType (RTTI9BlockType),
// and constructor10a1115c stores primaryvptr13dfda38. Do not infer that every
// non-air block is a solid support: water/plants still need engine validation.
template<class Read>Result inspect(Read& read,A base,A taggedBlock,Cell& out){
 out={};A block=plain(taggedBlock);
 if(block<4096||plain(rawPointer(read,block))!=base+BLOCK_TABLE)return Result::Unavailable;
 A type=rawPointer(read,block+104),table=plain(rawPointer(read,type));
 if(plain(type)<4096||table<base+0x13600000ULL||table>=base+0x14700000ULL)return Result::Unavailable;
 if(rawPointer(read,block+104)!=type||plain(rawPointer(read,block))!=base+BLOCK_TABLE)return Result::Unavailable;
 Result value=table==base+AIR_TABLE?Result::Air:Result::Block;
 out={taggedBlock,type,value};return value;
}
template<class Read>bool inertSupport(Read& read,A base,const Cell& cell){
 if(cell.result!=Result::Block||plain(cell.block)<4096||plain(cell.type)<4096||
    plain(rawPointer(read,cell.block))!=base+BLOCK_TABLE||rawPointer(read,plain(cell.block)+104)!=cell.type)return false;
 A table=plain(rawPointer(read,cell.type));
 for(A supported:INERT_TABLES)if(table==base+supported)return true;
 return false;
}
template<class Read>Result query(Read& read,A base,A taggedSource,Position p,Cell& out){
 out={};if(!source(read,base,taggedSource,p))return Result::Unavailable;
#if defined(__aarch64__)
 using GetBlock=A(*)(void*,const Position*);
 A block=reinterpret_cast<GetBlock>(base+GET_BLOCK)(reinterpret_cast<void*>(taggedSource),&p);
 if(!source(read,base,taggedSource,p))return Result::Unavailable;
 return inspect(read,base,block,out);
#else
 return Result::Unavailable;
#endif
}
}
