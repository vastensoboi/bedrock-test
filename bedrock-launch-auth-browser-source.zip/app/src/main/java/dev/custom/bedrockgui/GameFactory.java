package dev.custom.bedrockgui;

import android.app.*;
import android.content.Intent;
import java.io.*;

public final class GameFactory extends AppComponentFactory {
    @Override public Activity instantiateActivity(ClassLoader cl,String name,Intent intent)
            throws InstantiationException,IllegalAccessException,ClassNotFoundException {
        boolean browser=name.equals(GameRuntime.AUTH_BROWSER);
        if(!name.equals(GameRuntime.ACTIVITY)&&!browser)return super.instantiateActivity(cl,name,intent);
        try {
            if(browser){
                if(GameRuntime.loader==null)throw new IllegalStateException("Game process was restarted; launch the game and retry sign-in");
                GameRuntime.log("Auth: instantiate XAL BrowserLaunchActivity with game loader");
            }else{
                GameRuntime.prepare(intent,cl);
                GameRuntime.log("Factory: instantiate game Activity");
            }
            return super.instantiateActivity(GameRuntime.loader,name,intent);
        }catch(Exception|LinkageError error) {
            StringWriter trace=new StringWriter();error.printStackTrace(new PrintWriter(trace));
            GameRuntime.log("JAVA FAILURE\n"+trace);
            // No Context access on the returned Activity until Android attaches it.
            return super.instantiateActivity(cl,"dev.custom.bedrockgui.LaunchFailureActivity",intent);
        }
    }
}
