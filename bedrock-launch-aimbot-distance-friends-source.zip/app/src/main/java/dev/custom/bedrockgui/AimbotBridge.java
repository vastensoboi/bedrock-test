package dev.custom.bedrockgui;
/** Sharp aim with independent acquisition and attack distances, in tenths of a block. */
public final class AimbotBridge {
 private static volatile boolean ready,enabled;private static int aimTenths=30,attackTenths=30,cpsMin=15,cpsMax=15;
 private static String friendNames="";private static volatile int confirmedFriends=-1;
 private AimbotBridge(){}
 private static native int friends(String names);
 private static void applyFriends(){int count=friends(friendNames);int expected=friendNames.isEmpty()?0:friendNames.split("\\n").length;if(count!=expected){confirmedFriends=-1;throw new IllegalStateException("Native не подтвердил список друзей");}confirmedFriends=count;}
 public static String friendProtectionStatus(){return ready&&confirmedFriends>=0?"Защита автоударов активна: "+confirmedFriends+" друзей":"Список сохранён. Защита подключится при включении Aimbot в мире.";}
 public static synchronized void setFriends(String names){friendNames=names==null?"":names;if(ready)try{applyFriends();}catch(RuntimeException|LinkageError error){enabled=false;ready=false;confirmedFriends=-1;try{enable(false);pulse(false);}catch(RuntimeException|LinkageError ignored){}throw new IllegalStateException("Защита друзей не обновилась; Aimbot выключен",error);}}
 private static native String install(long base,long client);
 private static native void enable(boolean value);
 private static native void configure(int aimTenths,int attackTenths,int cpsMin,int cpsMax);
 private static native void pulse(boolean value);
 private static native String status();private static native String hudSnapshot();
 public static synchronized void prepare(long base,long client){try{if(!FastExpBridge.isReady())return;String error=install(base,client);if(!error.isEmpty())throw new IllegalStateException(error);configure(aimTenths,attackTenths,cpsMin,cpsMax);applyFriends();ready=true;GameRuntime.log("Aimbot: sharp aim and attack bridge prepared");}catch(RuntimeException|LinkageError e){ready=false;GameRuntime.log("Aimbot unavailable: "+e);}}
 public static boolean isReady(){return ready;}
 public static synchronized void setEnabled(boolean value){if(value&&!ready)throw new IllegalStateException("Нужен загруженный мир");if(ready){enable(value);pulse(value);}enabled=value;GameRuntime.log("Aimbot: enabled="+value);}
 public static synchronized void settings(int aimDistance,int attackDistance,int minimum,int maximum){aimTenths=Math.max(10,Math.min(60,aimDistance));attackTenths=Math.max(10,Math.min(aimTenths,attackDistance));cpsMin=Math.max(1,Math.min(40,minimum));cpsMax=Math.max(cpsMin,Math.min(40,maximum));if(ready)configure(aimTenths,attackTenths,cpsMin,cpsMax);}
 public static int cpsMin(){return cpsMin;}public static int cpsMax(){return cpsMax;}public static int cps(){return cpsMax;}
 public static void heartbeat(){if(ready)pulse(enabled);}
 public static String targetSnapshot(){return ready?hudSnapshot():"";}
 private static String distance(int tenths){return String.format(java.util.Locale.ROOT,"%.1f",tenths/10.0);}
 public static String describe(){if(!ready)return "Подключение к миру ещё не готово";return (enabled?"Наведение "+distance(aimTenths)+" · Удар "+distance(attackTenths)+" блоков · "+(cpsMin==cpsMax?Integer.toString(cpsMin):cpsMin+"–"+cpsMax)+" CPS":"Выключен")+"\n"+status();}
}
