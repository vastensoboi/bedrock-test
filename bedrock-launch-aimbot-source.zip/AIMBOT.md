# Aimbot · 0.51

1. Собери исходники через Build latest launch test и установи BedrockLaunchTest-0.51.
2. Войди в мир, где рядом есть другой игрок. Открой kulich → Таргет → Aimbot.
3. Выбери «Голова» или «Тело», радиус (по умолчанию 6 блоков) и включи модуль.
4. Поверни камеру: при найденной цели модуль должен возвращать её к выбранной
   точке и следовать за движением игрока. Переключи голову/тело для проверки.
5. Выключи модуль — камера должна сразу снова управляться вручную. Если нет
   наведения или возник вылет, сохрани журнал kulich 0.51.

Меню можно держать открытым; модуль сохраняет состояние при другом окне.
Если Android/Minecraft останавливает саму игру, наведение ждёт её обновлений.
При выключении и закрытии игрового процесса наведение прекращается.

Первая версия выбирает ближайшего RemotePlayer по расстоянию и удерживает
именно его, даже если другой игрок подошёл ближе. При исчезновении/смене мира
или выходе из радиуса ищется новая цель. Мобы не выбираются. Фильтра друзей,
команд и проверки стены пока нет. Камера и голова поворачиваются явно; ударов
и отдельной подмены поворота в пакетах нет. Реальная работа на телефоне ещё
не подтверждена: локальные тесты не заменяют эту проверку.

## Exact-build layout evidence

The existing GameEngineProbe verifies SHA-256
4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4.

- RemotePlayer RTTI primary vptr is 0x139f76b0; constructors store it at
  0xaf694a8/0xaf694ac and 0xaf699d4/0xaf699d8. LocalPlayer remains 0x139f6ea0.
- Actor EntityContext is registry at +8, registry+40 at +16, 32-bit entity at +24.
  ActorOwnerComponent FNV-1a key 0x85b93800 is already established by player lookup.
  Actor removed flag +617 is checked by native resolver 0xfdb3c24..0xfdb3c38.
- Registry buckets/nodes and sparse generation scheme are the same as the
  existing player probe: map header +96/+104/+120/+128, 32-byte nodes;
  root entity sparse pages +216. Component sparse pages begin at storage+8,
  payload-page vector at +80/+88/+96; 128 payloads per page. Owner payload size 8.
- Component hashes are FNV-1a of their names. ActorRotationComponent = 0x75df36b7,
  AABBShapeComponent = 0xbac1b3cf, ActorHeadRotationComponent = 0xbabe7211.
  Rotation data is 16 bytes (current and previous Vec2), shape is 32 bytes
  (min/max Vec3, width/height), head is 8 bytes (current/previous yaw).
- Actor +552 is position, +560 shape and +568 rotation. Position getter
  0xfd8e62c loads current XYZ; shape getter 0xfd9b14c loads width at +24;
  yaw getter 0xfdaf960 reads rotation+4. Component addresses must match the
  local/remote cached shape and local cached rotation before gameplay use.
- Actor setRot 0xfd8f694 loads two floats from x1 and writes current rotation;
  setYHeadRot 0xfdafa3c resolves hash 0xbabe7211 and writes s0 to current yaw.
  Both signatures and the first eight instructions are pinned in aim_profile.h.
  Original MTE-tagged local this pointer is retained for native calls.

Native acquisition is bounded to 4096 owner entries and a five-millisecond/read
budget. Targets are revalidated immediately before native calls; stale entity
indices/pointers never authorize rotation. Journal records binding rejection,
scanned entries, target ID, angle values and applied-call count. An applied call
count proves native dispatch; actual camera behaviour still requires device
observation. There is no raw memory-write backend or arbitrary target setter API.
