package dev.custom.bedrockgui;

import java.util.*;

/** Pure monotonic effect timer. Payload: captureAgeMs|id,amplifier,remainingTicks;... */
public final class BuffTimerModel {
    public static final long FRESH_MS=3000;
    private static final String[] NAMES={"", "Скорость","Замедление","Спешка","Усталость","Сила","Мгновенное лечение","Мгновенный урон","Прыгучесть","Тошнота","Регенерация","Сопротивление","Огнестойкость","Подводное дыхание","Невидимость","Слепота","Ночное зрение","Голод","Слабость","Отравление","Иссушение","Прилив здоровья","Поглощение","Насыщение","Левитация","Смертельный яд","Сила проводника","Плавное падение","Дурное знамение","Герой деревни","Тьма","Зловещее знамение","Знамение рейда","Заряд ветра","Плетение","Слизистость","Заражение"};
    private static final String[] ROMAN={"","I","II","III","IV","V","VI","VII","VIII","IX","X"};
    private static final class Effect {final int id,amplifier,ticks;Effect(int id,int amplifier,int ticks){this.id=id;this.amplifier=amplifier;this.ticks=ticks;}}
    private List<Effect> effects=Collections.emptyList();
    private long capturedAt=-1;
    private boolean available;
    public void update(String snapshot,long nowMs){
        available=false;effects=Collections.emptyList();capturedAt=-1;
        if(snapshot==null||snapshot.length()>4096||nowMs<0)return;
        try{
            String[] parts=snapshot.split("\\|",-1);if(parts.length!=2)return;
            long age=Long.parseLong(parts[0]);if(age<0||age>FRESH_MS||age>nowMs)return;
            TreeMap<Integer,Effect> parsed=new TreeMap<>();
            if(!parts[1].isEmpty()){
                String[] rows=parts[1].split(";",-1);if(rows.length>64)return;
                for(String row:rows){
                    String[] values=row.split(",",-1);if(values.length!=3)return;
                    int id=Integer.parseInt(values[0]),amplifier=Integer.parseInt(values[1]),ticks=Integer.parseInt(values[2]);
                    if(id<1||id>255||amplifier<0||amplifier>255||ticks< -1||parsed.containsKey(id))return;
                    parsed.put(id,new Effect(id,amplifier,ticks));
                }
            }
            effects=new ArrayList<>(parsed.values());capturedAt=nowMs-age;available=true;
        }catch(RuntimeException ignored){}
    }
    public boolean fresh(long nowMs){return available&&nowMs>=capturedAt&&nowMs-capturedAt<=FRESH_MS;}
    public List<String> lines(long nowMs){
        if(!fresh(nowMs))return Collections.singletonList("Эффекты недоступны");
        long elapsedTicks=(nowMs-capturedAt)/50;
        ArrayList<String> result=new ArrayList<>();
        for(Effect effect:effects){
            long remaining=effect.ticks== -1? -1:Math.max(0,effect.ticks-elapsedTicks);
            if(remaining==0)continue;
            int level=effect.amplifier+1;String strength=level<ROMAN.length?ROMAN[level]:Integer.toString(level);
            String name=effect.id<NAMES.length?NAMES[effect.id]:"Эффект №"+effect.id;
            result.add(name+" "+strength+"\t"+(remaining<0?"∞":duration(remaining)));
        }
        if(result.isEmpty())result.add("Нет активных эффектов");
        return Collections.unmodifiableList(result);
    }
    private static String duration(long ticks){
        long seconds=(ticks+19)/20;
        if(seconds>=3600)return String.format(Locale.ROOT,"%d:%02d:%02d",seconds/3600,seconds/60%60,seconds%60);
        return String.format(Locale.ROOT,"%d:%02d",seconds/60,seconds%60);
    }
}
