#include "../app/src/main/cpp/static_items_core.h"
#include <cassert>
#include <iostream>
#include <vector>
using namespace kulich_static_items;

struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;
 std::vector<uint8_t> bytes=std::vector<uint8_t>(0x60000);
 A next=root+0x10000;
 template<class T>void put(A address,T value){
  address=plain(address);assert(address>=root&&address-root+sizeof value<=bytes.size());
  std::memcpy(bytes.data()+address-root,&value,sizeof value);
 }
 A alloc(size_t size){A result=next;next=(next+size+7)&~A(7);assert(next-root<bytes.size());return result;}
 bool operator()(A address,void* out,size_t size){
  address=plain(address);
  if(address<root||address-root>bytes.size()||size>bytes.size()-(address-root))return false;
  std::memcpy(out,bytes.data()+address-root,size);return true;
 }
 uint8_t byte(A address){uint8_t value=255;assert((*this)(address,&value,1));return value;}
};
struct Fixture {
 static constexpr A base=0x10000000,client=Memory::root+0x1000,registry=Memory::root+0x3000,
  local=Memory::root+0x5000,item=Memory::root+0x8000,renderer=Memory::root+0xb000,data=Memory::root+0xc000;
 static constexpr uint32_t localId=0x40001,itemId=0x40002;
 Memory m;A owners=0,ownerPayload=0,entitySparse=0,ownerSparse=0;int calls=0,writes=0;bool failWrite=false;
 Fixture(){
  owners=m.alloc(104);A sparseVector=m.alloc(8);ownerSparse=m.alloc(8192);A payloadVector=m.alloc(8);ownerPayload=m.alloc(128*8);
  std::fill(m.bytes.begin()+ownerSparse-Memory::root,m.bytes.begin()+ownerSparse-Memory::root+8192,255);
  m.put(owners+8,sparseVector);m.put(owners+16,sparseVector+8);m.put(sparseVector,ownerSparse);
  m.put(ownerSparse+(localId&2047)*4,localId&0xfffc0000U);
  m.put(ownerSparse+(itemId&2047)*4,(itemId&0xfffc0000U)|1);
  m.put(owners+80,payloadVector);m.put(owners+88,payloadVector+8);m.put(owners+96,payloadVector+8);m.put(payloadVector,ownerPayload|Memory::tag);
  m.put(ownerPayload,local|Memory::tag);m.put(ownerPayload+8,item|Memory::tag);
  A buckets=m.alloc(64),nodes=m.alloc(32);for(int i=0;i<8;i++)m.put<int64_t>(buckets+i*8,-1);
  m.put<int64_t>(buckets+(OWNER&7)*8,0);m.put<int64_t>(nodes,-1);m.put(nodes+8,OWNER);m.put(nodes+16,owners);
  m.put(registry+96,buckets);m.put(registry+104,buckets+64);m.put(registry+120,nodes);m.put(registry+128,nodes+32);
  A entityPages=m.alloc(8);entitySparse=m.alloc(8192);
  std::fill(m.bytes.begin()+entitySparse-Memory::root,m.bytes.begin()+entitySparse-Memory::root+8192,255);
  m.put(registry+216,entityPages);m.put(registry+224,entityPages+8);m.put(entityPages,entitySparse);
  m.put(entitySparse+(localId&2047)*4,localId&0xfffc0000U);m.put(entitySparse+(itemId&2047)*4,(itemId&0xfffc0000U)|1);
  m.put(client,base+0x1388fe70ULL);m.put(client+576,std::array<A,3>{registry,Memory::root+0xd000,localId});
  m.put(local,std::array<A,4>{base+0x139f6ea0ULL,registry,registry+40,localId});m.put(local+3240,client);
  m.put(item,std::array<A,4>{base+ITEM_ACTOR_TABLE,registry,registry+40,itemId});
  m.put(renderer,base+RENDERER_TABLE);m.put(data,item|Memory::tag);
 }
 bool lookup(Binding& b){return resolve(m,base,client,renderer,data,b);}
 bool write(A address,uint8_t value){
  assert(address==(item|Memory::tag)+PRESENTATION_FLAG);assert(value<=1);
  if(failWrite)return false;
  writes++;m.put(address,value);return true;
 }
 template<class Original> bool invokeWith(Original original,bool enabled=true){
  auto writeValue=[&](A at,uint8_t value){return write(at,value);};
  auto find=[&](Binding& b){return lookup(b);};
  return invoke(writeValue,find,original,enabled);
 }
};

int main(){
 Fixture f;Binding binding{};
 assert(f.lookup(binding));assert(binding.actor==(Fixture::item|Memory::tag));
 assert(binding.flag==(Fixture::item|Memory::tag)+PRESENTATION_FLAG&&binding.entity==Fixture::itemId);
 // Only one presentation byte changes; actor age/position/velocity/pickup,
 // entity ownership and all other world memory stay byte-for-byte intact.
 auto before=f.m.bytes;
 assert(f.invokeWith([&](){f.calls++;assert(f.m.byte(binding.flag)==1);}));
 assert(f.calls==1&&f.writes==2&&before==f.m.bytes&&f.m.byte(binding.flag)==0);
 f.writes=0;
 assert(!f.invokeWith([&](){f.calls++;assert(f.m.byte(binding.flag)==0);},false));
 assert(f.calls==2&&f.writes==0&&before==f.m.bytes);
 f.m.put<uint8_t>(binding.flag,1);
 assert(!f.invokeWith([&](){f.calls++;assert(f.m.byte(binding.flag)==1);}));
 assert(f.calls==3&&f.writes==0&&f.m.byte(binding.flag)==1);
 f.m.put<uint8_t>(binding.flag,0);f.failWrite=true;
 assert(!f.invokeWith([&](){f.calls++;assert(f.m.byte(binding.flag)==0);}));
 assert(f.calls==4&&f.writes==0);f.failWrite=false;
 bool caught=false;
 try{f.invokeWith([&](){f.calls++;assert(f.m.byte(binding.flag)==1);throw 17;});}catch(int value){caught=value==17;}
 assert(caught&&f.calls==5&&f.m.byte(binding.flag)==0);
 // The engine changing the byte owns the new value; restore must not replay
 // our saved flag over it. Changing bindings/generations likewise forbids writes.
 f.writes=0;
 assert(f.invokeWith([&](){f.calls++;f.m.put<uint8_t>(binding.flag,0);}));
 assert(f.calls==6&&f.writes==1&&f.m.byte(binding.flag)==0);
 f.writes=0;
 assert(f.invokeWith([&](){f.m.put<uint8_t>(binding.flag,2);}));
 assert(f.writes==1&&f.m.byte(binding.flag)==2);f.m.put<uint8_t>(binding.flag,0);
 f.writes=0;
 assert(f.invokeWith([&](){f.m.put(Fixture::data,Fixture::item);})); // same plain address, different MTE tag
 assert(f.writes==1&&f.m.byte(binding.flag)==1);f.m.put(Fixture::data,Fixture::item|Memory::tag);f.m.put<uint8_t>(binding.flag,0);
 f.writes=0;
 assert(f.invokeWith([&](){f.m.put(f.entitySparse+(Fixture::itemId&2047)*4,uint32_t(0x80001));}));
 assert(f.writes==1&&f.m.byte(binding.flag)==1);f.m.put(f.entitySparse+(Fixture::itemId&2047)*4,(Fixture::itemId&0xfffc0000U)|1);f.m.put<uint8_t>(binding.flag,0);
 auto rejected=[&](){int calls=0,writes=f.writes;assert(!f.lookup(binding));assert(!f.invokeWith([&](){calls++;}));assert(calls==1&&f.writes==writes);};
 f.m.put(Fixture::renderer,Fixture::base+RENDERER_TABLE+8);rejected();f.m.put(Fixture::renderer,Fixture::base+RENDERER_TABLE);
 f.m.put(Fixture::item,Fixture::base+0x139f76b0ULL);rejected();f.m.put(Fixture::item,Fixture::base+ITEM_ACTOR_TABLE);
 f.m.put(Fixture::item+8,Fixture::registry+8);rejected();f.m.put(Fixture::item+8,Fixture::registry);
 f.m.put(Fixture::item+16,Fixture::registry);rejected();f.m.put(Fixture::item+16,Fixture::registry+40);
 f.m.put<uint8_t>(Fixture::item+617,1);rejected();f.m.put<uint8_t>(Fixture::item+617,0);
 f.m.put<uint8_t>(Fixture::item+PRESENTATION_FLAG,2);rejected();f.m.put<uint8_t>(Fixture::item+PRESENTATION_FLAG,0);
 f.m.put(f.ownerPayload+8,Fixture::local|Memory::tag);rejected();f.m.put(f.ownerPayload+8,Fixture::item|Memory::tag);
 f.m.put(f.ownerSparse+(Fixture::itemId&2047)*4,uint32_t(0x80001));rejected();f.m.put(f.ownerSparse+(Fixture::itemId&2047)*4,(Fixture::itemId&0xfffc0000U)|1);
 f.m.put(Fixture::local+3240,Fixture::client+8);rejected();f.m.put(Fixture::local+3240,Fixture::client);
 f.m.put<uint8_t>(Fixture::local+617,1);rejected();f.m.put<uint8_t>(Fixture::local+617,0);
 f.m.put(Fixture::client+576,std::array<A,3>{Fixture::registry+8,Memory::root+0xd000,Fixture::localId});rejected();
 f.m.put(Fixture::client+576,std::array<A,3>{Fixture::registry,Memory::root+0xd000,Fixture::localId});
 assert(f.lookup(binding));
 std::cout<<"PASS: registered dropped-item render binding; original once; scoped byte/tag restore; unchanged world memory; disabled/already-static/write-failed/engine-change/exception/type/registry/entity/owner guards\n";
}
