package com.mojang.minecraftpe;
/** Compile-only type declaration. NEVER package this stub in the app.
 * Runtime superclass comes from the user's installed Minecraft APK. */
public class MainActivity extends android.app.NativeActivity {}
