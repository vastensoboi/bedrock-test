package dev.custom.bedrockgui;
import java.nio.charset.StandardCharsets;
/** One atomic roster observation. N means nearby evidence; G means a full roster. */
public final class HudRosterData {
 public final String[] names;public final boolean global;public final long capturedAt;
 private HudRosterData(String[] names,boolean global,long at){this.names=names;this.global=global;capturedAt=at;}
 public boolean fresh(long now){return now>=capturedAt&&now-capturedAt<=3000;}
 public static HudRosterData parse(String snapshot,long now){
  try{
   if(snapshot==null||snapshot.length()>65536||now<0)return null;
   String[] fields=snapshot.split("\\|",-1);if(fields.length!=3||!(fields[1].equals("G")||fields[1].equals("N")))return null;
   long age=Long.parseLong(fields[0]);if(age<0||age>3000||age>now)return null;
   String[] rows=fields[2].isEmpty()?new String[0]:fields[2].split(";",-1);if(rows.length>2048)return null;
   String[] names=new String[rows.length];
   for(int i=0;i<rows.length;i++){
    String hex=rows[i];if(hex.isEmpty()||hex.length()>768||hex.length()%2!=0)return null;
    byte[] raw=new byte[hex.length()/2];for(int j=0;j<raw.length;j++){int a=Character.digit(hex.charAt(j*2),16),b=Character.digit(hex.charAt(j*2+1),16);if(a<0||b<0)return null;raw[j]=(byte)(a*16+b);}
    names[i]=new String(raw,StandardCharsets.UTF_8);if(names[i].indexOf('\0')>=0||names[i].indexOf('\n')>=0)return null;
   }
   return new HudRosterData(names,fields[1].equals("G"),now-age);
  }catch(RuntimeException error){return null;}
 }
}
