#pragma once
#include "aim_core.h"
namespace kulich_timer_move {
using namespace kulich_aim;
constexpr uint32_t SPEED=0x1268662eU,TRAVEL=0x39cf8d64U,GROUND=0xe1ca9e6bU,AIR=0xb147b030U,WATER=0x2802839dU,PLAYER=0xf95d258fU;
constexpr A GROUND_V2_TABLE=0x13acfbc0ULL,GROUND_V2_BULK=0xc1aea20ULL;
constexpr A GROUND_V1_TABLE=0x13acfc40ULL,GROUND_V1_BULK=0xc1b07c8ULL;
constexpr A WATER_TABLE=0x13b458e8ULL,WATER_BULK=0xcdc3f44ULL;
constexpr A AIR_TABLE=0x13b424a8ULL,AIR_BULK=0xcd51628ULL,AIR_SINGLE=0xcd51e00ULL;
inline int clamp(int value){return value<100?100:value>200?200:value;}
struct Local {A registry=0,actor=0;uint32_t entity=0xffffffffU;};
template<class Read>bool local(Read& read,A base,A client,A adapter,A table,A entityPtr,Local& out){
 out={};client=plain(client);adapter=plain(adapter);
 if(pointer(read,client)!=base+0x1388fe70ULL||pointer(read,adapter)!=base+table)return false;
 A weak[3]{};if(!read(client+576,weak,sizeof weak)||!plain(weak[0])||!plain(weak[1]))return false;
 A registry=plain(weak[0]);uint32_t entity=uint32_t(weak[2]);
 if(pointer(read,adapter+8)!=registry||(entityPtr&&integer(read,plain(entityPtr))!=entity))return false;
 auto v=view(read,registry);A owner=component(read,v.owners,entity,8);Actor actor{};
 if(!owner||!kulich_aim::actor(read,base,v,pointer(read,owner),true,actor)||actor.entity!=entity||pointer(read,actor.address+3240)!=client)return false;
 out={registry,actor.address,entity};return true;
}
struct Scalar {Local owner{};A payload=0;float value=0;};
inline bool same(const Scalar& a,const Scalar& b){return a.owner.registry==b.owner.registry&&a.owner.actor==b.owner.actor&&a.owner.entity==b.owner.entity&&a.payload==b.payload;}
template<class Read>bool input(Read& read,A base,A client,A adapter,A table,uint32_t flag,Scalar& out){
 out={};Local who{};if(!local(read,base,client,adapter,table,0,who))return false;
 A marked=pool(read,who.registry,flag);if(!marked||sparse(read,marked+8,who.entity)<0)return false;
 A payload=taggedComponent(read,pool(read,who.registry,SPEED),who.entity,4);float value=0;
 if(!payload||(plain(payload)&3)||!read(plain(payload),&value,4)||!std::isfinite(value)||value<0||value>16)return false;
 out={who,payload,value};return true;
}
// PlayerAirSpeed writes MobTravel.speed(+12) afresh from the native .02
// constant (plus sprinting) before travel consumes it. Keep that output;
// restoring it would erase the requested local acceleration.
template<class Read>bool airOutput(Read& read,A base,A client,A adapter,A entityPtr,Scalar& out){
 out={};Local who{};if(!local(read,base,client,adapter,AIR_TABLE,entityPtr,who))return false;
 A air=pool(read,who.registry,AIR),ground=pool(read,who.registry,GROUND),player=pool(read,who.registry,PLAYER);
 if(!air||!player||sparse(read,player+8,who.entity)<0||sparse(read,air+8,who.entity)<0||(ground&&sparse(read,ground+8,who.entity)>=0))return false;
 A payload=taggedComponent(read,pool(read,who.registry,TRAVEL),who.entity,40);float value=0;
 if(!payload||!read(plain(payload)+12,&value,4)||!std::isfinite(value)||
    (std::abs(value-.02f)>1e-6f&&std::abs(value-.026f)>1e-6f))return false;
 out={who,payload+12,value};return true;
}
// MovementSpeed is a temporary, local-only INPUT override. The original
// creates travel output for every actor once; only this player's input differs.
template<class Write,class Lookup,class Original>
bool invokeInput(Write& write,Lookup lookup,Original original,int hundredths){
 Scalar before{};float injected=0;bool changed=clamp(hundredths)>100&&lookup(before)&&before.value>0&&before.value<=8;
 if(changed){injected=before.value*(clamp(hundredths)/100.f);changed=std::isfinite(injected)&&write(before.payload,injected);}
 auto restore=[&](){if(!changed)return;Scalar after{};if(lookup(after)&&same(before,after)&&after.value==injected)write(before.payload,before.value);};
 try{original();}catch(...){restore();throw;}
 restore();return changed;
}
template<class Write,class Lookup,class Original>
bool invokeAir(Write& write,Lookup lookup,Original original,int hundredths){
 original();if(clamp(hundredths)<=100)return false;
 Scalar value{};if(!lookup(value)||value.value<=0)return false;
 float boosted=value.value*(clamp(hundredths)/100.f);return std::isfinite(boosted)&&write(value.payload,boosted);
}
}
