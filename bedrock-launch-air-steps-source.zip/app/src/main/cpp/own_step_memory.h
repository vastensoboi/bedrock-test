#pragma once
#include "aim_core.h"
#include "own_step_clock.h"

namespace kulich_own_step {
using namespace kulich_aim;
constexpr uint32_t REPLAY=0x9fc78512U,VALID_FRAME=0xefe55a9aU,
 INTERPOLATE=0x91a67f13U,MOVEMENT=0x94154cceU,CORRECTED=0x8a0c2797U,
 STATE_VECTOR=0x1b5d5238U,PASSENGER=0x98e40c0eU,
 ON_GROUND=0xc29078a0U,JUMPING=0x8fd20e98U,ITEM_USE=0x05b90aefU,MOVE_INPUT=0x018b1887U;
template<class Read>A rawPointer(Read& read,A at){A value=0;return read(plain(at),&value,8)?value:0;}
// The common pool lookup strips tags for memory inspection. Native calls need
// the allocation-tagged storage pointer retained in the registry's map row.
template<class Read>A rawPool(Read& read,A registry,uint32_t key,bool* known=nullptr){
 if(known)*known=false;
 A h[5]{};if(!read(plain(registry)+96,h,sizeof h))return 0;
 A buckets=plain(h[0]),end=plain(h[1]),nodes=plain(h[3]),last=plain(h[4]);
 if(buckets<4096||end<buckets||(end-buckets)%8||nodes<4096||last<nodes||(last-nodes)%32)return 0;
 A count=(end-buckets)/8,n=(last-nodes)/32;
 if(!count||count>4096||(count&(count-1))||!n||n>4096)return 0;
 int64_t index=-1;if(!read(buckets+(key&(count-1))*8,&index,8))return 0;
 for(unsigned tries=0;index!=-1&&tries<64;++tries){
  if(index<0||A(index)>=n)return 0;
  A row[4]{};if(!read(nodes+A(index)*32,row,sizeof row))return 0;
  if(uint32_t(row[1])==key){if(known)*known=true;return row[2];}
  index=int64_t(row[0]);
 }
 if(index==-1&&known)*known=true;
 return 0;
}
template<class Read>bool packed(Read& read,A storage,A& begin,uint64_t& count){
 A bounds[2]{};begin=0;count=0;
 if(!storage||!read(plain(storage)+32,bounds,sizeof bounds))return false;
 A first=plain(bounds[0]),last=plain(bounds[1]);
 if(first<4096||last<first||(last-first)%4||(last-first)/4>262143)return false;
 begin=bounds[0];count=(last-first)/4;return true;
}
enum class Presence {Unavailable,Absent,Present};
// Destructive cleanup must distinguish a missing entity from a failed read.
// The general read-only sparse()/component() helpers intentionally return a
// single failure value and cannot authorize removal/restoration on their own.
template<class Read>Presence locate(Read& read,A storage,uint32_t entity,uint64_t& index){
 index=0;if(!storage)return Presence::Absent;
 A sparseBounds[2]{},packedBounds[2]{};
 if(!read(plain(storage)+8,sparseBounds,sizeof sparseBounds)||!read(plain(storage)+32,packedBounds,sizeof packedBounds))return Presence::Unavailable;
 A first=plain(sparseBounds[0]),last=plain(sparseBounds[1]),begin=plain(packedBounds[0]),end=plain(packedBounds[1]);
 if(last<first||(last-first)%8||(last-first)/8>128||end<begin||(end-begin)%4||(end-begin)/4>262143||
    (first&&first<4096)||(begin&&begin<4096)||(first&7)||(begin&3))return Presence::Unavailable;
 uint64_t pageIndex=(entity>>11)&127,packedCount=(end-begin)/4;
 if(first==last)return packedCount?Presence::Unavailable:Presence::Absent;
 if(!first)return Presence::Unavailable;
 if(pageIndex>=(last-first)/8)return Presence::Absent;
 A page=0;if(!read(first+pageIndex*8,&page,8))return Presence::Unavailable;
 if(!page)return Presence::Absent;
 if(plain(page)<4096||(plain(page)&3))return Presence::Unavailable;
 uint32_t value=0;
 if(!read(plain(page)+(entity&2047)*4,&value,4))return Presence::Unavailable;
 if((value^(entity&0xfffc0000U))>0x3fffeU)return Presence::Absent;
 index=value&0x3ffffU;uint32_t actual=0;
 if(!begin||index>=packedCount||!read(begin+index*4,&actual,4)||actual!=entity)return Presence::Unavailable;
 return Presence::Present;
}
template<class Read>Presence payload(Read& read,A storage,uint32_t entity,unsigned stride,A& out){
 out=0;uint64_t index=0;Presence found=locate(read,storage,entity,index);
 if(found!=Presence::Present)return found;
 A bounds[3]{};
 if(!stride||stride>4096||!read(plain(storage)+80,bounds,sizeof bounds))return Presence::Unavailable;
 A first=plain(bounds[0]),last=plain(bounds[1]),cap=plain(bounds[2]);
 if(first<4096||(first&7)||last<first||cap<last||(last-first)%8||(last-first)/8>2048||index/128>=(last-first)/8)return Presence::Unavailable;
 A page=0;if(!read(first+(index/128)*8,&page,8)||plain(page)<4096)return Presence::Unavailable;
 out=page+(index%128)*stride;return Presence::Present;
}
struct Binding {
 Session session{};A actor=0,replay=0,history=0,sender=0,levelData=0;
 uint32_t entity=0xffffffffU;uint64_t world=0,historyFirst=0,historyCount=0,historyLast=0,current=0;
 std::array<float,3> position{},delta{};
};
template<class Read>bool resolveSession(Read& read,A base,A client,Binding& out){
 out={};client=plain(client);
 if(pointer(read,client)!=base+0x1388fe70ULL)return false;
 A weak[3]{};if(!read(client+576,weak,sizeof weak)||plain(weak[0])<4096||plain(weak[1])<4096)return false;
 uint32_t entity=uint32_t(weak[2]);A registry=plain(weak[0]);
 if((entity&0x3ffffU)==0x3ffffU||sparse(read,registry+216,entity)<0)return false;
 A owner=component(read,pool(read,registry,OWNER),entity,8),actor=rawPointer(read,owner);
 A header[4]{};uint8_t removed=1;
 if(!owner||plain(actor)<4096||!read(plain(actor),header,sizeof header)||
    plain(header[0])!=base+0x139f6ea0ULL||plain(header[1])!=registry||
    plain(header[2])!=registry+40||uint32_t(header[3])!=entity||
    pointer(read,plain(actor)+3240)!=client||!read(plain(actor)+617,&removed,1)||removed)return false;
 A level=rawPointer(read,plain(actor)+496),guard=rawPointer(read,plain(level)+128);uint8_t live=0;
 if(pointer(read,level)!=base+0x1394f510ULL||plain(guard)<4096||!read(plain(guard),&live,1)||!(live&1))return false;
 A levelData=rawPointer(read,plain(level)+144);uint64_t world=0;
 if(plain(levelData)<4096||!read(plain(levelData)+752,&world,8)||!world)return false;
 out.session={client,weak[0],level,levelData};out.actor=actor;out.entity=entity;out.world=world;out.levelData=levelData;
 out.sender=rawPointer(read,plain(actor)+1984);
 return plain(out.sender)>=4096&&pointer(read,out.sender)==base+0x13b3ac00ULL;
}
template<class Read>bool resolve(Read& read,A base,A client,Binding& out){
 if(!resolveSession(read,base,client,out))return false;
 A registry=plain(out.session.registry);uint32_t entity=out.entity;
 A replay=taggedComponent(read,pool(read,registry,REPLAY),entity,32);
 A history=rawPointer(read,plain(replay)+8);uint64_t bounds[2]{},current=0;
 if(!replay||plain(history)<4096||!read(plain(history)+48,bounds,sizeof bounds)||
    !read(plain(replay)+24,&current,8)||!bounds[0]||bounds[0]>4096||
    bounds[1]>UINT64_MAX-(bounds[0]-1))return false;
 A vector=component(read,pool(read,registry,STATE_VECTOR),entity,36);
 std::array<float,3> position{},delta{};
 if(!vector||!read(vector,position.data(),12)||!read(vector+24,delta.data(),12))return false;
 for(float value:position)if(!std::isfinite(value)||std::abs(value)>32000000.f)return false;
 for(float value:delta)if(!std::isfinite(value)||std::abs(value)>64000000.f)return false;
 out.replay=replay;out.history=history;out.historyFirst=bounds[1];out.historyCount=bounds[0];
 out.historyLast=bounds[1]+bounds[0]-1;out.current=current;out.position=position;out.delta=delta;
 return true;
}
inline bool same(const Binding& a,const Binding& b){
 return a.session==b.session&&a.actor==b.actor&&a.replay==b.replay&&a.history==b.history&&
  a.entity==b.entity&&a.sender==b.sender&&a.levelData==b.levelData&&a.world==b.world&&
  a.historyFirst==b.historyFirst&&a.historyCount==b.historyCount&&a.current==b.current&&
  !std::memcmp(a.position.data(),b.position.data(),12)&&!std::memcmp(a.delta.data(),b.delta.data(),12);
}
inline bool sameState(const Binding& a,const Binding& b){
 // Acknowledged old records may be pruned after submission. That does not
 // change the currently submitted actor state or invalidate a fresh step.
 Binding adjusted=a;adjusted.historyFirst=b.historyFirst;adjusted.historyCount=b.historyCount;
 return same(adjusted,b);
}
// Acknowledgements may prune old records while the native adapter appends one
// new final tick. Count shrinkage alone is not a failed append.
inline bool freshHistoryAppend(const Binding& before,const Binding& after,uint64_t tick){
 if(!(before.session==after.session)||before.actor!=after.actor||before.replay!=after.replay||
    before.history!=after.history||before.entity!=after.entity||before.sender!=after.sender||
    before.levelData!=after.levelData||before.world!=after.world)return false;
 if(!before.historyCount||before.historyCount>4096||!after.historyCount||after.historyCount>4096||
    before.historyFirst>before.historyLast||after.historyFirst>after.historyLast||
    before.historyLast-before.historyFirst!=before.historyCount-1||
    after.historyLast-after.historyFirst!=after.historyCount-1)return false;
 return before.current==before.historyLast&&before.historyLast!=UINT64_MAX&&tick==before.historyLast+1&&
  after.current==tick&&after.historyLast==tick&&after.historyFirst>=before.historyFirst;
}
// The native deque stores 56 records of 72 bytes per allocation. Return the
// original allocation tag, rather than constructing a pointer from its low bits.
template<class Read>A record(Read& read,A history,uint64_t tick){
 uint64_t h[8]{};
 if(!read(plain(history)+16,h,sizeof h))return 0;
 A pages=plain(h[0]),pagesEnd=plain(h[1]);uint64_t start=h[3],count=h[4],first=h[5];
 if(!count||count>4096||tick<first||tick-first>=count||start>UINT64_MAX-(tick-first)||
    pages<4096||pagesEnd<pages||(pagesEnd-pages)%8||(pagesEnd-pages)/8>8192)return 0;
 uint64_t index=start+tick-first,page=index/56;
 if(page>=(pagesEnd-pages)/8)return 0;
 A allocation=rawPointer(read,pages+page*8);
 return plain(allocation)>=4096?allocation+(index%56)*72:0;
}
template<class Read>bool cleanHistory(Read& read,const Binding& value){
 uint64_t state[3]{};
 if(!read(plain(value.history)+64,state,sizeof state)||(state[0]&3)||state[1]!=state[2])return false;
 // A pending marked frame with an inconsistent outer dirty flag must also be
 // rejected; an extra step may not consume any real server correction.
 for(uint64_t i=0;i<value.historyCount;++i){
  A frame=record(read,value.history,value.historyFirst+i);uint8_t flags=0;
  if(!frame||!read(plain(frame)+64,&flags,1)||(flags&1))return false;
 }
 return true;
}
// Only for this caller's fresh, not-yet-submitted record. Preserve every other
// marked record and bit1; an unrecognized binding/read failure authorizes no
// write. The caller must disarm this cleanup before submitting the new input.
template<class Read,class Write>bool clearSyntheticMark(Read& read,Write& write,const Binding& owner,uint64_t tick,A frame){
 A replay=taggedComponent(read,pool(read,plain(owner.session.registry),REPLAY),owner.entity,32);
 if(replay!=owner.replay||rawPointer(read,plain(replay)+8)!=owner.history||record(read,owner.history,tick)!=frame)return false;
 uint8_t flags=0;uint64_t bounds[2]{},dirty=0;
 if(!read(plain(frame)+64,&flags,1)||!read(plain(owner.history)+48,bounds,sizeof bounds)||
    !read(plain(owner.history)+64,&dirty,8))return false;
 if(!bounds[0]||bounds[0]>4096||bounds[1]>UINT64_MAX-(bounds[0]-1))return false;
 bool other=false;std::array<uint64_t,64> marked{};
 for(uint64_t i=0;i<bounds[0];++i){
  uint64_t current=bounds[1]+i;if(current==tick)continue;
  A at=record(read,owner.history,current);uint8_t state=0;
  if(!at||!read(plain(at)+64,&state,1))return false;
  if(state&1){other=true;marked[i/64]|=uint64_t(1)<<(i%64);}
 }
 A pending[2]{};if(!read(plain(owner.history)+72,pending,sizeof pending))return false;
 // Unconsumed history events are retained even if no record has been marked
 // yet. An exception cannot authorize clearing their outer work flag.
 other=other||pending[0]!=pending[1];
 uint64_t again[2]{},againDirty=0;uint8_t againFlags=0;
 if(!read(plain(owner.history)+48,again,sizeof again)||std::memcmp(bounds,again,sizeof bounds)||
    !read(plain(owner.history)+64,&againDirty,8)||againDirty!=dirty||
    !read(plain(frame)+64,&againFlags,1)||againFlags!=flags||
    record(read,owner.history,tick)!=frame||rawPointer(read,plain(replay)+8)!=owner.history)return false;
 // Revalidate the other writers' work, not just our frame and the already-set
 // outer bit. An event/mark can arrive without changing that outer bit's value.
 for(uint64_t i=0;i<bounds[0];++i){
  uint64_t current=bounds[1]+i;if(current==tick)continue;
  A at=record(read,owner.history,current);uint8_t state=0;
  if(!at||!read(plain(at)+64,&state,1)||bool(state&1)!=bool(marked[i/64]&(uint64_t(1)<<(i%64))))return false;
 }
 A pendingAgain[2]{};
 if(!read(plain(owner.history)+72,pendingAgain,sizeof pendingAgain)||std::memcmp(pending,pendingAgain,sizeof pending)||
    !read(plain(owner.history)+48,again,sizeof again)||std::memcmp(bounds,again,sizeof bounds)||
    !read(plain(owner.history)+64,&againDirty,8)||againDirty!=dirty||
    !read(plain(frame)+64,&againFlags,1)||againFlags!=flags||
    rawPointer(read,plain(replay)+8)!=owner.history)return false;
 uint8_t cleared=uint8_t(flags&~1U);
 if((flags&1)&&!write(frame+64,&cleared,1))return false;
 if(!other&&(dirty&1)){uint64_t remaining=dirty&~uint64_t(1);if(!write(owner.history+64,&remaining,8))return false;}
 return true;
}
}
