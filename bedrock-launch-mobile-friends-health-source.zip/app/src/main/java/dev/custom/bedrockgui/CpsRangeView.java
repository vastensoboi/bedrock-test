package dev.custom.bedrockgui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityNodeInfo;

/** One range track; coincident thumbs mean a fixed click rate. */
public final class CpsRangeView extends View {
    public interface Listener { void changed(int minimum,int maximum); }
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;
    private int minimum=15,maximum=15,active=1,pointer=-1;
    private int accent=0xfff5f5f5,track=0xff444444;
    private Listener listener;
    private boolean splitThumb;private float startX;

    public CpsRangeView(Context context){
        super(context);density=getResources().getDisplayMetrics().density;
        setFocusable(true);setClickable(true);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);describe();
    }
    public void setListener(Listener value){listener=value;}
    public void setColors(int foreground,int background){accent=foreground;track=background;invalidate();}
    public void setValues(int low,int high){minimum=clamp(low);maximum=Math.max(minimum,clamp(high));describe();invalidate();}
    private static int clamp(int value){return Math.max(1,Math.min(40,value));}
    private float left(){return 15*density;}
    private float right(){return Math.max(left(),getWidth()-15*density);}
    private float x(int value){return left()+(right()-left())*(value-1)/39f;}
    private int value(float x){return clamp(1+Math.round(39*(x-left())/Math.max(1,right()-left())));}
    private void describe(){setContentDescription("CPS от "+minimum+" до "+maximum+(minimum==maximum?", фиксированная частота":"")+". Выбран "+(active==0?"минимум":"максимум"));}
    private void change(int value){
        int low=minimum,high=maximum;
        if(active==0)minimum=Math.min(maximum,clamp(value));else maximum=Math.max(minimum,clamp(value));
        describe();invalidate();
        if((low!=minimum||high!=maximum)&&listener!=null)listener.changed(minimum,maximum);
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);float y=getHeight()/2f;
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4*density);paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(track);canvas.drawLine(left(),y,right(),y,paint);
        paint.setColor(accent);canvas.drawLine(x(minimum),y,x(maximum),y,paint);
        paint.setStyle(Paint.Style.FILL);canvas.drawCircle(x(minimum),y,10*density,paint);canvas.drawCircle(x(maximum),y,10*density,paint);
        if(isFocused()||pointer!=-1){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.5f*density);canvas.drawCircle(x(active==0?minimum:maximum),y,13*density,paint);}
    }
    @Override public boolean onTouchEvent(MotionEvent event){
        if(!isEnabled())return false;
        switch(event.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                pointer=event.getPointerId(0);float touch=event.getX();
                active=minimum==maximum?(touch<x(minimum)?0:1):(Math.abs(touch-x(minimum))<Math.abs(touch-x(maximum))?0:1);
                splitThumb=minimum==maximum&&Math.abs(touch-x(minimum))<18*density;startX=touch;
                ViewParent parent=getParent();if(parent!=null)parent.requestDisallowInterceptTouchEvent(true);
                requestFocus();if(!splitThumb)change(value(touch));else{describe();invalidate();}return true;
            case MotionEvent.ACTION_MOVE:
                int index=event.findPointerIndex(pointer);if(index>=0){float movedX=event.getX(index);if(splitThumb&&Math.abs(movedX-startX)>=density){active=movedX<startX?0:1;splitThumb=false;}if(!splitThumb)change(value(movedX));}return true;
            case MotionEvent.ACTION_POINTER_UP:
                if(event.getPointerId(event.getActionIndex())==pointer)finishTouch();return true;
            case MotionEvent.ACTION_UP:
                int last=event.findPointerIndex(pointer);if(last>=0&&!splitThumb)change(value(event.getX(last)));
                finishTouch();performClick();return true;
            case MotionEvent.ACTION_CANCEL:finishTouch();return true;
            default:return pointer!=-1;
        }
    }
    private void finishTouch(){pointer=-1;splitThumb=false;ViewParent parent=getParent();if(parent!=null)parent.requestDisallowInterceptTouchEvent(false);invalidate();}
    @Override public boolean performClick(){super.performClick();return true;}
    @Override public boolean onKeyDown(int keyCode,KeyEvent event){
        if(keyCode==KeyEvent.KEYCODE_DPAD_LEFT||keyCode==KeyEvent.KEYCODE_MINUS){change((active==0?minimum:maximum)-1);return true;}
        if(keyCode==KeyEvent.KEYCODE_DPAD_RIGHT||keyCode==KeyEvent.KEYCODE_PLUS){change((active==0?minimum:maximum)+1);return true;}
        if(keyCode==KeyEvent.KEYCODE_DPAD_CENTER||keyCode==KeyEvent.KEYCODE_ENTER){active=1-active;describe();invalidate();return true;}
        return super.onKeyDown(keyCode,event);
    }
    @Override public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info){
        super.onInitializeAccessibilityNodeInfo(info);info.setClassName("android.widget.SeekBar");
        info.setRangeInfo(AccessibilityNodeInfo.RangeInfo.obtain(AccessibilityNodeInfo.RangeInfo.RANGE_TYPE_INT,active==0?1:minimum,active==0?maximum:40,active==0?minimum:maximum));
        info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);
        info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD);
        info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS);
        info.addAction(new AccessibilityNodeInfo.AccessibilityAction(AccessibilityNodeInfo.ACTION_CLICK,"Изменять "+(active==0?"максимум":"минимум")));
    }
    @Override public boolean performAccessibilityAction(int action,Bundle arguments){
        if(action==AccessibilityNodeInfo.ACTION_CLICK){active=1-active;describe();invalidate();return true;}
        if(action==AccessibilityNodeInfo.ACTION_SCROLL_FORWARD){change((active==0?minimum:maximum)+1);return true;}
        if(action==AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD){change((active==0?minimum:maximum)-1);return true;}
        if(action==AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS.getId()&&arguments!=null){change(Math.round(arguments.getFloat(AccessibilityNodeInfo.ACTION_ARGUMENT_PROGRESS_VALUE)));return true;}
        return super.performAccessibilityAction(action,arguments);
    }
}
