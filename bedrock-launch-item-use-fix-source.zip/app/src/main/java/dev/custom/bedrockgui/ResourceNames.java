package dev.custom.bedrockgui;

/** Return a game-scoped fallback name only for game or host lookups. */
public final class ResourceNames {
    private static final String GAME="com.mojang.minecraftpe";
    private ResourceNames() {}
    public static String gameName(String name,String requestedPackage,String hostPackage) {
        if(name==null||name.isEmpty()||hostPackage==null)return null;
        int colon=name.indexOf(':');
        if(colon>=0) {
            String explicit=name.substring(0,colon);
            if(explicit.equals(hostPackage))return GAME+name.substring(colon);
            if(explicit.equals(GAME))return name;
            return null;
        }
        if(requestedPackage==null||requestedPackage.isEmpty()||requestedPackage.equals(hostPackage)||requestedPackage.equals(GAME))return name;
        return null;
    }
}
