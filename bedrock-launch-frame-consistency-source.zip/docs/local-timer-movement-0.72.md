# Player movement correction in 0.72

The 0.71 ground and water hooks modified `MovementSpeedComponent`. That float
is the native nonplayer input. Its successful write counter could increase
without changing the local player's travel speed. This was a real selection
error, independently of whether a particular server corrects movement.

## Exact native selector

These addresses describe the supplied Minecraft 1.26.60.4 ARM64 library:

* `0xcd27160` tests player membership in `w2`. The nonplayer branch returns the
  float at `x1`, the `MovementSpeedComponent` argument. The player branch tail
  calls `0x11f06018` and does not read `x1`.
* `0x11f06018` reads the optional float at `MovementAttributesComponent +0`,
  returning zero when the presence byte at `+4` is zero.
* The attributes component is hash `0xa795a68c`, stride 72. The Ground query
  constructs this hash at `0xc1aef14..0xc1aef24`; its entity loop uses stride
  72 at `0xc1afda8` and resolves the attribute pointer at `0xc1afedc`.
* The Ground callbacks call the selector at `0xc1af978` and `0xc1b0a08` with
  attributes in `x0` and MovementSpeed in `x1`. They execute synchronously
  within the existing adapter bulk calls and write native travel output before
  returning. There is no queued callback that outlives the scoped override.
* The Water adapter `0xcdc3f44` executes leaf `0xcdb6590` synchronously. Its
  call at `0xcdb65e8` to `0x11f06030` reads the optional water float at `+8`,
  with presence byte `+12`. Its call at `0xcdb668c` to `0xcd27160` reads the
  player land float at `+0`. The leaf selects or interpolates those values and
  writes `MobTravelComponent +12` at `0xcdb67c4`.

## Changed behavior

Ground now temporarily scales only the bound local player's present land
attribute. Water scales both present land and water attributes, so selecting
or interpolating either branch retains the requested multiplier. The hooks
never enable an absent optional value or change a presence byte. Attribute
values must be finite, positive and within the existing input limits.

Each original adapter still executes exactly once, with its original view.
Each attribute is restored separately only when the current client, registry,
actor, entity generation, tagged component address and injected value still
agree. A changed native value or recycled entity is not overwritten. Writes
retain the allocation tag. A failure to write one Water attribute does not
prevent the original from running or restoring the other changed attribute.

Native travel and collision handling continue to consume their own output.
There is no change to ActorMove requests, collision envelopes, global world
time, gravity, remote actors, item-use duration or swing callbacks. The air
route also retains its previous fresh-output checks. Native installation now
checks the selector, optional accessors, actual call sites, attribute query
and stride instructions in addition to the existing adapter profiles.

## Validation and limits

`LocalTimerCoreTest` models the disassembled native player selector, with
different values for MovementSpeed and the actual player attribute. It checks
Ground scaling, Water selection and interpolation, unchanged remote-player
attributes and nonplayer fallback, absent and malformed optional values,
tagged writes, one original dispatch, partial write failure, exceptions,
native changes and entity-generation changes. Existing air checks remain.
Both host and ARM64-conditional JNI syntax checks pass; the new instruction
profiles match the exact library byte for byte.

The `ground` and `water` counters now report writes to the actual player
inputs, and status identifies the route as `own-player-attributes`. Counters
are not a measurement of displacement or server acceptance. Device behavior
and server corrections still require an on-device comparison and journal;
this change does not bypass server movement validation.
