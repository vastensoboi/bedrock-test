#pragma once
#include "aim_core.h"
#include <string>
#include <vector>
namespace kulich_hud {
using namespace kulich_aim;
constexpr uint32_t MOB_EFFECTS=0xe6a1b550U;
// Exact build: Actor getter fdad2f0 resolves MobEffectsComponent, stride24.
// EffectInstance vector entries are160 bytes. Getters10102e58/60/efc expose
// id+0, duration+4, amplifier+32; duration-1 is infinite in the native tick.
struct HudEffect {int id,amplifier,ticks;};
template<class Read> bool readEffectValues(Read& read,A payload,std::vector<HudEffect>& out){
 out.clear();payload=plain(payload);A h[3]{},again[3]{};
 if(payload<4096||!read(payload,h,sizeof h))return false;
 A begin=plain(h[0]),end=plain(h[1]),cap=plain(h[2]);
 if((begin==0)!=(end==0)||end<begin||cap<end||(end-begin)%160||(cap-begin)%160||(end-begin)/160>128||(cap-begin)/160>1024)return false;
 if(end!=begin&&begin<4096)return false;
 std::vector<HudEffect> result;bool seen[39]{};
 for(A at=begin;at<end;at+=160){
  int32_t fields[9]{};if(!read(at,fields,sizeof fields))return false;
  int id=fields[0],ticks=fields[1],amplifier=fields[8];
  if(id<0||id>38||ticks< -1||amplifier<0||amplifier>255)return false;
  if(id==0||ticks==0)continue;
  // Multiple active records for one effect would be an inconsistent snapshot.
  if(seen[id])return false;
  seen[id]=true;
  result.push_back({id,amplifier,ticks});
 }
 if(!read(payload,again,sizeof again)||std::memcmp(h,again,sizeof h))return false;
 out.swap(result);return true;
}
template<class Read> bool readEffects(Read& read,A registry,uint32_t entity,std::vector<HudEffect>& out){
 out.clear();A storage=pool(read,registry,MOB_EFFECTS),payload=component(read,storage,entity,24);
 if(!payload)return false;
 std::vector<HudEffect> value;if(!readEffectValues(read,payload,value)||component(read,storage,entity,24)!=payload)return false;
 out.swap(value);return true;
}
inline std::string encodeEffects(const std::vector<HudEffect>& effects){
 std::string out;for(const auto& e:effects){if(!out.empty())out+=';';out+=std::to_string(e.id)+","+std::to_string(e.amplifier)+","+std::to_string(e.ticks);}return out;
}
template<class Read> bool readEffectVector(Read& read,A payload,std::string& out){
 out.clear();std::vector<HudEffect> value;if(!readEffectValues(read,payload,value))return false;out=encodeEffects(value);return true;
}
template<class Read> bool readBuffs(Read& read,A registry,uint32_t entity,std::string& out){
 out.clear();std::vector<HudEffect> value;if(!readEffects(read,registry,entity,value))return false;out=encodeEffects(value);return true;
}
}
