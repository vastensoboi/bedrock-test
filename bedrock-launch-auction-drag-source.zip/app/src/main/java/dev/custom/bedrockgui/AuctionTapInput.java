package dev.custom.bedrockgui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Calibration and one explicit refresh test in this app's own game window only. */
public final class AuctionTapInput {
    private final Activity activity;private final FrameLayout root;private final Runnable closeMenu;private final View floating;
    private final SharedPreferences prefs;private FrameLayout layer;private boolean busy,disposed;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int generation,dragGeneration,moveReturnsFalse;private float[] lastPoint;private long downTime;
    private GameEngineProbe.TapSession touchSession;
    private void closeSession(){if(touchSession!=null){touchSession.close();touchSession=null;}}
    public AuctionTapInput(Activity activity,FrameLayout root,View floating,Runnable closeMenu){
        this.activity=activity;this.root=root;this.floating=floating;this.closeMenu=closeMenu;prefs=activity.getSharedPreferences("auction-grid",0);
    }
    public boolean calibrating(){return layer!=null;}
    private void message(String text){Toast.makeText(activity,text,Toast.LENGTH_LONG).show();GameRuntime.log("Auto Buy input: "+text);}
    private boolean active(){return !disposed&&!activity.isFinishing()&&!activity.isDestroyed()&&activity.hasWindowFocus();}
    private InventoryGrid profile(int slots){
        String p="grid"+slots+".";if(!prefs.contains(p+"width"))return null;
        if(!prefs.contains(p+"ix")||!prefs.contains(p+"iy"))return null;
        try{
            SlotGrid grid=new SlotGrid(slots,prefs.getInt(p+"width",0),prefs.getInt(p+"height",0),prefs.getFloat(p+"x",0),prefs.getFloat(p+"y",0),prefs.getFloat(p+"rx",0),prefs.getFloat(p+"ry",0),prefs.getFloat(p+"nx",0),prefs.getFloat(p+"ny",0));
            return new InventoryGrid(grid,prefs.getFloat(p+"ix",0),prefs.getFloat(p+"iy",0));
        }
        catch(IllegalArgumentException error){return null;}
    }
    private void prepare(int slots,Runnable action){
        if(busy||disposed||calibrating()||lastPoint!=null)return;
        if(!GameEngineProbe.begin()){message("Дождись окончания текущего чтения");return;}
        busy=true;int token=generation;message("Проверяю открытое окно…");
        Thread worker=new Thread(()->{
            try{GameEngineProbe.run();GameEngineProbe.auctionSnapshot();}
            catch(RuntimeException|LinkageError error){GameRuntime.log("Auto Buy input prepare failed: "+error);}
            finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{
                busy=false;if(!active()||generation!=token)return;
                if(!GameEngineProbe.hasAuctionWindow(slots)){message(slots==54?"Открой список аукциона на 54 слота":"Открой окно покупки на 27 слотов");return;}
                action.run();
            });
        },"auction-input-prepare");worker.setDaemon(true);worker.start();
    }
    public void calibrate(int slots){prepare(slots,()->beginCalibration(slots));}
    private void beginCalibration(int slots){
        closeMenu.run();View decor=activity.getWindow().getDecorView();int width=decor.getWidth(),height=decor.getHeight();
        layer=new FrameLayout(activity);layer.setBackgroundColor(Color.argb(20,0,0,0));
        TextView hint=new TextView(activity);hint.setTextColor(Color.WHITE);hint.setTextSize(16);hint.setBackgroundColor(Color.argb(210,0,0,0));
        hint.setPadding(12,8,12,8);hint.setText("1/4: нажми в центр верхнего ЛЕВОГО слота (0)");
        FrameLayout.LayoutParams textBounds=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);layer.addView(hint,textBounds);
        Button cancel=new Button(activity);cancel.setText("Отмена настройки");
        FrameLayout.LayoutParams cancelBounds=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);layer.addView(cancel,cancelBounds);
        cancel.setOnClickListener(v->cancelCalibration());
        float[] points=new float[8];int[] index={0};
        layer.setOnTouchListener((v,event)->{
            if(event.getPointerCount()!=1)return true;
            if(event.getActionMasked()!=MotionEvent.ACTION_UP)return true;
            int[] origin=new int[2];decor.getLocationOnScreen(origin);
            points[index[0]*2]=event.getRawX()-origin[0];points[index[0]*2+1]=event.getRawY()-origin[1];index[0]++;
            if(index[0]==1)hint.setText("2/4: центр верхнего ПРАВОГО слота (8)");
            else if(index[0]==2)hint.setText("3/4: центр ЛЕВОГО слота второй строки (9)");
            else if(index[0]==3)hint.setText("4/4: центр ПЕРВОЙ ячейки своего инвентаря под сундуком (не хотбар)");
            else{
                try{
                    SlotGrid grid=new SlotGrid(slots,width,height,points[0],points[1],points[2],points[3],points[4],points[5]);
                    new InventoryGrid(grid,points[6],points[7]);
                    String p="grid"+slots+".";
                    prefs.edit().putInt(p+"width",width).putInt(p+"height",height).putFloat(p+"x",points[0]).putFloat(p+"y",points[1])
                            .putFloat(p+"rx",points[2]).putFloat(p+"ry",points[3]).putFloat(p+"nx",points[4]).putFloat(p+"ny",points[5]).putFloat(p+"ix",points[6]).putFloat(p+"iy",points[7]).apply();
                    GameRuntime.log("Auto Buy input: calibrated slots="+slots+" viewport="+width+"x"+height+" origin="+grid.x+","+grid.y+" pitch="+grid.dx+","+grid.dy+" inventoryOrigin="+points[6]+","+points[7]);
                    message("Сетка настроена: "+slots+" слотов");
                }catch(IllegalArgumentException error){message(error.getMessage());}
                cancelCalibration();
            }
            return true;
        });
        root.addView(layer,new FrameLayout.LayoutParams(-1,-1));layer.bringToFront();
    }
    private void cancelCalibration(){if(layer!=null){root.removeView(layer);layer=null;}}
    public void testRefresh(){
        prepare(54,()->{
            InventoryGrid profile=profile(54);View decor=activity.getWindow().getDecorView();
            if(profile==null||!profile.chest.fits(54,decor.getWidth(),decor.getHeight())){message("Настрой сетку заново: нужны 4 точки, включая инвентарь");return;}
            closeMenu.run();
            handler.post(()->{
                if(!active())return;
                float[] point=profile.chest.point(49);int[] origin=new int[2];decor.getLocationOnScreen(origin);
                android.graphics.Rect icon=new android.graphics.Rect();floating.getGlobalVisibleRect(icon);
                if(icon.contains(Math.round(point[0]+origin[0]),Math.round(point[1]+origin[1]))){message("Перемести круглую иконку с кнопки обновления");return;}
                try{touchSession=GameEngineProbe.openTapSession();}
                catch(java.io.IOException|RuntimeException error){message("Не удалось подготовить касание: "+error.getMessage());return;}
                if(!active()||!touchSession.validate()){closeSession();message("Окно изменилось. Нажатие отменено");return;}
                float[] destination=profile.point(touchSession.destinationSlot());
                int drag=++dragGeneration;moveReturnsFalse=0;
                lastPoint=point;downTime=SystemClock.uptimeMillis();
                boolean accepted=dispatch(MotionEvent.ACTION_DOWN,point,downTime);
                if(!accepted){finishDrag(false,"DOWN not accepted");return;}
                // Move like a finger dragging a stack; a tap merely highlights the slot.
                for(int step=1;step<=6;step++){
                    final int part=step;
                    handler.postDelayed(()->{
                        if(lastPoint==null||dragGeneration!=drag)return;
                        if(!active()||touchSession==null||!touchSession.validateDuringDrag()){
                            finishDrag(false,"window changed during MOVE");return;
                        }
                        float t=part/6f;
                        float[] next={point[0]+(destination[0]-point[0])*t,point[1]+(destination[1]-point[1])*t};
                        lastPoint=next;
                        if(!dispatch(MotionEvent.ACTION_MOVE,next,downTime))moveReturnsFalse++;
                    },100+step*50);
                }
                handler.postDelayed(()->{
                    if(lastPoint==null||dragGeneration!=drag)return;
                    boolean valid=active()&&touchSession!=null&&touchSession.validateDuringDrag()&&SystemClock.uptimeMillis()-downTime<=1600;
                    finishDrag(valid,valid?"drag delivered; server result unconfirmed":"window changed or gesture delayed");
                },480);

            });
        });
    }
    private void finishDrag(boolean release,String reason){
        if(lastPoint==null)return;
        dragGeneration++;
        long held=SystemClock.uptimeMillis()-downTime;int action=release?MotionEvent.ACTION_UP:MotionEvent.ACTION_CANCEL;
        boolean delivered=!activity.isDestroyed()&&dispatch(action,lastPoint,downTime);
        GameRuntime.log("Auto Buy input: refresh drag "+(release?"UP":"CANCEL")+" accepted="+delivered+" durationMs="+held+
                " destinationSlot="+(touchSession==null?-1:touchSession.destinationSlot())+" point="+Arrays.toString(lastPoint)+" moveReturnsFalse="+moveReturnsFalse+" reason="+reason);
        lastPoint=null;closeSession();
        if(active())message(release?"Перетаскивание «Обновить» отправлено. Проверь, обновились ли лоты":"Перетаскивание отменено: окно или ввод изменились");
    }
    private boolean dispatch(int action,float[] point,long down){
        MotionEvent.PointerProperties property=new MotionEvent.PointerProperties();property.id=0;property.toolType=MotionEvent.TOOL_TYPE_FINGER;
        MotionEvent.PointerCoords coords=new MotionEvent.PointerCoords();coords.x=point[0];coords.y=point[1];coords.pressure=(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_MOVE)?1:0;coords.size=0.05f;
        MotionEvent event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,1,new MotionEvent.PointerProperties[]{property},new MotionEvent.PointerCoords[]{coords},0,0,1,1,0,0,InputDevice.SOURCE_TOUCHSCREEN,0);
        try{return activity.dispatchTouchEvent(event);}finally{event.recycle();}
    }
    public void dispose(){
        disposed=true;generation++;dragGeneration++;cancelCalibration();handler.removeCallbacksAndMessages(null);
        if(lastPoint!=null&&!activity.isDestroyed())dispatch(MotionEvent.ACTION_CANCEL,lastPoint,downTime);lastPoint=null;closeSession();
    }
}
