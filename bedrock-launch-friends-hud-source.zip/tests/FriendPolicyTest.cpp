#include "../app/src/main/cpp/friend_core.h"
#include <cassert>
#include <iostream>
using namespace kulich_aim;
int main(){
 FriendPolicy p;assert(p.empty()&&p.check(nullptr)==FriendPolicy::Enemy);
 assert(p.replace("Steve_1\nAnn"));assert(p.size()==2);
 assert(p.check("STEVE_1")==FriendPolicy::Friend&&p.check("ann")==FriendPolicy::Friend);
 assert(p.check("Anna")==FriendPolicy::Enemy&&p.check("NotSteve_1")==FriendPolicy::Enemy);
 assert(p.check(nullptr)==FriendPolicy::Unknown&&p.check("")==FriendPolicy::Unknown);
 assert(p.check("[VIP] Ann")==FriendPolicy::Unknown&&p.check("§aAnn")==FriendPolicy::Unknown);
 assert(!p.replace("Ann\n../x")&&p.size()==2&&p.check("Ann")==FriendPolicy::Friend);
 assert(!p.replace(std::string("Ann\0Bob",7))&&p.size()==2);
 assert(!p.replace(std::string(17,'a'))&&p.size()==2);
 assert(friendKey("User_01234567890")=="user_01234567890");
 // Updating the list while a lock exists changes the final dispatch decision.
 assert(p.check("Enemy")==FriendPolicy::Enemy);assert(p.replace("Enemy"));assert(p.check("Enemy")==FriendPolicy::Friend);
 assert(p.replace("")&&p.empty()&&p.check("Enemy")==FriendPolicy::Enemy);
 std::string maximum;for(int i=0;i<128;i++){if(i)maximum+='\n';maximum+="User"+std::to_string(i);}assert(p.replace(maximum)&&p.size()==128);
 assert(!p.replace(maximum+"\nExtra")&&p.size()==128&&p.check("USER127")==FriendPolicy::Friend);
 std::cout<<"PASS: exact case-insensitive friend identity, unknown fail-closed, atomic invalid updates and live add/remove decision\n";
}
