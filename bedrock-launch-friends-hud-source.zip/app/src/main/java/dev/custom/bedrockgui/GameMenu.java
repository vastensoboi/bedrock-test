package dev.custom.bedrockgui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Categorized in-window menu. Gameplay entries only enable when a real handler is registered. */
public final class GameMenu {
    public interface Toggle { void setEnabled(boolean enabled) throws Exception; }
    private static final String TARGET = "target", UTILITY = "utility", CUSTOM = "customization";
    private int INK,MUTED,ACCENT,PANEL,BUTTON,CATEGORY,SELECTED,LINE,ICON,WARNING;
    private int[] palette;private boolean lightTheme;
    private final Activity activity;
    private final SharedPreferences preferences;
    private final FrameLayout root;
    private final Button floating;private final TargetHud targetHud;
    private final View shade;
    private final LinearLayout panel, body, categories, moduleList, details;
    private final ScrollView moduleScroll, detailScroll;
    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final Drag iconDrag, panelDrag;
    private final Resize resize;
    private String category, selected;
    private boolean wide = true;
    private boolean resizing;
    private KulichScripts scripts;
    private final FastExpStart fastStart;
    private final AuctionTapInput auctionInput;
    private final AutoBuyController autoBuy;private TextView autoBuyStatus;
    private final AimbotController aimbot;private TextView aimbotStatus;private int aimRadius,aimCpsMin,aimCpsMax;
    private float widthRatio, heightRatio;
    private TextView friendsList;

    private static final class Entry {
        final String id, category;
        String title, description;
        Toggle callback;
        boolean enabled;
        Entry(String id, String category, String title, String description) {
            this.id = id;this.category = category;this.title = title;this.description = description;
        }
    }

    public GameMenu(Activity activity) {
        this.activity = activity;
        FriendStore.initialize(activity);
        fastStart=new FastExpStart(activity.getIntent()!=null&&activity.getIntent().getBooleanExtra("fastExpAuto",false),android.os.SystemClock.uptimeMillis());
        preferences = activity.getSharedPreferences("game-menu-ui", 0);
        setPalette("white".equals(preferences.getString("menu.theme","black")));
        FastExpBridge.setTickInterval(preferences.getInt("fast_exp_ticks",3));
        widthRatio = preferences.getFloat("panel.widthRatio", 0.86f);
        heightRatio = preferences.getFloat("panel.heightRatio", 0.86f);
        category = preferences.getString("category", UTILITY);
        if (!TARGET.equals(category) && !UTILITY.equals(category) && !CUSTOM.equals(category)) category = UTILITY;
        root = new FrameLayout(activity);
        targetHud=new TargetHud(activity);root.addView(targetHud.view(),targetHud.bounds());

        shade = new View(activity);
        shade.setBackgroundColor(Color.argb(85, 0, 0, 0));shade.setClickable(true);
        shade.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        shade.setVisibility(View.GONE);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        panel = new LinearLayout(activity);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(background(PANEL, 18));panel.setElevation(dp(8));
        panel.setPadding(dp(12), dp(8), dp(12), dp(12));panel.setClickable(true);panel.setVisibility(View.GONE);
        LinearLayout header = new LinearLayout(activity);header.setGravity(Gravity.CENTER_VERTICAL);header.setClickable(true);
        LinearLayout brand = new LinearLayout(activity);brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = label("kulich", 23);title.setTypeface(Typeface.DEFAULT_BOLD);title.setTextColor(ACCENT);
        brand.addView(title);TextView hint = label("Перемещение — за заголовок", 11);hint.setTextColor(MUTED);brand.addView(hint);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        Button journal = button("Журнал");journal.setTextSize(13);
        header.addView(journal, new LinearLayout.LayoutParams(dp(86), dp(40)));
        journal.setOnClickListener(v -> {
            TransactionTrace.flush();GameRuntime.log("Menu: opening diagnostics from game");
            android.content.Intent intent = new android.content.Intent(activity, MainActivity.class)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                    .putExtra("showLaunchLog", true);
            try { activity.startActivity(intent); }
            catch (RuntimeException error) {
                GameRuntime.log("Menu: diagnostics unavailable: " + error.getClass().getSimpleName());
                Toast.makeText(activity, "Не удалось открыть журнал", Toast.LENGTH_LONG).show();
            }
        });
        panel.addView(header, new LinearLayout.LayoutParams(-1, dp(54)));
        body = new LinearLayout(activity);panel.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout footer = new LinearLayout(activity);footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView sizeHint = label("Размер окна", 12);sizeHint.setTextColor(MUTED);
        footer.addView(sizeHint, new LinearLayout.LayoutParams(0, -2, 1));
        TextView grip = label("◢", 27);grip.setGravity(Gravity.CENTER);grip.setTextColor(ACCENT);
        grip.setClickable(true);grip.setContentDescription("Изменить размер меню: потяни за угол");
        footer.addView(grip, new LinearLayout.LayoutParams(dp(48), -1));
        panel.addView(footer, new LinearLayout.LayoutParams(-1, dp(40)));
        categories = new LinearLayout(activity);
        moduleList = new LinearLayout(activity);moduleList.setOrientation(LinearLayout.VERTICAL);
        details = new LinearLayout(activity);details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(18), dp(12), dp(12), dp(12));
        moduleScroll = new ScrollView(activity);moduleScroll.setFillViewport(true);moduleScroll.addView(moduleList);
        detailScroll = new ScrollView(activity);detailScroll.setFillViewport(true);detailScroll.addView(details);
        root.addView(panel, new FrameLayout.LayoutParams(dp(740), dp(340)));
        panelDrag = new Drag(panel, "panel.", 0.5f, 0.5f, null);
        header.setOnTouchListener((v, event) -> resizing || panelDrag.touch(event));
        resize = new Resize();grip.setOnTouchListener((v, event) -> resize.touch(event));

        floating = button("kulich");floating.setTextSize(13);floating.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable circle = new GradientDrawable();circle.setShape(GradientDrawable.OVAL);
        circle.setColor(ICON);circle.setStroke(dp(2), ACCENT);floating.setBackground(circle);
        floating.setStateListAnimator(null);floating.setElevation(dp(16));
        floating.setContentDescription("kulich: нажми для меню или перетащи круглую иконку");
        root.addView(floating, new FrameLayout.LayoutParams(dp(68), dp(68)));
        floating.setOnClickListener(v -> toggle());
        iconDrag = new Drag(floating, "", 0.04f, 0.2f, () -> floating.performClick());
        floating.setOnTouchListener((v, event) -> iconDrag.touch(event));
        auctionInput=new AuctionTapInput(activity,root,floating,this::close);
        autoBuy=new AutoBuyController(activity,auctionInput,text->GameRuntime.log("Auto Buy: "+text),()->!auctionInput.calibrating()&&!activity.isFinishing()&&!activity.isDestroyed());
        aimbot=new AimbotController(activity);aimRadius=Math.max(1,Math.min(5,preferences.getInt("aim.radius",3)));int legacyCps=Math.max(1,Math.min(40,preferences.getInt("aim.cps",15)));
        aimCpsMin=Math.max(1,Math.min(40,preferences.getInt("aim.cps.min",legacyCps)));
        aimCpsMax=Math.max(aimCpsMin,Math.min(40,preferences.getInt("aim.cps.max",legacyCps)));
        AimbotBridge.settings(aimRadius,aimCpsMin,aimCpsMax);
        addToggle("aimbot",TARGET,"Aimbot","Резкое наведение и удары по выбранному игроку. Дистанция и CPS настраиваются ниже.",aimbot::setEnabled);
        entries.put("friends",new Entry("friends",TARGET,"Друзья","Aimbot исключает друзей из целей и проверяет список перед автоударом. Список сохраняется."));

        addCatalog("auto_buy", "Auto Buy", "Обновление аукциона → подбор по правилам → проверка окна покупки → покупка → проверка получения предмета.");
        addToggle("auto_buy","Auto Buy", "Обновление, подбор и покупка по правилам из твоего скрипта. Работает при открытом kulich и другом окне поверх игры.",autoBuy::setEnabled);
        addCatalog("block_trap", "Block Trap", "Размещение блоков вокруг выбранной цели с учётом списка друзей.");
        addCatalog("fast_exp", "Fast Exp", "Ускоренное использование пузырьков опыта из руки.");
        entries.put("menu_theme",new Entry("menu_theme",CUSTOM,"Цвет меню","Белая или чёрная тема. Выбор сохраняется автоматически."));
        root.postDelayed(fastHeartbeat,400);
        arrange(true);
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> fit());
        activity.getWindow().addContentView(root, new ViewGroup.LayoutParams(-1, -1));root.post(this::fit);
        root.post(this::loadScripts);
    }

    private void loadScripts(){
        if(activity.isFinishing()||activity.isDestroyed())return;
        scripts=new KulichScripts(new KulichScripts.Host(){
            public void register(String id,String name,String description,KulichScripts.Toggle callback){
                addToggle(id,name,description,callback::set);
            }
            public void log(String value){GameRuntime.log(value);}
            public Object fast(String operation,Object value){
                switch(operation){
                    case "ready":return FastExpBridge.isReady();
                    case "status":return FastExpBridge.describe();
                    case "enable":FastExpBridge.setEnabled(Boolean.TRUE.equals(value));return null;
                    case "interval":FastExpBridge.setTickInterval(((Number)value).intValue());return null;
                    default:throw new IllegalArgumentException("Unsupported Fast Exp operation");
                }
            }
            public void failed(String id){
                Entry entry=entries.get(id);if(entry!=null)entry.enabled=false;
                FastExpBridge.setEnabled(false);renderModules();renderDetails();
            }
        });
        try(java.io.InputStream input=activity.getAssets().open("kulich-api.js")){
            String bootstrap=ScriptFiles.read(input,ScriptFiles.MAX_BYTES);
            long start=android.os.SystemClock.uptimeMillis();
            for(java.io.File file:ScriptFiles.list(new java.io.File(activity.getFilesDir(),"scripts"))){
                if(android.os.SystemClock.uptimeMillis()-start>2000){GameRuntime.log("Scripts: startup time limit reached");break;}
                try(java.io.InputStream source=new java.io.FileInputStream(file)){
                    scripts.load(bootstrap,ScriptFiles.read(source,ScriptFiles.MAX_BYTES),file.getName());
                }catch(java.io.IOException error){GameRuntime.log("Script read failed: "+error.getClass().getSimpleName());}
            }
        }catch(java.io.IOException|RuntimeException error){GameRuntime.log("Scripts unavailable: "+error);}
    }

    private void addCatalog(String id, String title, String description) {
        entries.put(id, new Entry(id, UTILITY, title, description));
    }
    /** Bind implemented gameplay behavior to a catalog ID, or add a new utility module. UI thread only. */
    public void addToggle(String id, String title, String description, Toggle callback) {
        addToggle(id, UTILITY, title, description, callback);
    }
    public void addToggle(String id, String category, String title, String description, Toggle callback) {
        if (id == null || id.isEmpty() || callback == null || (!TARGET.equals(category) && !UTILITY.equals(category) && !CUSTOM.equals(category)))
            throw new IllegalArgumentException("Module requires an ID, category and real callback");
        Entry entry = entries.get(id);
        if (entry != null && entry.callback != null) throw new IllegalArgumentException("Duplicate module ID: " + id);
        if (entry == null) { entry = new Entry(id, category, title, description);entries.put(id, entry); }
        else if (!entry.category.equals(category)) throw new IllegalArgumentException("Module category does not match catalog");
        entry.title = title;entry.description = description;entry.callback = callback;
        renderModules();renderDetails();
    }
    private void arrange(boolean wide) {
        this.wide = wide;body.removeAllViews();detach(categories);detach(moduleScroll);detach(detailScroll);
        categories.setOrientation(wide ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        body.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        if (wide) {
            body.addView(categories, new LinearLayout.LayoutParams(dp(136), -1));
            body.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            body.addView(moduleScroll, new LinearLayout.LayoutParams(dp(180), -1));
            body.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            body.addView(detailScroll, new LinearLayout.LayoutParams(0, -1, 1));
        } else {
            body.addView(categories, new LinearLayout.LayoutParams(-1, dp(76)));
            LinearLayout content = new LinearLayout(activity);
            content.addView(moduleScroll, new LinearLayout.LayoutParams(0, -1, 0.43f));
            content.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            content.addView(detailScroll, new LinearLayout.LayoutParams(0, -1, 0.57f));
            body.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        }
        renderCategories();renderModules();renderDetails();
    }
    private void renderCategories() {
        categories.removeAllViews();
        categoryRow(TARGET, "01", "Таргет");categoryRow(UTILITY, "02", "Вспомогательные\nфункции");categoryRow(CUSTOM,"03","Кастомизация");
    }
    private void categoryRow(String id, String number, String title) {
        LinearLayout row = new LinearLayout(activity);row.setOrientation(LinearLayout.VERTICAL);
        row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10), dp(8), dp(6), dp(8));
        boolean chosen = id.equals(category);
        row.setBackground(background(chosen ? SELECTED : CATEGORY, 10));
        TextView index = label(number, 11);index.setTextColor(chosen ? ACCENT : MUTED);row.addView(index);
        TextView name = label(title, 14);name.setTextColor(chosen ? INK : MUTED);row.addView(name);
        row.setOnClickListener(v -> {
            category = id;selected = null;preferences.edit().putString("category", id).apply();
            renderCategories();renderModules();renderDetails();
        });
        LinearLayout.LayoutParams bounds = wide ? new LinearLayout.LayoutParams(-1, 0, 1) :
                new LinearLayout.LayoutParams(0, -1, 1);
        bounds.setMargins(dp(3), dp(3), dp(3), dp(3));categories.addView(row, bounds);
    }
    private void renderModules() {
        moduleList.removeAllViews();
        boolean any = false;
        for (Entry entry : entries.values()) {
            if (!entry.category.equals(category)) continue;
            any = true;
            LinearLayout row = new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(14), dp(8), dp(14));
            if (entry.id.equals(selected)) row.setBackground(background(SELECTED, 10));
            TextView dot = label("●", 11);dot.setTextColor(entry.enabled ? ACCENT : MUTED);
            row.addView(dot, new LinearLayout.LayoutParams(dp(20), -2));
            LinearLayout text = new LinearLayout(activity);text.setOrientation(LinearLayout.VERTICAL);
            text.addView(label(entry.title, 16));
            TextView status = label(entry.id.equals("friends") ? (FriendStore.names().length+" в списке") : entry.id.equals("menu_theme") ? (lightTheme?"Белая тема":"Чёрная тема") : entry.callback == null ? "Не подключён" : entry.enabled ? "Включён" : "Выключен", 11);
            status.setTextColor(MUTED);text.addView(status);row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
            TextView arrow = label("›", 23);arrow.setTextColor(MUTED);row.addView(arrow);
            row.setOnClickListener(v -> { selected = entry.id;renderModules();renderDetails(); });
            moduleList.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        if (!any) {
            TextView empty = label("Пока нет модулей", 14);empty.setTextColor(MUTED);empty.setPadding(dp(12), dp(20), dp(8), 0);
            moduleList.addView(empty);
        }
    }
    private void renderDetails() {
        Entry fast=entries.get("fast_exp");
        if(fast!=null&&fast.callback==null&&FastExpBridge.isReady()){fast.callback=FastExpBridge::setEnabled;renderModules();}
        autoBuyStatus=null;aimbotStatus=null;friendsList=null;details.removeAllViews();Entry entry = entries.get(selected);
        if (entry == null || !entry.category.equals(category)) {
            details.setGravity(Gravity.CENTER);
            TextView icon = label("◇", 54);icon.setTextColor(MUTED);details.addView(icon);
            TextView hint = label("Выбери модуль", 18);hint.setTextColor(MUTED);details.addView(hint);return;
        }
        details.setGravity(Gravity.TOP);
        TextView title = label(entry.title, 23);title.setTypeface(Typeface.DEFAULT_BOLD);details.addView(title);
        TextView description = label(entry.description, 14);description.setTextColor(MUTED);
        description.setPadding(0, dp(14), 0, dp(20));details.addView(description);
        if(entry.id.equals("menu_theme")){renderThemeSettings();return;}
        if(entry.id.equals("friends")){renderFriendsSettings();return;}
        if(entry.id.equals("aimbot")){renderToggle(entry);renderAimbotSettings();}
        if(entry.id.equals("auto_buy")){
            renderToggle(entry);
            autoBuyStatus=label(autoBuy.status(),13);autoBuyStatus.setTextColor(ACCENT);details.addView(autoBuyStatus);
            Button wanted=button("Предметы и цены");details.addView(wanted);
            TextView wantedList=label(AutoBuyDefaultRules.buyingList(),12);wantedList.setTextColor(MUTED);wantedList.setVisibility(View.GONE);details.addView(wantedList);
            wanted.setOnClickListener(v->wantedList.setVisibility(wantedList.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
            Button refreshTest=button("Проверить нативное обновление");details.addView(refreshTest,new LinearLayout.LayoutParams(-1,dp(52)));
            refreshTest.setOnClickListener(v->{close();autoBuy.testNativeRefresh();});
            TextView rules=label("Используются цены и зачарования из твоего скрипта. Броня с неподтверждённым типом и предметы без рыночной цены пропускаются. Интервал обновления — от 0,3 с с ожиданием ответа сервера. Открытие kulich, касания экрана и другое окно не ставят модуль на паузу.",12);rules.setTextColor(MUTED);details.addView(rules);
            Button extra=button("Диагностика");details.addView(extra);
            LinearLayout advanced=new LinearLayout(activity);advanced.setOrientation(LinearLayout.VERTICAL);advanced.setVisibility(View.GONE);details.addView(advanced);
            extra.setOnClickListener(v->advanced.setVisibility(advanced.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
            Button trace=button("Записать настоящее действие контейнера");advanced.addView(trace);
            TextView traceState=label("Необязательная запись запросов для диагностики.",12);traceState.setTextColor(MUTED);advanced.addView(traceState);
            trace.setOnClickListener(v->{
                autoBuy.setEnabled(false);fastStart.cancel();FastExpBridge.setEnabled(false);entry.enabled=false;renderModules();
                for(int i=0;i<details.getChildCount();i++)if(details.getChildAt(i) instanceof Switch)((Switch)details.getChildAt(i)).setChecked(false);
                if(!GameEngineProbe.begin()){traceState.setText("Дождись завершения чтения");return;}
                trace.setEnabled(false);traceState.setText("Подключаю запись действий…");
                Thread recorder=new Thread(()->{
                    String result;
                    try{GameEngineProbe.run();result=GameEngineProbe.startTransactionTrace();}
                    catch(RuntimeException|LinkageError error){result="Запись не включена: "+error.getMessage();GameRuntime.log("Transaction trace unavailable: "+error);}
                    finally{GameEngineProbe.end();}
                    String message=result;activity.runOnUiThread(()->{if(!activity.isDestroyed()){trace.setEnabled(true);traceState.setText(message);}});
                },"inventory-trace-install");recorder.setDaemon(true);recorder.start();
            });
            Button saveTrace=button("Сохранить запись действий");advanced.addView(saveTrace);
            saveTrace.setOnClickListener(v->{try{traceState.setText(TransactionTrace.save()+"\nЗапись добавлена в журнал kulich.");}catch(RuntimeException|LinkageError error){traceState.setText("Не удалось сохранить: "+error.getMessage());}});
            Button snapshot=button("Считать открытый аукцион");advanced.addView(snapshot,new LinearLayout.LayoutParams(-1,dp(52)));
            TextView output=label("Открой аукцион сервера. Эта кнопка только читает лоты; автоматическая покупка включается переключателем Auto Buy.",12);
            output.setTextColor(MUTED);advanced.addView(output);
            snapshot.setOnClickListener(v->{
                if(!GameEngineProbe.begin()){Toast.makeText(activity,"Чтение уже выполняется",Toast.LENGTH_SHORT).show();return;}
                snapshot.setEnabled(false);output.setText("Считываю контейнер…");
                Thread worker=new Thread(()->{
                    String result;
                    try{GameEngineProbe.run();result=GameEngineProbe.auctionSnapshot();}
                    finally{GameEngineProbe.end();}
                    String text=result;
                    activity.runOnUiThread(()->{if(!activity.isFinishing()&&!activity.isDestroyed()){snapshot.setEnabled(true);output.setText(text);}});
                },"auction-snapshot");worker.setDaemon(true);worker.start();
            });
        }
        if(entry.id.equals("fast_exp"))renderFastExpInterval();
        if (entry.callback != null&&!entry.id.equals("auto_buy")&&!entry.id.equals("aimbot")) renderToggle(entry);
        if(entry.id.equals("fast_exp")&&entry.callback!=null){
            TextView note=label("Использует только пузырьки опыта из руки. Открытие меню и другого окна не выключает модуль. Работает вместе с Auto Buy.",12);
            note.setTextColor(MUTED);details.addView(note);
            Button stats=button("Статус Fast Exp");details.addView(stats);
            TextView nativeState=label(FastExpBridge.describe(),12);nativeState.setTextColor(MUTED);details.addView(nativeState);
            stats.setOnClickListener(v->{String value=FastExpBridge.describe();nativeState.setText(value);GameRuntime.log(value);});
        }
        TextView state = label(entry.callback == null ? "Модуль ещё не подключён к игре" : entry.id.equals("fast_exp") ? "Мост установлен; работу проверяем в мире" : "Готов к работе", 13);
        state.setTextColor(entry.callback == null ? WARNING : ACCENT);state.setPadding(0, dp(12), 0, 0);details.addView(state);
        if (entry.id.equals("fast_exp") && entry.callback == null) {
            Button probe = button("Включить Fast Exp");
            details.addView(probe, new LinearLayout.LayoutParams(-1, dp(52)));
            TextView output = label("Подключение проверится автоматически в загруженном мире. Меню можно оставить открытым.", 12);
            output.setTextColor(MUTED);output.setPadding(0, dp(10), 0, 0);details.addView(output);
            probe.setOnClickListener(v -> {
                fastStart.cancel();
                if (!GameEngineProbe.begin()) {
                    Toast.makeText(activity, "Проверка уже выполняется", Toast.LENGTH_SHORT).show();return;
                }
                probe.setEnabled(false);output.setText("Включаю Fast Exp…");
                Thread worker = new Thread(() -> {
                    String result;
                    try { result = GameEngineProbe.run(); }
                    finally { GameEngineProbe.end(); }
                    activity.runOnUiThread(() -> {
                        if (activity.isFinishing() || activity.isDestroyed()) return;
                        probe.setEnabled(true);output.setText(result);
                        if(FastExpBridge.isReady()){
                            try{FastExpBridge.setEnabled(true);}
                            catch(RuntimeException|LinkageError error){GameRuntime.log("Fast Exp enable failed: "+error);}
                            renderModules();renderDetails();
                        }else output.setText("Не удалось подключиться. Войди в мир и нажми «Включить Fast Exp» ещё раз.\n"+result);
                    });
                }, "game-engine-probe");
                worker.setDaemon(true);worker.start();
            });
        }
    }
    private void renderFriendsSettings(){
        TextView hint=label("Добавить: .add Ник\nУдалить: .remove Ник\nРегистр букв не важен. Указывай сам ник без привилегии.",13);
        hint.setTextColor(MUTED);details.addView(hint);
        EditText command=new EditText(activity);command.setSingleLine(true);command.setTextColor(INK);command.setHintTextColor(MUTED);
        command.setHint(".add Ник / .remove Ник");
        command.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        command.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE|android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        command.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(64)});
        details.addView(command,new LinearLayout.LayoutParams(-1,dp(48)));
        Button submit=button("Выполнить");details.addView(submit,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView feedback=label("Команда выполняется локально в kulich.",12);feedback.setTextColor(MUTED);details.addView(feedback);
        friendsList=label(FriendStore.summary(),14);friendsList.setPadding(0,dp(14),0,0);details.addView(friendsList);
        Runnable execute=()->{
            try{feedback.setText(FriendStore.execute(command.getText().toString()));}
            catch(RuntimeException|LinkageError error){
                aimbot.setEnabled(false);Entry aim=entries.get("aimbot");if(aim!=null)aim.enabled=false;
                feedback.setText("Не удалось обновить защиту друзей. Aimbot выключен.");GameRuntime.log("Friend sync failed: "+error);
            }
            friendsList.setText(FriendStore.summary());renderModules();
        };
        submit.setOnClickListener(v->execute.run());
        command.setOnEditorActionListener((v,action,event)->{
            boolean enter=event!=null&&event.getKeyCode()==KeyEvent.KEYCODE_ENTER&&event.getAction()==KeyEvent.ACTION_UP;
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE||enter){execute.run();return true;}return false;
        });
    }
    private void renderFastExpInterval(){
        TextView caption=label("Интервал: "+FastExpBridge.tickInterval()+" тик(ов) на бросок",14);
        caption.setTextColor(INK);details.addView(caption);
        SeekBar slider=new SeekBar(activity);tintControl(slider);slider.setMax(9);slider.setProgress(FastExpBridge.tickInterval()-1);
        slider.setContentDescription("Интервал Fast Exp от 1 до 10 тиков");
        details.addView(slider,new LinearLayout.LayoutParams(-1,dp(44)));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int progress,boolean fromUser){
                if(!fromUser)return;
                int ticks=progress+1;FastExpBridge.setTickInterval(ticks);
                preferences.edit().putInt("fast_exp_ticks",ticks).apply();
                caption.setText("Интервал: "+ticks+" тик(ов) на бросок");
            }
            public void onStartTrackingTouch(SeekBar bar){}
            public void onStopTrackingTouch(SeekBar bar){GameRuntime.log("Fast Exp: interval="+FastExpBridge.tickInterval()+" game ticks");}
        });
    }
    private void renderAimbotSettings(){
        details.addView(label("Резкое наведение",16));
        TextView reach=label("Дистанция: "+aimRadius+" блоков",14);details.addView(reach);
        SeekBar range=new SeekBar(activity);range.setMax(4);range.setProgress(aimRadius-1);tintControl(range);details.addView(range,new LinearLayout.LayoutParams(-1,dp(44)));
        range.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean user){if(!user)return;aimRadius=v+1;AimbotBridge.settings(aimRadius,aimCpsMin,aimCpsMax);preferences.edit().putInt("aim.radius",aimRadius).apply();reach.setText("Дистанция: "+aimRadius+" блоков");}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        LinearLayout clicksCard=new LinearLayout(activity);clicksCard.setOrientation(LinearLayout.VERTICAL);
        clicksCard.setPadding(dp(14),dp(8),dp(14),dp(8));clicksCard.setBackground(background(CATEGORY,14));
        LinearLayout rateRow=new LinearLayout(activity);rateRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView rateTitle=label("CPS",15);rateRow.addView(rateTitle,new LinearLayout.LayoutParams(0,dp(34),1));
        TextView rate=label(cpsRangeLabel(),14);rate.setTypeface(Typeface.DEFAULT_BOLD);rate.setGravity(Gravity.CENTER);
        rate.setPadding(dp(10),0,dp(10),0);rate.setBackground(background(SELECTED,8));rateRow.addView(rate,new LinearLayout.LayoutParams(-2,dp(30)));
        clicksCard.addView(rateRow,new LinearLayout.LayoutParams(-1,-2));
        CpsRangeView clicks=new CpsRangeView(activity);clicks.setColors(ACCENT,LINE);clicks.setValues(aimCpsMin,aimCpsMax);
        clicksCard.addView(clicks,new LinearLayout.LayoutParams(-1,dp(48)));
        clicks.setListener((minimum,maximum)->{aimCpsMin=minimum;aimCpsMax=maximum;AimbotBridge.settings(aimRadius,aimCpsMin,aimCpsMax);preferences.edit().putInt("aim.cps.min",aimCpsMin).putInt("aim.cps.max",aimCpsMax).apply();rate.setText(cpsRangeLabel());});
        details.addView(clicksCard,new LinearLayout.LayoutParams(-1,-2));
        TextView rateHint=label("Левый круг — минимум, правый — максимум (1–40). Совмести круги, чтобы зафиксировать CPS.",12);rateHint.setTextColor(MUTED);details.addView(rateHint);
        details.addView(label("Дистанция задаёт наведение и попытки удара. Попадания и урон зависят от игры и сервера.",12));
        aimbotStatus=label(aimbot.displayStatus(),12);details.addView(aimbotStatus);
    }
    private String cpsRangeLabel(){return aimCpsMin==aimCpsMax?aimCpsMin+" · фикс.":aimCpsMin+" – "+aimCpsMax;}
    private void renderToggle(Entry entry) {
        if(entry.id.equals("fast_exp"))entry.enabled=FastExpBridge.isEnabled();
        Switch control = new Switch(activity);control.setText("Включить");control.setTextSize(17);control.setTextColor(INK);
        control.setChecked(entry.enabled);tintControl(control);details.addView(control, new LinearLayout.LayoutParams(-1, dp(48)));
        boolean[] reverting = {false};
        control.setOnCheckedChangeListener((button, enabled) -> {
            if (reverting[0] || entry.callback == null) return;
            if(entry.id.equals("fast_exp"))fastStart.cancel();
            try { entry.callback.setEnabled(enabled);entry.enabled = enabled;renderModules(); }
            catch (Exception | LinkageError error) {
                reverting[0] = true;control.setChecked(entry.enabled);reverting[0] = false;
                GameRuntime.log("Menu module failed: " + entry.id + " / " + error);
                Toast.makeText(activity, error.getMessage()==null?"Не удалось изменить модуль":error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private long lastFastLog;
    private final Runnable fastHeartbeat=new Runnable(){public void run(){
        if(activity.isFinishing()||activity.isDestroyed())return;
        Entry buy=entries.get("auto_buy");if(buy!=null&&buy.enabled!=autoBuy.isEnabled()){buy.enabled=autoBuy.isEnabled();renderModules();if("auto_buy".equals(selected))renderDetails();}
        Entry aim=entries.get("aimbot");if(aim!=null&&aim.enabled!=aimbot.isEnabled()){aim.enabled=aimbot.isEnabled();renderModules();if("aimbot".equals(selected))renderDetails();}
        if(autoBuyStatus!=null)autoBuyStatus.setText(autoBuy.status());
        if(aimbotStatus!=null)aimbotStatus.setText(aimbot.displayStatus());
        if(friendsList!=null)friendsList.setText(FriendStore.summary());
        FastExpBridge.heartbeat();
        AimbotBridge.heartbeat();
        targetHud.updateSnapshot(AimbotBridge.targetSnapshot());
        if(scripts!=null)scripts.tick();
        long now=android.os.SystemClock.uptimeMillis();
        if(fastStart.due(now,true)&&GameEngineProbe.begin()){
            fastStart.begin();
            Thread worker=new Thread(()->{
                try{GameEngineProbe.run();}
                catch(RuntimeException|LinkageError error){GameRuntime.log("Fast Exp startup failed: "+error);}
                finally{GameEngineProbe.end();}
                activity.runOnUiThread(()->{
                    boolean alive=!activity.isFinishing()&&!activity.isDestroyed();
                    if(fastStart.result(android.os.SystemClock.uptimeMillis(),GameEngineProbe.playerFound()&&FastExpBridge.isReady(),alive)){
                        try{FastExpBridge.setEnabled(true);renderModules();renderDetails();GameRuntime.log("Fast Exp: startup request enabled in verified world");}
                        catch(RuntimeException|LinkageError error){GameRuntime.log("Fast Exp startup enable failed: "+error);}
                    }
                });
            },"fast-exp-startup");worker.setDaemon(true);worker.start();
        }
        if(now-lastFastLog>3000){lastFastLog=now;if(FastExpBridge.isEnabled())GameRuntime.log(FastExpBridge.describe());if(aimbot.isEnabled())GameRuntime.log(aimbot.status());}
        root.postDelayed(this,400);
    }};
    private void toggle() { if (panel.getVisibility() == View.VISIBLE) close();else open(); }
    public void open() { shade.setVisibility(View.VISIBLE);panel.setVisibility(View.VISIBLE);floating.bringToFront(); }
    public void close() { panel.setVisibility(View.GONE);shade.setVisibility(View.GONE);floating.bringToFront(); }
    public void dispose() {
        fastStart.cancel();
        aimbot.dispose();autoBuy.dispose();auctionInput.dispose();
        if(scripts!=null){scripts.close();scripts=null;}
        root.removeCallbacks(fastHeartbeat);FastExpBridge.setEnabled(false);
        for (Entry entry : entries.values()) if (entry.enabled && entry.callback != null) {
            try { entry.callback.setEnabled(false);entry.enabled = false; }
            catch (Exception | LinkageError error) { GameRuntime.log("Menu module cleanup failed: " + entry.id + " / " + error); }
        }
        detach(root);
    }
    private void fit() {
        if (root.getWidth() == 0 || root.getHeight() == 0) return;
        FrameLayout.LayoutParams bounds = (FrameLayout.LayoutParams) panel.getLayoutParams();
        int width = menuWidth(root.getWidth() * widthRatio);
        int height = menuHeight(root.getHeight() * heightRatio);
        if (bounds.width != width || bounds.height != height) { bounds.width = width;bounds.height = height;panel.setLayoutParams(bounds); }
        boolean useWide = width >= dp(620);if (useWide != wide) arrange(useWide);
        iconDrag.apply();if (!resizing) panelDrag.apply();
    }
    private int menuWidth(float value) {
        int maximum = Math.max(1, root.getWidth() - dp(24));
        return Math.max(Math.min(dp(360), maximum), Math.min(Math.round(value), maximum));
    }
    private int menuHeight(float value) {
        int maximum = Math.max(1, root.getHeight() - dp(24));
        return Math.max(Math.min(dp(264), maximum), Math.min(Math.round(value), maximum));
    }
    private final class Resize {
        float rawX, rawY, anchorX, anchorY;int startWidth, startHeight, pointer = -1;
        boolean touch(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pointer = event.getPointerId(0);rawX = event.getRawX(0);rawY = event.getRawY(0);
                    anchorX = panel.getX();anchorY = panel.getY();startWidth = panel.getWidth();startHeight = panel.getHeight();
                    resizing = true;root.requestDisallowInterceptTouchEvent(true);return true;
                case MotionEvent.ACTION_MOVE: move(event);return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerId(event.getActionIndex()) == pointer) {
                        int next = event.getActionIndex() == 0 ? 1 : 0;pointer = event.getPointerId(next);
                        rawX = event.getRawX(next);rawY = event.getRawY(next);
                        startWidth = panel.getLayoutParams().width;startHeight = panel.getLayoutParams().height;
                    }
                    return true;
                case MotionEvent.ACTION_UP: move(event);finish();return true;
                case MotionEvent.ACTION_CANCEL: finish();return true;
                default: return true;
            }
        }
        void move(MotionEvent event) {
            int index = event.findPointerIndex(pointer);if (index < 0) return;
            int width = menuWidth(startWidth + event.getRawX(index) - rawX);
            int height = menuHeight(startHeight + event.getRawY(index) - rawY);
            // Limit growth to the space after the anchored top-left corner.
            width = Math.min(width, Math.max(1, (int) (root.getWidth() - anchorX)));
            height = Math.min(height, Math.max(1, (int) (root.getHeight() - anchorY)));
            widthRatio = width / (float) Math.max(1, root.getWidth());
            heightRatio = height / (float) Math.max(1, root.getHeight());
            FrameLayout.LayoutParams bounds = (FrameLayout.LayoutParams) panel.getLayoutParams();
            if (bounds.width != width || bounds.height != height) { bounds.width = width;bounds.height = height;panel.setLayoutParams(bounds); }
            panel.setX(anchorX);panel.setY(anchorY);
            panelDrag.x = anchorX / Math.max(1, root.getWidth() - width);
            panelDrag.y = anchorY / Math.max(1, root.getHeight() - height);
            boolean useWide = width >= dp(620);if (useWide != wide) arrange(useWide);
        }
        void finish() {
            pointer = -1;resizing = false;root.requestDisallowInterceptTouchEvent(false);
            preferences.edit().putFloat("panel.widthRatio", widthRatio).putFloat("panel.heightRatio", heightRatio).apply();
            panelDrag.save();
        }
    }
    private final class Drag {
        final View target;final String prefix;final Runnable tap;
        float x, y, rawX, rawY, startX, startY;int pointer = -1;boolean moved;
        Drag(View target, String prefix, float x, float y, Runnable tap) {
            this.target = target;this.prefix = prefix;this.tap = tap;
            this.x = preferences.getFloat(prefix + "x", x);this.y = preferences.getFloat(prefix + "y", y);
        }
        boolean touch(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pointer = event.getPointerId(0);rawX = event.getRawX(0);rawY = event.getRawY(0);
                    startX = target.getX();startY = target.getY();moved = false;root.requestDisallowInterceptTouchEvent(true);return true;
                case MotionEvent.ACTION_MOVE: move(event);return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerId(event.getActionIndex()) == pointer) {
                        int next = event.getActionIndex() == 0 ? 1 : 0;pointer = event.getPointerId(next);
                        rawX = event.getRawX(next);rawY = event.getRawY(next);startX = target.getX();startY = target.getY();moved = true;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    move(event);if (moved) save();else if (tap != null) tap.run();finish();return true;
                case MotionEvent.ACTION_CANCEL: if (moved) save();finish();return true;
                default: return true;
            }
        }
        void move(MotionEvent event) {
            int index = event.findPointerIndex(pointer);if (index < 0) return;
            float dx = event.getRawX(index) - rawX, dy = event.getRawY(index) - rawY;
            if (Math.hypot(dx, dy) > ViewConfiguration.get(activity).getScaledTouchSlop()) moved = true;
            if (!moved) return;
            int spanX = Math.max(0, root.getWidth() - target.getWidth()), spanY = Math.max(0, root.getHeight() - target.getHeight());
            target.setX(Math.max(0, Math.min(startX + dx, spanX)));target.setY(Math.max(0, Math.min(startY + dy, spanY)));
            if (spanX > 0) x = target.getX() / spanX;if (spanY > 0) y = target.getY() / spanY;
        }
        void apply() { target.setX(x * Math.max(0, root.getWidth() - target.getWidth()));target.setY(y * Math.max(0, root.getHeight() - target.getHeight())); }
        void save() { preferences.edit().putFloat(prefix + "x", x).putFloat(prefix + "y", y).apply(); }
        void finish() { pointer = -1;root.requestDisallowInterceptTouchEvent(false); }
    }
    private void setPalette(boolean light){
        lightTheme=light;
        palette=light?new int[]{0xff171717,0xff5c5c5c,0xff171717,0xfffafafa,0xffe4e4e4,0xfff0f0f0,0xffd6d6d6,0xffc7c7c7,0xffffffff,0xff806000}:
                new int[]{0xfff5f5f5,0xffababab,0xfff5f5f5,0xff101010,0xff292929,0xff1b1b1b,0xff383838,0xff444444,0xff151515,0xffd2b57b};
        INK=palette[0];MUTED=palette[1];ACCENT=palette[2];PANEL=palette[3];BUTTON=palette[4];CATEGORY=palette[5];SELECTED=palette[6];LINE=palette[7];ICON=palette[8];WARNING=palette[9];
    }
    private int remap(int color,int[] previous){for(int i=0;i<previous.length;i++)if(previous[i]==color)return palette[i];return color;}
    private void recolor(View view,int[] previous){
        if(view instanceof TextView){TextView text=(TextView)view;text.setTextColor(remap(text.getCurrentTextColor(),previous));}
        android.graphics.drawable.Drawable drawable=view.getBackground();
        if(drawable instanceof GradientDrawable){GradientDrawable shape=(GradientDrawable)drawable;android.content.res.ColorStateList color=shape.getColor();if(color!=null)shape.setColor(remap(color.getDefaultColor(),previous));}
        else if(drawable instanceof android.graphics.drawable.ColorDrawable){android.graphics.drawable.ColorDrawable color=(android.graphics.drawable.ColorDrawable)drawable;color.setColor(remap(color.getColor(),previous));}
        tintControl(view);
        if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++)recolor(group.getChildAt(i),previous);}
    }
    private void tintControl(View view){
        if(view instanceof CpsRangeView)((CpsRangeView)view).setColors(ACCENT,LINE);
        if(view instanceof Switch){Switch toggle=(Switch)view;
            toggle.setThumbTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{ACCENT,MUTED}));
            toggle.setTrackTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{SELECTED,LINE}));
        }
        if(view instanceof SeekBar){SeekBar bar=(SeekBar)view;bar.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));bar.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(LINE));}
    }
    private void changeTheme(boolean light){
        int[] previous=palette;setPalette(light);preferences.edit().putString("menu.theme",light?"white":"black").apply();
        recolor(root,previous);((GradientDrawable)floating.getBackground()).setStroke(dp(2),ACCENT);
        renderCategories();renderModules();renderDetails();GameRuntime.log("Menu theme: "+(light?"white":"black"));
    }
    private void renderThemeSettings(){
        Button white=button((lightTheme?"✓ ":"")+"Белая");details.addView(white,new LinearLayout.LayoutParams(-1,dp(52)));white.setOnClickListener(v->changeTheme(true));
        Button black=button((!lightTheme?"✓ ":"")+"Чёрная");details.addView(black,new LinearLayout.LayoutParams(-1,dp(52)));black.setOnClickListener(v->changeTheme(false));
        TextView hint=label("Тема меняется сразу: фон, текст, кнопки и круглая иконка kulich. Скрипт импортировать не нужно.",13);hint.setTextColor(MUTED);details.addView(hint);
    }
    private static void detach(View view) { if (view.getParent() instanceof ViewGroup) ((ViewGroup) view.getParent()).removeView(view); }
    private int dp(int value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }
    private TextView label(String text, int size) { TextView view = new TextView(activity);view.setText(text);view.setTextSize(size);view.setTextColor(INK);view.setGravity(Gravity.CENTER_VERTICAL);return view; }
    private Button button(String text) { Button view = new Button(activity);view.setText(text);view.setTextColor(INK);view.setTextSize(18);view.setAllCaps(false);view.setMinWidth(0);view.setMinimumWidth(0);view.setPadding(dp(4), 0, dp(4), 0);view.setBackground(background(BUTTON, 12));return view; }
    private View separator() { View view = new View(activity);view.setBackgroundColor(LINE);return view; }
    private GradientDrawable background(int color, int radius) { GradientDrawable shape = new GradientDrawable();shape.setColor(color);shape.setCornerRadius(dp(radius));return shape; }
}
