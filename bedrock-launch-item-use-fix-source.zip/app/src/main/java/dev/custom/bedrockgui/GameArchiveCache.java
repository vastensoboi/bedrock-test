package dev.custom.bedrockgui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Extracts ARM64 libraries only. Does not execute extracted code. */
public final class GameArchiveCache {
    public interface Progress { void update(String text); }
    public static final class Result {
        public final File directory;
        public final List<String> libraries;
        Result(File directory, List<String> libraries) {
            this.directory = directory; this.libraries = Collections.unmodifiableList(libraries);
        }
    }
    private static final long MAX_FILE = 512L * 1024 * 1024;
    private static final long MAX_TOTAL = 2L * 1024 * 1024 * 1024;
    private GameArchiveCache() {}
    public static Result prepare(List<File> apks, File cache, Progress progress) throws Exception {
        if (apks.isEmpty()) throw new IOException("Нет APK игры");
        if (!cache.isDirectory() && !cache.mkdirs()) throw new IOException("Не удалось создать кэш");
        Set<String> names = new LinkedHashSet<>();
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        for (File apk : apks) {
            if (!apk.isFile() || !apk.canRead()) throw new IOException("Недоступен APK: " + apk.getName());
            digest.update((apk.getCanonicalPath()+"\n"+apk.length()+"\n"+apk.lastModified()+"\n").getBytes(StandardCharsets.UTF_8));
        }
        StringBuilder key = new StringBuilder();
        for (byte b : digest.digest()) key.append(String.format(Locale.ROOT, "%02x", b & 255));
        File stage = Files.createTempDirectory(cache.toPath(), "stage-").toFile();
        File destination = new File(cache, "arm64-" + key);
        boolean moved = false;
        try {
            long total = 0;
            byte[] buffer = new byte[65536];
            for (File apk : apks) {
                try (ZipFile zip = new ZipFile(apk)) {
                    Enumeration<? extends ZipEntry> entries = zip.entries();
                    while (entries.hasMoreElements()) {
                        if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException("Проверка отменена");
                        ZipEntry entry = entries.nextElement();
                        if (entry.isDirectory() || !entry.getName().startsWith("lib/arm64-v8a/")) continue;
                        String name = entry.getName().substring("lib/arm64-v8a/".length());
                        if (!name.matches("[A-Za-z0-9_+.-]+\\.so")) continue;
                        if (!names.add(name)) throw new IOException("Повторяющаяся библиотека в APK: " + name);
                        if (entry.getSize() > MAX_FILE) throw new IOException("Слишком большая библиотека: " + name);
                        if (names.size() > 512) throw new IOException("Слишком много библиотек");
                        progress.update("Подготовка: " + name);
                        File output = new File(stage, name);
                        long bytes = 0;
                        CRC32 crc = new CRC32();
                        try (InputStream input = zip.getInputStream(entry); FileOutputStream stream = new FileOutputStream(output)) {
                            // Mark read-only before writing through the already open descriptor.
                            // This also follows Android's safer dynamic-code-loading file policy.
                            if (!output.setReadOnly()) throw new IOException("Не удалось защитить " + name);
                            int count;
                            while ((count = input.read(buffer)) != -1) {
                                if (Thread.currentThread().isInterrupted()) throw new InterruptedIOException("Проверка отменена");
                                bytes += count; total += count;
                                if (bytes > MAX_FILE || total > MAX_TOTAL) throw new IOException("Превышен лимит распаковки");
                                stream.write(buffer, 0, count); crc.update(buffer, 0, count);
                            }
                            stream.getFD().sync();
                        }
                        if (entry.getSize() >= 0 && entry.getSize() != bytes) throw new IOException("Размер не совпал: " + name);
                        if (entry.getCrc() >= 0 && entry.getCrc() != crc.getValue()) throw new IOException("CRC не совпала: " + name);
                        validateArm64(output);
                    }
                }
            }
            if (!names.contains("libminecraftpe.so")) throw new IOException("ARM64 libminecraftpe.so не найдена в APK и split APK");
            // Re-extract each run; avoid silently trusting a previous interrupted or stale cache.
            if (destination.exists()) remove(destination);
            try { Files.move(stage.toPath(), destination.toPath(), StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(stage.toPath(), destination.toPath()); }
            moved = true;
            return new Result(destination, new ArrayList<>(names));
        } finally { if (!moved) remove(stage); }
    }
    public static void validateArm64(File file) throws IOException {
        byte[] head = new byte[64];
        try (DataInputStream stream = new DataInputStream(new FileInputStream(file))) { stream.readFully(head); }
        if (head[0] != 0x7f || head[1] != 'E' || head[2] != 'L' || head[3] != 'F' ||
                head[4] != 2 || head[5] != 1 || head[6] != 1 || head[16] != 3 || head[17] != 0 ||
                (head[18] & 255) != 183 || head[19] != 0 || head[52] != 64 || head[53] != 0) {
            throw new IOException("Не ELF64 ARM64: " + file.getName());
        }
    }
    public static void clear(File cache) throws IOException { if (cache.exists()) remove(cache); }
    private static void remove(File file) throws IOException {
        if (Files.isDirectory(file.toPath(), LinkOption.NOFOLLOW_LINKS)) {
            File[] children = file.listFiles();
            if (children == null) throw new IOException("Не удалось прочитать каталог кэша");
            for (File child : children) remove(child);
        }
        Files.deleteIfExists(file.toPath());
    }
}
