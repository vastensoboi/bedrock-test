#include "fast_exp_core.h"
#include <jni.h>
#include <atomic>
#include <mutex>
#include <chrono>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cerrno>
#include <string>
namespace {
using kulich::Address;
using Tick=void(*)(void*);
using Use=bool(*)(void*,void*,bool);
std::atomic<Address> gameBase{0},boundClient{0};
std::atomic<bool> enabled{false};
std::atomic<int64_t> lease{0},lastUse{0};
std::atomic<uint64_t> ticks{0},attempts{0},returnedTrue{0};
std::atomic<int> lastSlot{-1},lastCount{0};
int memory=-1;Tick baseTick=nullptr,survivalTick=nullptr;
std::mutex installMutex,callMutex;
int64_t millis(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(Address at,void* dest,size_t size){
 at=kulich::untag(at);
 if(memory<0||at<4096||size>65536||at>0x00ffffffffffffffULL-size)return false;
 ssize_t n;do{n=pread(memory,dest,size,static_cast<off_t>(at));}while(n<0&&errno==EINTR);
 return n==static_cast<ssize_t>(size);
}
void act(void* mode){
 ticks.fetch_add(1,std::memory_order_relaxed);
 int64_t now=millis();
 if(!enabled.load(std::memory_order_acquire)||now>lease.load()||now-lastUse.load()<150)return;
 std::unique_lock<std::mutex> lock(callMutex,std::try_to_lock);if(!lock.owns_lock())return;
 auto read=readMemory;auto base=gameBase.load();
 auto held=kulich::resolve(read,base,boundClient.load(),reinterpret_cast<Address>(mode));
 if(!held.stack)return;
 // The mode and player belong to the engine tick that invoked this callback.
 // No cached object or Java worker thread is used to call useItem.
 if(!enabled.load()||millis()>lease.load())return;
 Address table=0;if(!readMemory(reinterpret_cast<Address>(mode),&table,8))return;
 auto use=reinterpret_cast<Use>(table==base+0x13d227d0ULL?base+0x100a0060ULL:base+0x100a142cULL);
 lastUse.store(now);lastSlot.store(held.slot);lastCount.store(held.count);attempts.fetch_add(1);
 if(use(mode,reinterpret_cast<void*>(held.stack),false))returnedTrue.fetch_add(1);
}
void tickBase(void* self){baseTick(self);act(self);}
void tickSurvival(void* self){survivalTick(self);act(self);}
std::string install(Address base,Address client){
 std::lock_guard<std::mutex> guard(installMutex);
 if(gameBase.load()){if(gameBase.load()!=base)return "Game library base changed";boundClient.store(client);return {};}
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0)return "Cannot open own process memory";
 Address cv=0;if(!readMemory(client,&cv,8)||cv!=base+0x1388fe70ULL)return "Client type mismatch";
 Address a=base+0x13d227d0ULL+80,b=base+0x13d22900ULL+80;
 Address originalA=0,originalB=0,useA=0,useB=0;
 if(!readMemory(a,&originalA,8)||!readMemory(b,&originalB,8)||
    !readMemory(a+16,&useA,8)||!readMemory(b+16,&useB,8)||
    originalA!=base+0x100a0ad8ULL||originalB!=base+0x100a14b8ULL||
    useA!=base+0x100a0060ULL||useB!=base+0x100a142cULL)return "GameMode function profile mismatch";
 long pageSize=sysconf(_SC_PAGESIZE);if(pageSize<=0)return "Invalid page size";
 Address page=a-a%pageSize;if(b<page||b+8>page+static_cast<Address>(pageSize))return "Unexpected vtable pages";
 // Require the expected read-only, non-executable game mapping before changing
 // only its two tick entries. The original entries are saved before publishing.
 FILE* maps=fopen("/proc/self/maps","r");if(!maps)return "Cannot inspect vtable mapping";
 char line[2048],perms[5]={};unsigned long long lo,hi;bool found=false;
 while(fgets(line,sizeof(line),maps)){
  if(sscanf(line,"%llx-%llx %4s",&lo,&hi,perms)==3&&page>=lo&&page+pageSize<=hi){
   found=perms[0]=='r'&&perms[1]=='-'&&perms[2]=='-'&&std::string(line).find("/libminecraftpe.so")!=std::string::npos;break;
  }
 }
 fclose(maps);if(!found)return "Unexpected vtable mapping permissions";
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ|PROT_WRITE))return "Cannot update tick table";
 baseTick=reinterpret_cast<Tick>(originalA);survivalTick=reinterpret_cast<Tick>(originalB);
 boundClient.store(client);gameBase.store(base);
 __atomic_store_n(reinterpret_cast<Address*>(a),reinterpret_cast<Address>(&tickBase),__ATOMIC_RELEASE);
 __atomic_store_n(reinterpret_cast<Address*>(b),reinterpret_cast<Address>(&tickSurvival),__ATOMIC_RELEASE);
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ)){
  __atomic_store_n(reinterpret_cast<Address*>(a),originalA,__ATOMIC_RELEASE);
  __atomic_store_n(reinterpret_cast<Address*>(b),originalB,__ATOMIC_RELEASE);
  gameBase.store(0);return "Cannot restore vtable read-only protection";
 }
 return {};
}
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_FastExpBridge_install(JNIEnv* env,jclass,jlong base,jlong client){
 auto error=install(static_cast<Address>(base),static_cast<Address>(client));return env->NewStringUTF(error.c_str());
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_FastExpBridge_enable(JNIEnv*,jclass,jboolean value){
 enabled.store(value);lease.store(0);lastUse.store(0);
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_FastExpBridge_pulse(JNIEnv*,jclass,jboolean active){lease.store(active?millis()+1200:0);}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_FastExpBridge_status(JNIEnv* env,jclass){
 char text[256];snprintf(text,sizeof(text),"Fast Exp: enabled=%d ticks=%llu useItem calls=%llu returnedTrue=%llu slot=%d count=%d",
 enabled.load(),static_cast<unsigned long long>(ticks.load()),static_cast<unsigned long long>(attempts.load()),
 static_cast<unsigned long long>(returnedTrue.load()),lastSlot.load(),lastCount.load());return env->NewStringUTF(text);
}
