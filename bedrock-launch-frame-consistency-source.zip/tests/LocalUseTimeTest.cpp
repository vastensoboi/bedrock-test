#include "../app/src/main/cpp/local_use_time_core.h"
#include <cassert>
#include <iostream>
#include <vector>
using namespace kulich_use_timer;
struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;
 std::vector<uint8_t> bytes=std::vector<uint8_t>(0x50000);A next=root+0x10000;
 template<class T>void put(A at,T value){at=plain(at);assert(at>=root&&at-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+at-root,&value,sizeof value);}
 A alloc(size_t n){A at=next;next=(next+n+7)&~A(7);assert(next-root<bytes.size());return at;}
 bool operator()(A at,void* out,size_t n){at=plain(at);if(at<root||at-root>bytes.size()||n>bytes.size()-(at-root))return false;std::memcpy(out,bytes.data()+at-root,n);return true;}
};
struct Storage {A pool=0,sparse=0;};
Storage makeStorage(Memory& m,uint32_t entity,unsigned stride){
 Storage s{};s.pool=m.alloc(104);s.sparse=m.alloc(8192);A pages=m.alloc(8),payloads=m.alloc(8),payload=m.alloc(128*stride);
 std::memset(m.bytes.data()+s.sparse-Memory::root,255,8192);
 m.put(pages,s.sparse|Memory::tag);m.put(s.pool+8,pages);m.put(s.pool+16,pages+8);m.put(s.sparse+(entity&2047)*4,entity&0xfffc0000U);
 m.put(payloads,payload|Memory::tag);m.put(s.pool+80,payloads);m.put(s.pool+88,payloads+8);m.put(s.pool+96,payloads+8);return s;
}
struct Fixture {
 static constexpr A base=0x10000000,client=Memory::root+0x1000,registry=Memory::root+0x3000,actorAddress=Memory::root+0x5000,adapter=Memory::root+0x7000,entityPointer=Memory::root+0x8000;
 static constexpr uint32_t entity=0x40001;
 Memory m;std::array<Storage,5> stores{};A payload=0;
 uint32_t keys[5]{OWNER,ITEM_USE,USE_DURING_MOVEMENT,MOVEMENT_TICK,ACTOR_TICK};
 Fixture(){
  unsigned strides[]{8,16,1,1,1};for(int i=0;i<5;i++)stores[i]=makeStorage(m,entity,strides[i]);
  A buckets=m.alloc(64),nodes=m.alloc(5*32);for(int i=0;i<8;i++)m.put<int64_t>(buckets+i*8,-1);
  for(int i=0;i<5;i++){int64_t previous=-1;m(buckets+(keys[i]&7)*8,&previous,8);m.put(nodes+i*32,previous);m.put(nodes+i*32+8,keys[i]);m.put(nodes+i*32+16,stores[i].pool);m.put<int64_t>(buckets+(keys[i]&7)*8,i);}
  m.put(registry+96,buckets);m.put(registry+104,buckets+64);m.put(registry+120,nodes);m.put(registry+128,nodes+5*32);
  A entityPages=m.alloc(8),entitySparse=m.alloc(8192);m.put(entityPages,entitySparse);m.put(registry+216,entityPages);m.put(registry+224,entityPages+8);m.put(entitySparse+(entity&2047)*4,entity&0xfffc0000U);
  m.put(client,base+0x1388fe70ULL);m.put(client+576,std::array<A,3>{registry,Memory::root+0x9000,entity});
  m.put(actorAddress,base+0x139f6ea0ULL);m.put(actorAddress+8,registry);m.put(actorAddress+16,registry+40);m.put(actorAddress+24,entity);m.put(actorAddress+3240,client);m.put<uint8_t>(actorAddress+617,0);
  m.put(component(m,stores[0].pool,entity,8),actorAddress|Memory::tag);
  payload=taggedComponent(m,stores[1].pool,entity,16);UseState state{};state.prefix[0]=7;state.remaining=110;state.suffix=99;m.put(payload,state);
  m.put(adapter,base+hooks[0].table);m.put(adapter+8,registry);m.put(entityPointer,entity);
 }
 void member(int index,bool value){m.put(stores[index].sparse+(entity&2047)*4,value?entity&0xfffc0000U:uint32_t(0xffffffffU));}
 void remaining(int value){m.put(payload+8,int32_t(value));}
 int remaining(){int32_t value=-1;assert(m(payload+8,&value,4));return value;}
};
int main(){
 Fixture f;Binding binding{};
 auto movement=[&](Binding& out){return resolve(f.m,Fixture::base,Fixture::client,Fixture::adapter,Fixture::entityPointer,Phase::Movement,out);};
 auto before=f.m.bytes;
 assert(movement(binding)&&binding.payload==f.payload&&binding.state.remaining==110&&f.m.bytes==before);
 assert(resolve(f.m,Fixture::base,Fixture::client,Fixture::adapter,0,Phase::Movement,binding));
 f.m.put(Fixture::entityPointer,Fixture::entity+1);assert(!movement(binding));f.m.put(Fixture::entityPointer,Fixture::entity);
 f.member(3,false);assert(!movement(binding));f.member(3,true);
 f.m.put(Fixture::adapter,Fixture::base+hooks[1].table);
 assert(!resolve(f.m,Fixture::base,Fixture::client,Fixture::adapter,0,Phase::Ordinary,binding));
 f.member(2,false);assert(resolve(f.m,Fixture::base,Fixture::client,Fixture::adapter,0,Phase::Ordinary,binding));
 f.member(4,false);assert(!resolve(f.m,Fixture::base,Fixture::client,Fixture::adapter,0,Phase::Ordinary,binding));f.member(4,true);f.member(2,true);f.m.put(Fixture::adapter,Fixture::base+hooks[0].table);
 f.m.put(Fixture::actorAddress,Fixture::base+0x139f76b0ULL);assert(!movement(binding));f.m.put(Fixture::actorAddress,Fixture::base+0x139f6ea0ULL);
 f.m.put(Fixture::actorAddress+3240,Fixture::client+8);assert(!movement(binding));f.m.put(Fixture::actorAddress+3240,Fixture::client);
 f.m.put<uint8_t>(Fixture::actorAddress+617,1);assert(!movement(binding));f.m.put<uint8_t>(Fixture::actorAddress+617,0);
 f.remaining(-1);assert(!movement(binding));f.remaining(72001);assert(!movement(binding));
 // Each original callback runs once, and only this player's counter receives
 // extra progression. A second observed actor retains the ordinary cadence.
 int calls=0,writes=0,remoteRemaining=1000;bool failWrite=false;
 auto write=[&](A at,int32_t value){assert(at==f.payload+8&&(at&0xff00000000000000ULL)==Memory::tag);if(failWrite)return false;++writes;f.m.put(at,value);return true;};
 auto original=[&](){++calls;if(f.remaining()>0)f.remaining(f.remaining()-1);--remoteRemaining;};
 UseClock clock;
 f.remaining(110);unsigned added=0;while(f.remaining()>0){added+=invoke(clock,write,movement,original,true,110);assert(calls<200);}
 assert(calls==100&&added==10&&writes==10&&remoteRemaining==900);
 // Both native phase adapters run, but only one selects this player. Calls
 // for an excluded phase/foreign entity must not erase fractional progress.
 clock.reset();calls=writes=0;f.remaining(110);added=0;int foreignCalls=0;
 auto excluded=[](Binding&){return false;};
 while(f.remaining()>0){
  added+=invoke(clock,write,movement,original,true,110);
  assert(invoke(clock,write,excluded,[&](){++foreignCalls;},true,110)==0);
 }
 assert(calls==100&&foreignCalls==100&&added==10&&writes==10);
 clock.reset();calls=writes=0;f.remaining(100);while(f.remaining()>0)invoke(clock,write,movement,original,true,200);assert(calls==50&&writes==50);
 clock.reset();calls=writes=0;f.remaining(100);while(f.remaining()>0)invoke(clock,write,movement,original,true,100);assert(calls==100&&writes==0);
 // Preserve the engine's own zero transition; never jump to a negative count.
 clock.reset();calls=writes=0;f.remaining(1);assert(invoke(clock,write,movement,original,true,200)==0&&f.remaining()==0&&calls==1&&writes==0);
 f.remaining(0);assert(invoke(clock,write,movement,original,true,200)==0&&f.remaining()==0);
 // Failed writes and disabled state do not accrue a later catch-up burst.
 clock.reset();f.remaining(10);failWrite=true;assert(invoke(clock,write,movement,original,true,200)==0&&f.remaining()==9);failWrite=false;
 assert(invoke(clock,write,movement,original,false,200)==0&&f.remaining()==8);
 // New use identities or reset counts discard prior fractional progress.
 clock.reset();f.remaining(20);for(int i=0;i<9;i++)assert(invoke(clock,write,movement,original,true,110)==0);
 UseState changed{};assert(f.m(f.payload,&changed,sizeof changed));changed.prefix[0]++;changed.remaining=20;f.m.put(f.payload,changed);
 assert(invoke(clock,write,movement,original,true,110)==0&&f.remaining()==19);
 clock.reset();f.remaining(20);for(int i=0;i<9;i++)assert(invoke(clock,write,movement,original,true,110)==0);f.remaining(40);
 assert(invoke(clock,write,movement,original,true,110)==0&&f.remaining()==39);
 // On an exception restore only an unconsumed injected value in the same
 // live component. An engine-changed counter is never overwritten.
 clock.reset();f.remaining(10);bool threw=false;
 try{invoke(clock,write,movement,[](){throw 7;},true,200);}catch(int){threw=true;}
 assert(threw&&f.remaining()==10);
 clock.reset();f.remaining(10);threw=false;
 try{invoke(clock,write,movement,[&](){f.remaining(4);throw 8;},true,200);}catch(int){threw=true;}
 assert(threw&&f.remaining()==4);
 std::cout<<"PASS: own-use duration progress, fractional 1.10 and 2.00 cadence, native zero completion, movement/ordinary filters, remote isolation, tagged writes, identity resets and failure guards\n";
}
