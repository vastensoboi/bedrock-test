#pragma once
#include <atomic>
#include <cstdint>

namespace kulich_own_step {
// Admission only: this neither waits for a callback nor schedules native work.
// The caller must end every entered reader and every admitted replay exactly
// once. Active callback counts must remain below 2^63 (the exclusive bit).
class InputGate {
 static constexpr uint64_t exclusive=uint64_t(1)<<63,readers=exclusive-1;
 static_assert(std::atomic<uint64_t>::is_always_lock_free,"Input admission requires lock-free uint64 atomics");
 std::atomic<uint64_t> state_{0},epoch_{1},exhausted_{0};
 uint64_t advanceEpoch()noexcept{
  uint64_t previous=epoch_.fetch_add(1,std::memory_order_acq_rel);
  if(previous==UINT64_MAX)exhausted_.store(1,std::memory_order_release);
  return previous+1;
 }
public:
 struct Admission {bool entered=false,replay=false;uint64_t token=0;};
 uint64_t epoch()const noexcept{
  return exhausted_.load(std::memory_order_acquire)?0:epoch_.load(std::memory_order_acquire);
 }
 Admission beginInput()noexcept{
  // fetch_add has no reader-versus-reader CAS loss. Even a rejected reader
  // keeps its temporary count until its epoch update has become visible.
  uint64_t previous=state_.fetch_add(1,std::memory_order_acq_rel);
  uint64_t token=advanceEpoch();
  if(previous&exclusive){state_.fetch_sub(1,std::memory_order_release);return {false,true,0};}
  return {true,false,token};
 }
 void endInput()noexcept{state_.fetch_sub(1,std::memory_order_release);}
 bool tryBeginReplay(uint64_t expectedEpoch)noexcept{
  if(!expectedEpoch||exhausted_.load(std::memory_order_acquire))return false;
  uint64_t expected=0;
  if(!state_.compare_exchange_strong(expected,exclusive,std::memory_order_acq_rel,std::memory_order_relaxed))return false;
  if(exhausted_.load(std::memory_order_acquire)||epoch_.load(std::memory_order_acquire)!=expectedEpoch){
   endReplay();return false;
  }
  return true;
 }
 void endReplay()noexcept{
  // A rejected reader may still be between fetch_add and fetch_sub. Clearing
  // only the exclusive bit preserves that count; storing zero would lose it.
  state_.fetch_and(readers,std::memory_order_release);
 }
};
}
