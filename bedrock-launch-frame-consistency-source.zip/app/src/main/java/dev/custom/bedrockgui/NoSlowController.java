package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

/** World preparation never enables Aimbot; menu/focus changes retain the toggle. */
public final class NoSlowController {
    private final Activity activity;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean requested,preparing,disposed;
    private int generation;
    private String message="Выключен";
    public NoSlowController(Activity activity){this.activity=activity;}
    public boolean isEnabled(){return requested;}
    public String status(){return !requested||!NoSlowBridge.isReady()?message:NoSlowBridge.describe();}
    public String displayStatus(){return status().split("\n",2)[0];}
    public void setEnabled(boolean value){
        if(disposed)return;
        generation++;requested=value;handler.removeCallbacksAndMessages(null);
        if(!value){NoSlowBridge.setEnabled(false);message="Выключен";return;}
        if(NoSlowBridge.isReady()){
            try{NoSlowBridge.setEnabled(true);}
            catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить No Slow. Причина в журнале";throw error;}
            return;
        }
        message="Подключаю No Slow. Нужен загруженный мир";prepare(generation);
    }
    private void prepare(int epoch){
        if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
        if(preparing||!GameEngineProbe.begin()){handler.postDelayed(()->prepare(epoch),400);return;}
        preparing=true;
        Thread worker=new Thread(()->{
            try{GameEngineProbe.run();}
            catch(RuntimeException|LinkageError error){GameRuntime.log("No Slow preparation failed: "+error);}
            finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{
                preparing=false;
                if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
                if(GameEngineProbe.playerFound()&&NoSlowBridge.isReady()){
                    try{NoSlowBridge.setEnabled(true);}
                    catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить No Slow. Причина в журнале";GameRuntime.log("No Slow enable failed: "+error);}
                }else if(GameEngineProbe.playerFound()){
                    requested=false;message="No Slow не подключился. Причина в журнале";
                }else{
                    message="Войди в мир: No Slow подключится автоматически";handler.postDelayed(()->prepare(epoch),8000);
                }
            });
        },"no-slow-prepare");worker.setDaemon(true);worker.start();
    }
    public void dispose(){setEnabled(false);disposed=true;handler.removeCallbacksAndMessages(null);}
}
