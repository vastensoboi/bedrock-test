#pragma once
#include "aim_core.h"
namespace kulich_noslow {
using namespace kulich_aim;
constexpr uint32_t MODIFIER=0x867fc92cU,MOVE_INPUT=0x018b1887U,GAMEPLAY=0xa406686eU;
constexpr A ADAPTER_TABLE=0x13aca618ULL,BULK=0xc127284ULL,SINGLE=0xc127a54ULL;
struct Binding {A registry=0,actor=0,payload=0;uint32_t entity=0xffffffffU;float factor=1;};
template<class Read> bool resolve(Read& read,A base,A client,A adapter,A entityPointer,Binding& out){
 out={};adapter=plain(adapter);client=plain(client);
 if(pointer(read,client)!=base+0x1388fe70ULL||pointer(read,adapter)!=base+ADAPTER_TABLE)return false;
 A weak[3]{};if(!read(client+576,weak,sizeof weak)||!plain(weak[0])||!plain(weak[1]))return false;
 A registry=plain(weak[0]);uint32_t entity=uint32_t(weak[2]);
 if(pointer(read,adapter+8)!=registry||(entityPointer&&integer(read,plain(entityPointer))!=entity))return false;
 View v=view(read,registry);A owner=component(read,v.owners,entity,8);Actor local{};
 if(!owner||!actor(read,base,v,pointer(read,owner),true,local)||local.entity!=entity||pointer(read,local.address+3240)!=client)return false;
 A modifierPool=pool(read,registry,MODIFIER);
 A payload=taggedComponent(read,modifierPool,entity,4);
 if(!payload||(plain(payload)&3)||!component(read,pool(read,registry,MOVE_INPUT),entity,100)||!component(read,pool(read,registry,GAMEPLAY),entity,80))return false;
 float factor=1;if(!read(plain(payload),&factor,4)||!std::isfinite(factor)||factor<0||factor>1)return false;
 out={registry,local.address,payload,entity,factor};return true;
}
// Scoped single-float override. All original movement/use logic still runs;
// restore only the same live component and only if the engine left it at 1.
template<class Read,class Write,class Lookup,class Original>
bool invoke(Read& read,Write& write,Lookup lookup,Original original,bool enabled){
 Binding before{};bool changed=enabled&&lookup(before)&&before.factor<1&&write(before.payload,1.0f);
 auto restore=[&](){
  if(!changed)return;
  Binding after{};float current=0;
  if(lookup(after)&&after.registry==before.registry&&after.actor==before.actor&&after.entity==before.entity&&after.payload==before.payload&&
     read(plain(after.payload),&current,4)&&current==1.0f)write(before.payload,before.factor);
 };
 try{original();}catch(...){restore();throw;}
 restore();return changed;
}
}
