#pragma once
#include "aim_core.h"

namespace kulich_static_items {
using namespace kulich_aim;
constexpr A RENDERER_TABLE=0x139d57d8ULL,ITEM_ACTOR_TABLE=0x13d4e468ULL,RENDER=0xab71828ULL;
constexpr A PRESENTATION_FLAG=1112;
constexpr A BLOCK_GETTER=0x10777338ULL;
struct Binding {
 A client=0,registry=0,actor=0,renderer=0,renderData=0,flag=0;
 uint32_t entity=0xffffffffU;
 uint8_t value=0;
};

// ActorRenderData owns a pointer to the live, registered ItemActor. Preserve
// that pointer's memory tag for the scoped byte write; reads use plain addresses.
// The exact-build flag gates native item presentation, not world simulation.
template<class Read> bool resolve(Read& read,A base,A client,A renderer,A renderData,Binding& out){
 out={};client=plain(client);
 if(!base||client<4096||plain(renderer)<4096||plain(renderData)<4096||
    pointer(read,client)!=base+0x1388fe70ULL||pointer(read,renderer)!=base+RENDERER_TABLE)return false;
 A weak[3]{};
 if(!read(client+576,weak,sizeof weak)||plain(weak[0])<4096||!plain(weak[1]))return false;
 A registry=plain(weak[0]);uint32_t localEntity=uint32_t(weak[2]);
 if((localEntity&0x3ffffU)==0x3ffffU||sparse(read,registry+216,localEntity)<0)return false;
 A rawActor=0;
 if(!read(plain(renderData),&rawActor,8)||plain(rawActor)<4096)return false;
 A address=plain(rawActor),header[4]{};
 if(!read(address,header,sizeof header)||plain(header[0])!=base+ITEM_ACTOR_TABLE||
    plain(header[1])!=registry||plain(header[2])!=registry+40)return false;
 uint32_t entity=uint32_t(header[3]);
 if((entity&0x3ffffU)==0x3ffffU||entity==localEntity||sparse(read,registry+216,entity)<0)return false;
 uint8_t removed=1,flag=0;
 if(!read(address+617,&removed,1)||removed||!read(address+PRESENTATION_FLAG,&flag,1)||flag>1)return false;
 A owners=pool(read,registry,OWNER),owner=component(read,owners,entity,8);
 if(!owner||pointer(read,owner)!=address)return false;
 // Bind to the current local player's world; stale menu/previous-world
 // render data must not become writable merely because its vptr matches.
 A localOwner=component(read,owners,localEntity,8),local=pointer(read,localOwner),localHeader[4]{};
 if(!localOwner||!local||!read(local,localHeader,sizeof localHeader)||
    plain(localHeader[0])!=base+0x139f6ea0ULL||plain(localHeader[1])!=registry||
    plain(localHeader[2])!=registry+40||uint32_t(localHeader[3])!=localEntity||
    pointer(read,local+3240)!=client)return false;
 uint8_t localRemoved=1;
 if(!read(local+617,&localRemoved,1)||localRemoved)return false;
 A currentWeak[3]{},currentActor=0;
 if(!read(client+576,currentWeak,sizeof currentWeak)||std::memcmp(weak,currentWeak,sizeof weak)||
    !read(plain(renderData),&currentActor,8)||currentActor!=rawActor)return false;
 out={client,registry,rawActor,renderer,renderData,rawActor+PRESENTATION_FLAG,entity,flag};return true;
}

inline bool same(const Binding& a,const Binding& b){
 return a.client==b.client&&a.registry==b.registry&&a.actor==b.actor&&a.renderer==b.renderer&&
        a.renderData==b.renderData&&a.flag==b.flag&&a.entity==b.entity;
}

// The engine draws exactly once. Never retain an ItemActor pointer or modify
// age, position, velocity, inventory or pickup. Restore only the same live
// binding, and only if the engine left our byte unchanged.
template<class Write,class Lookup,class Original>
bool invoke(Write& write,Lookup lookup,Original original,bool enabled){
 Binding before{};
 bool changed=enabled&&lookup(before)&&before.value==0&&write(before.flag,uint8_t(1));
 auto restore=[&](){
  if(!changed)return;
  Binding after{};
  if(lookup(after)&&same(before,after)&&after.value==1)write(before.flag,before.value);
 };
 try{original();}catch(...){restore();throw;}
 restore();return changed;
}

// ItemRenderer uses ActorRenderData+16 as its translation, not the actor's
// world position. Its model MatrixStack is reached by the verified getter
// 0xae04bb0: context+40 -> object+24 -> MatrixStack+72. The top-entry layout
// and dirty byte are proved by 0x11a191e4..234 and 0x11a199ac.
struct MatrixBinding {
 A context=0,contextOwner=0,viewOwner=0,stack=0,map=0,mapEnd=0,page=0,matrix=0;
 A start=0,size=0;
 std::array<float,16> value{};
 std::array<float,3> position{};
};
template<class Read> A rawPointer(Read& read,A at){A value=0;return read(plain(at),&value,8)&&plain(value)>=4096?value:0;}
inline bool validMatrix(const std::array<float,16>& matrix){
 for(float value:matrix)if(!std::isfinite(value)||std::abs(value)>1e8f)return false;
 if(std::abs(matrix[3])>.001f||std::abs(matrix[7])>.001f||std::abs(matrix[11])>.001f||std::abs(matrix[15]-1)>.001f)return false;
 double determinant=double(matrix[0])*(double(matrix[5])*matrix[10]-double(matrix[9])*matrix[6])-
  double(matrix[4])*(double(matrix[1])*matrix[10]-double(matrix[9])*matrix[2])+
  double(matrix[8])*(double(matrix[1])*matrix[6]-double(matrix[5])*matrix[2]);
 return std::isfinite(determinant)&&std::abs(determinant)>1e-12&&std::abs(determinant)<1e12;
}
template<class Read> bool matrixBinding(Read& read,A context,A renderData,MatrixBinding& out){
 out={};if(plain(context)<4096||plain(renderData)<4096)return false;
 A owner=rawPointer(read,plain(context)+40),view=owner?rawPointer(read,plain(owner)+24):0;
 if(!view||plain(view)>0x00ffffffffffff00ULL)return false;
 A stack=view+72,header[5]{};
 if(!read(plain(stack)+8,header,sizeof header))return false;
 A map=plain(header[0]),end=plain(header[1]),start=header[3],size=header[4];
 if(!map||end<map||(end-map)%8||(end-map)/8>4096||!size||size>4096||
    start>262144||size>262144-start)return false;
 A index=start+size-1;if((index>>6)>=(end-map)/8)return false;
 A page=rawPointer(read,map+(index>>6)*8);if(!page)return false;
 A matrix=page+(index&63)*64;
 if(plain(matrix)&3)return false;
 MatrixBinding value{context,owner,view,stack,header[0],header[1],page,matrix,start,size,{},{}};
 if(!read(plain(matrix),value.value.data(),sizeof value.value)||!validMatrix(value.value)||
    !read(plain(renderData)+16,value.position.data(),sizeof value.position))return false;
 for(float p:value.position)if(!std::isfinite(p)||std::abs(p)>32000000)return false;
 A again[5]{};
 if(!read(plain(stack)+8,again,sizeof again)||std::memcmp(header,again,sizeof header)||
    rawPointer(read,plain(context)+40)!=owner||rawPointer(read,plain(owner)+24)!=view||
    rawPointer(read,map+(index>>6)*8)!=page)return false;
 out=value;return true;
}
inline bool sameMatrix(const MatrixBinding& a,const MatrixBinding& b){
 return a.context==b.context&&a.contextOwner==b.contextOwner&&a.viewOwner==b.viewOwner&&a.stack==b.stack&&
  a.map==b.map&&a.mapEnd==b.mapEnd&&a.page==b.page&&a.matrix==b.matrix&&a.start==b.start&&a.size==b.size;
}
// Rotate only the flat item's draw basis by -90 degrees about local X. The
// conjugated translation keeps the exact camera-relative render pivot fixed:
// M' * T(p) = M * T(p) * Rx(-90). No physical position or ground Y is changed.
inline bool flatMatrix(const MatrixBinding& binding,std::array<float,16>& result){
 if(!validMatrix(binding.value))return false;
 const auto& m=binding.value;double px=binding.position[0],py=binding.position[1],pz=binding.position[2];
 if(!std::isfinite(px)||!std::isfinite(py)||!std::isfinite(pz))return false;
 double rotate[16]{1,0,0,0,0,0,-1,0,0,1,0,0,0,py-pz,pz+py,1};
 for(int column=0;column<4;column++)for(int row=0;row<4;row++){
  double value=0;for(int k=0;k<4;k++)value+=double(m[k*4+row])*rotate[column*4+k];
  if(!std::isfinite(value)||std::abs(value)>1e8)return false;
  result[column*4+row]=float(value);
 }
 return validMatrix(result);
}
template<class Write,class Lookup,class Original>
bool invokeMatrix(Write& write,Lookup lookup,Original original){
 MatrixBinding before{};std::array<float,16> injected{};
 bool changed=lookup(before)&&flatMatrix(before,injected)&&write(before.matrix,before.stack,injected);
 auto restore=[&](){
  if(!changed)return;
  MatrixBinding after{};
  if(lookup(after)&&sameMatrix(before,after)&&after.value==injected)write(before.matrix,before.stack,before.value);
 };
 try{original();}catch(...){restore();throw;}
 restore();return changed;
}
}
