package dev.custom.bedrockgui;

/** The native bridge calls useItem only from the game's own GameMode tick. */
public final class FastExpBridge {
    private static volatile boolean loaded,ready,enabled,foreground;
    private FastExpBridge(){}
    private static native String install(long base,long client);
    private static native void enable(boolean value);
    private static native void pulse(boolean active);
    private static native String status();
    public static synchronized void prepare(long base,long client) {
        try {
            if(!loaded){System.loadLibrary("kulichbridge");loaded=true;}
            String error=install(base,client);
            if(!error.isEmpty())throw new IllegalStateException(error);
            ready=true;GameRuntime.log("Fast Exp: native tick bridge installed; disabled by default");
        }catch(RuntimeException|LinkageError error){GameRuntime.log("Fast Exp bridge unavailable: "+error);}
    }
    public static boolean isReady(){return ready;}
    public static boolean isEnabled(){return enabled;}
    public static void setEnabled(boolean value){
        if(value&&!ready)throw new IllegalStateException("Native bridge is not prepared");
        if(loaded)enable(value);
        enabled=value;GameRuntime.log("Fast Exp: requested enabled="+value);
        if(ready)GameRuntime.log(describe());
    }
    public static void foreground(boolean value){
        foreground=value;
        if(!value&&loaded)setEnabled(false);
    }
    public static void heartbeat(boolean menuClosed){if(ready)pulse(enabled&&foreground&&menuClosed);}
    public static String describe(){return ready?status():"Fast Exp: native bridge is not prepared";}
}
