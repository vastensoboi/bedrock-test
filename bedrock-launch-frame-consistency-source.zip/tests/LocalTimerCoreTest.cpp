#include "../app/src/main/cpp/local_timer_core.h"
#include <cassert>
#include <vector>
#include <iostream>
using namespace kulich_timer_move;
struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;std::vector<unsigned char> bytes=std::vector<unsigned char>(0x40000);A next=root+0x10000;
 template<class T>void put(A at,T value){at=plain(at);assert(at>=root&&at-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+at-root,&value,sizeof value);}
 A alloc(size_t n){A out=next;next=(next+n+7)&~A(7);assert(next-root<bytes.size());return out;}
 bool operator()(A at,void* out,size_t n){at=plain(at);if(at<root||at-root>bytes.size()||n>bytes.size()-(at-root))return false;std::memcpy(out,bytes.data()+at-root,n);return true;}
};
A storage(Memory& m,uint32_t id,unsigned stride){
 A pool=m.alloc(104),vector=m.alloc(8),sparse=m.alloc(8192),pages=m.alloc(8),payload=m.alloc(128*stride);
 std::fill(m.bytes.begin()+sparse-Memory::root,m.bytes.begin()+sparse-Memory::root+8192,255);
 m.put(pool+8,vector);m.put(pool+16,vector+8);m.put(vector,sparse);m.put(sparse+(id&2047)*4,id&0xfffc0000U);
 m.put(pool+80,pages);m.put(pool+88,pages+8);m.put(pool+96,pages+8);m.put(pages,payload|Memory::tag);return pool;
}
int main(){
 Memory m;constexpr A base=0x10000000,client=Memory::root+0x1000,registry=Memory::root+0x3000,actorAddress=Memory::root+0x5000,adapter=Memory::root+0x7000,idPointer=Memory::root+0x8000;constexpr uint32_t id=0x40001;
 uint32_t keys[]{OWNER,SHAPE,ROTATION,SPEED,GROUND,WATER,AIR,PLAYER,TRAVEL,ATTRIBUTES};unsigned strides[]{8,32,16,4,1,1,1,1,40,72};A pools[10]{};
 for(int i=0;i<10;i++)pools[i]=storage(m,id,strides[i]);
 A buckets=m.alloc(128),nodes=m.alloc(10*32);for(int i=0;i<16;i++)m.put<int64_t>(buckets+i*8,-1);
 for(int i=0;i<10;i++){int64_t prev=-1;m(buckets+(keys[i]&15)*8,&prev,8);m.put(nodes+i*32,prev);m.put(nodes+i*32+8,keys[i]);m.put(nodes+i*32+16,pools[i]);m.put<int64_t>(buckets+(keys[i]&15)*8,i);}
 m.put(registry+96,buckets);m.put(registry+104,buckets+128);m.put(registry+120,nodes);m.put(registry+128,nodes+10*32);
 A entityPages=m.alloc(8),entitySparse=m.alloc(8192);m.put(registry+216,entityPages);m.put(registry+224,entityPages+8);m.put(entityPages,entitySparse);m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|1);
 m.put(client,base+0x1388fe70ULL);m.put(client+576,std::array<A,3>{registry,Memory::root+0x9000,id});m.put(adapter,base+GROUND_V2_TABLE);m.put(adapter+8,registry);m.put(idPointer,id);
 m.put(actorAddress,base+0x139f6ea0ULL);m.put(actorAddress+8,registry);m.put(actorAddress+16,registry+40);m.put(actorAddress+24,id);m.put(actorAddress+3240,client);
 m.put(component(m,pools[0],id,8),actorAddress|Memory::tag);A shape=component(m,pools[1],id,32),rotation=component(m,pools[2],id,16);
 m.put(actorAddress+560,shape);m.put(actorAddress+568,rotation);m.put(shape,Box{{-.3f,0,-.3f},{.3f,1.8f,.3f},.6f,1.8f});m.put(rotation,Angles{});
 A speed=taggedComponent(m,pools[3],id,4),travel=taggedComponent(m,pools[8],id,40),attributes=taggedComponent(m,pools[9],id,72);
 m.put(speed,.7f);m.put(attributes,.1f);m.put<uint8_t>(attributes+4,1);m.put(attributes+8,.02f);m.put<uint8_t>(attributes+12,1);
 A otherAttributes=attributes+72,otherSpeed=speed+4;
 m.put(otherAttributes,.25f);m.put<uint8_t>(otherAttributes+4,1);m.put(otherSpeed,.4f);
 auto lookup=[&](Scalar& b){return input(m,base,client,adapter,GROUND_V2_TABLE,GROUND,b);};
 Scalar bind{};assert(lookup(bind)&&bind.payload==attributes&&bind.owner.entity==id);
 bool failWrite=false;int calls=0,writes=0;float localOutput=0,otherOutput=.4f;
 A rejectAddress=0;
 auto write=[&](A at,float value){assert(at==attributes||at==attributes+8||at==travel+12);assert((at&0xff00000000000000ULL)==Memory::tag);if(failWrite||at==rejectAddress)return false;++writes;m.put(at,value);return true;};
 // Model the disassembled cd27160/11f06018 selector, not a fake original
 // that reads whichever field the hook happened to modify. Player speed
 // ignores MovementSpeed; absent optional attributes produce zero.
 auto selectedSpeed=[&](bool player,A attrs,A fallback){float value=0;uint8_t present=0;if(player){assert(m(attrs+4,&present,1));if(present)assert(m(attrs,&value,4));}else assert(m(fallback,&value,4));return value;};
 auto original=[&](){++calls;localOutput=selectedSpeed(true,attributes,speed);otherOutput=selectedSpeed(false,otherAttributes,otherSpeed);assert(selectedSpeed(true,otherAttributes,otherSpeed)==.25f);};
 assert(invokeInput(write,lookup,original,150));assert(calls==1&&writes==2&&std::abs(localOutput-.15f)<1e-6&&otherOutput==.4f);float value=0;m(attributes,&value,4);assert(value==.1f);m(speed,&value,4);assert(value==.7f);
 assert(!invokeInput(write,lookup,original,100)&&calls==2);
 auto changing=[&](){++calls;m.put(attributes,.3f);};assert(invokeInput(write,lookup,changing,200));m(attributes,&value,4);assert(value==.3f);m.put(attributes,.1f);
 bool threw=false;try{invokeInput(write,lookup,[](){throw 7;},200);}catch(int){threw=true;}m(attributes,&value,4);assert(threw&&value==.1f);
 failWrite=true;assert(!invokeInput(write,lookup,original,200));failWrite=false;
 m.put(adapter+8,registry+8);assert(!lookup(bind));m.put(adapter+8,registry);
 m.put(actorAddress+3240,client+8);assert(!lookup(bind));m.put(actorAddress+3240,client);
 m.put(attributes,NAN);assert(!lookup(bind));m.put(attributes,.1f);
 m.put<uint8_t>(attributes+4,0);assert(!lookup(bind));assert(!invokeInput(write,lookup,original,200)&&localOutput==0);m.put<uint8_t>(attributes+4,1);
 m.put<uint8_t>(attributes+4,2);assert(!lookup(bind));m.put<uint8_t>(attributes+4,1);
 m.put(speed,NAN);assert(lookup(bind));m.put(speed,.7f); // unused player fallback is immaterial
 assert(!input(m,base,client,adapter,GROUND_V2_TABLE,GROUND,bind,1));
 A playerSparse=pointer(m,pointer(m,pools[7]+8));m.put(playerSparse+(id&2047)*4,uint32_t(0xffffffffU));assert(!lookup(bind));m.put(playerSparse+(id&2047)*4,id&0xfffc0000U);
 // Water uses both optional attributes. Boosting only land speed leaves
 // the ordinary water branch unchanged; scaling both preserves native blends.
 m.put(adapter,base+WATER_TABLE);
 auto waterLookup=[&](size_t slot,Scalar& b){return input(m,base,client,adapter,WATER_TABLE,WATER,b,unsigned(slot));};
 float blend=0,waterOutput=0;
 auto waterOriginal=[&](){++calls;float water=selectedSpeed(true,attributes+8,speed);waterOutput=water+(selectedSpeed(true,attributes,speed)-water)*blend;assert(selectedSpeed(true,otherAttributes,otherSpeed)==.25f);};
 for(float alpha:{0.f,.35f,1.f}){
  blend=alpha;int beforeCalls=calls;assert(invokeInputs<2>(write,waterLookup,waterOriginal,150));assert(calls==beforeCalls+1);
  assert(std::abs(waterOutput-(.02f+(.1f-.02f)*blend)*1.5f)<1e-6);
  m(attributes,&value,4);assert(value==.1f);m(attributes+8,&value,4);assert(value==.02f);
 }
 m.put<uint8_t>(attributes+12,0);blend=0;assert(invokeInputs<2>(write,waterLookup,waterOriginal,200)&&waterOutput==0);m(attributes+8,&value,4);assert(value==.02f);m.put<uint8_t>(attributes+12,1);
 rejectAddress=attributes;blend=0;assert(invokeInputs<2>(write,waterLookup,waterOriginal,200)&&std::abs(waterOutput-.04f)<1e-6);rejectAddress=0;
 auto waterChanging=[&](){waterOriginal();m.put(attributes+8,.03f);};assert(invokeInputs<2>(write,waterLookup,waterChanging,200));m(attributes,&value,4);assert(value==.1f);m(attributes+8,&value,4);assert(value==.03f);m.put(attributes+8,.02f);
 threw=false;try{invokeInputs<2>(write,waterLookup,[](){throw 7;},200);}catch(int){threw=true;}assert(threw);m(attributes,&value,4);assert(value==.1f);m(attributes+8,&value,4);assert(value==.02f);
 // If generation changes during native execution, do not write the old
 // component back into a potentially reused allocation.
 m.put(adapter,base+GROUND_V2_TABLE);auto recycled=[&](){m.put(entitySparse+(id&2047)*4,uint32_t(0x80001));};
 assert(invokeInput(write,lookup,recycled,200));m(attributes,&value,4);assert(value==.2f);m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|1);m.put(attributes,.1f);
 // Air output is generated afresh by the original; preserve it for movement,
 // and only accept the exact player+air filter and native .02/.026 outputs.
 m.put(adapter,base+AIR_TABLE);A groundPages=pointer(m,pools[4]+8),groundSparse=pointer(m,groundPages);
 m.put(groundSparse+(id&2047)*4,uint32_t(0xffffffffU));
 auto airLookup=[&](Scalar& b){return airOutput(m,base,client,adapter,idPointer,b);};
 auto airOriginal=[&](){++calls;m.put(travel+12,.02f);};
 assert(invokeAir(write,airLookup,airOriginal,200));m(travel+12,&value,4);assert(std::abs(value-.04f)<1e-6);
 assert(invokeAir(write,airLookup,airOriginal,200));m(travel+12,&value,4);assert(std::abs(value-.04f)<1e-6); // not .08 from repeated output scaling
 assert(!invokeAir(write,airLookup,[](){},200));
 m.put(idPointer,id+1);airOriginal();assert(!airLookup(bind));m.put(idPointer,id);
 m.put(playerSparse+(id&2047)*4,uint32_t(0xffffffffU));assert(!airLookup(bind));
 assert(clamp(1)==100&&clamp(999)==200);
 std::cout<<"PASS: actual player attribute selector, ground/water native blends, unchanged fallback/other actors/presence flags, original once, scoped restoration and generation guards, tagged writes, native air freshness\n";
}
