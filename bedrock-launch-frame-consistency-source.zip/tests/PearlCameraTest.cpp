#include "../app/src/main/cpp/pearl_camera_core.h"
#include <cassert>
#include <iostream>
#include <vector>
using namespace kulich_pearl_camera;
struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;
 std::vector<unsigned char> bytes=std::vector<unsigned char>(0x50000);A next=root+0x10000;
 template<class T>void put(A at,const T& value){at=plain(at);assert(at>=root&&at-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+at-root,&value,sizeof value);}
 A alloc(size_t n){A at=next;next=(next+n+7)&~A(7);assert(next-root<bytes.size());return at;}
 bool operator()(A at,void* out,size_t n){at=plain(at);if(at<root||at-root>bytes.size()||n>bytes.size()-(at-root))return false;std::memcpy(out,bytes.data()+at-root,n);return true;}
 A storage(uint32_t id,unsigned stride){
  A p=alloc(104),vector=alloc(8),sparsePage=alloc(8192),pages=alloc(8),data=alloc(128*stride);
  std::fill(bytes.begin()+sparsePage-root,bytes.begin()+sparsePage-root+8192,255);
  put(p+8,vector);put(p+16,vector+8);put(vector,sparsePage);put(sparsePage+(id&2047)*4,id&0xfffc0000U);
  put(p+80,pages);put(p+88,pages+8);put(p+96,pages+8);put(pages,data|tag);return p;
 }
};
bool near(double a,double b){return std::abs(a-b)<1e-5;}
int main(){
 NativeFields fields{};fields.quaternion[3]=1;fields.origin[0]=17;fields.origin[1]=65;fields.origin[2]=-30;
 fields.aspect=16.f/9;fields.verticalFov=float(70/DEGREES);fields.nearPlane=.1f;fields.farPlane=1024;
 for(int i=0;i<4;i++)fields.extra[i*5]=1;
 Camera cam{};assert(decode(fields,cam)&&near(cam.verticalFov,70)&&near(cam.pose.yaw,180));
 assert(cam.origin.x==17&&cam.origin.y==65&&cam.origin.z==-30);
 for(int i=0;i<16;i++)assert(near(cam.view[i],i%5==0?1:0));
 // A third-person/front/rolled camera follows the render quaternion, independent
 // of player yaw; native extra transform is applied before projection.
 const float s=std::sqrt(.5f);fields.quaternion[1]=s;fields.quaternion[3]=s;
 fields.extra[12]=.25f;assert(decode(fields,cam)&&near(cam.pose.yaw,90));
 double dx=-10,dy=0,dz=0;
 double cameraX=cam.view[0]*dx+cam.view[4]*dy+cam.view[8]*dz+cam.view[12];
 double cameraZ=cam.view[2]*dx+cam.view[6]*dy+cam.view[10]*dz+cam.view[14];
 assert(near(cameraX,.25)&&near(cameraZ,-10));
 fields.extra[0]=0;fields.extra[1]=1;fields.extra[4]=-1;fields.extra[5]=0;
 assert(decode(fields,cam));assert(near(cam.view[9],-1));
 NativeFields bad=fields;bad.verticalFov=0;assert(!decode(bad,cam));bad=fields;bad.quaternion[3]=NAN;assert(!decode(bad,cam));
 bad=fields;bad.extra[12]=INFINITY;assert(!decode(bad,cam));bad=fields;bad.extra[15]=0;assert(!decode(bad,cam));bad=fields;bad.nearPlane=2000;assert(!decode(bad,cam));
 Memory m;constexpr A registry=Memory::root+0x1000;constexpr uint32_t id=0x40001;
 A cameraPool=m.storage(id,280),renderPool=m.storage(id,1),liquidPool=m.storage(id,4),buckets=m.alloc(64),nodes=m.alloc(96);
 for(int i=0;i<8;i++)m.put<int64_t>(buckets+i*8,-1);
 uint32_t keys[]{CAMERA,RENDER_CAMERA,LIQUID_OFFSET};A pools[]{cameraPool,renderPool,liquidPool};
 for(int i=0;i<3;i++){int64_t prev=-1;m(buckets+(keys[i]&7)*8,&prev,8);m.put(nodes+i*32,prev);m.put(nodes+i*32+8,keys[i]);m.put(nodes+i*32+16,pools[i]);m.put<int64_t>(buckets+(keys[i]&7)*8,i);}
 m.put(registry+96,buckets);m.put(registry+104,buckets+64);m.put(registry+120,nodes);m.put(registry+128,nodes+96);
 A entities=m.alloc(8),entitySparse=m.alloc(8192);m.put(registry+216,entities);m.put(registry+224,entities+8);m.put(entities,entitySparse);m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|1);
 A payload=taggedComponent(m,cameraPool,id,280);m.put(plain(payload)+40,fields);
 CameraContext ctx{registry|Memory::tag,(registry+40)|Memory::tag,id,0,1,{}};
 assert(readCamera(m,ctx,cam)&&cam.component==payload&&near(cam.verticalFov,70));
 A liquid=component(m,liquidPool,id,4);m.put(liquid,.125f);assert(readCamera(m,ctx,cam)&&near(cam.origin.y,65.125));m.put(liquid,NAN);assert(!readCamera(m,ctx,cam));m.put(liquid,0.f);
 ctx.present=0;assert(!readCamera(m,ctx,cam));ctx.present=1;ctx.storage=registry+48;assert(!readCamera(m,ctx,cam));ctx.storage=registry+40;
 ctx.entity+=0x40000;assert(!readCamera(m,ctx,cam));ctx.entity=id;
 m.put(entitySparse+(id&2047)*4,0x80001U);assert(!readCamera(m,ctx,cam));
 std::cout<<"PASS: real render FOV/origin, native matrix multiplication, third person/roll/translation, tagged ECS reads, stale context guards\n";
}
