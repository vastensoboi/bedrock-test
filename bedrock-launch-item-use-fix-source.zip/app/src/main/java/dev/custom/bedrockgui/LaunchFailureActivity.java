package dev.custom.bedrockgui;
import android.app.Activity;
import android.os.*;
import android.widget.*;
public final class LaunchFailureActivity extends Activity {
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        LinearLayout page=new LinearLayout(this);page.setOrientation(1);page.setPadding(24,32,24,24);
        TextView text=new TextView(this);text.setText("Тест запуска остановился на ошибке. Вернись в приложение и сохрани журнал запуска.");page.addView(text);
        Button back=new Button(this);back.setText("Вернуться");back.setOnClickListener(v->finish());page.addView(back);setContentView(page);
    }
    @Override public void onDestroy(){super.onDestroy();new Handler(Looper.getMainLooper()).postDelayed(()->android.os.Process.killProcess(android.os.Process.myPid()),100);}
}
