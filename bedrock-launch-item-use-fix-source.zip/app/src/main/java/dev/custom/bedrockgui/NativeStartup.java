package dev.custom.bedrockgui;

import java.io.File;
/** Must be instantiated by GameRuntime's child loader, not by the host loader. */
public final class NativeStartup {
    private NativeStartup() {}
    public static void prepare(String directory,String application,String[] providers)throws Exception {
        if(application!=null&&!application.isEmpty()) {
            GameRuntime.log("Native: initializing application class "+application);
            Class.forName(application,true,NativeStartup.class.getClassLoader());
        }
        if(providers!=null)for(String provider:providers) {
            GameRuntime.log("Native: initializing provider class "+provider);
            Class.forName(provider,true,NativeStartup.class.getClassLoader());
        }
        String[] order={"c++_shared","fmod","maesdk","conscrypt_jni","HttpClient.Android","MediaDecoders_Android","PlayFabMultiplayer","minecraftpe"};
        for(String name:order) {
            if(!new File(directory,"lib"+name+".so").isFile()) {
                if(name.equals("minecraftpe"))throw new IllegalStateException("libminecraftpe.so missing");
                continue;
            }
            GameRuntime.log("Native: loading "+name);
            System.loadLibrary(name);
            GameRuntime.log("Native: loaded "+name);
        }
        GameRuntime.log("Native: loading mc forwarding shim");
        System.loadLibrary("mc");
        GameRuntime.log("Native: mc shim loaded");
    }
}
