# Local item-use progress

The exact ARM64 ItemUseTickDurationSystem writes only the remaining integer
at ItemInUseComponent +8 (component hash `0x05b90aef`, storage stride 16).
The movement bulk callback at `0xc128648` decrements it at `0xc12884c..858`;
the movement single callback at `0xc128af0` does the same at `0xc128bdc..be8`.
The ordinary single callback at `0xc129564` uses `0xc12964c..658`. All subtract
one and skip storing a negative result. Native Player::normalTick reads the
same counter at `0x101f1e6c` for item-use particles and at `0x101f1f88` to
dispatch the natural zero/completion path. This is an item-use progress path,
not a global tick-rate adjustment.

The movement adapter primary vptr is `0x13aca718`, callbacks slots 6/7 are
`0xc128648` and `0xc128af0`. It requires ActorMovementTickNeededComponent
`0x94154cce` and ItemInUseTicksDuringMovementComponent `0x9b80c0c9`.
The ordinary adapter is `0x13aca798`, callbacks `0xc129214`/`0xc129564`;
it requires ActorTickNeededComponent `0x2744aa41` and excludes the movement-use
marker. A single callback's third argument is a pointer to the entity ID:
`0x134686ec` copies its uint32 value, preserving no additional context.

Before the original callback, a fractional clock may consume at most one
additional remaining tick for factors 1.00–2.00. It reserves one remaining tick
for the original decrement, so the engine still transitions through zero and
performs its own completion, inventory and network logic. Only the bound local
player's tagged component is writable. Registry/generation, exact LocalPlayer
type, back-reference, owner slot, component identity and callback filters must
all agree. Use changes, count resets, disable and failed writes clear fractional
progress. Successful extra progress is committed, not restored as an input
modifier. The original callback always runs exactly once.

Tests cover the expected 110-duration/1.10 and 100-duration/2.00 schedules,
normal remote progress, both filters, zero completion, invalid state, tags,
identity resets, failed writes and conditional exception rollback. Server-side
consumption acknowledgement and Nevertime compatibility are not implied by
this client-side timer. This does not accelerate every game action or every
animation; those require their own verified local update paths.
