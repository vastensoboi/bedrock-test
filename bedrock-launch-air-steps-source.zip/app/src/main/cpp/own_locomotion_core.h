#pragma once
#include "own_step_memory.h"

// Read-only eligibility for ordinary own-player travel. Read only the native
// jump-related input masks; do not alter MoveInput, issue jump requests, modify
// velocity or run native physics. The auxiliary bits' semantic names are unknown.
namespace kulich_own_step {
constexpr uint32_t AIR_TRAVEL=0xb147b030U,GROUND_TRAVEL=0xe1ca9e6bU,WATER_TRAVEL=0x2802839dU,
 GLIDING=0x27a011eeU,FLYING=0x42910726U,LOCAL_JUMP=0xda6293f1U,
 GROUND_JUMP=0x4ea8c276U,TRIGGER_JUMP=0xf37efb0fU;
enum class Motion {Unknown,Ground,Air};
enum class MotionReason {Ready,Unavailable,JumpHeld,PendingJump,Unsupported};
struct MotionState {
 Session session{};A actor=0,replay=0,history=0;uint32_t entity=0xffffffffU;
 A input=0;bool inputKnown=false,jumpIntent=false;uint32_t jumpPrimaryBits=0;uint16_t jumpAuxBits=0;
 Motion mode=Motion::Unknown;
 Presence onGround=Presence::Unavailable,jumping=Presence::Unavailable,
  air=Presence::Unavailable,ground=Presence::Unavailable,water=Presence::Unavailable,
  gliding=Presence::Unavailable,flying=Presence::Unavailable,
  localJump=Presence::Unavailable,groundJump=Presence::Unavailable,triggerJump=Presence::Unavailable;
};
inline bool operator==(const MotionState& a,const MotionState& b){
 return a.session==b.session&&a.actor==b.actor&&a.replay==b.replay&&a.history==b.history&&a.entity==b.entity&&
  a.input==b.input&&a.inputKnown==b.inputKnown&&a.jumpIntent==b.jumpIntent&&
  a.jumpPrimaryBits==b.jumpPrimaryBits&&a.jumpAuxBits==b.jumpAuxBits&&
  a.mode==b.mode&&a.onGround==b.onGround&&a.jumping==b.jumping&&a.air==b.air&&a.ground==b.ground&&
  a.water==b.water&&a.gliding==b.gliding&&a.flying==b.flying&&a.localJump==b.localJump&&
  a.groundJump==b.groundJump&&a.triggerJump==b.triggerJump;
}
inline bool operator!=(const MotionState& a,const MotionState& b){return !(a==b);}
inline MotionReason classify(MotionState& state){
 state.mode=Motion::Unknown;
 state.jumpIntent=state.inputKnown&&((state.jumpPrimaryBits&0x20U)||(state.jumpAuxBits&0x30U));
 if(!state.inputKnown)return MotionReason::Unavailable;
 const Presence flags[]={state.onGround,state.jumping,state.air,state.ground,state.water,state.gliding,
  state.flying,state.localJump,state.groundJump,state.triggerJump};
 for(Presence flag:flags)if(flag==Presence::Unavailable)return MotionReason::Unavailable;
 // A held jump may recreate an edge or span landing. Request absence alone is
 // not evidence that its input lifecycle is safe for an extra native frame.
 if(state.jumping!=Presence::Absent||state.jumpIntent)return MotionReason::JumpHeld;
 if(state.localJump!=Presence::Absent||state.groundJump!=Presence::Absent||state.triggerJump!=Presence::Absent)
  return MotionReason::PendingJump;
 if(state.water!=Presence::Absent||state.gliding!=Presence::Absent||state.flying!=Presence::Absent||
    (state.air==Presence::Present&&state.ground==Presence::Present))return MotionReason::Unsupported;
 if(state.onGround==Presence::Present){state.mode=Motion::Ground;return MotionReason::Ready;}
 if(state.air==Presence::Present&&state.ground==Presence::Absent){state.mode=Motion::Air;return MotionReason::Ready;}
 return MotionReason::Unsupported;
}
template<class Read>Presence motionPresence(Read& read,A registry,uint32_t entity,uint32_t key){
 bool known=false;A storage=rawPool(read,registry,key,&known);uint64_t index=0;
 if(!known)return Presence::Unavailable;
 return locate(read,storage,entity,index);
}
template<class Read>bool motionInput(Read& read,const Binding& binding,MotionState& out){
 bool known=false;A storage=rawPool(read,binding.session.registry,MOVE_INPUT,&known),input=0;
 if(!known||payload(read,storage,binding.entity,100,input)!=Presence::Present||plain(input)<4096)return false;
 uint32_t primary=0,againPrimary=0;uint16_t auxiliary=0,againAuxiliary=0;
 if(!read(plain(input),&primary,4)||!read(plain(input)+96,&auxiliary,2))return false;
 bool againKnown=false;A againStorage=rawPool(read,binding.session.registry,MOVE_INPUT,&againKnown),againInput=0;
 if(!againKnown||againStorage!=storage||payload(read,againStorage,binding.entity,100,againInput)!=Presence::Present||
    againInput!=input||!read(plain(againInput),&againPrimary,4)||!read(plain(againInput)+96,&againAuxiliary,2)||
    (primary&0x20U)!=(againPrimary&0x20U)||(auxiliary&0x30U)!=(againAuxiliary&0x30U))return false;
 out.input=input;out.inputKnown=true;out.jumpPrimaryBits=primary&0x20U;out.jumpAuxBits=auxiliary&0x30U;
 return true;
}
template<class Read>MotionReason motion(Read& read,const Binding& binding,MotionState& out){
 out={};out.session=binding.session;out.actor=binding.actor;out.replay=binding.replay;
 out.history=binding.history;out.entity=binding.entity;
 if(!binding.session.valid()||plain(binding.actor)<4096||
    (binding.entity&0x3ffffU)==0x3ffffU)return MotionReason::Unavailable;
 constexpr uint32_t keys[]={ON_GROUND,JUMPING,AIR_TRAVEL,GROUND_TRAVEL,WATER_TRAVEL,GLIDING,FLYING,
  LOCAL_JUMP,GROUND_JUMP,TRIGGER_JUMP};
 Presence* fields[]={&out.onGround,&out.jumping,&out.air,&out.ground,&out.water,&out.gliding,&out.flying,
  &out.localJump,&out.groundJump,&out.triggerJump};
 for(unsigned i=0;i<sizeof(keys)/sizeof(keys[0]);++i)
  *fields[i]=motionPresence(read,binding.session.registry,binding.entity,keys[i]);
 if(!motionInput(read,binding,out))return MotionReason::Unavailable;
 return classify(out);
}
}
