# Aimbot 0.55 — faster turns, reduced jitter and target priorities

Target -> Aimbot now offers Nearest and Lowest HP. Rescan candidates every
300 ms. Keep the current target unless a candidate is about 8% closer (squared
distance threshold .85), or has more than 0.5 fewer HP. Rank equal HP by distance.
Unknown health is never zero: prefer known HP, otherwise fall back to nearest
and display the fallback. Exclude zero-health players when the attribute is
available. Health is client-visible data; servers may omit updates or send the
same/default health for remote players.

Tune existing installs once to 240 degrees/second and 80 ms response; subsequent
user changes persist. Faster coarse acquisition uses adaptive easing, with a
180 ms smooth start ramp for each new target. Final aim uses a hysteresis band:
stop within .12 degrees, resume outside .24 degrees. Keep native input feedback,
pending-yaw accounting, exact camera binding and Head/Body points. This reduces
small corrective oscillations and repeated target switching; phone behaviour
and perceived smoothness still need testing. No new frame hook is introduced.

Health reader evidence in the exact supplied library: AttributesComponent key
0xfd3b0613, payload stride 88 from 0xfdabaa4; parallel sorted uint32 ID vector
+0/+8 and AttributeInstance vector +24/+32, stride 136 from 0x10177014.
Health attribute global 0x141d8f48 is initialized with minecraft:health at
0x1018e97c..0x1018e9a0; its ID getter at 0x101a8bf0 reads +4. Thus the runtime
ID is read from base+0x141d8f4c. Health lookup and positive-value test appear
at 0x101be38c..0x101be3a8; current-value getter 0x101a9ad0 reads float +124.
Use bounded read-only lookups, entity sparse generations, finite/range checks,
matching vector lengths and unchanged header re-read. No new native calls.

Validation: all eleven gameplay suites, including nearest vs HP selection,
unknown/NaN/dead health, hysteresis and acquisition ramp; native C++ syntax,
Android 35/Rhino Java checks and address/undefined sanitizers (leak checking
disabled under debugger). Full APK linking and on-phone behaviour are unverified.

Upload bedrock-launch-aimbot-priority-source.zip to the repository root and run
Build latest launch test. Install BedrockLaunchTest-0.55. Test priorities near
two players with different distance/health; check Head and Body and adjust
Speed/Smoothness as desired. Journal phase=camera-input-v3 includes priority,
hp, current view and goal angles. Fast Exp and Auto Buy remain unchanged.

## Earlier releases

# Aimbot · 0.54: точка наведения и плавность

В видео 0.53 камера уходит в небо вместо удержания головы. В преобразовании
вертикального ввода был неверный знак; расчёт ошибки ещё использовал углы
Actor, отстающие от состояния камеры. Исправлены обе причины.

Теперь ошибка считается по DirectLook: мировой pitch = минус pitch камеры,
мировой yaw = 180° минус её yaw с учётом ожидающего поворота. Вертикальный ввод
имеет обратный знак относительно требуемого мирового pitch. Повторный тик до
обработки ввода не добавляет уже ожидающий поворот ещё раз.

Точка «Голова» — центр по X/Z и 90% высоты bounding box; «Тело» — центр по X/Z
и 60% высоты (грудь). Положение цели читается заново при обновлении; одна цель
удерживается по прежним правилам. Автоматических ударов нет.

Добавлена «Плавность»: 40–200 мс с шагом 20, по умолчанию 100 мс. Больше значение
— мягче доводка, но больше отставание от быстро движущейся цели. Экспоненциальная
доводка зависит от прошедшего времени, сохраняет общий предел скорости поворота
60–360°/с и прекращает коррекции менее 0.04° у неподвижной точки. Настройка
сохраняется как aim.smooth_ms. Нового кадрового хука нет: используется прежний
игровой callback и система камеры Minecraft.

Собери BedrockLaunchTest-0.54 через Build latest launch test. В игре открой
kulich → Таргет → Aimbot. Проверь «Голова» и «Тело» рядом с игроком на одном
уровне, затем выше/ниже себя; измени плавность и выключи модуль для проверки
возврата ручного управления. Плавность 100 мс уже установлена по умолчанию.
Результат на телефоне ещё не проверен.

В журнале версия различается по phase=camera-input-v2. Добавлены smoothMs,
viewPitch/viewYaw (состояние ввода камеры с ожидающим yaw) и goalPitch/goalYaw
(углы к выбранной точке). cameraChanges отдельно считает изменения quaternion.
Эти данные не показывают причины серверных флагов.

## Evidence correcting the previous model

In the supplied exact-build library, CameraDirectLookSystem at 0x11e6e530
builds quaternion (sin(p/2)*cos(y/2), cos(p/2)*sin(y/2),
-sin(p/2)*sin(y/2), cos(p/2)*cos(y/2)). The first trig calls at 0x1360e640
resolve to cosf via GOT 0x13fc9e58; calls at 0x13686950 resolve to sinf via
GOT 0x14005fe0. The 0.53 test model had misidentified this convention.

Camera forward helper 0x11e99170 rotates the constant (0,0,-1) at 0x140426d8.
UpdatePlayerFromCamera at 0x8a42760 calls that path and Vec3-to-angles
0x13521d9c, whose pitch is -atan2(forward.y, horizontal length). Together
these establish world pitch=-DirectLook.pitch and yaw=pi-DirectLook.yaw.
The native input callback 0x11e5dcb4 still increments native pitch by input.x
and subtracts input.y from pending yaw. No native profile/ABI is changed.

Validation: eleven gameplay suites; the new regression oracle builds native
quaternions and projects the forward vector rather than assuming Actor pitch
has the input sign. Tests cover up/down sign, head/torso convergence at multiple
heights, yaw wrap, delayed camera consumption, smoothing, stationary deadband,
limits, and 20/40/60 Hz model sampling. Android 35/Rhino Java typechecks, native
C++ syntax and address/undefined sanitizers pass (leak check disabled under
debugger). These checks do not replace a phone test or full Android APK build.

## Earlier implementation (superseded)

# Aimbot · 0.53: ввод активной камеры

Проверка на телефоне показала: в 0.51/0.52 изменение углов Actor не поворачивает
экран. Счётчик `applied` подтверждал вызовы, а не видимое наведение.

В 0.53 модуль больше не вызывает Actor::setRot/setYHeadRot. Он получает активную
камеру клиента и передаёт ограниченный поворот обработчику обзора Minecraft.
Игра сама обновляет камеру и направление игрока. Голова/тело, радиус, удержание
цели и настройка скорости 60–360°/с сохранены.

Собери BedrockLaunchTest-0.53 через Build latest launch test, открой
kulich → Таргет → Aimbot и проверь рядом с другим игроком в выбранном радиусе.
Проверь сначала «Голова», затем «Тело»; после выключения управление должно
оставаться ручным. На телефоне новый путь ещё не проверен.

Если экран неподвижен, сохрани журнал 0.53. `phase=camera-input` отличает новую
версию; `camera` показывает ID привязанной камеры; `applied` считает принятые
изменения ввода; `cameraChanges` считает изменения ориентации CameraComponent
между обновлениями. Они не заменяют наблюдение за экраном. `reason=7` означает,
что активная камера/её ввод не прошли проверку, `reason=8` — обработчик не
подтвердил ожидаемые значения ввода. Причины флагов Nevertime журнал клиента
не устанавливает.

## Camera path evidence for the supplied ARM64 library

The existing exact SHA-256 gate remains in place. Native code prefixes are
pinned alongside the older Actor profiles.

- ClientInstance virtual 165 points to 0x9b8bbf8. Client +424 owns the registry
  interface; its +8 lifetime pointer is checked alive before native dispatch.
  The original tagged client pointer comes from LocalPlayer +3240.
- 0x9c706c0 returns optional<StrictEntityContext> for the active camera using
  the native AArch64 x8 aggregate-result ABI. Layout: registry +0, registry+40
  at +8, entity ID +16, present byte +24; total 32 bytes. Context construction
  is visible at 0x134686b8; optional construction at 0x13469160.
- Require matching entity generation, ActiveCameraComponent (0x113040a1) and
  CurrentInputCameraComponent (0xf6c60b46) in the returned camera registry.
  CameraComponent (0x4f6047c7) stride 280; CameraDirectLookComponent
  (0xceb578f1) stride 20. These are FNV-1a of MinecraftCamera::qualified names.
- CameraDirectLook has yaw radians +0, pitch radians +4, pending yaw delta +8,
  minimum pitch +12 and maximum pitch +16. Its system at 0x11e6e530 consumes
  pending yaw, builds a unit quaternion at CameraComponent +40, then clears
  the pending yaw. Payload strides and offsets appear at 0x11e6e6e8..0x11e6e7b4.
- The input callback 0x11e5dcb4 takes context, camera, direct-look and a pointer
  to a two-float degree delta. It adds delta.x * pi/180 to pitch, subtracts
  delta.y * pi/180 from pending yaw, then normalizes/clamps pitch. The registry
  dispatcher at 0x11e5dd18 passes this callback and delta into 0x11e6df64.
- Native input dispatch runs on the existing game-update callback. Both native
  payload arguments retain the allocation tags from their storage pages.
  All read-only lookups still use untagged addresses. Revalidate components,
  finite pitch limits, unit quaternion and lease immediately before dispatch;
  read back input state afterwards. No direct rotation or packet writes.

Validation: eleven gameplay suites, including active camera identity/generation,
input-vs-render camera tags, MTE payload tags, invalid quaternion/limits and a
native-input/camera-consumption model; all app Java typechecks with Android 35
and Rhino; C++ syntax with warnings as errors; address/undefined sanitizers
(leak check disabled under the sandbox debugger). Full ARM64 APK linking and
visible camera behaviour require GitHub Actions and the phone.

## Earlier implementation (superseded)

# Aimbot · 0.52: плавный поворот

В журнале 0.51 цель найдена, привязка корректна, вызовы поворота выполняются.
Сообщений сервера, объясняющих «флаги», в журнале нет. Совместимость с Nevertime
по этому отчёту подтвердить нельзя.

В 0.52 поворот перенесён перед обновлением игрока и ограничен по скорости.
Настройка «Скорость поворота» — 60–360°/с, по умолчанию 180°/с. При обычном
обновлении раз в 50 мс это до 9° суммарного изменения pitch/yaw за обновление.
При задержке не накапливается большой разворот: учитывается максимум 100 мс.
Голова/тело, радиус и удержание одной цели сохранены. При захвате модуль сначала
плавно доворачивает камеру, затем следует за целью в пределах выбранной скорости.

Собери BedrockLaunchTest-0.52 через Build latest launch test. Проверь рядом
с другим игроком. Если снова возникают рывки или откаты, выключи модуль и сохрани
журнал 0.52. В нём добавлены maxTurn, speed и phase=before-update. Они помогают
проверить клиентские повороты, но не заменяют сообщение/журнал самого сервера.

## Предыдущая версия и схема данных

# Aimbot · 0.51

1. Собери исходники через Build latest launch test и установи BedrockLaunchTest-0.51.
2. Войди в мир, где рядом есть другой игрок. Открой kulich → Таргет → Aimbot.
3. Выбери «Голова» или «Тело», радиус (по умолчанию 6 блоков) и включи модуль.
4. Поверни камеру: при найденной цели модуль должен возвращать её к выбранной
   точке и следовать за движением игрока. Переключи голову/тело для проверки.
5. Выключи модуль — камера должна сразу снова управляться вручную. Если нет
   наведения или возник вылет, сохрани журнал kulich 0.51.

Меню можно держать открытым; модуль сохраняет состояние при другом окне.
Если Android/Minecraft останавливает саму игру, наведение ждёт её обновлений.
При выключении и закрытии игрового процесса наведение прекращается.

Первая версия выбирает ближайшего RemotePlayer по расстоянию и удерживает
именно его, даже если другой игрок подошёл ближе. При исчезновении/смене мира
или выходе из радиуса ищется новая цель. Мобы не выбираются. Фильтра друзей,
команд и проверки стены пока нет. Камера и голова поворачиваются явно; ударов
и отдельной подмены поворота в пакетах нет. Реальная работа на телефоне ещё
не подтверждена: локальные тесты не заменяют эту проверку.

## Exact-build layout evidence

The existing GameEngineProbe verifies SHA-256
4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4.

- RemotePlayer RTTI primary vptr is 0x139f76b0; constructors store it at
  0xaf694a8/0xaf694ac and 0xaf699d4/0xaf699d8. LocalPlayer remains 0x139f6ea0.
- Actor EntityContext is registry at +8, registry+40 at +16, 32-bit entity at +24.
  ActorOwnerComponent FNV-1a key 0x85b93800 is already established by player lookup.
  Actor removed flag +617 is checked by native resolver 0xfdb3c24..0xfdb3c38.
- Registry buckets/nodes and sparse generation scheme are the same as the
  existing player probe: map header +96/+104/+120/+128, 32-byte nodes;
  root entity sparse pages +216. Component sparse pages begin at storage+8,
  payload-page vector at +80/+88/+96; 128 payloads per page. Owner payload size 8.
- Component hashes are FNV-1a of their names. ActorRotationComponent = 0x75df36b7,
  AABBShapeComponent = 0xbac1b3cf, ActorHeadRotationComponent = 0xbabe7211.
  Rotation data is 16 bytes (current and previous Vec2), shape is 32 bytes
  (min/max Vec3, width/height), head is 8 bytes (current/previous yaw).
- Actor +552 is position, +560 shape and +568 rotation. Position getter
  0xfd8e62c loads current XYZ; shape getter 0xfd9b14c loads width at +24;
  yaw getter 0xfdaf960 reads rotation+4. Component addresses must match the
  local/remote cached shape and local cached rotation before gameplay use.
- Actor setRot 0xfd8f694 loads two floats from x1 and writes current rotation;
  setYHeadRot 0xfdafa3c resolves hash 0xbabe7211 and writes s0 to current yaw.
  Both signatures and the first eight instructions are pinned in aim_profile.h.
  Original MTE-tagged local this pointer is retained for native calls.

Native acquisition is bounded to 4096 owner entries and a five-millisecond/read
budget. Targets are revalidated immediately before native calls; stale entity
indices/pointers never authorize rotation. Journal records binding rejection,
scanned entries, target ID, angle values and applied-call count. An applied call
count proves native dispatch; actual camera behaviour still requires device
observation. There is no raw memory-write backend or arbitrary target setter API.
