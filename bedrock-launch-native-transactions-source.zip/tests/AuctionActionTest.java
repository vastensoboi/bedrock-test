package dev.custom.bedrockgui;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
public final class AuctionActionTest {
    static final long ROOT=0x200000,BASE=0x10000000;static final byte[] memory=new byte[0x40000];
    static final int PLAYER=0,CLIENT=0x2000,MANAGER=0x4000,NODE=0x5000,MODEL=0x6000,SLOTS=0x8000,INVNODE=0xe000,INVMODEL=0xf000,INVSLOTS=0x10000;
    static void q(int at,long v){ByteBuffer.wrap(memory).order(ByteOrder.LITTLE_ENDIAN).putLong(at,v);}
    static void integer(int at,int v){ByteBuffer.wrap(memory).order(ByteOrder.LITTLE_ENDIAN).putInt(at,v);}
    static void str(int at,String value,int heap){byte[] bytes=value.getBytes(StandardCharsets.UTF_8);Arrays.fill(memory,at,at+24,(byte)0);
        if(bytes.length<=22){memory[at]=(byte)(bytes.length*2);System.arraycopy(bytes,0,memory,at+1,bytes.length);}
        else{memory[at]=1;q(at+8,bytes.length);q(at+16,ROOT+heap);System.arraycopy(bytes,0,memory,heap,bytes.length);}}
    static void display(int tag,String name,String... lore){
        Arrays.fill(memory,tag,tag+0x900,(byte)0);
        int display=tag+0x100,n=tag+0x200,l=tag+0x300,list=tag+0x400;
        q(tag,BASE+0x13ebe0b0L);q(tag+16,ROOT+display);
        str(display+32,"display",0);q(display+56,BASE+0x13ebe0b0L);q(display+72,ROOT+n);integer(display+96,10);
        str(n+32,"Name",0);q(n+56,BASE+0x13ebe5f8L);str(n+64,name,tag+0x700);integer(n+96,8);q(n+8,ROOT+l);
        str(l+32,"Lore",0);q(l+56,BASE+0x13ebe350L);integer(l+96,9);q(l+64,ROOT+list);q(l+72,ROOT+list+lore.length*8);q(l+80,ROOT+list+lore.length*8);
        for(int i=0;i<lore.length;i++){int text=tag+0x500+i*128;q(list+i*8,ROOT+text);q(text,BASE+0x13ebe5f8L);str(text+8,lore[i],tag+0x800+i*64);}
    }
    static void stack(int slot,int tag){int at=SLOTS+slot*152;q(at+8,ROOT+0x14000);q(at+16,ROOT+tag);memory[at+34]=1;}
    static AuctionMemoryProbe probe()throws Exception{
        AuctionMemoryProbe p=new AuctionMemoryProbe(Collections.singletonList(new EngineMemoryProbe.Region(ROOT,ROOT+memory.length,0,true,true,"heap")),(a,out,n)->{System.arraycopy(memory,(int)(a-ROOT),out,0,n);return true;},BASE,s->{},false);
        p.scan(ROOT+PLAYER,ROOT+CLIENT);return p;
    }
    static void check(boolean v){if(!v)throw new AssertionError();}
    static void offer(){display(0x16000,"Сфера Виверны","Цена: 1000$","Игрок: Seller");}
    public static void main(String[] args)throws Exception{
        q(PLAYER,BASE+0x139f6ea0L);q(3240,ROOT+CLIENT);q(0x578,ROOT+MANAGER);
        q(MANAGER,BASE+0x137e8f20L);q(MANAGER+192,ROOT+NODE);q(NODE+40,ROOT+MODEL);q(NODE,ROOT+INVNODE);
        q(MODEL,BASE+0x13d34298L);q(MODEL+216,ROOT+SLOTS);q(MODEL+224,ROOT+SLOTS+54*152);q(MODEL+232,ROOT+SLOTS+54*152);
        q(INVNODE+40,ROOT+INVMODEL);q(INVMODEL,BASE+0x13d341b0L);q(INVMODEL+216,ROOT+INVSLOTS);q(INVMODEL+224,ROOT+INVSLOTS+27*152);q(INVMODEL+232,ROOT+INVSLOTS+27*152);
        for(int i=0;i<54;i++)q(SLOTS+i*152,BASE+0x13d95ff8L);for(int i=0;i<27;i++)q(INVSLOTS+i*152,BASE+0x13d95ff8L);
        q(0x14000,ROOT+0x14100);q(0x14100,BASE+0x13d9a028L);
        offer();display(0x18000,"Обновить");stack(5,0x16000);stack(49,0x18000);
        AuctionMemoryProbe p=probe();AutoBuyCycle.Snapshot s=p.snapshot();check(s.complete&&s.at(5).verdict.accepted);
        AuctionMemoryProbe.ActionToken open=p.actionToken(s,5);check(open!=null&&p.validateAction(open,true));
        display(0x16000,"Сфера Виверны","Цена: 2000$","Игрок: Seller");check(!p.validateAction(open,true));offer();
        q(0x578,0);check(!p.validateAction(open,false));q(0x578,ROOT+MANAGER);
        q(MANAGER+192,ROOT+INVNODE);check(!p.validateAction(open,true));q(MANAGER+192,ROOT+NODE);
        memory[INVSLOTS+34]=1;check(!p.validateAction(open,true)&&p.validateAction(open,false));memory[INVSLOTS+34]=0;
        q(MODEL+224,ROOT+SLOTS+27*152);check(!p.validateAction(open,false));
        for(int i=0;i<54;i++){memory[SLOTS+i*152+34]=0;q(SLOTS+i*152+16,0);}
        display(0x1a000,"Купить");display(0x1c000,"Вернуться");stack(10,0x1a000);stack(13,0x16000);stack(16,0x1c000);
        p=probe();s=p.snapshot();check(s.complete&&s.slots==27);
        AuctionMemoryProbe.ActionToken buy=p.actionToken(s,10);check(buy!=null&&p.validateAction(buy,true));
        display(0x16000,"Сфера Виверны","Цена: 1000$","Игрок: Other");check(!p.validateAction(buy,true));offer();
        display(0x1c000,"Отмена");check(!p.validateAction(buy,true));
        System.out.println("PASS: live native-model action guards, listing/confirmation token validity, mutated price/seller/control/owner/window/space rejection");
    }
}
