package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.SystemClock;
import android.os.Handler;
import android.os.Looper;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** UI-thread coordinator; reads on one worker, injects only in the hosted Activity. */
public final class AutoBuyController {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final BooleanSupplier available;
    private final Runnable pulse=new Runnable(){public void run(){
        if(!enabled||disposed)return;
        tick(available.getAsBoolean());
        if(enabled&&!disposed)handler.postDelayed(this,25);
    }};
    private final Activity activity;private final AuctionTapInput input;private final Consumer<String> notify;
    private AutoBuyCycle cycle;private boolean enabled,started,busy,disposed,initial;private int generation;
    private volatile long lastReadMs,lastRefreshGap;
    private long pausedAt=-1,lastRefreshAt,lastTelemetry;
    private long nextRead;private String status="Выключен. Используются правила из твоего Auto Buy";
    public AutoBuyController(Activity activity,AuctionTapInput input,Consumer<String> notify,BooleanSupplier available){this.activity=activity;this.input=input;this.notify=notify;this.available=available;}
    public boolean isEnabled(){return enabled;}
    public String status(){return status+"\nЧтение: "+lastReadMs+" мс · Интервал попыток: "+(lastRefreshGap>0?lastRefreshGap+" мс":"ещё не измерен");}
    private void report(String value){if(!status.equals(value)){status=value;GameRuntime.log("Auto Buy cycle: "+value);}}
    public void setEnabled(boolean value){
        if(!value){stop("Выключен");return;}
        if(disposed)throw new IllegalStateException("Игра закрывается");
        if(!input.readyForAutomation())throw new IllegalStateException("Готовый профиль недоступен: открой игру горизонтально");
        generation++;cycle=new AutoBuyCycle();enabled=true;started=false;initial=true;nextRead=0;pausedAt=-1;lastRefreshAt=0;lastRefreshGap=0;
        report("Включён · обновление 0,3 с. Открой аукцион и закрой меню kulich");
        handler.removeCallbacks(pulse);handler.post(pulse);
    }
    private void stop(String reason){
        enabled=false;started=false;generation++;handler.removeCallbacks(pulse);input.cancelAutomatic();report(reason);notify.accept(reason);
    }
    private void pause(){
        if(!enabled||pausedAt>=0)return;
        pausedAt=SystemClock.uptimeMillis();cycle.openingInterrupted();generation++;input.cancelAutomatic();report("Пауза. Продолжу после возврата в игру и закрытия меню");
    }
    public void inactive(){pause();}
    public void menuOpened(){pause();}
    public void tick(boolean available){
        if(!enabled||disposed)return;
        if(!available){pause();return;}
        if(pausedAt>=0){cycle.suspendTime(SystemClock.uptimeMillis()-pausedAt);pausedAt=-1;nextRead=SystemClock.uptimeMillis()+100;report("Продолжаю Auto Buy");}
        if(busy||input.inputBusy()||SystemClock.uptimeMillis()<nextRead)return;
        if(!GameEngineProbe.begin())return;
        started=true;busy=true;int epoch=generation;boolean prepare=initial;initial=false;
        Thread worker=new Thread(()->{
            AutoBuyCycle.Snapshot state=null;
            try{
                long readStart=SystemClock.uptimeMillis();
                if(prepare&&!GameEngineProbe.playerFound())GameEngineProbe.run();
                GameEngineProbe.auctionSnapshot(false);state=GameEngineProbe.auctionState();
                if(prepare&&(state==null||!state.complete)&&GameEngineProbe.playerFound()){
                    // Cached bindings can belong to a previous world/player.
                    GameEngineProbe.run();GameEngineProbe.auctionSnapshot(false);state=GameEngineProbe.auctionState();
                }
                lastReadMs=SystemClock.uptimeMillis()-readStart;
                if(SystemClock.uptimeMillis()-lastTelemetry>=3000){lastTelemetry=SystemClock.uptimeMillis();GameRuntime.log("Auto Buy timing: readMs="+lastReadMs+" refreshAttemptGapMs="+lastRefreshGap);}
            }catch(RuntimeException|LinkageError error){GameRuntime.log("Auto Buy worker failed: "+error.getClass().getSimpleName());}
            finally{GameEngineProbe.end();}
            AutoBuyCycle.Snapshot snapshot=state;
            activity.runOnUiThread(()->{
                busy=false;if(disposed||!enabled||epoch!=generation)return;
                if(activity.isFinishing()||activity.isDestroyed()){stop("Игра закрывается");return;}
                if(!this.available.getAsBoolean()){pause();return;}
                AutoBuyCycle.Action action=cycle.next(snapshot,SystemClock.uptimeMillis());report(action.message);nextRead=Math.max(SystemClock.uptimeMillis()+150,cycle.pollAfter());
                if(action.kind==AutoBuyCycle.Kind.STOP){stop(action.message);return;}
                if(action.kind==AutoBuyCycle.Kind.WAIT)return;
                AuctionMemoryProbe.ActionToken token=GameEngineProbe.actionToken(snapshot,action.slot);
                if(action.kind==AutoBuyCycle.Kind.REFRESH){long now=SystemClock.uptimeMillis();if(lastRefreshAt>0)lastRefreshGap=now-lastRefreshAt;lastRefreshAt=now;}
                input.automatic(token,complete->{
                    if(disposed||!enabled||epoch!=generation)return;
                    if(!complete){
                        if(action.kind==AutoBuyCycle.Kind.REFRESH&&input.transientRefreshFailure()){
                            report("Перечитываю аукцион после изменения окна");nextRead=SystemClock.uptimeMillis()+AutoBuyCycle.REFRESH_INTERVAL_MS;
                        }else if(action.kind==AutoBuyCycle.Kind.OPEN&&cycle.openingInterrupted()){
                            report("Выбор лота прерван. Перечитываю аукцион");nextRead=SystemClock.uptimeMillis()+300;
                        }else stop("Ввод отменён: окно или лот изменились. Проверь экран перед повторным включением");
                    }
                    else nextRead=Math.max(SystemClock.uptimeMillis()+(action.kind==AutoBuyCycle.Kind.REFRESH?20:600),cycle.pollAfter());
                });
            });
        },"auto-buy-cycle");worker.setDaemon(true);worker.start();
    }
    public void dispose(){disposed=true;stop("Auto Buy завершён вместе с игрой");}
}
