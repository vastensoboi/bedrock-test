package dev.custom.bedrockgui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Categorized in-window menu. Gameplay entries only enable when a real handler is registered. */
public final class GameMenu {
    public interface Toggle { void setEnabled(boolean enabled) throws Exception; }
    private static final String TARGET = "target", UTILITY = "utility";
    private static final int INK = Color.rgb(222, 235, 229), MUTED = Color.rgb(143, 166, 156);
    private static final int ACCENT = Color.rgb(125, 221, 172);
    private final Activity activity;
    private final SharedPreferences preferences;
    private final FrameLayout root;
    private final Button floating;
    private final View shade;
    private final LinearLayout panel, body, categories, moduleList, details;
    private final ScrollView moduleScroll, detailScroll;
    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final Drag iconDrag, panelDrag;
    private String category, selected;
    private boolean wide = true;

    private static final class Entry {
        final String id, category;
        String title, description;
        Toggle callback;
        boolean enabled;
        Entry(String id, String category, String title, String description) {
            this.id = id;this.category = category;this.title = title;this.description = description;
        }
    }

    public GameMenu(Activity activity) {
        this.activity = activity;
        preferences = activity.getSharedPreferences("game-menu-ui", 0);
        category = preferences.getString("category", UTILITY);
        if (!TARGET.equals(category) && !UTILITY.equals(category)) category = UTILITY;
        root = new FrameLayout(activity);

        shade = new View(activity);
        shade.setBackgroundColor(Color.argb(85, 0, 0, 0));shade.setClickable(true);
        shade.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        shade.setVisibility(View.GONE);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        panel = new LinearLayout(activity);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(background(Color.rgb(15, 24, 20), 18));panel.setElevation(dp(8));
        panel.setPadding(dp(12), dp(8), dp(12), dp(12));panel.setClickable(true);panel.setVisibility(View.GONE);
        LinearLayout header = new LinearLayout(activity);header.setGravity(Gravity.CENTER_VERTICAL);header.setClickable(true);
        LinearLayout brand = new LinearLayout(activity);brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = label("kulich", 23);title.setTypeface(Typeface.DEFAULT_BOLD);title.setTextColor(ACCENT);
        brand.addView(title);TextView hint = label("Перетащи окно за заголовок", 11);hint.setTextColor(MUTED);brand.addView(hint);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = button("×");close.setContentDescription("Закрыть меню");close.setOnClickListener(v -> close());
        header.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        panel.addView(header, new LinearLayout.LayoutParams(-1, dp(54)));
        body = new LinearLayout(activity);panel.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        categories = new LinearLayout(activity);
        moduleList = new LinearLayout(activity);moduleList.setOrientation(LinearLayout.VERTICAL);
        details = new LinearLayout(activity);details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(18), dp(12), dp(12), dp(12));
        moduleScroll = new ScrollView(activity);moduleScroll.setFillViewport(true);moduleScroll.addView(moduleList);
        detailScroll = new ScrollView(activity);detailScroll.setFillViewport(true);detailScroll.addView(details);
        root.addView(panel, new FrameLayout.LayoutParams(dp(740), dp(340)));
        panelDrag = new Drag(panel, "panel.", 0.5f, 0.5f, null);
        header.setOnTouchListener((v, event) -> panelDrag.touch(event));

        floating = button("kulich");floating.setTextSize(13);floating.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable circle = new GradientDrawable();circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(20, 76, 58));circle.setStroke(dp(2), ACCENT);floating.setBackground(circle);
        floating.setStateListAnimator(null);floating.setElevation(dp(16));
        floating.setContentDescription("kulich: нажми для меню или перетащи круглую иконку");
        root.addView(floating, new FrameLayout.LayoutParams(dp(68), dp(68)));
        floating.setOnClickListener(v -> toggle());
        iconDrag = new Drag(floating, "", 0.04f, 0.2f, () -> floating.performClick());
        floating.setOnTouchListener((v, event) -> iconDrag.touch(event));

        addCatalog("auto_buy", "Auto Buy", "Покупка выбранных предметов с учётом ограничения цены.");
        addCatalog("block_trap", "Block Trap", "Размещение блоков вокруг выбранной цели с учётом списка друзей.");
        addCatalog("fast_exp", "Fast Exp", "Ускоренное использование пузырьков опыта из руки.");
        arrange(true);
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> fit());
        activity.getWindow().addContentView(root, new ViewGroup.LayoutParams(-1, -1));root.post(this::fit);
    }

    private void addCatalog(String id, String title, String description) {
        entries.put(id, new Entry(id, UTILITY, title, description));
    }
    /** Bind implemented gameplay behavior to a catalog ID, or add a new utility module. UI thread only. */
    public void addToggle(String id, String title, String description, Toggle callback) {
        addToggle(id, UTILITY, title, description, callback);
    }
    public void addToggle(String id, String category, String title, String description, Toggle callback) {
        if (id == null || id.isEmpty() || callback == null || (!TARGET.equals(category) && !UTILITY.equals(category)))
            throw new IllegalArgumentException("Module requires an ID, category and real callback");
        Entry entry = entries.get(id);
        if (entry != null && entry.callback != null) throw new IllegalArgumentException("Duplicate module ID: " + id);
        if (entry == null) { entry = new Entry(id, category, title, description);entries.put(id, entry); }
        else if (!entry.category.equals(category)) throw new IllegalArgumentException("Module category does not match catalog");
        entry.title = title;entry.description = description;entry.callback = callback;
        renderModules();renderDetails();
    }
    private void arrange(boolean wide) {
        this.wide = wide;body.removeAllViews();detach(categories);detach(moduleScroll);detach(detailScroll);
        categories.setOrientation(wide ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        body.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        if (wide) {
            body.addView(categories, new LinearLayout.LayoutParams(dp(136), -1));
            body.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            body.addView(moduleScroll, new LinearLayout.LayoutParams(dp(180), -1));
            body.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            body.addView(detailScroll, new LinearLayout.LayoutParams(0, -1, 1));
        } else {
            body.addView(categories, new LinearLayout.LayoutParams(-1, dp(60)));
            LinearLayout content = new LinearLayout(activity);
            content.addView(moduleScroll, new LinearLayout.LayoutParams(0, -1, 0.43f));
            content.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            content.addView(detailScroll, new LinearLayout.LayoutParams(0, -1, 0.57f));
            body.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        }
        renderCategories();renderModules();renderDetails();
    }
    private void renderCategories() {
        categories.removeAllViews();
        categoryRow(TARGET, "01", "Таргет");categoryRow(UTILITY, "02", "Вспомогательные\nфункции");
    }
    private void categoryRow(String id, String number, String title) {
        LinearLayout row = new LinearLayout(activity);row.setOrientation(LinearLayout.VERTICAL);
        row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10), dp(8), dp(6), dp(8));
        boolean chosen = id.equals(category);
        row.setBackground(background(chosen ? Color.rgb(28, 57, 42) : Color.rgb(20, 30, 25), 10));
        TextView index = label(number, 11);index.setTextColor(chosen ? ACCENT : MUTED);row.addView(index);
        TextView name = label(title, 14);name.setTextColor(chosen ? INK : MUTED);row.addView(name);
        row.setOnClickListener(v -> {
            category = id;selected = null;preferences.edit().putString("category", id).apply();
            renderCategories();renderModules();renderDetails();
        });
        LinearLayout.LayoutParams bounds = wide ? new LinearLayout.LayoutParams(-1, dp(84)) :
                new LinearLayout.LayoutParams(0, -1, 1);
        bounds.setMargins(dp(3), dp(3), dp(3), dp(3));categories.addView(row, bounds);
    }
    private void renderModules() {
        moduleList.removeAllViews();
        boolean any = false;
        for (Entry entry : entries.values()) {
            if (!entry.category.equals(category)) continue;
            any = true;
            LinearLayout row = new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(14), dp(8), dp(14));
            if (entry.id.equals(selected)) row.setBackground(background(Color.rgb(27, 53, 38), 10));
            TextView dot = label("●", 11);dot.setTextColor(entry.enabled ? ACCENT : MUTED);
            row.addView(dot, new LinearLayout.LayoutParams(dp(20), -2));
            LinearLayout text = new LinearLayout(activity);text.setOrientation(LinearLayout.VERTICAL);
            text.addView(label(entry.title, 16));
            TextView status = label(entry.callback == null ? "Не подключён" : entry.enabled ? "Включён" : "Выключен", 11);
            status.setTextColor(MUTED);text.addView(status);row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
            TextView arrow = label("›", 23);arrow.setTextColor(MUTED);row.addView(arrow);
            row.setOnClickListener(v -> { selected = entry.id;renderModules();renderDetails(); });
            moduleList.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        if (!any) {
            TextView empty = label("Пока нет модулей", 14);empty.setTextColor(MUTED);empty.setPadding(dp(12), dp(20), dp(8), 0);
            moduleList.addView(empty);
        }
    }
    private void renderDetails() {
        details.removeAllViews();Entry entry = entries.get(selected);
        if (entry == null || !entry.category.equals(category)) {
            details.setGravity(Gravity.CENTER);
            TextView icon = label("◇", 54);icon.setTextColor(Color.rgb(64, 86, 74));details.addView(icon);
            TextView hint = label("Выбери модуль", 18);hint.setTextColor(MUTED);details.addView(hint);return;
        }
        details.setGravity(Gravity.TOP);
        TextView title = label(entry.title, 23);title.setTypeface(Typeface.DEFAULT_BOLD);details.addView(title);
        TextView description = label(entry.description, 14);description.setTextColor(MUTED);
        description.setPadding(0, dp(14), 0, dp(20));details.addView(description);
        Switch control = new Switch(activity);control.setText("Включить");control.setTextSize(17);control.setTextColor(INK);
        control.setChecked(entry.enabled);control.setEnabled(entry.callback != null);details.addView(control, new LinearLayout.LayoutParams(-1, dp(48)));
        TextView state = label(entry.callback == null ? "Не подключён к игре" : "Готов к работе", 13);
        state.setTextColor(entry.callback == null ? Color.rgb(210, 181, 123) : ACCENT);state.setPadding(0, dp(12), 0, 0);details.addView(state);
        boolean[] reverting = {false};
        control.setOnCheckedChangeListener((button, enabled) -> {
            if (reverting[0] || entry.callback == null) return;
            try { entry.callback.setEnabled(enabled);entry.enabled = enabled;renderModules(); }
            catch (Exception | LinkageError error) {
                reverting[0] = true;control.setChecked(entry.enabled);reverting[0] = false;
                GameRuntime.log("Menu module failed: " + entry.id + " / " + error);
                Toast.makeText(activity, "Не удалось изменить модуль", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void toggle() { if (panel.getVisibility() == View.VISIBLE) close();else open(); }
    public void open() { shade.setVisibility(View.VISIBLE);panel.setVisibility(View.VISIBLE);floating.bringToFront(); }
    public void close() { panel.setVisibility(View.GONE);shade.setVisibility(View.GONE);floating.bringToFront(); }
    public void dispose() {
        for (Entry entry : entries.values()) if (entry.enabled && entry.callback != null) {
            try { entry.callback.setEnabled(false);entry.enabled = false; }
            catch (Exception | LinkageError error) { GameRuntime.log("Menu module cleanup failed: " + entry.id + " / " + error); }
        }
        detach(root);
    }
    private void fit() {
        if (root.getWidth() == 0 || root.getHeight() == 0) return;
        FrameLayout.LayoutParams bounds = (FrameLayout.LayoutParams) panel.getLayoutParams();
        int width = Math.min(dp(840), Math.max(1, Math.min((int) (root.getWidth() * 0.86f), root.getWidth() - dp(24))));
        int height = Math.min(dp(480), Math.max(1, Math.min((int) (root.getHeight() * 0.86f), root.getHeight() - dp(24))));
        if (bounds.width != width || bounds.height != height) { bounds.width = width;bounds.height = height;panel.setLayoutParams(bounds); }
        boolean useWide = width >= dp(620);if (useWide != wide) arrange(useWide);
        iconDrag.apply();panelDrag.apply();
    }
    private final class Drag {
        final View target;final String prefix;final Runnable tap;
        float x, y, rawX, rawY, startX, startY;int pointer = -1;boolean moved;
        Drag(View target, String prefix, float x, float y, Runnable tap) {
            this.target = target;this.prefix = prefix;this.tap = tap;
            this.x = preferences.getFloat(prefix + "x", x);this.y = preferences.getFloat(prefix + "y", y);
        }
        boolean touch(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pointer = event.getPointerId(0);rawX = event.getRawX(0);rawY = event.getRawY(0);
                    startX = target.getX();startY = target.getY();moved = false;root.requestDisallowInterceptTouchEvent(true);return true;
                case MotionEvent.ACTION_MOVE: move(event);return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerId(event.getActionIndex()) == pointer) {
                        int next = event.getActionIndex() == 0 ? 1 : 0;pointer = event.getPointerId(next);
                        rawX = event.getRawX(next);rawY = event.getRawY(next);startX = target.getX();startY = target.getY();moved = true;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    move(event);if (moved) save();else if (tap != null) tap.run();finish();return true;
                case MotionEvent.ACTION_CANCEL: if (moved) save();finish();return true;
                default: return true;
            }
        }
        void move(MotionEvent event) {
            int index = event.findPointerIndex(pointer);if (index < 0) return;
            float dx = event.getRawX(index) - rawX, dy = event.getRawY(index) - rawY;
            if (Math.hypot(dx, dy) > ViewConfiguration.get(activity).getScaledTouchSlop()) moved = true;
            if (!moved) return;
            int spanX = Math.max(0, root.getWidth() - target.getWidth()), spanY = Math.max(0, root.getHeight() - target.getHeight());
            target.setX(Math.max(0, Math.min(startX + dx, spanX)));target.setY(Math.max(0, Math.min(startY + dy, spanY)));
            if (spanX > 0) x = target.getX() / spanX;if (spanY > 0) y = target.getY() / spanY;
        }
        void apply() { target.setX(x * Math.max(0, root.getWidth() - target.getWidth()));target.setY(y * Math.max(0, root.getHeight() - target.getHeight())); }
        void save() { preferences.edit().putFloat(prefix + "x", x).putFloat(prefix + "y", y).apply(); }
        void finish() { pointer = -1;root.requestDisallowInterceptTouchEvent(false); }
    }
    private static void detach(View view) { if (view.getParent() instanceof ViewGroup) ((ViewGroup) view.getParent()).removeView(view); }
    private int dp(int value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }
    private TextView label(String text, int size) { TextView view = new TextView(activity);view.setText(text);view.setTextSize(size);view.setTextColor(INK);view.setGravity(Gravity.CENTER_VERTICAL);return view; }
    private Button button(String text) { Button view = new Button(activity);view.setText(text);view.setTextColor(INK);view.setTextSize(18);view.setAllCaps(false);view.setMinWidth(0);view.setMinimumWidth(0);view.setPadding(dp(4), 0, dp(4), 0);view.setBackground(background(Color.rgb(29, 57, 43), 12));return view; }
    private View separator() { View view = new View(activity);view.setBackgroundColor(Color.rgb(37, 54, 45));return view; }
    private GradientDrawable background(int color, int radius) { GradientDrawable shape = new GradientDrawable();shape.setColor(color);shape.setCornerRadius(dp(radius));return shape; }
}
