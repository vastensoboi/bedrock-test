package dev.custom.bedrockgui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.util.*;

/** Imports JS as text only, with deterministic private filenames and a size limit. */
public final class ScriptFiles {
    public static final int MAX_BYTES=128*1024;
    private ScriptFiles(){}
    public static String read(InputStream input,int limit)throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[4096];int n;
        while((n=input.read(buffer))!=-1){if(out.size()>limit-n)throw new IOException("Скрипт слишком большой");out.write(buffer,0,n);}
        String text=new String(out.toByteArray(),StandardCharsets.UTF_8);
        return text.startsWith("\ufeff")?text.substring(1):text;
    }
    public static File[] list(File root)throws IOException {
        File canonical=root.getCanonicalFile();File[] files=canonical.listFiles(f->f.getName().matches("script-[0-9a-f]{64}\\.js"));
        if(files==null)return new File[0];
        List<File> result=new ArrayList<>();
        for(File file:files)if(!Files.isSymbolicLink(file.toPath())&&file.isFile()&&file.getParentFile().equals(canonical)&&file.length()<=MAX_BYTES)result.add(file);
        result.sort(Comparator.comparing(File::getName));return result.toArray(new File[0]);
    }
    public static String store(File directory,InputStream input)throws IOException {
        String text=read(input,MAX_BYTES);
        if(text.trim().isEmpty())throw new IOException("Пустой скрипт");
        if(text.contains("@protohax/userscript"))throw new IOException("Нужен скрипт kulich API; API ProtoHax ещё не реализован");
        byte[] bytes=text.getBytes(StandardCharsets.UTF_8);StringBuilder name=new StringBuilder("script-");
        try{for(byte b:MessageDigest.getInstance("SHA-256").digest(bytes))name.append(String.format(Locale.ROOT,"%02x",b&255));}
        catch(NoSuchAlgorithmException error){throw new IOException(error);}
        name.append(".js");File root=directory.getCanonicalFile();
        Files.createDirectories(root.toPath());Path file=new File(root,name.toString()).toPath();
        if(Files.exists(file,LinkOption.NOFOLLOW_LINKS)){
            if(Files.isSymbolicLink(file)||!Files.isRegularFile(file))throw new IOException("Недопустимый файл скрипта");
            return name.toString();
        }
        if(list(root).length>=16)throw new IOException("Лимит: 16 скриптов");
        Files.write(file,bytes,StandardOpenOption.CREATE_NEW);return name.toString();
    }
    public static int archive(File directory,File backup)throws IOException {
        File[] files=list(directory);if(files.length==0)return 0;
        Files.createDirectories(backup.getCanonicalFile().toPath());
        for(File file:files)Files.move(file.toPath(),new File(backup.getCanonicalFile(),file.getName()).toPath(),StandardCopyOption.REPLACE_EXISTING);
        return files.length;
    }
}
