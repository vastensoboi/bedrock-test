package dev.custom.bedrockgui;

import android.content.*;
import android.content.res.*;
import android.content.res.loader.*;
import android.os.ParcelFileDescriptor;
import dalvik.system.DexClassLoader;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Shared state in this app's :game process, never in the installed game's process. */
public final class GameRuntime {
    public static final String ACTIVITY = "dev.custom.bedrockgui.HostedGameActivity";
    public static final String STARTUP = "dev.custom.bedrockgui.NativeStartup";
    public static final String AUTH_BROWSER = "com.microsoft.xal.browser.BrowserLaunchActivity";
    public static final String AUTH_RETURN = "com.microsoft.xal.browser.IntentHandler";
    public static final String AUTH_WEBVIEW = "com.microsoft.xal.browser.WebKitWebViewController";
    public static volatile ClassLoader loader;
    public static String[] apks;
    public static String nativeDirectory;
    public static GameResources resources;
    private static File journal;
    private static ResourcesLoader resourcesLoader;
    private static final List<ResourcesProvider> providers = new ArrayList<>();
    private GameRuntime() {}
    public static synchronized void log(String value) {
        if(journal==null)return;
        try(FileOutputStream out=new FileOutputStream(journal,true)) {
            out.write((System.currentTimeMillis()+" "+value+"\n").getBytes(StandardCharsets.UTF_8));out.getFD().sync();
        } catch(IOException ignored) {}
    }
    public static void prepare(Intent intent,ClassLoader parent) throws Exception {
        if(intent==null||intent.getStringExtra("journal")==null)throw new IOException("No launch parameters");
        journal=new File(intent.getStringExtra("journal"));
        log("Factory: preparing hosted process");
        String logSetup=intent.getStringExtra("contentLogSetup");
        if(logSetup!=null)log(logSetup);
        apks=intent.getStringArrayExtra("apks");
        String lib=intent.getStringExtra("libs"),host=intent.getStringExtra("hostApk"),hostLib=intent.getStringExtra("hostLib");
        if(apks==null||apks.length==0||lib==null||host==null||hostLib==null)throw new IOException("Incomplete launch parameters");
        nativeDirectory=lib;
        String dex=host+File.pathSeparator+String.join(File.pathSeparator,apks);
        loader=new DexClassLoader(dex,intent.getStringExtra("optimized"),lib+File.pathSeparator+hostLib,parent) {
            @Override protected Class<?> loadClass(String name,boolean resolve)throws ClassNotFoundException {
                if(name.equals(ACTIVITY)||name.equals(STARTUP)||name.startsWith("com.mojang.")) {
                    synchronized(this) {
                        Class<?> found=findLoadedClass(name);
                        if(found==null) {
                            try { found=findClass(name); } catch(ClassNotFoundException missing) { found=super.loadClass(name,false); }
                        }
                        if(resolve)resolveClass(found);return found;
                    }
                }
                return super.loadClass(name,resolve);
            }
        };
        log("Factory: game class loader created");
        // Load the bootstrap class through the GAME loader so System.loadLibrary
        // uses its native namespace and the prepared native-library directories.
        Class<?> startup=Class.forName(STARTUP,true,loader);
        startup.getMethod("prepare",String.class,String.class,String[].class)
                .invoke(null,lib,intent.getStringExtra("gameApplication"),intent.getStringArrayExtra("gameProviders"));
        log("Factory: native startup returned");
    }
    public static Context attachResources(Context base)throws IOException {
        Context isolated=base.createConfigurationContext(base.getResources().getConfiguration());
        resourcesLoader=new ResourcesLoader();
        for(String path:apks) {
            try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(new File(path),ParcelFileDescriptor.MODE_READ_ONLY)) {
                ResourcesProvider provider=ResourcesProvider.loadFromApk(fd);
                providers.add(provider);resourcesLoader.addProvider(provider);
            }
        }
        isolated.getResources().addLoaders(resourcesLoader);
        // SDKs retain applicationContext and later resolve game resources there.
        // Previously only the Activity's isolated Resources had game APKs.
        // Keep Context accessors inherited to preserve cached JNI method owners.
        Resources applicationResources=base.getApplicationContext().getResources();
        if(applicationResources!=isolated.getResources())applicationResources.addLoaders(resourcesLoader);
        for(String name:new String[]{"google_app_id","common_google_play_services_unknown_issue"}) {
            int id=applicationResources.getIdentifier(name,"string","com.mojang.minecraftpe");
            log("Application resource lookup: "+name+" -> "+(id==0?"MISS":"available"));
        }
        resources=new GameResources(isolated.getResources(),base.getPackageName());
        resources.addLoaders(resourcesLoader);
        log("Activity: game resources attached");
        return new ContextWrapper(isolated) {
            @Override public ClassLoader getClassLoader(){return loader;}
            @Override public Resources getResources(){return resources;}
            @Override public AssetManager getAssets(){return resources.getAssets();}
        };
    }
}
