#pragma once
#include "aim_core.h"
#include <cstddef>
namespace kulich_aim {
constexpr uint32_t CAMERA=0x4f6047c7U,DIRECT_LOOK=0xceb578f1U;
constexpr uint32_t ACTIVE_CAMERA=0x113040a1U,INPUT_CAMERA=0xf6c60b46U;
// Native optional<StrictEntityContext>: large aggregate returned through x8 on
// AArch64. It owns no reference; use only during the same game-thread callback.
struct CameraContext {A registry=0,storage=0;uint32_t entity=0xffffffffU,padding=0;uint8_t present=0,reserved[7]{};};
struct DirectLook {float yaw=0,pitch=0,pendingYaw=0,minPitch=0,maxPitch=0;};
struct CameraBinding {A camera=0,direct=0;DirectLook look{};};
static_assert(sizeof(CameraContext)==32&&offsetof(CameraContext,present)==24&&offsetof(CameraContext,entity)==16,"Native camera context ABI");
static_assert(sizeof(DirectLook)==20,"Direct look storage stride");
inline bool valid(const DirectLook& d){
 constexpr double pi=3.14159265358979323846;
 return std::isfinite(d.yaw)&&std::abs(d.yaw)<=100&&std::isfinite(d.pitch)&&std::abs(d.pitch)<=pi&&
  std::isfinite(d.pendingYaw)&&std::abs(d.pendingYaw)<=2*pi&&std::isfinite(d.minPitch)&&std::isfinite(d.maxPitch)&&
  d.minPitch>=-pi&&d.maxPitch<=pi&&d.minPitch<d.maxPitch&&d.pitch>=d.minPitch-.01&&d.pitch<=d.maxPitch+.01;
}
template<class Read> bool cameraBinding(Read& read,const CameraContext& context,CameraBinding& out){
 A registry=plain(context.registry);if(context.present!=1||registry<4096||plain(context.storage)!=registry+40||
  (context.entity&0x3ffffU)==0x3ffffU||sparse(read,registry+216,context.entity)<0)return false;
 A active=pool(read,registry,ACTIVE_CAMERA),input=pool(read,registry,INPUT_CAMERA);
 if(!active||!input||sparse(read,active+8,context.entity)<0||sparse(read,input+8,context.entity)<0)return false;
 A camera=taggedComponent(read,pool(read,registry,CAMERA),context.entity,280);
 A direct=taggedComponent(read,pool(read,registry,DIRECT_LOOK),context.entity,20);DirectLook value{};
 if(!camera||!direct||!read(plain(direct),&value,sizeof value)||!valid(value))return false;
 // CameraDirectLookSystem writes a unit quaternion here before rendering.
 float q[4]{};if(!read(plain(camera)+40,q,sizeof q))return false;
 double norm=0;for(float v:q){if(!std::isfinite(v))return false;norm+=double(v)*v;}
 if(norm<.90||norm>1.10)return false;
 out={camera,direct,value};return true;
}
// CameraDirectLookSystem builds q=(sin(p/2)*cos(y/2), cos(p/2)*sin(y/2),
// -sin(p/2)*sin(y/2), cos(p/2)*cos(y/2)). Native camera forward rotates -Z.
// Therefore world pitch=-p and world yaw=pi-y, not the Actor pose. Include
// pending yaw so a second player tick cannot replay an unconsumed correction.
constexpr double CAMERA_RAD=3.14159265358979323846/180.0;
inline bool cameraPose(const DirectLook& look,Angles& pose){
 if(!valid(look))return false;
 pose={float(-look.pitch/CAMERA_RAD),float(180.0-(look.yaw+double(look.pendingYaw))/CAMERA_RAD)};
 return std::isfinite(pose.pitch)&&std::isfinite(pose.yaw);
}
// One input update reaches the requested angle, respecting camera pitch limits.
// Pending yaw is included in cameraPose, so repeated updates do not replay it.
inline bool cameraSnap(Angles desired,const DirectLook& look,Angles& value,Angles& delta){
 Angles current{};if(!cameraPose(look,current)||!std::isfinite(desired.pitch)||!std::isfinite(desired.yaw))return false;
 double pitch=std::fmax(-89.9,std::fmin(89.9,double(desired.pitch)));
 double nativePitch=std::fmax(double(look.minPitch),std::fmin(double(look.maxPitch),-pitch*CAMERA_RAD));
 delta={float((nativePitch-look.pitch)/CAMERA_RAD),float(std::remainder(double(desired.yaw)-current.yaw,360.0))};
 value={float(-nativePitch/CAMERA_RAD),current.yaw+delta.yaw};return true;
}
class AimDeadzone {
 bool quiet=false;
public:
 void reset(){quiet=false;}
 bool hold(double error){if(!std::isfinite(error)){quiet=false;return false;}quiet=error<=(quiet?.24:.12);return quiet;}
};
class AimRamp {
 A actor=0;uint32_t entity=0xffffffffU;int64_t start=0;
public:
 void reset(){actor=0;}
 double scale(A address,uint32_t id,int64_t now){
  if(actor!=address||entity!=id||now<start){actor=address;entity=id;start=now;}
  double t=std::fmax(0.0,std::fmin(1.0,double(now-start)/180));return .25+.75*t*t*(3-2*t);
 }
};
inline Vec aimPoint(const Box& box,bool head){
 return {(double(box.lo[0])+box.hi[0])*.5,box.lo[1]+(box.hi[1]-box.lo[1])*(head?.90:.60),(double(box.lo[2])+box.hi[2])*.5};
}
// Native input uses degrees: native pitch += input.x*rad, pending yaw -=
// input.y*rad. Ease near the actual camera pose and cap combined angular speed.
inline bool cameraInput(Angles desired,double allowance,double seconds,double response,const DirectLook& look,Angles& value,Angles& delta){
 Angles current{};
 if(!cameraPose(look,current)||!std::isfinite(desired.pitch)||!std::isfinite(desired.yaw)||
    !std::isfinite(allowance)||allowance<0||!std::isfinite(seconds)||seconds<0||seconds>.100001||
    !std::isfinite(response)||response<.04||response>.20)return false;
 double dp=std::fmax(-89.9,std::fmin(89.9,double(desired.pitch)))-current.pitch;
 double dy=std::remainder(double(desired.yaw)-current.yaw,360.0);
 // Fast acquisition; retain gentle final approach without tiny repeated nudges.
 double adaptive=response*(.55+.45*std::exp(-std::hypot(dp,dy)/8));
 double alpha=-std::expm1(-seconds/adaptive);
 Angles eased{float(current.pitch+dp*alpha),float(current.yaw+dy*alpha)};
 // Ignore sub-pixel corrections to a stationary point, with no random offsets.
 if(std::hypot(dp,dy)<=.12)eased=current;
 if(!turnToward(current,eased,allowance,value))return false;
 delta={current.pitch-value.pitch,float(std::remainder(double(value.yaw)-current.yaw,360.0))};
 double nativePitch=std::fmax(double(look.minPitch),std::fmin(double(look.maxPitch),look.pitch+delta.pitch*CAMERA_RAD));
 delta.pitch=float((nativePitch-look.pitch)/CAMERA_RAD);value.pitch=current.pitch-delta.pitch;
 return std::isfinite(delta.pitch)&&std::isfinite(delta.yaw)&&angleGap(current,value)<=allowance+.001;
}
}
