package dev.custom.bedrockgui;

import android.content.Context;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.concurrent.TimeUnit;

/** Own UID only; record up to 20 minutes, retaining at most two 2 MiB segments. */
public final class OwnLogCapture {
    private static java.lang.Process current;
    private static final int SEGMENT = 2 * 1024 * 1024;
    private OwnLogCapture() {}

    public static synchronized void start(Context context) {
        if (current != null) current.destroy();
        current = null;
        File directory = context.getFilesDir();
        File status = new File(directory, "own-logcat-status.txt");
        RollingLog log = new RollingLog(directory, SEGMENT);
        try {
            log.reset();
            writeStatus(status, "Запись начата: " + System.currentTimeMillis() +
                    "; лимит времени 20 минут, хранится до 4 МиБ.");
            java.lang.Process process = new ProcessBuilder("/system/bin/logcat",
                    "--uid=" + android.os.Process.myUid(), "-v", "threadtime", "-T", "1")
                    .redirectErrorStream(true).start();
            current = process;
            Thread reader = new Thread(() -> {
                String end = "Поток logcat завершён";
                try (InputStream input = process.getInputStream()) {
                    byte[] buffer = new byte[4096];int count;
                    while ((count = input.read(buffer)) != -1) {
                        synchronized (OwnLogCapture.class) {
                            if (current != process) return;
                            log.append(buffer, count);
                        }
                    }
                } catch (IOException error) {
                    end = "Поток logcat остановлен: " + error;
                } finally {
                    process.destroy();
                    synchronized (OwnLogCapture.class) {
                        if (current == process) {
                            writeStatus(status, end + "; время: " + System.currentTimeMillis());
                            current = null;
                        }
                    }
                }
            }, "own-logcat-reader");
            reader.setDaemon(true);reader.start();
            Thread timeout = new Thread(() -> {
                try { if (!process.waitFor(20, TimeUnit.MINUTES)) process.destroy(); }
                catch (InterruptedException error) { Thread.currentThread().interrupt();process.destroy(); }
            }, "own-logcat-timeout");
            timeout.setDaemon(true);timeout.start();
        } catch (IOException error) {
            writeStatus(status, "Logcat недоступен: " + error);
        }
    }
    private static void writeStatus(File file, String value) {
        try { Files.write(file.toPath(), value.getBytes(StandardCharsets.UTF_8)); }
        catch (IOException ignored) {}
    }
    public static String tail(Context context) throws IOException {
        File directory = context.getFilesDir();
        File status = new File(directory, "own-logcat-status.txt");
        String state = status.isFile() ? new String(Files.readAllBytes(status.toPath()), StandardCharsets.UTF_8) :
                "Состояние записи недоступно.";
        byte[] bytes = new RollingLog(directory, SEGMENT).tail(256 * 1024);
        return state + "\n" + (bytes.length == 0 ? "Собственный logcat не записан." :
                new String(bytes, StandardCharsets.UTF_8));
    }
}
