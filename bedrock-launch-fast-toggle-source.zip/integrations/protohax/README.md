# Auto Buy preparation

This script requires @protohax/userscript and its packet/container API. The
Android launcher does not execute it. Auto Buy in kulich is still unavailable;
no purchase toggle is enabled until live container reads and server-backed
clicks are implemented. rules.json contains the migrated rule data for that work.

The supplied script had a missing object brace, nme/ration typos, and shared
armor defaults overwriting per-item prices. These are repaired. Live auction
NBT is re-parsed instead of trusting a stack-ID/count cache. Confirmation
requires a readable matching price/seller when verification is enabled. New
enables reset previous auction samples. Dry run is enabled by default and sends
no click, refresh or pagination requests. Submitted purchase requests are not
reported as confirmed purchases. These fixes do not validate server packet ABI.

Local mock tests covered price-rule precedence, changed NBT with the same stack
ID, invalid counts, zero outgoing packets in dry run, and cancellation when the
confirmation price is missing. Actual ProtoHax/server testing is still needed.
