#pragma once
#include "aim_core.h"

namespace kulich_static_items {
using namespace kulich_aim;
constexpr A RENDERER_TABLE=0x139d57d8ULL,ITEM_ACTOR_TABLE=0x13d4e468ULL,RENDER=0xab71828ULL;
constexpr A PRESENTATION_FLAG=1112;
struct Binding {
 A client=0,registry=0,actor=0,renderer=0,renderData=0,flag=0;
 uint32_t entity=0xffffffffU;
 uint8_t value=0;
};

// ActorRenderData owns a pointer to the live, registered ItemActor. Preserve
// that pointer's memory tag for the scoped byte write; reads use plain addresses.
// The exact-build flag gates native item presentation, not world simulation.
template<class Read> bool resolve(Read& read,A base,A client,A renderer,A renderData,Binding& out){
 out={};client=plain(client);
 if(!base||client<4096||plain(renderer)<4096||plain(renderData)<4096||
    pointer(read,client)!=base+0x1388fe70ULL||pointer(read,renderer)!=base+RENDERER_TABLE)return false;
 A weak[3]{};
 if(!read(client+576,weak,sizeof weak)||plain(weak[0])<4096||!plain(weak[1]))return false;
 A registry=plain(weak[0]);uint32_t localEntity=uint32_t(weak[2]);
 if((localEntity&0x3ffffU)==0x3ffffU||sparse(read,registry+216,localEntity)<0)return false;
 A rawActor=0;
 if(!read(plain(renderData),&rawActor,8)||plain(rawActor)<4096)return false;
 A address=plain(rawActor),header[4]{};
 if(!read(address,header,sizeof header)||plain(header[0])!=base+ITEM_ACTOR_TABLE||
    plain(header[1])!=registry||plain(header[2])!=registry+40)return false;
 uint32_t entity=uint32_t(header[3]);
 if((entity&0x3ffffU)==0x3ffffU||entity==localEntity||sparse(read,registry+216,entity)<0)return false;
 uint8_t removed=1,flag=0;
 if(!read(address+617,&removed,1)||removed||!read(address+PRESENTATION_FLAG,&flag,1)||flag>1)return false;
 A owners=pool(read,registry,OWNER),owner=component(read,owners,entity,8);
 if(!owner||pointer(read,owner)!=address)return false;
 // Bind to the current local player's world; stale menu/previous-world
 // render data must not become writable merely because its vptr matches.
 A localOwner=component(read,owners,localEntity,8),local=pointer(read,localOwner),localHeader[4]{};
 if(!localOwner||!local||!read(local,localHeader,sizeof localHeader)||
    plain(localHeader[0])!=base+0x139f6ea0ULL||plain(localHeader[1])!=registry||
    plain(localHeader[2])!=registry+40||uint32_t(localHeader[3])!=localEntity||
    pointer(read,local+3240)!=client)return false;
 uint8_t localRemoved=1;
 if(!read(local+617,&localRemoved,1)||localRemoved)return false;
 A currentWeak[3]{},currentActor=0;
 if(!read(client+576,currentWeak,sizeof currentWeak)||std::memcmp(weak,currentWeak,sizeof weak)||
    !read(plain(renderData),&currentActor,8)||currentActor!=rawActor)return false;
 out={client,registry,rawActor,renderer,renderData,rawActor+PRESENTATION_FLAG,entity,flag};return true;
}

inline bool same(const Binding& a,const Binding& b){
 return a.client==b.client&&a.registry==b.registry&&a.actor==b.actor&&a.renderer==b.renderer&&
        a.renderData==b.renderData&&a.flag==b.flag&&a.entity==b.entity;
}

// The engine draws exactly once. Never retain an ItemActor pointer or modify
// age, position, velocity, inventory or pickup. Restore only the same live
// binding, and only if the engine left our byte unchanged.
template<class Write,class Lookup,class Original>
bool invoke(Write& write,Lookup lookup,Original original,bool enabled){
 Binding before{};
 bool changed=enabled&&lookup(before)&&before.value==0&&write(before.flag,uint8_t(1));
 auto restore=[&](){
  if(!changed)return;
  Binding after{};
  if(lookup(after)&&same(before,after)&&after.value==1)write(before.flag,before.value);
 };
 try{original();}catch(...){restore();throw;}
 restore();return changed;
}
}
