#pragma once
#include <string>
#include <set>
namespace kulich_aim {
// Normalize verified raw names; display text may veto an attack, never prove
// that an unknown actor is an enemy.
inline std::string friendKey(const char* name){
 if(!name)return {};
 std::string key;
 for(const unsigned char* p=reinterpret_cast<const unsigned char*>(name);*p;p++){
  unsigned char c=*p;if(key.size()>=16)return {};
  if(c>='A'&&c<='Z')c=static_cast<unsigned char>(c-'A'+'a');
  if(!((c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'))return {};
  key.push_back(static_cast<char>(c));
 }
 return key;
}
class FriendPolicy {
 std::set<std::string> names;
 static bool asciiName(unsigned char c){return (c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_';}
 static bool wordByte(unsigned char c){return asciiName(c)||c>=0x80;}
 bool displayFriend(const char* display)const{
  if(!display)return false;
  // The caller supplies a bounded native display string. Minecraft colour and
  // style controls are UTF-8 C2 A7 followed by one ASCII alphanumeric code.
  std::string text;
  for(size_t i=0;i<384&&display[i];){
   unsigned char c=static_cast<unsigned char>(display[i]);
   if(c==0xc2&&i+2<384&&static_cast<unsigned char>(display[i+1])==0xa7&&display[i+2]&&
      ((display[i+2]>='0'&&display[i+2]<='9')||(display[i+2]>='A'&&display[i+2]<='Z')||(display[i+2]>='a'&&display[i+2]<='z'))){i+=3;continue;}
   text.push_back(display[i++]);
  }
  unsigned brackets=0;
  for(size_t i=0;i<text.size();){
   unsigned char c=static_cast<unsigned char>(text[i]);
   if(c=='['){brackets++;i++;continue;}
   if(c==']'){if(brackets)brackets--;i++;continue;}
   if(brackets||!wordByte(c)){i++;continue;}
   size_t start=i;bool digits=true;
   while(i<text.size()&&wordByte(static_cast<unsigned char>(text[i]))){if(text[i]<'0'||text[i]>'9')digits=false;i++;}
   // Treat non-ASCII bytes as part of a word, so Ann inside a Cyrillic/Latin
   // mixed word cannot accidentally match. Numeric HP tokens are not aliases.
   if(digits||i-start>16)continue;
   std::string token=text.substr(start,i-start),key=friendKey(token.c_str());
   if(!key.empty()&&names.count(key))return true;
  }
  return false;
 }
public:
 enum Decision{Enemy,Friend,Unknown};
 bool replace(const std::string& encoded){
  if(encoded.size()>2176)return false;
  std::set<std::string> next;size_t start=0;
  while(start<encoded.size()){
   size_t end=encoded.find('\n',start);if(end==std::string::npos)end=encoded.size();
   std::string row=encoded.substr(start,end-start),key=friendKey(row.c_str());
   if(row.find('\0')!=std::string::npos||key.empty()||next.size()>=128)return false;
   next.insert(key);start=end+1;
  }
  names.swap(next);return true;
 }
 bool empty()const{return names.empty();}
 size_t size()const{return names.size();}
 Decision check(const char* rawName,const char* displayName=nullptr)const{
  if(names.empty())return Enemy;
  std::string key=friendKey(rawName);
  if((!key.empty()&&names.count(key))||displayFriend(displayName))return Friend;
  // A heuristic display match can only protect; it never authorizes attacks.
  return key.empty()?Unknown:Enemy;
 }
};
}
