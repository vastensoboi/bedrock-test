package dev.custom.bedrockgui;

import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.View;
import java.util.*;

/** Passive full-viewport overlay, including native render roll/bob. Unknown projection uses a labelled top-down plan. */
public final class PearlTrajectoryView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;private PearlPrediction.Frame frame;private boolean enabled;
    public PearlTrajectoryView(Context context){super(context);density=getResources().getDisplayMetrics().density;setClickable(false);setFocusable(false);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
    public void setEnabledPrediction(boolean value){enabled=value;setVisibility(value?VISIBLE:GONE);if(!value)frame=null;invalidate();}
    public void updateSnapshot(String snapshot){frame=PearlPrediction.parse(snapshot,SystemClock.uptimeMillis());invalidate();}
    private float dp(float value){return value*density;}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);long now=SystemClock.uptimeMillis();if(!enabled||frame==null||!frame.fresh(now)||frame.pearls.isEmpty())return;
        boolean world=frame.camera.projectsWorld();float radius=dp(86),cx=getWidth()-radius-dp(14),cy=radius+dp(42);
        if(!world){
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(0x66ffffff);canvas.drawCircle(cx,cy,radius,paint);canvas.drawLine(cx-dp(5),cy,cx+dp(5),cy,paint);canvas.drawLine(cx,cy-dp(5),cx,cy+dp(5),paint);
            text(canvas,"Жемчуг · план сверху",cx-radius,cy-radius-dp(10),Color.WHITE);
        }
        int index=0;for(PearlPrediction.Pearl pearl:frame.pearls){
            int color=pearl.owner==0?0xff87f1a8:pearl.owner==1?0xffffb36b:0xffe7e7ff;
            List<PearlPrediction.Vec> positions=PearlPrediction.simulate(pearl,PearlPrediction.MAX_TICKS);Path line=new Path();boolean started=false;PearlPrediction.Point last=null;
            int save=canvas.save();if(!world)canvas.clipRect(cx-radius,cy-radius,cx+radius,cy+radius);
            for(PearlPrediction.Vec position:positions){
                PearlPrediction.Point point=world?PearlPrediction.project(position,frame.camera,getWidth(),getHeight()):PearlPrediction.topDown(position,frame.camera,cx,cy,radius/64.0);
                if(point==null){started=false;continue;}
                if(!started){line.moveTo((float)point.x,(float)point.y);started=true;}else line.lineTo((float)point.x,(float)point.y);last=point;
            }
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(2));paint.setColor(color);canvas.drawPath(line,paint);canvas.restoreToCount(save);
            double eta=PearlPrediction.secondsToLanding(pearl,now-frame.capturedAt);
            String label=(pearl.owner==0?"Твой":pearl.owner==1?"Другой":"Жемчуг")+" · "+(Double.isNaN(eta)?"время неизвестно":String.format(Locale.ROOT,"≈ %.1f с",eta));
            if(world&&last!=null&&last.x>=0&&last.x<=getWidth()&&last.y>=0&&last.y<=getHeight())text(canvas,label,(float)Math.min(last.x,getWidth()-dp(150)),(float)Math.max(dp(18),last.y),color);
            else if(!world&&index<4)text(canvas,label,cx-radius,cy+radius+dp(18+index*16),color);
            index++;
        }
        postInvalidateDelayed(50);
    }
    private void text(Canvas canvas,String value,float x,float y,int color){paint.setStyle(Paint.Style.FILL);paint.setColor(color);paint.setTextSize(dp(11));paint.setShadowLayer(dp(1),0,dp(1),Color.BLACK);canvas.drawText(value,x,y,paint);paint.clearShadowLayer();}
}
