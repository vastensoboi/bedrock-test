#pragma once
#include <cstdint>
#include <string>
#include "own_frame_trace.h"
namespace kulich_own_step {
std::string install(uint64_t base,uint64_t client);
bool ready();
void settingsChanged();
kulich_frame::Trace input(void* sender,void* packet,uint64_t callerLr,uint64_t callerSp)noexcept;
std::string report();
}
