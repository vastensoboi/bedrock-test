package dev.custom.bedrockgui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public final class OwnLogRecorderTest {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    private static void await(CountDownLatch latch)throws Exception{check(latch.await(5,TimeUnit.SECONDS),"Timed out waiting for capture thread");}
    private static final class Feed extends InputStream {
        final BlockingQueue<byte[]> chunks=new LinkedBlockingQueue<>();
        final Semaphore reads=new Semaphore(0);
        final CountDownLatch closed=new CountDownLatch(1);
        static final byte[] EOF=new byte[0];
        void offer(String value){chunks.add(value.getBytes(StandardCharsets.UTF_8));}
        void eof(){chunks.add(EOF);}
        void ready()throws Exception{check(reads.tryAcquire(5,TimeUnit.SECONDS),"Reader did not request data");}
        @Override public int read(){throw new AssertionError("Recorder should read bounded chunks");}
        @Override public int read(byte[] out,int offset,int size)throws IOException{
            reads.release();
            try{
                byte[] next=chunks.take();if(next==EOF)return -1;
                check(next.length<=size,"Test chunk exceeds reader buffer");
                System.arraycopy(next,0,out,offset,next.length);return next.length;
            }catch(InterruptedException error){Thread.currentThread().interrupt();throw new IOException(error);}
        }
        @Override public void close(){closed.countDown();}
    }
    private static final class FakeProcess extends Process {
        final Feed feed=new Feed();
        final CountDownLatch waiting=new CountDownLatch(1),exited=new CountDownLatch(1),destroyed=new CountDownLatch(1);
        volatile boolean alive=true,timedOut;
        void expire(){timedOut=true;exited.countDown();}
        @Override public InputStream getInputStream(){return feed;}
        @Override public InputStream getErrorStream(){return new ByteArrayInputStream(new byte[0]);}
        @Override public OutputStream getOutputStream(){return new ByteArrayOutputStream();}
        @Override public boolean isAlive(){return alive;}
        @Override public int exitValue(){if(alive)throw new IllegalThreadStateException();return 0;}
        @Override public int waitFor()throws InterruptedException{exited.await();return 0;}
        @Override public boolean waitFor(long value,TimeUnit unit)throws InterruptedException{
            waiting.countDown();
            if(!exited.await(10,TimeUnit.SECONDS))throw new AssertionError("Test did not release timeout");
            return !timedOut;
        }
        @Override public void destroy(){alive=false;exited.countDown();destroyed.countDown();}
    }
    private static int foreignLease(File directory)throws Exception{
        Process child=new ProcessBuilder(new File(System.getProperty("java.home"),"bin/java").getPath(),
                "-cp",System.getProperty("java.class.path"),OwnLogRecorderTest.class.getName(),
                "lease",directory.getAbsolutePath()).redirectErrorStream(true).start();
        check(child.waitFor(5,TimeUnit.SECONDS),"Cross-process lock check hung");
        return child.exitValue();
    }
    public static void main(String[] args)throws Exception{
        if(args.length==2&&args[0].equals("lease")){
            try(CaptureLease lease=CaptureLease.acquire(new File(args[1]))){System.exit(lease==null?3:0);}
        }
        File directory=Files.createTempDirectory("own-log-recorder").toFile();
        List<FakeProcess> processes=new ArrayList<>();
        AtomicLong clock=new AtomicLong(100);
        AtomicInteger starts=new AtomicInteger();
        OwnLogRecorder recorder=new OwnLogRecorder(20000,4096,()->{
            starts.incrementAndGet();FakeProcess process=new FakeProcess();processes.add(process);return process;
        },clock::get);
        try{
            check(recorder.start(directory,true),"Initial writer did not start");
            FakeProcess first=processes.get(0);first.feed.ready();await(first.waiting);
            first.feed.offer("INITIAL HISTORY\n");first.feed.ready();
            check(recorder.start(directory,false)&&starts.get()==1,"Resume restarted a healthy writer");
            byte[] history=new RollingLog(directory,4096).tail(8192);
            OwnLogRecorder contender=new OwnLogRecorder(20000,4096,()->{throw new AssertionError("Second writer started");},clock::get);
            check(!contender.start(directory,true),"Another recorder acquired an active writer");
            check(Arrays.equals(history,new RollingLog(directory,4096).tail(8192)),"Contender reset active logs");
            check(foreignLease(directory)==3,"A separate process acquired an active writer");

            // The old timeout thread has not yet ended: elapsed-clock expiry at
            // resume must replace its process and preserve accumulated history.
            clock.set(20101);
            check(recorder.start(directory,false)&&starts.get()==2,"Expired capture was not recovered");
            check(!first.isAlive(),"Expired process was not stopped");
            FakeProcess second=processes.get(1);second.feed.ready();
            String resumed=new String(new RollingLog(directory,4096).tail(8192),StandardCharsets.UTF_8);
            check(resumed.contains("INITIAL HISTORY")&&resumed.contains("Запись возобновлена"),"Resume discarded history");
            String status=Files.readString(new File(directory,"own-logcat-status.txt").toPath());
            first.feed.offer("STALE READER DATA\n");await(first.feed.closed);
            check(recorder.start(directory,false)&&starts.get()==2,"Stale reader stopped new process");
            check(status.equals(Files.readString(new File(directory,"own-logcat-status.txt").toPath())),"Stale reader overwrote new status");
            check(!new String(new RollingLog(directory,4096).tail(8192),StandardCharsets.UTF_8).contains("STALE READER"),"Old process wrote after ownership transfer");

            // Timeout of an active recorder is explicit; its buffered reader
            // may finish after a new writer has taken over.
            await(second.waiting);second.expire();await(second.destroyed);
            check(Files.readString(new File(directory,"own-logcat-status.txt").toPath()).contains("Лимит времени записи истёк"),"Timeout reason missing");
            check(recorder.start(directory,false)&&starts.get()==3,"Timeout could not recover");
            FakeProcess third=processes.get(2);third.feed.ready();
            second.feed.eof();await(second.feed.closed);
            check(recorder.start(directory,false)&&starts.get()==3,"Old timeout cleanup affected recovery");
            check(foreignLease(directory)==3,"Recovery lost cross-process ownership");

            for(int i=0;i<5;i++){third.feed.offer("x".repeat(4096));third.feed.ready();}
            check(new File(directory,"own-logcat.txt").length()<=4096&&new File(directory,"own-logcat.previous.txt").length()<=4096,"Segments exceeded bounds");
            recorder.stop();
            check(foreignLease(directory)==0,"Stop did not release kernel ownership");
            third.feed.eof();await(third.feed.closed);
            OwnLogRecorder failing=new OwnLogRecorder(20000,4096,()->{throw new IOException("expected start failure");},clock::get);
            check(!failing.start(directory,false)&&failing.problem().contains("expected start failure"),"Start failure was not retained");
            check(foreignLease(directory)==0,"Failed start retained lock");
            check(recorder.start(directory,true),"New launch did not acquire released ownership");
            FakeProcess fourth=processes.get(3);fourth.feed.ready();
            check(new RollingLog(directory,4096).tail(8192).length<4096,"Fresh launch retained previous session");
            fourth.feed.eof();await(fourth.destroyed);
            check(recorder.start(directory,false)&&starts.get()==5,"EOF did not allow recovery");
            processes.get(4).feed.ready();
            recorder.stop();
        }finally{
            recorder.stop();
            for(FakeProcess process:processes){process.destroy();process.feed.eof();}
            try(var paths=Files.walk(directory.toPath())){
                for(Path path:paths.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(path);
            }
        }
        System.out.println("PASS: single writer across processes, idempotent resume, expired/EOF capture recovery, retained bounded history, stale reader/timeout guards, explicit timeout, failed-start lock release and fresh-launch reset");
    }
}
