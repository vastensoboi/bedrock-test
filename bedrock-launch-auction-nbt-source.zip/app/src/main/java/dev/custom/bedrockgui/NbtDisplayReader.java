package dev.custom.bedrockgui;

import java.io.*;
import java.nio.*;
import java.nio.charset.*;
import java.util.*;

/** Exact-build, read-only display.Name/display.Lore decoder, not a general NBT dump. */
public final class NbtDisplayReader {
    public interface Reader { byte[] read(long address,int bytes)throws IOException; }
    public static final class Display {
        public String name="";public final List<String> lore=new ArrayList<>();
        public String log(){return "name="+quote(name)+" lore="+quote(String.join(" | ",lore));}
    }
    private final Reader reader;private final long base;
    public NbtDisplayReader(Reader reader,long base){this.reader=reader;this.base=base;}
    private static long q(byte[] bytes,int at){return EngineMemoryProbe.untag(ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).getLong(at));}
    private static int n(byte[] bytes,int at){return ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).getInt(at);}
    private String string(long address,int limit)throws IOException {
        byte[] header=reader.read(address,24);if(header==null)return null;
        boolean large=(header[0]&1)!=0;long size=large?q(header,8):(header[0]&255)>>>1;
        if(size>limit||(!large&&size>22))return null;
        byte[] bytes=large?reader.read(q(header,16),(int)size):Arrays.copyOfRange(header,1,1+(int)size);
        if(bytes==null||!Arrays.equals(header,reader.read(address,24)))return null;
        try{return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();}
        catch(CharacterCodingException error){return null;}
    }
    private long find(long compound,String wanted)throws IOException {
        byte[] header=reader.read(compound,32);if(header==null||q(header,0)!=base+0x13ebe0b0L)return 0;
        ArrayDeque<Long> queue=new ArrayDeque<>();Set<Long> seen=new HashSet<>();long root=q(header,16);if(root!=0)queue.add(root);
        long result=0;
        while(!queue.isEmpty()&&seen.size()<128){
            long node=queue.remove();if(!seen.add(node))continue;
            byte[] entry=reader.read(node,104);if(entry==null)continue;
            String key=string(node+32,128);
            if(wanted.equals(key)){
                int alternative=n(entry,96);
                if(alternative>=0&&alternative<16)result=node+56;
                break;
            }
            long left=q(entry,0),right=q(entry,8);if(left!=0)queue.add(left);if(right!=0)queue.add(right);
        }
        return Arrays.equals(header,reader.read(compound,32))?result:0;
    }
    public Display read(long tag)throws IOException {
        long display=find(tag,"display");if(display==0)return null;
        byte[] compound=reader.read(display,32);if(compound==null||q(compound,0)!=base+0x13ebe0b0L)return null;
        Display value=new Display();long name=find(display,"Name");
        if(name!=0){byte[] type=reader.read(name,8);if(type!=null&&q(type,0)==base+0x13ebe5f8L){String s=string(name+8,512);if(s!=null)value.name=s;}}
        long lore=find(display,"Lore");
        if(lore!=0){
            byte[] list=reader.read(lore,32);
            if(list!=null&&q(list,0)==base+0x13ebe350L){
                long begin=q(list,8),end=q(list,16),cap=q(list,24);long length=end-begin;
                if(begin!=0&&end>=begin&&cap>=end&&cap-begin<=8*256&&length%8==0&&length<=8*64){
                    byte[] pointers=reader.read(begin,(int)length);int total=0;
                    if(pointers!=null)for(int i=0;i<pointers.length&&value.lore.size()<24;i+=8){
                        long item=q(pointers,i);byte[] type=reader.read(item,8);
                        if(type==null||q(type,0)!=base+0x13ebe5f8L)break;
                        String s=string(item+8,1024);if(s==null||total+s.length()>4096)break;
                        value.lore.add(s);total+=s.length();
                    }
                    if(!Arrays.equals(list,reader.read(lore,32))||!Arrays.equals(pointers,reader.read(begin,(int)length)))return null;
                }
            }
        }
        if(!Arrays.equals(compound,reader.read(display,32)))return null;
        return value.name.isEmpty()&&value.lore.isEmpty()?null:value;
    }
    private static String quote(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","\\r").replace("\n","\\n").replace("\t","\\t")+"\"";}
}
