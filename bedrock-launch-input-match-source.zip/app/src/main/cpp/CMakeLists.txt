cmake_minimum_required(VERSION 3.22.1)
project(kulichbridge LANGUAGES CXX ASM)
add_library(kulichbridge SHARED fast_exp.cpp no_slow.cpp static_items.cpp pearl.cpp block_trap.cpp local_timer.cpp movement_correction.cpp movement_input.S aim.cpp transaction_action.cpp transaction_trace.cpp transaction_response.S)
target_compile_features(kulichbridge PRIVATE cxx_std_17)
target_link_libraries(kulichbridge PRIVATE m)
target_compile_options(kulichbridge PRIVATE
    $<$<COMPILE_LANGUAGE:CXX>:-Wall>
    $<$<COMPILE_LANGUAGE:CXX>:-Wextra>
    $<$<COMPILE_LANGUAGE:CXX>:-Werror>
    $<$<COMPILE_LANGUAGE:CXX>:-mbranch-protection=standard>)
