package dev.custom.bedrockgui;

import android.content.res.Resources;
import java.util.HashSet;
import java.util.Set;

/** Resolve the game's dynamic resource names without changing Android package/UID identity. */
public final class GameResources extends Resources {
    private static final String GAME = "com.mojang.minecraftpe";
    private final String hostPackage;
    private final Set<String> reported = new HashSet<>();
    public GameResources(Resources base,String hostPackage) {
        super(base.getAssets(),base.getDisplayMetrics(),base.getConfiguration());
        this.hostPackage=hostPackage;
    }
    @Override public int getIdentifier(String name,String type,String packageName) {
        int original=super.getIdentifier(name,type,packageName);
        if(original!=0||name==null)return original;
        String remapped=ResourceNames.gameName(name,packageName,hostPackage);
        if(remapped==null)return 0;
        int result=super.getIdentifier(remapped,type,GAME);
        report(name+" / "+type+" / "+packageName,
                result==0?"MISS":"mapped to 0x"+Integer.toHexString(result));
        return result;
    }
    private synchronized void report(String key,String result) {
        if(reported.size()<32&&reported.add(key))GameRuntime.log("Resource lookup: "+key+" -> "+result);
    }
}
