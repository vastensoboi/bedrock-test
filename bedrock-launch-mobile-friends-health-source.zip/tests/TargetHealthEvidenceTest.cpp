#include "../app/src/main/cpp/aim_health_evidence.h"
#include <cassert>
#include <vector>
#include <iostream>
using namespace kulich_aim;
struct Memory {
 static constexpr A root=0x10000;std::vector<unsigned char> data=std::vector<unsigned char>(0x10000);unsigned reads=0;bool corrupt=false;
 template<class T> void put(A at,T value){assert(at>=root&&at-root+sizeof value<=data.size());std::memcpy(data.data()+at-root,&value,sizeof value);}
 bool operator()(A at,void* out,size_t size){reads++;if(at<root||at-root>data.size()||size>data.size()-(at-root))return false;std::memcpy(out,data.data()+at-root,size);if(corrupt&&at==root+0x2000&&reads>20)static_cast<unsigned char*>(out)[0]^=8;return true;}
};
int main(){
 Memory m;constexpr A actor=Memory::root+0x100,data=Memory::root+0x2000,items=Memory::root+0x3000,item=Memory::root+0x4000,table=Memory::root+0x5000,fn=Memory::root+0x6000;
 assert(metadataEvidence(m,actor)=="metadata unavailable");
 m.put(actor+320,data);m.put(data,items);m.put(data+8,items+85*8);m.put(items+84*8,item);m.put(item,table);m.put(table+24,fn);
 m.put<uint32_t>(fn,0x52800080);m.put<uint32_t>(fn+4,0xd65f03c0);std::array<unsigned char,24> s{};std::string tag="3/24 ";s[0]=static_cast<unsigned char>(tag.size()*2);std::memcpy(s.data()+1,tag.data(),tag.size());m.put(item+16,s);
 auto before=m.data;std::string result=metadataEvidence(m,actor);assert(result.find("id=84 type=4 utf8hex=332f323420")!=std::string::npos&&m.data==before);
 // Primitive data is raw evidence, not a fabricated health interpretation.
 m.put<uint32_t>(fn,0x52800060);m.put<uint64_t>(item+8,0x0102030405060708ULL);result=metadataEvidence(m,actor);assert(result.find("type=3 raw8=0807060504030201")!=std::string::npos);
 m.put<uint32_t>(fn,0x52800020);result=metadataEvidence(m,actor);assert(result.find("type=1 raw8=")!=std::string::npos);
 m.put<uint32_t>(fn+4,0);assert(metadataEvidence(m,actor)=="metadata contains no readable values");
 m.put(data+8,items+1025*8);assert(metadataEvidence(m,actor)=="metadata unavailable");
 // A valid large vector is scanned only through id127, with bounded output.
 m.put(data+8,items+1024*8);m.put(items+200*8,item);m.put(items+84*8,A(0));m.put<uint32_t>(fn+4,0xd65f03c0);m.reads=0;result=metadataEvidence(m,actor);assert(result=="metadata contains no readable values"&&m.reads<140);
 std::cout<<"PASS: bounded typed metadata health evidence, UTF-8 hex, primitive raw fields, readonly and malformed guards\n";
}
