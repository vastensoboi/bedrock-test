#pragma once
#include <cstdint>
#include <limits>
namespace kulich_callsite {
constexpr uint64_t RETURN_OFFSET=0xaf64da8ULL,PACKET_STACK_OFFSET=120;
// This is the exact profiled native construction/send site, not a test for
// whether a numeric tick happens to resemble the current world counter.
inline bool fresh(uint64_t base,uint64_t packet,uint64_t callerLr,uint64_t callerSp){
 constexpr uint64_t mask=0x00ffffffffffffffULL;
 return base&&base<=mask-RETURN_OFFSET&&(callerLr&mask)==base+RETURN_OFFSET&&
  (callerSp&mask)>=4096&&!(callerSp&15)&&
  callerSp<=std::numeric_limits<uint64_t>::max()-PACKET_STACK_OFFSET&&
  packet==callerSp+PACKET_STACK_OFFSET;
}
}
