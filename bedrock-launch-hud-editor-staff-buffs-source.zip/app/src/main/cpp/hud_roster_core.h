#pragma once
#include "aim_combat.h"
#include <set>
#include <string>
#include <vector>
namespace kulich_hud {
using namespace kulich_aim;
// Level::getPlayerListMap at10b16318 reads Level+1192. UUID lookup at
//10ad97f4 hashes the two UUID words and returns the native name string at
//hashnode+80 (success at10ad98ac), not an Actor proximity list.
template<class Read> bool levelRoster(Read& read,A base,A level,const std::string& knownPlayer,std::vector<std::string>& out){
 out.clear();level=plain(level);
 if(knownPlayer.empty()||pointer(read,level)!=base+0x13e0a0f8ULL)return false;
 A map=pointer(read,level+1192),h[4]{},again[4]{};
 if(!map||!read(map,h,sizeof h)||h[1]>8192||h[3]>1024||!h[3]||!h[1]||!plain(h[0])||!plain(h[2]))return false;
 std::set<A> visited;std::vector<std::string> names;bool associated=false;A node=plain(h[2]);
 while(node){
  if(visited.size()>=h[3]||!visited.insert(node).second)return false;
  char name[385]{};if(!playerString(read,node+80,name,sizeof name)||!name[0])return false;
  std::string value(name);if(value==knownPlayer)associated=true;
  names.push_back(value);A next=0;if(!read(node,&next,8))return false;node=plain(next);
 }
 if(visited.size()!=h[3]||!associated||pointer(read,level)!=base+0x13e0a0f8ULL||pointer(read,level+1192)!=map||!read(map,again,sizeof again)||std::memcmp(h,again,sizeof h))return false;
 out.swap(names);return true;
}
// Discover a directly referenced RTTI-verified Level in the already validated
//client/player object. No guessed Level pointer is dereferenced as a Level.
// Membership of the known local player's raw name binds the roster to session.
template<class Read> bool globalRoster(Read& read,A base,A client,A player,std::vector<std::string>& out){
 out.clear();char localName[385]{};if(!playerIdentity(read,player,localName,sizeof localName))return false;
 std::set<A> tried;std::vector<std::string> found;bool success=false;
 for(A owner:{plain(player),plain(client)}){
  std::array<A,408> fields{};if(!read(owner,fields.data(),sizeof fields))continue;
  for(A raw:fields){A possible=plain(raw);if(possible<4096||possible==owner||!tried.insert(possible).second)continue;
   if(pointer(read,possible)!=base+0x13e0a0f8ULL)continue;
   std::vector<std::string> names;if(!levelRoster(read,base,possible,localName,names))continue;
   if(success&&names!=found)return false;
   found.swap(names);success=true;
  }
 }
 if(success)out.swap(found);
 return success;
}
template<class Read> bool nearbyRoster(Read& read,A base,const View& v,const Actor& self,std::vector<std::string>& out){
 out.clear();A h[3]{},again[3]{};if(!v.owners||!read(v.owners+80,h,sizeof h))return false;
 A begin=plain(h[0]),end=plain(h[1]),cap=plain(h[2]);if(!begin||end<begin||cap<end||(end-begin)%8||(end-begin)/8>32)return false;
 std::set<std::string> names;char local[385]{};if(playerIdentity(read,self.address,local,sizeof local))names.insert(local);
 for(A i=0;i<(end-begin)/8;i++){
  A page=pointer(read,begin+i*8);if(!page)continue;std::array<A,128> owners{};if(!read(page,owners.data(),sizeof owners))return false;
  for(A raw:owners){A address=plain(raw);if(!address||address==self.address)continue;Actor remote{};if(!actor(read,base,v,address,false,remote))continue;
   char name[385]{};if(playerIdentity(read,address,name,sizeof name))names.insert(name);
  }
 }
 if(!read(v.owners+80,again,sizeof again)||std::memcmp(h,again,sizeof h))return false;
 out.assign(names.begin(),names.end());return true;
}
inline std::string encodeRoster(const std::vector<std::string>& names){
 constexpr char hex[]="0123456789abcdef";std::string out;
 for(const auto& name:names){if(!out.empty())out+=';';for(unsigned char c:name){out.push_back(hex[c>>4]);out.push_back(hex[c&15]);}}
 return out;
}
}
