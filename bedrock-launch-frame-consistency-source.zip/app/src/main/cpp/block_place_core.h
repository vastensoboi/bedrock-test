#pragma once
#include "aim_core.h"
#include "block_query_core.h"
#include <algorithm>

// Exact 1.26.60.4 arm64 bindings; all native calls are game-thread only.
// Caller owns entity lifetime/generation, friend, distance and terrain checks.
namespace kulich_block_place {
using namespace kulich_aim;
using Position=kulich_block_query::Position;
constexpr A USE_ON=0x1009f214ULL,SURVIVAL_USE_ON=0x100a1480ULL;
// 10777338 returns BlockType*, not Block*. Use the renderer's state getter:
// 107772cc -> Item::isBlock / getBlockType -> BlockType default Block+512.
constexpr A STACK_BLOCK=0x107772ccULL;
constexpr A STACK_BLOCK_TYPE=0x10777338ULL;
struct Vec3 {float x=0,y=0,z=0;};
struct Held {
 A player=0,mode=0,stack=0,block=0,inventory=0,proxy=0,begin=0,item=0;
 int slot=-1,count=0;
};
struct Profile {A offset;uint32_t words[8];};
constexpr Profile PROFILES[]={
 {USE_ON,{0xa9ba7bfdU,0xa9016ffcU,0xa90267faU,0xa9035ff8U,0xa90457f6U,0xa9054ff4U,0x910003fdU,0xd11503ffU}},
 {SURVIVAL_USE_ON,{0x39432008U,0x34000168U,0xd00209a8U,0x39690108U,0x34000108U,0xa9bf7bfdU,0x910003fdU,0x2a1f03e1U}},
 {STACK_BLOCK,{0xa9be7bfdU,0xf9000bf3U,0x910003fdU,0xf9400408U,0xaa0003f3U,0xb4000248U,0xf9400100U,0xb4000200U}},
 {STACK_BLOCK_TYPE,{0xf9400408U,0xb40000c8U,0xf9400100U,0xb4000080U,0xf9400008U,0xf9401d01U,0xd61f0020U,0xaa1f03e0U}},
 {0x10919948ULL,{0xf9410000U,0xd65f03c0U,0x52804408U,0x12001c09U,0x72a00048U,0x7100493fU,0x1ac02508U,0x1a9f27e9U}},
 // Vanilla build's first-use lambda passes explicit stack/support/face/world
 // hitpoint/mainhand/null expected block/true to virtual slot14 (+112).
 {0x100a3d98ULL,{0x394086a8U,0xf9400289U,0xf9400ea2U,0x39408aa5U,0x394082a3U,0x7100051fU,0xf9403928U,0x1a9f17e7U}}
};
template<class Read> bool profiles(Read& read,A base){
 for(const auto& p:PROFILES){uint32_t code[8]{};if(!read(base+p.offset,code,sizeof code)||std::memcmp(code,p.words,sizeof code))return false;}
 return kulich_block_query::profile(read,base);
}
template<class Read> A placeFunction(Read& read,A base,A taggedMode,A taggedPlayer){
 A mode=plain(taggedMode),table=pointer(read,mode);
 if(pointer(read,mode+8)!=plain(taggedPlayer)||pointer(read,plain(taggedPlayer)+2568)!=mode)return 0;
 A expected=table==base+0x13d227d0ULL?base+USE_ON:table==base+0x13d22900ULL?base+SURVIVAL_USE_ON:0;
 return expected&&pointer(read,table+112)==expected?expected:0;
}
// Pure read-only inventory binding. Raw allocation tags survive to the later
// native arguments; compare/check addresses only after stripping their tags.
template<class Read> bool inventoryHeld(Read& read,A base,A client,A taggedPlayer,Held& out,int* reason=nullptr){
 out={};if(reason)*reason=0;
 auto reject=[&](int value){if(reason)*reason=value;return false;};
 client=plain(client);A player=plain(taggedPlayer),mode=0;
 if(!base||pointer(read,client)!=base+0x1388fe70ULL||pointer(read,player)!=base+0x139f6ea0ULL||
    pointer(read,player+3240)!=client||!read(player+2568,&mode,8)||!placeFunction(read,base,mode,taggedPlayer))return reject(1);
 A proxy=pointer(read,player+1424);if(!proxy||pointer(read,proxy)!=base+0x13d43520ULL)return reject(2);
 int32_t slot=-1;uint8_t suspended=1;
 if(!read(proxy+16,&slot,4)||slot<0||slot>8||!read(proxy+176,&suspended,1)||suspended)return reject(3);
 A inventory=pointer(read,proxy+184);
 if(!inventory||pointer(read,inventory)!=base+0x13d42b08ULL)return reject(4);
 A rawBegin=0;if(!read(inventory+320,&rawBegin,8))return reject(5);
 A begin=plain(rawBegin),end=pointer(read,inventory+328);
 if(!begin||end<begin||(end-begin)%152||(end-begin)/152<9||(end-begin)/152>256)return reject(5);
 A rawStack=rawBegin+A(slot)*152,stack=plain(rawStack);
 uint8_t count=0;
 if(pointer(read,stack)!=base+0x13d95ff8ULL||!read(stack+34,&count,1)||!count)return reject(6);
 A handle=pointer(read,stack+8),item=handle?pointer(read,handle):0,table=item?pointer(read,item):0;
 A blockGetter=table?pointer(read,table+56):0;
 A blockPredicate=table?pointer(read,table+80):0;
 if(!item||table<base+0x13600000ULL||table>=base+0x14700000ULL||
    blockGetter<base+0x6000000ULL||blockGetter>=base+0x136869b0ULL||
    blockPredicate<base+0x6000000ULL||blockPredicate>=base+0x136869b0ULL)return reject(7);
 int32_t current=-1;uint8_t again=0;A currentMode=0,currentBegin=0;
 if(!read(proxy+16,&current,4)||current!=slot||!read(proxy+176,&again,1)||again||
    pointer(read,player+1424)!=proxy||pointer(read,proxy+184)!=inventory||
    !read(inventory+320,&currentBegin,8)||currentBegin!=rawBegin||pointer(read,inventory+328)!=end||
    pointer(read,stack+8)!=handle||pointer(read,handle)!=item||!read(stack+34,&again,1)||again!=count||
    !read(player+2568,&currentMode,8)||currentMode!=mode||!placeFunction(read,base,currentMode,taggedPlayer))return reject(8);
 out={taggedPlayer,mode,rawStack,0,inventory,proxy,rawBegin,item,slot,count};return true;
}
struct NativeStackBlock {
 A base;
 A operator()(A stack)const{
#if defined(__aarch64__)
  // The state getter may also consult an ItemStack cache. Require a real
  // block type on the selected item before accepting any cached state.
  A type=reinterpret_cast<A(*)(void*)>(base+STACK_BLOCK_TYPE)(reinterpret_cast<void*>(stack));
  if(plain(type)<4096)return 0;
  return reinterpret_cast<A(*)(void*)>(base+STACK_BLOCK)(reinterpret_cast<void*>(stack));
#else
  (void)stack;return 0;
#endif
 }
};
template<class Read,class BlockGetter> bool resolveHeld(Read& read,A base,A client,A player,Held& out,BlockGetter getter,int* reason=nullptr){
 Held before{},after{};
 if(!inventoryHeld(read,base,client,player,before,reason))return false;
 A block=getter(before.stack);
 if(plain(block)<4096){if(reason)*reason=9;return false;}
 if(!inventoryHeld(read,base,client,player,after,reason)||before.player!=after.player||before.mode!=after.mode||
    before.stack!=after.stack||before.begin!=after.begin||before.item!=after.item||before.slot!=after.slot||before.count!=after.count){if(reason)*reason=8;return false;}
 out=after;out.block=block;return true;
}
template<class Read> bool resolveHeld(Read& read,A base,A client,A player,Held& out,int* reason=nullptr){
 return resolveHeld(read,base,client,player,out,NativeStackBlock{base},reason);
}
inline bool faceCentre(Position support,unsigned face,Vec3& out){
 if(face>5||std::abs(double(support.x))>32000000||std::abs(double(support.z))>32000000||std::abs(double(support.y))>32767)return false;
 constexpr float offset[6][3]={{.5f,0,.5f},{.5f,1,.5f},{.5f,.5f,0},{.5f,.5f,1},{0,.5f,.5f},{1,.5f,.5f}};
 out={support.x+offset[face][0],support.y+offset[face][1],support.z+offset[face][2]};return true;
}
// Success bit0 is native acceptance, not server confirmation. Bit1 asks the
// caller's animation path for a swing, as in 0x100a40d0..40fc.
template<class Use> uint32_t dispatchPlace(Use use,A taggedMode,A taggedStack,Position support,uint8_t face,Vec3 worldHit){
 Vec3 expected{};if(!use||plain(taggedMode)<4096||plain(taggedStack)<4096||!faceCentre(support,face,expected)||
    !std::isfinite(worldHit.x)||!std::isfinite(worldHit.y)||!std::isfinite(worldHit.z)||
    std::abs(worldHit.x-expected.x)>.51f||std::abs(worldHit.y-expected.y)>.51f||std::abs(worldHit.z-expected.z)>.51f)return 0;
 return uint32_t(use(reinterpret_cast<void*>(taggedMode),reinterpret_cast<void*>(taggedStack),&support,face,&worldHit,uint32_t(0),nullptr,true));
}
using NativeUse=uint32_t(*)(void*,void*,const Position*,uint8_t,const Vec3*,uint32_t,const void*,bool);
template<class Read> uint32_t place(Read& read,A base,const Held& held,Position support,uint8_t face){
 A function=placeFunction(read,base,held.mode,held.player);Vec3 hit{};
 if(!function||!held.block||!faceCentre(support,face,hit))return 0;
#if defined(__aarch64__)
 return dispatchPlace(reinterpret_cast<NativeUse>(function),held.mode,held.stack,support,face,hit);
#else
 return 0;
#endif
}
}
