package dev.custom.bedrockgui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Minimal bounded reader for selected Android tombstone protobuf fields.
 * Schema: AOSP system/core/debuggerd/proto/tombstone.proto. */
public final class TombstoneSummary {
    private static final int LIMIT=8*1024*1024;
    private TombstoneSummary(){}
    private static final class Field {
        final int id; final long number; final byte[] bytes;
        Field(int id,long number,byte[] bytes){this.id=id;this.number=number;this.bytes=bytes;}
    }
    private static long varint(byte[] data,int[] at)throws IOException {
        long result=0;
        for(int shift=0;shift<64;shift+=7){
            if(at[0]>=data.length)throw new EOFException("Truncated protobuf varint");
            int b=data[at[0]++]&255;
            if(shift==63&&(b&254)!=0)throw new IOException("Protobuf varint overflow");
            result|=(long)(b&127)<<shift;if((b&128)==0)return result;
        }
        throw new IOException("Invalid protobuf varint");
    }
    private static List<Field> fields(byte[] data)throws IOException {
        if(data.length>LIMIT)throw new IOException("Tombstone exceeds limit");
        List<Field> result=new ArrayList<>();int[] at={0};
        while(at[0]<data.length){
            long tag=varint(data,at);int id=(int)(tag>>>3),wire=(int)(tag&7);
            if(id<1||id>536870911)throw new IOException("Invalid protobuf field");
            long value=0;byte[] bytes=null;long length;
            switch(wire){
                case 0:value=varint(data,at);break;
                case 1:length=8;if(length>data.length-at[0])throw new EOFException();at[0]+=8;break;
                case 2:
                    length=varint(data,at);
                    if(length<0||length>data.length-at[0])throw new EOFException("Truncated protobuf data");
                    bytes=Arrays.copyOfRange(data,at[0],at[0]+(int)length);at[0]+=(int)length;break;
                case 5:if(data.length-at[0]<4)throw new EOFException();at[0]+=4;break;
                default:throw new IOException("Unsupported protobuf wire type: "+wire);
            }
            if(result.size()>=20000)throw new IOException("Too many protobuf fields");
            result.add(new Field(id,value,bytes));
        }
        return result;
    }
    private static String text(List<Field> fields,int id){
        for(Field f:fields)if(f.id==id&&f.bytes!=null)return new String(f.bytes,StandardCharsets.UTF_8);
        return "";
    }
    private static long number(List<Field> fields,int id){for(Field f:fields)if(f.id==id)return f.number;return 0;}
    public static String read(InputStream input)throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;
        while((count=input.read(buffer))!=-1){if(out.size()+count>LIMIT)throw new IOException("Tombstone exceeds 8 MiB");out.write(buffer,0,count);}
        List<Field> root=fields(out.toByteArray());StringBuilder result=new StringBuilder();
        String abort=text(root,14);result.append("Abort message: ").append(abort.isEmpty()?"не предоставлено":abort).append('\n');
        long tid=number(root,6);result.append("Crash tid: ").append(tid).append('\n');
        for(Field field:root)if(field.id==10&&field.bytes!=null){
            List<Field> signal=fields(field.bytes);result.append("Signal: ").append(number(signal,1)).append(' ').append(text(signal,2)).append('\n');
        }
        for(Field field:root)if(field.id==15&&field.bytes!=null){String cause=text(fields(field.bytes),1);if(!cause.isEmpty())result.append("Cause: ").append(cause).append('\n');}
        for(Field field:root)if(field.id==16&&field.bytes!=null){
            List<Field> entry=fields(field.bytes);if(number(entry,1)!=tid)continue;
            for(Field value:entry)if(value.id==2&&value.bytes!=null){
                List<Field> thread=fields(value.bytes);result.append("Thread: ").append(text(thread,2)).append('\n');int frame=0;
                for(Field f:thread)if(f.id==4&&f.bytes!=null&&frame<40){
                    List<Field> backtrace=fields(f.bytes);
                    result.append('#').append(frame++).append(" pc ").append(Long.toHexString(number(backtrace,1)))
                        .append(' ').append(text(backtrace,6)).append(" (").append(text(backtrace,4)).append('+')
                        .append(number(backtrace,5)).append(") build=").append(text(backtrace,8)).append('\n');
                }
            }
        }
        return result.toString();
    }
}
