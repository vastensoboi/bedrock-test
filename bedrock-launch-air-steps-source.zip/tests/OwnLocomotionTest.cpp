#include "../app/src/main/cpp/own_locomotion_core.h"
#include <cassert>
#include <iostream>
#include <vector>

using namespace kulich_own_step;
constexpr Presence absent=Presence::Absent,present=Presence::Present,unavailable=Presence::Unavailable;

MotionState ordinary(){
 MotionState state{};
 state.inputKnown=true;state.input=0x1000;
 state.onGround=state.ground=present;
 state.jumping=state.air=state.water=state.gliding=state.flying=
  state.localJump=state.groundJump=state.triggerJump=absent;
 return state;
}
void phases(){
 MotionState state=ordinary();
 assert(classify(state)==MotionReason::Ready&&state.mode==Motion::Ground);
 state.jumping=present;state.onGround=absent;state.ground=absent;state.air=present;
 assert(classify(state)==MotionReason::JumpHeld&&state.mode==Motion::Unknown);
 state.jumping=absent;
 assert(classify(state)==MotionReason::Ready&&state.mode==Motion::Air);
 // Landing while still classified for air is native travel's responsibility.
 // Ground eligibility preserves the existing actual-OnGround policy.
 state.onGround=present;
 assert(classify(state)==MotionReason::Ready&&state.mode==Motion::Ground);
 state.air=absent;state.ground=present;
 assert(classify(state)==MotionReason::Ready&&state.mode==Motion::Ground);
 state.ground=absent;
 assert(classify(state)==MotionReason::Ready&&state.mode==Motion::Ground);
 state.onGround=absent;
 assert(classify(state)==MotionReason::Unsupported&&state.mode==Motion::Unknown);
}
void unsafeModes(){
 auto check=[](Presence MotionState::*field,MotionReason expected){
  auto state=ordinary();state.*field=present;
  assert(classify(state)==expected&&state.mode==Motion::Unknown);
 };
 for(auto field:{&MotionState::localJump,&MotionState::groundJump,&MotionState::triggerJump})check(field,MotionReason::PendingJump);
 for(auto field:{&MotionState::water,&MotionState::gliding,&MotionState::flying})check(field,MotionReason::Unsupported);
 check(&MotionState::air,MotionReason::Unsupported);
 for(auto field:{&MotionState::onGround,&MotionState::jumping,&MotionState::air,&MotionState::ground,
                &MotionState::water,&MotionState::gliding,&MotionState::flying,&MotionState::localJump,
                &MotionState::groundJump,&MotionState::triggerJump}){
  auto state=ordinary();state.*field=unavailable;
  assert(classify(state)==MotionReason::Unavailable&&state.mode==Motion::Unknown);
 }
 auto state=ordinary();state.onGround=absent;state.ground=absent;state.air=present;state.jumping=present;
 assert(classify(state)==MotionReason::JumpHeld);
 state.jumping=absent;state.localJump=present;assert(classify(state)==MotionReason::PendingJump);
 for(bool airborne:{false,true}){
  auto inputState=ordinary();if(airborne){inputState.onGround=inputState.ground=absent;inputState.air=present;}
  inputState.inputKnown=false;assert(classify(inputState)==MotionReason::Unavailable);
  inputState.inputKnown=true;inputState.jumpPrimaryBits=0x20;
  assert(classify(inputState)==MotionReason::JumpHeld&&inputState.jumpIntent);
  inputState.jumpPrimaryBits=0;
  for(uint16_t mask:{uint16_t(0x10),uint16_t(0x20),uint16_t(0x30)}){
   inputState.jumpAuxBits=mask;assert(classify(inputState)==MotionReason::JumpHeld&&inputState.jumpIntent);
  }
  inputState.jumpPrimaryBits=0x40;inputState.jumpAuxBits=0x08;
  assert(classify(inputState)==MotionReason::Ready&&!inputState.jumpIntent);
 }
}

struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;
 std::vector<unsigned char> bytes=std::vector<unsigned char>(0x80000);A next=root+0x10000;
 template<class T>void put(A at,const T& value){
  at=plain(at);assert(at>=root&&at-root<=bytes.size()&&sizeof value<=bytes.size()-(at-root));
  std::memcpy(bytes.data()+at-root,&value,sizeof value);
 }
 A alloc(size_t size){A result=next;next=(next+size+7)&~A(7);assert(next-root<bytes.size());return result;}
 bool operator()(A at,void* out,size_t size){
  assert(at==plain(at));
  if(at<root||at-root>bytes.size()||size>bytes.size()-(at-root))return false;
  std::memcpy(out,bytes.data()+at-root,size);return true;
 }
};
struct Fixture {
 static constexpr A registry=Memory::root+0x3000;static constexpr uint32_t entity=0x40001;
 static constexpr unsigned count=11;
 static constexpr uint32_t keys[count]={ON_GROUND,JUMPING,AIR_TRAVEL,GROUND_TRAVEL,WATER_TRAVEL,
  GLIDING,FLYING,LOCAL_JUMP,GROUND_JUMP,TRIGGER_JUMP,MOVE_INPUT};
 struct Storage {A address=0,page=0,packed=0;};
 Memory memory;Binding binding{};A buckets=0,nodes=0,inputPages=0,input=0;std::array<Storage,count> storages{};
 Fixture(){
  binding.session={Memory::root+0x1000,registry|Memory::tag,Memory::root+0x5000,Memory::root+0x6000};
  binding.actor=(Memory::root+0x7000)|Memory::tag;binding.replay=(Memory::root+0x8000)|Memory::tag;
  binding.history=(Memory::root+0x9000)|Memory::tag;binding.entity=entity;
  buckets=memory.alloc(32*8);nodes=memory.alloc(count*32);
  for(unsigned i=0;i<32;++i)memory.put<int64_t>(buckets+i*8,-1);
  for(unsigned i=0;i<count;++i){
   auto& storage=storages[i];storage.address=memory.alloc(i==10?104:64);A vector=memory.alloc(8);
   storage.page=memory.alloc(8192);storage.packed=memory.alloc(4);
   memory.put(storage.address+8,vector|Memory::tag);memory.put(storage.address+16,(vector+8)|Memory::tag);
   memory.put(vector,storage.page|Memory::tag);memory.put(storage.address+32,storage.packed|Memory::tag);
   memory.put(storage.address+40,storage.packed|Memory::tag);
   std::fill(memory.bytes.begin()+storage.page-Memory::root,
             memory.bytes.begin()+storage.page-Memory::root+8192,255);
   int64_t prior=-1;assert(memory(buckets+(keys[i]&31)*8,&prior,8));
   memory.put(nodes+i*32,prior);memory.put(nodes+i*32+8,keys[i]);memory.put(nodes+i*32+16,storage.address|Memory::tag);
   memory.put<int64_t>(buckets+(keys[i]&31)*8,i);
   if(i==10){
    inputPages=memory.alloc(8);input=memory.alloc(128*100)|Memory::tag;
    memory.put(storage.address+80,inputPages|Memory::tag);memory.put(storage.address+88,(inputPages+8)|Memory::tag);
    memory.put(storage.address+96,(inputPages+8)|Memory::tag);memory.put(inputPages,input);
   }
  }
  memory.put(registry+96,buckets|Memory::tag);memory.put(registry+104,(buckets+32*8)|Memory::tag);
  memory.put(registry+120,nodes|Memory::tag);memory.put(registry+128,(nodes+count*32)|Memory::tag);
  set(0,true);set(3,true);set(10,true);
 }
 void set(unsigned index,bool presentFlag){
  const auto& storage=storages[index];
  memory.put(storage.page+(entity&2047)*4,presentFlag?(entity&0xfffc0000U):0xffffffffU);
  memory.put(storage.packed,entity);
  memory.put(storage.address+40,(storage.packed+(presentFlag?4:0))|Memory::tag);
 }
 MotionState read(MotionReason expected){
  const auto before=memory.bytes;MotionState out{};
  assert(motion(memory,binding,out)==expected&&memory.bytes==before);return out;
 }
};

void nativeFlags(){
 Fixture fixture;
 auto ground=fixture.read(MotionReason::Ready);assert(ground.mode==Motion::Ground);
 assert(ground.session==fixture.binding.session&&ground.actor==fixture.binding.actor&&ground.history==fixture.binding.history);
 fixture.set(0,false);fixture.set(3,false);fixture.set(2,true);fixture.set(1,true);
 fixture.read(MotionReason::JumpHeld);
 fixture.set(1,false);auto air=fixture.read(MotionReason::Ready);assert(air.mode==Motion::Air&&air!=ground);
 auto again=fixture.read(MotionReason::Ready);assert(again==air);
 fixture.set(4,true);fixture.read(MotionReason::Unsupported);fixture.set(4,false);
 for(unsigned index:{7U,8U,9U}){fixture.set(index,true);fixture.read(MotionReason::PendingJump);fixture.set(index,false);}
 fixture.binding.entity^=0x40000U;fixture.read(MotionReason::Unavailable);fixture.binding.entity=Fixture::entity;
 fixture.memory.put(fixture.storages[2].packed,Fixture::entity^0x40000U);
 fixture.read(MotionReason::Unavailable);fixture.memory.put(fixture.storages[2].packed,Fixture::entity);
 // Missing a known map entry is absence; a failed lookup is not.
 fixture.memory.put(fixture.nodes+4*32+8,uint32_t(0x12345678));
 assert(fixture.read(MotionReason::Ready).water==absent);
 auto inaccessible=[&](A at,void* out,size_t size){return at==fixture.storages[7].address+8?false:fixture.memory(at,out,size);};
 auto before=fixture.memory.bytes;MotionState state{};
 assert(motion(inaccessible,fixture.binding,state)==MotionReason::Unavailable&&fixture.memory.bytes==before);
 auto unreadableRegistry=[&](A at,void* out,size_t size){return at==Fixture::registry+96?false:fixture.memory(at,out,size);};
 assert(motion(unreadableRegistry,fixture.binding,state)==MotionReason::Unavailable&&fixture.memory.bytes==before);
 // Snapshot equality includes owner, full allocation tags and history binding.
 auto current=fixture.read(MotionReason::Ready);fixture.binding.session.client++;
 assert(current!=fixture.read(MotionReason::Ready));fixture.binding.session.client--;
 fixture.binding.history^=0x0100000000000000ULL;assert(current!=fixture.read(MotionReason::Ready));
 fixture.binding.history^=0x0100000000000000ULL;
 fixture.binding.entity=0xffffffffU;fixture.read(MotionReason::Unavailable);
}

void inputIntentAndIdentity(){
 Fixture fixture;auto& memory=fixture.memory;
 auto current=fixture.read(MotionReason::Ready);assert(current.inputKnown&&current.input==fixture.input&&!current.jumpIntent);
 for(uint32_t primary:{0x20U,0x21U}){
  memory.put(fixture.input,primary);auto state=fixture.read(MotionReason::JumpHeld);
  assert(state.jumping==absent&&state.jumpIntent&&state.jumpPrimaryBits==0x20U);
 }
 memory.put(fixture.input,uint32_t(0));
 for(uint16_t auxiliary:{uint16_t(0x10),uint16_t(0x20),uint16_t(0x30)}){
  memory.put(fixture.input+96,auxiliary);auto state=fixture.read(MotionReason::JumpHeld);
  assert(state.jumping==absent&&state.jumpIntent&&state.jumpAuxBits==auxiliary);
 }
 memory.put(fixture.input+96,uint16_t(0x08));memory.put(fixture.input,uint32_t(0x40));
 assert(current==fixture.read(MotionReason::Ready));
 // Only relevant masks participate in snapshots; unrelated direction bits do not.
 memory.put(fixture.input,uint32_t(0));memory.put(fixture.input+96,uint16_t(0));
 memory.put(fixture.inputPages,fixture.input^0x0100000000000000ULL);
 assert(current!=fixture.read(MotionReason::Ready));memory.put(fixture.inputPages,fixture.input);
 memory.put(fixture.storages[10].packed,Fixture::entity^0x40000U);
 fixture.read(MotionReason::Unavailable);memory.put(fixture.storages[10].packed,Fixture::entity);
 fixture.set(10,false);fixture.read(MotionReason::Unavailable);fixture.set(10,true);
 auto blocked=[&](A at,void* out,size_t count){return at==plain(fixture.input)+96?false:memory(at,out,count);};
 auto before=memory.bytes;MotionState out{};
 assert(motion(blocked,fixture.binding,out)==MotionReason::Unavailable&&!out.inputKnown&&memory.bytes==before);
 unsigned reads=0;
 auto changing=[&](A at,void* bytes,size_t count){
  bool result=memory(at,bytes,count);
  if(at==plain(fixture.input)&&++reads==1)memory.put(fixture.input,uint32_t(0x20));
  return result;
 };
 assert(motion(changing,fixture.binding,out)==MotionReason::Unavailable&&!out.inputKnown);
 memory.put(fixture.input,uint32_t(0));reads=0;
 auto reallocated=[&](A at,void* bytes,size_t count){
  bool result=memory(at,bytes,count);
  if(at==plain(fixture.input)&&++reads==1)memory.put(fixture.inputPages,fixture.input^0x0100000000000000ULL);
  return result;
 };
 assert(motion(reallocated,fixture.binding,out)==MotionReason::Unavailable&&!out.inputKnown);
 memory.put(fixture.inputPages,fixture.input);
 // A missing MoveInput map entry does not authorize air or ground acceleration.
 memory.put(fixture.nodes+10*32+8,uint32_t(0x12345678));fixture.read(MotionReason::Unavailable);
}

int main(){
 phases();unsafeModes();nativeFlags();inputIntentAndIdentity();
 std::cout<<"PASS: own normal-ground/released-air classification, fresh input jump masks, held/pending exclusion, unsupported travel, tagged read-only selectors, generation and snapshot guards\n";
}
