package dev.custom.bedrockgui;
import java.util.*;
public final class AutoBuyCycleTest {
    static void check(boolean b){if(!b)throw new AssertionError();}
    static AutoBuyCycle.Lot offer(int slot,int count,long price,String seller){return new AutoBuyCycle.Lot(slot,count,123,456,"Сфера Виверны","",Arrays.asList("Цена: "+price+"$","Игрок: "+seller),Collections.emptyMap());}
    static AutoBuyCycle.Lot control(int slot,String name){return new AutoBuyCycle.Lot(slot,1,23,45,name,"",Collections.emptyList(),Collections.emptyMap());}
    static AutoBuyCycle.Snapshot snapshot(int slots,AutoBuyCycle.Lot offer,int amount,boolean space){
        Map<Integer,AutoBuyCycle.Lot> lots=new TreeMap<>();if(offer!=null)lots.put(offer.slot,offer);
        if(slots==54)lots.put(49,control(49,"§aОбновить"));
        if(slots==27){lots.put(10,control(10,"§a§lКупить"));lots.put(16,control(16,"§c§lВернуться"));}
        Map<String,Integer> inventory=new HashMap<>();inventory.put(offer(0,1,1000,"Seller").itemKey(),amount);
        return new AutoBuyCycle.Snapshot(slots,lots,inventory,true,space,new Object());
    }
    public static void main(String[] args){
        AutoBuyCycle refresh=new AutoBuyCycle();
        check(refresh.next(snapshot(54,null,0,true),0).kind==AutoBuyCycle.Kind.REFRESH);
        check(refresh.pollAfter()==300);
        check(refresh.next(snapshot(54,null,0,true),299).kind==AutoBuyCycle.Kind.WAIT);
        check(refresh.next(snapshot(54,null,0,true),300).kind==AutoBuyCycle.Kind.REFRESH);
        check(refresh.pollAfter()==600);
        AutoBuyCycle cycle=new AutoBuyCycle();AutoBuyCycle.Lot lot=offer(5,1,1000,"Seller");
        check(cycle.next(snapshot(54,lot,0,true),0).kind==AutoBuyCycle.Kind.OPEN);
        check(cycle.next(snapshot(27,offer(13,1,1000,"Seller"),0,true),700).kind==AutoBuyCycle.Kind.BUY);
        check(cycle.next(snapshot(27,offer(13,1,1000,"Seller"),0,true),1500).kind==AutoBuyCycle.Kind.WAIT);
        check(cycle.next(snapshot(54,null,1,true),2000).message.contains("Подтверждено покупок: 1"));
        check(cycle.next(snapshot(54,lot,1,true),3600).kind==AutoBuyCycle.Kind.REFRESH); // no duplicate offer
        for(AutoBuyCycle.Lot changed:new AutoBuyCycle.Lot[]{offer(13,1,2000,"Seller"),offer(13,1,1000,"Other"),offer(13,2,1000,"Seller"),new AutoBuyCycle.Lot(13,1,124,456,lot.name,"",lot.lore,lot.ench)}){
            AutoBuyCycle c=new AutoBuyCycle();check(c.next(snapshot(54,lot,0,true),0).kind==AutoBuyCycle.Kind.OPEN);
            check(c.next(snapshot(27,changed,0,true),700).kind==AutoBuyCycle.Kind.STOP);
        }
        AutoBuyCycle retained=new AutoBuyCycle();retained.next(snapshot(54,lot,0,true),0);
        retained.next(snapshot(27,offer(13,1,1000,"Seller"),0,true),700);
        check(retained.next(snapshot(27,offer(13,1,1000,"Seller"),1,true),2000).kind==AutoBuyCycle.Kind.RETURN);
        check(retained.next(snapshot(54,null,1,true),3600).kind==AutoBuyCycle.Kind.WAIT);
        check(retained.next(snapshot(54,null,1,true),4200).kind==AutoBuyCycle.Kind.REFRESH);
        AutoBuyCycle noReply=new AutoBuyCycle();noReply.next(snapshot(54,lot,0,true),0);
        noReply.next(snapshot(27,offer(13,1,1000,"Seller"),0,true),700);
        check(noReply.next(snapshot(54,null,0,true),9000).kind==AutoBuyCycle.Kind.STOP);
        check(noReply.next(snapshot(54,lot,0,true),12000).kind==AutoBuyCycle.Kind.STOP);
        check(new AutoBuyCycle().next(snapshot(54,lot,0,false),0).kind==AutoBuyCycle.Kind.STOP);
        check(new AutoBuyCycle().next(snapshot(54,offer(0,1,58501,"Seller"),0,true),0).kind==AutoBuyCycle.Kind.REFRESH);
        AutoBuyCycle unavailable=new AutoBuyCycle();
        check(unavailable.next(null,0).kind==AutoBuyCycle.Kind.WAIT);
        check(unavailable.next(null,2400).kind==AutoBuyCycle.Kind.WAIT);
        check(unavailable.next(null,2550).kind==AutoBuyCycle.Kind.WAIT);
        check(unavailable.next(snapshot(54,null,0,true),3000).kind==AutoBuyCycle.Kind.REFRESH);
        AutoBuyCycle otherWindow=new AutoBuyCycle();
        check(otherWindow.next(snapshot(27,null,0,true),0).kind==AutoBuyCycle.Kind.WAIT);
        check(otherWindow.next(snapshot(54,null,0,true),300).kind==AutoBuyCycle.Kind.REFRESH);
        AutoBuyCycle paused=new AutoBuyCycle();
        paused.next(snapshot(54,lot,0,true),0);
        paused.next(snapshot(27,offer(13,1,1000,"Seller"),0,true),700);
        paused.suspendTime(10000);
        check(paused.next(snapshot(54,null,0,true),12000).kind==AutoBuyCycle.Kind.WAIT);
        check(paused.next(snapshot(54,null,1,true),13000).message.contains("Подтверждено покупок"));
        AutoBuyCycle interrupted=new AutoBuyCycle();interrupted.next(snapshot(54,lot,0,true),0);
        check(interrupted.openingInterrupted());
        check(interrupted.next(snapshot(54,null,0,true),300).kind==AutoBuyCycle.Kind.REFRESH);
        check(!interrupted.openingInterrupted());
        AutoBuyCycle transientRead=new AutoBuyCycle();
        check(transientRead.next(null,0).kind==AutoBuyCycle.Kind.WAIT);
        check(transientRead.next(snapshot(54,null,0,true),150).kind==AutoBuyCycle.Kind.REFRESH);
        check(transientRead.next(null,450).kind==AutoBuyCycle.Kind.WAIT);
        check(transientRead.next(snapshot(54,lot,0,true),600).kind==AutoBuyCycle.Kind.OPEN);
        AutoBuyCycle refreshMissing=new AutoBuyCycle();
        AutoBuyCycle.Snapshot emptyFooter=new AutoBuyCycle.Snapshot(54,Collections.emptyMap(),Collections.emptyMap(),true,true,null);
        check(refreshMissing.next(emptyFooter,0).kind==AutoBuyCycle.Kind.WAIT);
        check(refreshMissing.next(snapshot(54,null,0,true),150).kind==AutoBuyCycle.Kind.REFRESH);
        AutoBuyCycle timeout=new AutoBuyCycle();timeout.next(snapshot(54,lot,0,true),0);
        check(timeout.next(snapshot(54,lot,0,true),6000).kind==AutoBuyCycle.Kind.STOP);
        AutoBuyCycle badControl=new AutoBuyCycle();badControl.next(snapshot(54,lot,0,true),0);
        AutoBuyCycle.Snapshot normal=snapshot(27,offer(13,1,1000,"Seller"),0,true);
        Map<Integer,AutoBuyCycle.Lot> missing=new HashMap<>(normal.lots);missing.remove(16);
        check(badControl.next(new AutoBuyCycle.Snapshot(27,missing,normal.inventory,true,true,null),700).kind==AutoBuyCycle.Kind.STOP);
        System.out.println("PASS: full refresh/open/confirm/receipt cycle, exact preview, duplicate suppression, no retry after uncertain purchase, limits/space/timeout/control guards");
    }
}
