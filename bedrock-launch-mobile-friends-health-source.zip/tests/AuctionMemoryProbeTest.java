package dev.custom.bedrockgui;
import java.nio.*;
import java.util.*;

public final class AuctionMemoryProbeTest {
    private static void check(boolean v){if(!v)throw new AssertionError();}
    private static void q(byte[] b,int at,long value){ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).putLong(at,value);}
    public static void main(String[] args)throws Exception {
        EngineMemoryProbe.Region parsed=EngineMemoryProbe.Region.parse("  1000-2000 rw-p 00001000 00:00 0   /tmp/path with spaces (deleted)  ");
        check(parsed.start==0x1000&&parsed.end==0x2000&&parsed.offset==0x1000&&parsed.readable&&parsed.writable&&parsed.path.equals("/tmp/path with spaces (deleted)"));
        parsed=EngineMemoryProbe.Region.parse("1000-2000\tr--p\t0\t00:00\t0");
        check(parsed.readable&&!parsed.writable&&parsed.path.isEmpty());
        for(String invalid:List.of("missing fields","2000-1000 rw-p 0 00:00 0","1000-1000 rw-p 0 00:00 0")){
            boolean rejected=false;try{EngineMemoryProbe.Region.parse(invalid);}catch(IllegalArgumentException expected){rejected=true;}check(rejected);
        }
        long root=0x200000,base=0x10000000,player=root,client=root+0x2000,manager=root+0x4000,node=root+0x5000,model=root+0x6000,slots=root+0x8000;
        byte[] memory=new byte[0x20000];
        q(memory,0,base+0x139f6ea0L);q(memory,3240,client);q(memory,0x578,0xb400000000000000L|manager);
        q(memory,(int)(manager-root),base+0x137e8f20L);q(memory,(int)(manager-root+192),node);
        q(memory,(int)(node-root+40),model);q(memory,(int)(model-root),base+0x13d35930L);
        q(memory,(int)(model-root+216),slots);q(memory,(int)(model-root+224),slots+54*152);q(memory,(int)(model-root+232),slots+54*152);
        for(int i=0;i<54;i++)q(memory,(int)(slots-root+i*152),base+0x13d95ff8L);
        memory[(int)(slots-root+34)]=64;memory[(int)(slots-root+152+34)]=1;
        List<EngineMemoryProbe.Region> regions=Arrays.asList(new EngineMemoryProbe.Region(root,root+memory.length,0,true,true,"heap"));
        EngineMemoryProbe.Reader reader=(addr,out,size)->{System.arraycopy(memory,(int)(addr-root),out,0,size);return true;};
        List<String> logs=new ArrayList<>();
        String result=new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client);
        check(result.contains("slots=54")&&result.contains("nonEmpty=2")&&result.contains("0:64"));
        q(memory,(int)(model-root),base+0x13d34298L);
        check(new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client).contains("slots=54"));
        // End-to-end regression: read userdata from the actual ItemStack +16,
        // then traverse the display tree and decode its Name (not just the NBT helper).
        int tag=0xc000,displayNode=0xc100,nameNode=0xc200;
        q(memory,(int)(slots-root+16),root+tag);
        q(memory,tag,base+0x13ebe0b0L);q(memory,tag+16,root+displayNode);
        memory[displayNode+32]=14;System.arraycopy("display".getBytes(java.nio.charset.StandardCharsets.UTF_8),0,memory,displayNode+33,7);
        q(memory,displayNode+56,base+0x13ebe0b0L);q(memory,displayNode+72,root+nameNode);
        ByteBuffer.wrap(memory).order(ByteOrder.LITTLE_ENDIAN).putInt(displayNode+96,10);
        memory[nameNode+32]=8;System.arraycopy("Name".getBytes(java.nio.charset.StandardCharsets.UTF_8),0,memory,nameNode+33,4);
        q(memory,nameNode+56,base+0x13ebe5f8L);memory[nameNode+64]=16;
        System.arraycopy("test lot".getBytes(java.nio.charset.StandardCharsets.UTF_8),0,memory,nameNode+65,8);
        ByteBuffer.wrap(memory).order(ByteOrder.LITTLE_ENDIAN).putInt(nameNode+96,8);
        logs.clear();new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client);
        check(logs.stream().anyMatch(s->s.contains("Auto Buy lot: slot=0")&&s.contains("test lot")));
        check(logs.stream().anyMatch(s->s.contains("CompoundTag userdata=1 display entries decoded=1")));
        int refreshTag=0xd000,refreshNode=0xd100,refreshName=0xd200;
        q(memory,(int)(slots-root+49*152+16),root+refreshTag);memory[(int)(slots-root+49*152+34)]=1;
        q(memory,refreshTag,base+0x13ebe0b0L);q(memory,refreshTag+16,root+refreshNode);
        memory[refreshNode+32]=14;System.arraycopy("display".getBytes(java.nio.charset.StandardCharsets.UTF_8),0,memory,refreshNode+33,7);
        q(memory,refreshNode+56,base+0x13ebe0b0L);q(memory,refreshNode+72,root+refreshName);
        ByteBuffer.wrap(memory).order(ByteOrder.LITTLE_ENDIAN).putInt(refreshNode+96,10);
        memory[refreshName+32]=8;System.arraycopy("Name".getBytes(java.nio.charset.StandardCharsets.UTF_8),0,memory,refreshName+33,4);
        q(memory,refreshName+56,base+0x13ebe5f8L);byte[] label="Обновить".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        memory[refreshName+64]=(byte)(label.length*2);System.arraycopy(label,0,memory,refreshName+65,label.length);
        ByteBuffer.wrap(memory).order(ByteOrder.LITTLE_ENDIAN).putInt(refreshName+96,8);
        // Main inventory model: server-provided 27-slot backing vector.
        long invNode=root+0xf000,invModel=root+0xe000,invSlots=root+0x10000;
        q(memory,(int)(node-root),invNode);q(memory,(int)(invNode-root+40),invModel);
        q(memory,(int)(invModel-root),base+0x13d341b0L);q(memory,(int)(invModel-root+216),invSlots);
        q(memory,(int)(invModel-root+224),invSlots+27*152);q(memory,(int)(invModel-root+232),invSlots+27*152);
        for(int i=0;i<27;i++)q(memory,(int)(invSlots-root+i*152),base+0x13d95ff8L);
        long hotbarNode=root+0xf100,hotbarModel=root+0x12000,hotbarSlots=root+0x13000;
        q(memory,(int)(invNode-root),hotbarNode);q(memory,(int)(hotbarNode-root+40),hotbarModel);q(memory,(int)(hotbarModel-root),base+0x13d341b0L);memory[(int)(hotbarModel-root+40)]=28;
        q(memory,(int)(hotbarModel-root+216),hotbarSlots);q(memory,(int)(hotbarModel-root+224),hotbarSlots+9*152);q(memory,(int)(hotbarModel-root+232),hotbarSlots+9*152);
        for(int i=0;i<9;i++)q(memory,(int)(hotbarSlots-root+i*152),base+0x13d95ff8L);
        AuctionMemoryProbe inputProbe=new AuctionMemoryProbe(regions,reader,base,logs::add);
        inputProbe.scan(player,client);AuctionMemoryProbe.TapToken token=inputProbe.token(54);
        check(token!=null&&token.destinationSlot()==0&&inputProbe.validateTap(token));
        memory[(int)(invSlots-root+34)]=1;check(!inputProbe.validateTap(token));check(inputProbe.validateDragWindow(token));
        AuctionMemoryProbe nextEmpty=new AuctionMemoryProbe(regions,reader,base,logs::add);nextEmpty.scan(player,client);
        check(nextEmpty.token(54)!=null&&nextEmpty.token(54).destinationSlot()==1);
        for(int i=0;i<27;i++)memory[(int)(invSlots-root+i*152+34)]=1;
        nextEmpty.scan(player,client);check(nextEmpty.token(54)==null);
        for(int i=0;i<27;i++)memory[(int)(invSlots-root+i*152+34)]=0;
        q(memory,(int)(model-root+224),slots+27*152);check(!inputProbe.validateDragWindow(token));q(memory,(int)(model-root+224),slots+54*152);
        q(memory,0x578,0);check(!inputProbe.validateTap(token));q(memory,0x578,manager);
        memory[refreshName+65]='X';check(!inputProbe.validateTap(token));memory[refreshName+65]=label[0];
        q(memory,(int)(model-root+224),slots+27*152);check(!inputProbe.validateTap(token));q(memory,(int)(model-root+224),slots+54*152);
        byte[] original=memory.clone();
        new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client);check(Arrays.equals(original,memory));
        q(memory,3240,client+8);check(!new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client).contains("slots=54"));q(memory,3240,client);
        q(memory,(int)(slots-root),0);check(!new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client).contains("slots=54"));q(memory,(int)(slots-root),base+0x13d95ff8L);
        final int[] n={0};EngineMemoryProbe.Reader changing=(addr,out,size)->{
            if(addr==slots&&size==54*152&&n[0]++==1)memory[(int)(slots-root+34)]=63;
            return reader.read(addr,out,size);
        };
        AuctionMemoryProbe partialRead=new AuctionMemoryProbe(regions,changing,base,logs::add);
        partialRead.scan(player,client);
        check(partialRead.snapshot().complete&&partialRead.snapshot().at(0)==null&&partialRead.snapshot().skippedLots==1);
        check(partialRead.actionToken(partialRead.snapshot(),49)!=null); // unaffected refresh stays usable
        // Model pointer-dense actor fields; the quiet path must not probe them.
        for(int offset=8;offset+8<=4304;offset+=8)if(offset!=0x578&&offset!=3240)q(memory,offset,client);
        List<EngineMemoryProbe.Region> many=new ArrayList<>(regions);
        for(int i=0;i<2048;i++)many.add(new EngineMemoryProbe.Region(0x800000L+i*4096,0x801000L+i*4096,0,true,true,"other"));
        Collections.reverse(many);
        final int[] reads={0};EngineMemoryProbe.Reader measured=(addr,out,size)->{reads[0]++;return reader.read(addr,out,size);};
        new AuctionMemoryProbe(many,measured,base,line->{},true).scan(player,client);int full=reads[0];reads[0]=0;
        AuctionMemoryProbe fast=new AuctionMemoryProbe(many,measured,base,line->{},false);fast.scan(player,client);
        check(fast.windowSlots()==54&&reads[0]+400<full);
        System.out.println("PASS: tagged manager, container/vector snapshot, read-only memory, changed player/vptr rejection, changing listing cell isolation");
    }
}
