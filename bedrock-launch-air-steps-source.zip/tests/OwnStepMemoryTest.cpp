#include "../app/src/main/cpp/own_step_memory.h"
#include <cassert>
#include <iostream>
#include <vector>

using namespace kulich_own_step;

struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;
 std::vector<unsigned char> bytes=std::vector<unsigned char>(0x80000);
 A next=root+0x10000;
 template<class T>void put(A at,const T& value){
  at=plain(at);assert(at>=root&&at-root<=bytes.size()&&sizeof value<=bytes.size()-(at-root));
  std::memcpy(bytes.data()+at-root,&value,sizeof value);
 }
 A alloc(size_t size){A result=next;next=(next+size+7)&~A(7);assert(next-root<bytes.size());return result;}
 bool operator()(A at,void* out,size_t size){
  assert(at==plain(at));
  if(at<root||at-root>bytes.size()||size>bytes.size()-(at-root))return false;
  std::memcpy(out,bytes.data()+at-root,size);return true;
 }
};

template<class Check>void readOnly(Memory& memory,Check check){
 auto before=memory.bytes;check();assert(memory.bytes==before);
}

struct Storage {A pool=0,sparsePage=0,payload=0,packedBegin=0;unsigned stride=0;};
Storage storage(Memory& m,uint32_t entity,unsigned stride){
 Storage result;result.pool=m.alloc(104);result.stride=stride;
 A sparseVector=m.alloc(8);result.sparsePage=m.alloc(8192);
 A pages=m.alloc(8);result.payload=m.alloc(128*stride)|Memory::tag;
 result.packedBegin=m.alloc(4)|Memory::tag;
 std::fill(m.bytes.begin()+result.sparsePage-Memory::root,
           m.bytes.begin()+result.sparsePage-Memory::root+8192,255);
 m.put(result.pool+8,sparseVector|Memory::tag);m.put(result.pool+16,(sparseVector+8)|Memory::tag);
 m.put(sparseVector,result.sparsePage|Memory::tag);
 m.put(result.sparsePage+(entity&2047)*4,(entity&0xfffc0000U)|5U);
 m.put(result.pool+32,result.packedBegin);m.put(result.pool+40,result.packedBegin+4);
 m.put(result.packedBegin,entity);
 m.put(result.pool+80,pages|Memory::tag);m.put(result.pool+88,(pages+8)|Memory::tag);
 m.put(result.pool+96,(pages+8)|Memory::tag);m.put(pages,result.payload);
 return result;
}

struct Fixture {
 static constexpr A base=0x10000000,client=Memory::root+0x1000,registry=Memory::root+0x3000,
  actor=Memory::root+0x5000,sender=Memory::root+0x7000,level=Memory::root+0x8000,
  guard=Memory::root+0x9000,levelData=Memory::root+0xa000,history=Memory::root+0xc000;
 static constexpr uint32_t entity=0x40001;
 static constexpr uint64_t first=100,count=60,start=54,world=200;
 Memory m;Storage owner,replay,state;A buckets=0,nodes=0,entitySparse=0,pages=0;
 std::array<A,3> allocations{};
 Fixture():owner(storage(m,entity,8)),replay(storage(m,entity,32)),state(storage(m,entity,36)){
  const uint32_t keys[]{OWNER,REPLAY,STATE_VECTOR};const A pools[]{owner.pool,replay.pool,state.pool};
  buckets=m.alloc(128);nodes=m.alloc(3*32);
  for(unsigned i=0;i<16;++i)m.put<int64_t>(buckets+i*8,-1);
  for(unsigned i=0;i<3;++i){
   int64_t previous=-1;assert(m(buckets+(keys[i]&15)*8,&previous,8));
   m.put(nodes+i*32,previous);m.put(nodes+i*32+8,keys[i]);
   m.put(nodes+i*32+16,pools[i]|Memory::tag);m.put<int64_t>(buckets+(keys[i]&15)*8,i);
  }
  m.put(registry+96,buckets|Memory::tag);m.put(registry+104,(buckets+128)|Memory::tag);
  m.put(registry+120,nodes|Memory::tag);m.put(registry+128,(nodes+3*32)|Memory::tag);
  A entityPages=m.alloc(8);entitySparse=m.alloc(8192);
  m.put(registry+216,entityPages|Memory::tag);m.put(registry+224,(entityPages+8)|Memory::tag);
  m.put(entityPages,entitySparse|Memory::tag);m.put(entitySparse+(entity&2047)*4,(entity&0xfffc0000U)|7U);
  m.put(client,base+0x1388fe70ULL);
  m.put(client+576,std::array<A,3>{registry|Memory::tag,(Memory::root+0xb000)|Memory::tag,entity});
  m.put(actor,std::array<A,4>{base+0x139f6ea0ULL,registry|Memory::tag,(registry+40)|Memory::tag,entity});
  m.put(actor+3240,client|Memory::tag);m.put(actor+496,level|Memory::tag);
  m.put(actor+1984,sender|Memory::tag);m.put(actor+617,uint8_t(0));
  m.put(sender,base+0x13b3ac00ULL);m.put(level,base+0x1394f510ULL);
  m.put(level+128,guard|Memory::tag);m.put(guard,uint8_t(1));
  m.put(level+144,levelData|Memory::tag);m.put(levelData+752,world);
  m.put(owner.payload+5*8,actor|Memory::tag);
  m.put(replayAddress()+8,history|Memory::tag);m.put(replayAddress()+24,first+count-1);
  m.put(stateAddress(),std::array<float,3>{1.25f,64,-2.5f});
  m.put(stateAddress()+24,std::array<float,3>{.1f,-.2f,.3f});
  pages=m.alloc(3*8);
  for(unsigned i=0;i<allocations.size();++i){
   allocations[i]=m.alloc(56*72)|((Memory::tag>>56)+i)<<56;
   m.put(pages+i*8,allocations[i]);
  }
  m.put(history+16,pages|Memory::tag);m.put(history+24,(pages+3*8)|Memory::tag);
  m.put(history+40,start);m.put(history+48,count);m.put(history+56,first);
  m.put(history+64,uint64_t(0));m.put(history+72,uint64_t(9));m.put(history+80,uint64_t(9));
 }
 A replayAddress()const{return replay.payload+5*32;}
 A stateAddress()const{return plain(state.payload)+5*36;}
 Binding binding(){Binding out;readOnly(m,[&]{assert(resolve(m,base,client|Memory::tag,out));});return out;}
 void rejects(bool sessionOnly=false){
  Binding out;readOnly(m,[&]{assert(!(sessionOnly?resolveSession(m,base,client|Memory::tag,out):resolve(m,base,client|Memory::tag,out)));});
 }
};

void taggedBindingsAndSession(){
 Fixture f;auto& m=f.m;Binding value=f.binding();
 readOnly(m,[&]{
  assert(value.session.client==f.client&&value.session.registry==(f.registry|Memory::tag));
  assert(value.session.level==(f.level|Memory::tag)&&value.actor==(f.actor|Memory::tag));
  assert(value.sender==(f.sender|Memory::tag)&&value.levelData==(f.levelData|Memory::tag));
  assert(value.replay==f.replayAddress()&&value.history==(f.history|Memory::tag));
  assert(value.entity==f.entity&&value.world==f.world&&value.current==f.first+f.count-1);
  assert(value.historyFirst==f.first&&value.historyCount==f.count&&value.historyLast==f.first+f.count-1);
  assert(value.position[0]==1.25f&&value.delta[2]==.3f);
  assert(rawPool(m,f.registry|Memory::tag,REPLAY)==(f.replay.pool|Memory::tag));
  bool known=false;assert(rawPool(m,f.registry,REPLAY,&known)==(f.replay.pool|Memory::tag)&&known);
  known=false;assert(rawPool(m,f.registry,CORRECTED,&known)==0&&known);
  auto inaccessible=[&](A at,void* out,size_t bytes){return at==f.registry+96?false:m(at,out,bytes);};
  known=true;assert(rawPool(inaccessible,f.registry,CORRECTED,&known)==0&&!known);
  assert(pool(m,f.registry,REPLAY)==f.replay.pool);
  A begin=0;uint64_t count=0;
  assert(packed(m,f.replay.pool|Memory::tag,begin,count)&&begin==f.replay.packedBegin&&count==1);
  assert(rawPointer(m,f.replayAddress()+8)==(f.history|Memory::tag));
  assert(same(value,value));
  auto changed=value;changed.world++;assert(!same(value,changed));
  changed=value;changed.history^=0x0100000000000000ULL;assert(!same(value,changed));
  assert(!sameState(value,changed));
  changed=value;changed.historyFirst++;changed.historyCount--;assert(!same(value,changed)&&sameState(value,changed));
  changed=value;changed.position[0]+=.25f;assert(!sameState(value,changed));
  changed=value;changed.session.clockSource^=0x0100000000000000ULL;assert(!same(value,changed)&&!sameState(value,changed));
 });
 // Binding the client/Level session must work before a replay component exists.
 m.put(f.nodes+32+8,uint32_t(0x12345678));
 Binding session;readOnly(m,[&]{assert(resolveSession(m,f.base,f.client|Memory::tag,session));});f.rejects();
 assert(session.session==value.session&&session.world==value.world&&session.replay==0&&session.history==0);
 m.put(f.nodes+32+8,REPLAY);
 m.put(f.replayAddress()+8,A(0));
 readOnly(m,[&]{assert(resolveSession(m,f.base,f.client,session));});f.rejects();
 m.put(f.replayAddress()+8,f.history|Memory::tag);
 m.put(f.entitySparse+(f.entity&2047)*4,uint32_t(0x80007));f.rejects(true);
 m.put(f.entitySparse+(f.entity&2047)*4,(f.entity&0xfffc0000U)|7U);
 m.put(f.replay.sparsePage+(f.entity&2047)*4,uint32_t(0x80005));f.rejects();
 readOnly(m,[&]{assert(resolveSession(m,f.base,f.client,session));});
 m.put(f.replay.sparsePage+(f.entity&2047)*4,(f.entity&0xfffc0000U)|5U);
 m.put(f.owner.sparsePage+(f.entity&2047)*4,uint32_t(0x80005));f.rejects(true);
 m.put(f.owner.sparsePage+(f.entity&2047)*4,(f.entity&0xfffc0000U)|5U);
 m.put(f.actor+24,uint64_t(f.entity+0x40000));f.rejects(true);m.put(f.actor+24,uint64_t(f.entity));
 m.put(f.actor+617,uint8_t(1));f.rejects(true);m.put(f.actor+617,uint8_t(0));
 m.put(f.actor+3240,f.client+8);f.rejects(true);m.put(f.actor+3240,f.client|Memory::tag);
 assert(same(value,f.binding()));
}

void levelAndStateGuards(){
 Fixture f;auto& m=f.m;
 m.put(f.guard,uint8_t(0));f.rejects(true);m.put(f.guard,uint8_t(2));f.rejects(true);
 m.put(f.guard,uint8_t(3));assert(f.binding().world==f.world);m.put(f.guard,uint8_t(1));
 m.put(f.level+128,A(0));f.rejects(true);m.put(f.level+128,f.guard|Memory::tag);
 m.put(f.level,f.base+0x1394f518ULL);f.rejects(true);m.put(f.level,f.base+0x1394f510ULL);
 m.put(f.levelData+752,uint64_t(0));f.rejects(true);
 m.put(f.levelData+752,uint64_t(201));assert(f.binding().world==201);m.put(f.levelData+752,f.world);
 m.put(f.level+144,A(0));f.rejects(true);m.put(f.level+144,f.levelData|Memory::tag);
 auto inaccessible=[&](A at,void* out,size_t size){return at==f.levelData+752?false:m(at,out,size);};
 readOnly(m,[&]{Binding out;assert(!resolveSession(inaccessible,f.base,f.client,out));});
 for(unsigned i=0;i<3;++i){
  m.put(f.stateAddress()+i*4,std::numeric_limits<float>::quiet_NaN());f.rejects();
  m.put(f.stateAddress()+i*4,32000004.f);f.rejects();
  m.put(f.stateAddress()+i*4,-32000004.f);f.rejects();
  m.put(f.stateAddress()+i*4,32000000.f);assert(f.binding().position[i]==32000000.f);
  m.put(f.stateAddress()+i*4,0.f);
  m.put(f.stateAddress()+24+i*4,std::numeric_limits<float>::infinity());f.rejects();
  m.put(f.stateAddress()+24+i*4,64000008.f);f.rejects();
  m.put(f.stateAddress()+24+i*4,-64000008.f);f.rejects();
  m.put(f.stateAddress()+24+i*4,-64000000.f);assert(f.binding().delta[i]==-64000000.f);
  m.put(f.stateAddress()+24+i*4,0.f);
 }
 m.put(f.history+48,uint64_t(0));f.rejects();m.put(f.history+48,uint64_t(4097));f.rejects();
 m.put(f.history+48,uint64_t(2));m.put(f.history+56,UINT64_MAX);f.rejects();
 m.put(f.history+48,uint64_t(1));assert(f.binding().historyLast==UINT64_MAX);
}

void dequeAndDirtyHistory(){
 Fixture f;auto& m=f.m;auto value=f.binding();
 readOnly(m,[&]{
  // The first two records finish allocation zero; the next 56 fill allocation
  // one, and the last two begin allocation two. Every allocation keeps its tag.
  for(uint64_t i=0;i<f.count;++i){
   uint64_t index=f.start+i;
   assert(record(m,f.history|Memory::tag,f.first+i)==f.allocations[index/56]+(index%56)*72);
  }
  assert(!record(m,f.history,f.first-1)&&!record(m,f.history,f.first+f.count));
  assert(cleanHistory(m,value));
 });
 for(uint64_t dirty:{1ULL,2ULL,3ULL}){
  m.put(f.history+64,dirty);readOnly(m,[&]{assert(!cleanHistory(m,value));});
 }
 m.put(f.history+64,uint64_t(0));m.put(f.history+80,uint64_t(10));
 readOnly(m,[&]{assert(!cleanHistory(m,value));});m.put(f.history+80,uint64_t(9));
 // A pending correction anywhere in the deque is rejected even when the outer
 // dirty state is clear, including both sides of each allocation boundary.
 for(uint64_t i:{0ULL,1ULL,2ULL,57ULL,58ULL,59ULL}){
  A frame=record(m,f.history,f.first+i);m.put(frame+64,uint8_t(1));
  readOnly(m,[&]{assert(!cleanHistory(m,value));});m.put(frame+64,uint8_t(0));
 }
 A frame=record(m,f.history,f.first);m.put(frame+64,uint8_t(2));
 readOnly(m,[&]{assert(cleanHistory(m,value));});m.put(frame+64,uint8_t(0));
 auto missing=[&](A at,void* out,size_t size){return at==plain(f.allocations[1])+64?false:m(at,out,size);};
 readOnly(m,[&]{assert(!cleanHistory(missing,value));});
 m.put(f.pages+8,A(0));readOnly(m,[&]{assert(!record(m,f.history,f.first+2)&&!cleanHistory(m,value));});
 m.put(f.pages+8,f.allocations[1]);
 m.put(f.history+24,(f.pages+8)|Memory::tag);
 readOnly(m,[&]{assert(!record(m,f.history,f.first+2)&&!cleanHistory(m,value));});
 m.put(f.history+24,(f.pages+24)|Memory::tag);
 m.put(f.history+40,UINT64_MAX);readOnly(m,[&]{assert(!record(m,f.history,f.first+1));});
 m.put(f.history+40,f.start);
 m.put(f.history+48,uint64_t(4097));readOnly(m,[&]{assert(!record(m,f.history,f.first));});
 m.put(f.history+48,f.count);
 m.put(f.history+24,(f.pages+23)|Memory::tag);readOnly(m,[&]{assert(!record(m,f.history,f.first));});
 m.put(f.history+24,(f.pages+24)|Memory::tag);
 readOnly(m,[&]{assert(cleanHistory(m,value));});
}

void malformedStorage(){
 Fixture f;auto& m=f.m;
 m.put(f.registry+104,(f.buckets+24)|Memory::tag);
 readOnly(m,[&]{assert(!rawPool(m,f.registry|Memory::tag,REPLAY));});
 m.put(f.registry+104,(f.buckets+128)|Memory::tag);
 m.put<int64_t>(f.buckets+(REPLAY&15)*8,3);
 readOnly(m,[&]{assert(!rawPool(m,f.registry|Memory::tag,REPLAY));});
 m.put<int64_t>(f.buckets+(REPLAY&15)*8,1);
 A begin=99;uint64_t count=99;
 readOnly(m,[&]{assert(!packed(m,0,begin,count)&&begin==0&&count==0);});
 m.put(f.replay.pool+40,f.replay.packedBegin+3);
 readOnly(m,[&]{assert(!packed(m,f.replay.pool|Memory::tag,begin,count));});
 m.put(f.replay.pool+40,f.replay.packedBegin-4);
 readOnly(m,[&]{assert(!packed(m,f.replay.pool|Memory::tag,begin,count));});
 m.put(f.replay.pool+40,f.replay.packedBegin+uint64_t(262144)*4);
 readOnly(m,[&]{assert(!packed(m,f.replay.pool|Memory::tag,begin,count));});
 m.put(f.replay.pool+40,f.replay.packedBegin+4);
 readOnly(m,[&]{assert(packed(m,f.replay.pool|Memory::tag,begin,count)&&count==1);});
}

void cleanupPresenceAndFailure(){
 Fixture f;auto& m=f.m;A storage=f.replay.pool|Memory::tag;
 // Use a fully consistent one-entry packed/sparse pair for destructive lookup.
 m.put(f.replay.sparsePage+(f.entity&2047)*4,f.entity&0xfffc0000U);
 uint64_t index=99;A at=0;
 readOnly(m,[&]{assert(locate(m,storage,f.entity,index)==Presence::Present&&index==0);
  assert(payload(m,storage,f.entity,32,at)==Presence::Present&&at==f.replay.payload);});
 A vector=pointer(m,f.replay.pool+8),payloadVector=pointer(m,f.replay.pool+80);
 for(A bad:{f.replay.pool+8,f.replay.pool+32,vector,f.replay.sparsePage+(f.entity&2047)*4,
            plain(f.replay.packedBegin),f.replay.pool+80,payloadVector}){
  auto missing=[&](A address,void* out,size_t bytes){return address==bad?false:m(address,out,bytes);};
  readOnly(m,[&]{assert(payload(missing,storage,f.entity,32,at)==Presence::Unavailable&&at==0);});
 }
 m.put(f.replay.sparsePage+(f.entity&2047)*4,uint32_t(0xffffffffU));
 readOnly(m,[&]{assert(locate(m,storage,f.entity,index)==Presence::Absent);});
 m.put(f.replay.sparsePage+(f.entity&2047)*4,f.entity&0xfffc0000U);
 m.put(f.replay.packedBegin,uint32_t(0x80001));
 readOnly(m,[&]{assert(locate(m,storage,f.entity,index)==Presence::Unavailable);});
 m.put(f.replay.packedBegin,f.entity);
 m.put(payloadVector,A(0));readOnly(m,[&]{assert(payload(m,storage,f.entity,32,at)==Presence::Unavailable);});
 readOnly(m,[&]{assert(payload(m,0,f.entity,32,at)==Presence::Absent&&at==0);});
}

void syntheticMarkCleanup(){
 Fixture f;auto& m=f.m;Binding owner=f.binding();uint64_t tick=f.first+3;
 A own=record(m,f.history,tick),other=record(m,f.history,f.first+1);unsigned writes=0;
 auto write=[&](A tagged,const void* bytes,size_t count){
  assert(tagged!=plain(tagged));A address=plain(tagged);
  assert(address>=Memory::root&&address-Memory::root+count<=m.bytes.size());
  std::memcpy(m.bytes.data()+address-Memory::root,bytes,count);++writes;return true;
 };
 m.put(own+64,uint8_t(0x81));m.put(other+64,uint8_t(1));m.put(f.history+64,uint64_t(0x83));
 assert(clearSyntheticMark(m,write,owner,tick,own)&&writes==1);
 uint8_t ownFlags=0,otherFlags=0;uint64_t dirty=0;
 assert(m(plain(own)+64,&ownFlags,1)&&ownFlags==0x80);
 assert(m(plain(other)+64,&otherFlags,1)&&otherFlags==1);
 assert(m(f.history+64,&dirty,8)&&dirty==0x83); // Genuine other mark and bit1 retained.
 writes=0;assert(clearSyntheticMark(m,write,owner,tick,own)&&writes==0);
 m.put(other+64,uint8_t(0));m.put(own+64,uint8_t(3));
 assert(clearSyntheticMark(m,write,owner,tick,own)&&writes==2);
 assert(m(plain(own)+64,&ownFlags,1)&&ownFlags==2);
 assert(m(f.history+64,&dirty,8)&&dirty==0x82);
 m.put(own+64,uint8_t(0));m.put(f.history+64,uint64_t(0x83));writes=0;
 assert(clearSyntheticMark(m,write,owner,tick,own)&&writes==1);
 assert(m(f.history+64,&dirty,8)&&dirty==0x82);
 m.put(f.history+64,uint64_t(1));m.put(f.history+72,A(0x300000));m.put(f.history+80,A(0x300010));writes=0;
 assert(clearSyntheticMark(m,write,owner,tick,own)&&writes==0);
 assert(m(f.history+64,&dirty,8)&&dirty==1);
 m.put(f.history+72,A(0));m.put(f.history+80,A(0));
 m.put(own+64,uint8_t(1));m.put(f.history+64,uint64_t(1));writes=0;
 auto missing=[&](A address,void* bytes,size_t count){return address==plain(other)+64?false:m(address,bytes,count);};
 auto before=m.bytes;assert(!clearSyntheticMark(missing,write,owner,tick,own)&&writes==0&&before==m.bytes);
 Binding wrong=owner;wrong.history^=0x0100000000000000ULL;
 assert(!clearSyntheticMark(m,write,wrong,tick,own)&&writes==0&&before==m.bytes);
 auto cannotWrite=[&](A,const void*,size_t){return false;};
 assert(!clearSyntheticMark(m,cannotWrite,owner,tick,own)&&before==m.bytes);
 unsigned attempts=0;auto partial=[&](A tagged,const void* bytes,size_t count){if(++attempts==2)return false;return write(tagged,bytes,count);};
 assert(!clearSyntheticMark(m,partial,owner,tick,own)&&attempts==2);
 assert(m(plain(own)+64,&ownFlags,1)&&ownFlags==0&&m(f.history+64,&dirty,8)&&dirty==1);
}

void arrivingWorkDuringCleanup(){
 Fixture f;auto& m=f.m;Binding owner=f.binding();uint64_t tick=f.first+3;
 A own=record(m,f.history,tick),other=record(m,f.history,f.first+1);unsigned writes=0,reads=0;
 auto write=[&](A,const void*,size_t){++writes;return true;};
 m.put(own+64,uint8_t(1));m.put(f.history+64,uint64_t(1));
 auto arrivingMark=[&](A address,void* out,size_t bytes){
  if(address==plain(other)+64&&++reads==2)m.put(other+64,uint8_t(1));
  return m(address,out,bytes);
 };
 assert(!clearSyntheticMark(arrivingMark,write,owner,tick,own)&&writes==0);
 uint8_t state=0;assert(m(plain(other)+64,&state,1)&&state==1);
 m.put(other+64,uint8_t(0));reads=0;
 auto arrivingEvent=[&](A address,void* out,size_t bytes){
  if(address==f.history+72&&++reads==2){m.put(f.history+72,A(0x300000));m.put(f.history+80,A(0x300010));}
  return m(address,out,bytes);
 };
 assert(!clearSyntheticMark(arrivingEvent,write,owner,tick,own)&&writes==0);
 assert(m(plain(own)+64,&state,1)&&state==1);
}

void appendedHistoryWithPruning(){
 Fixture fixture;Binding before=fixture.binding(),after=before;
 const uint64_t next=before.historyLast+1;
 after.current=after.historyLast=next;++after.historyCount;
 assert(freshHistoryAppend(before,after,next));
 // Normal full-window trimming and multiple acknowledged records are valid.
 for(uint64_t pruned:{1ULL,3ULL,60ULL}){
  auto trimmed=after;trimmed.historyFirst+=pruned;trimmed.historyCount-=pruned;
  assert(freshHistoryAppend(before,trimmed,next));
 }
 auto changed=after;--changed.historyFirst;++changed.historyCount;
 assert(!freshHistoryAppend(before,changed,next));
 changed=after;--changed.current;assert(!freshHistoryAppend(before,changed,next));
 changed=after;++changed.historyLast;++changed.historyCount;assert(!freshHistoryAppend(before,changed,next));
 changed=after;--changed.historyCount;assert(!freshHistoryAppend(before,changed,next));
 changed=after;changed.history^=0x0100000000000000ULL;assert(!freshHistoryAppend(before,changed,next));
 changed=after;++changed.world;assert(!freshHistoryAppend(before,changed,next));
 // Pre-append pruning changes the baseline without changing the current pose.
 auto current=before;current.historyFirst+=2;current.historyCount-=2;
 assert(sameState(before,current));
 changed=current;changed.current=changed.historyLast=next;++changed.historyCount;
 assert(freshHistoryAppend(current,changed,next)&&freshHistoryAppend(before,changed,next));
 changed=before;changed.current=changed.historyFirst=changed.historyLast=UINT64_MAX;changed.historyCount=1;
 assert(!freshHistoryAppend(changed,changed,0));
}

int main(){
 taggedBindingsAndSession();levelAndStateGuards();dequeAndDirtyHistory();malformedStorage();cleanupPresenceAndFailure();syntheticMarkCleanup();arrivingWorkDuringCleanup();appendedHistoryWithPruning();
 std::cout<<"PASS: own-step bindings, tagged reads, stale generations, deque bounds, known absence versus failed reads, and owned dirty-mark cleanup preserving genuine records/events\n";
}
