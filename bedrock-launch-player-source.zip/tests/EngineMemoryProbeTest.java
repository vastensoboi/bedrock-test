import dev.custom.bedrockgui.EngineMemoryProbe;
import java.io.*;
import java.nio.*;
import java.util.*;

public final class EngineMemoryProbeTest {
    static void check(boolean value){if(!value)throw new AssertionError();}
    static void put(byte[] bytes,int offset,long value){ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).putLong(offset,value);}
    static void word(byte[] bytes,int offset,int value){ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).putInt(offset,value);}
    public static void main(String[] args)throws Exception {
        long base=0x100000000L,globals=0x100000,game=0x200000,client=0x204000,player=0x208000,mode=0x20c000,stale=0x214000;
        Map<Long,byte[]> memory=new LinkedHashMap<>();
        byte[] global=new byte[64],g=new byte[7664],c=new byte[3648],p=new byte[4304],m=new byte[16];
        put(global,0,game);put(global,8,0xb400000000000000L|player);put(global,16,stale);
        put(g,0,base+0x1389f8b8L);put(g,0x100,client);put(g,0x108,0x12345678);
        put(c,0,base+0x1388fe70L);put(c,0x200,player);
        put(p,0,base+0x139f6ea0L);put(p,0x300,mode);
        put(m,0,base+0x13d22900L);put(m,8,player);
        memory.put(globals,global);memory.put(game,g);memory.put(client,c);memory.put(player,p);memory.put(mode,m);
        EngineMemoryProbe.Reader reader=(address,destination,count)->{
            for(Map.Entry<Long,byte[]> e:memory.entrySet()){
                long offset=address-e.getKey();
                if(offset>=0&&offset<=e.getValue().length-count){System.arraycopy(e.getValue(),(int)offset,destination,0,count);return true;}
            }
            throw new IOException("Unmapped/stale fixture address");
        };
        List<EngineMemoryProbe.Region> maps=Arrays.asList(
                EngineMemoryProbe.Region.parse("00100000-00100040 rw-p 00000000 00:00 0 [globals]"),
                EngineMemoryProbe.Region.parse("00200000-00240000 rw-p 00000000 00:00 0 [heap]"));
        List<String> log=new ArrayList<>();
        EngineMemoryProbe.Result result=new EngineMemoryProbe(maps,reader,base,log::add).scan(globals,globals+64);
        check(result.candidates.get("MinecraftGame")==1);check(result.candidates.get("ClientInstance")==1);
        check(result.candidates.get("LocalPlayer")==1);check(result.candidates.get("SurvivalMode")==1);
        check(result.candidates.size()==4);check(result.readFailures==1);check(!result.limited);
        check(EngineMemoryProbe.untag(0xb400000000208000L)==player);
        check(log.stream().anyMatch(s->s.contains("Link MinecraftGame+0x100 -> ClientInstance")));
        check(log.stream().anyMatch(s->s.contains("Link ClientInstance+0x200 -> LocalPlayer")));
        check(log.stream().anyMatch(s->s.contains("Link SurvivalMode+0x8 -> LocalPlayer")));
        // Exercise the actual tree layout: the client is no longer a direct
        // MinecraftGame field, and the player is only reachable through it.
        long tree=0x218000;byte[] node=new byte[72];
        put(g,0x100,0);put(g,0x980,tree);put(global,8,0);
        put(c,24,base+0x13890c20L);put(node,0,tree);node[24]=1;node[32]=2;
        put(node,40,0xb400000000000000L|(client+24));put(node,48,0);put(node,56,client);
        memory.put(tree,node);List<String> treeLog=new ArrayList<>();
        EngineMemoryProbe.Result treeResult=new EngineMemoryProbe(maps,reader,base,treeLog::add).scan(globals,globals+64);
        check(treeResult.candidates.get("ClientInstance")==1);check(treeResult.candidates.get("LocalPlayer")==1);
        check(treeResult.candidates.get("SurvivalMode")==1);check(!treeResult.limited);
        check(treeLog.stream().anyMatch(s->s.contains("Client tree key=2 node+40 -> ClientInstance")));
        // The player exists only in paged ECS storage, with a colliding hash
        // bucket, nonzero sparse page and a dense index beyond the first page.
        long registry=0x220000,buckets=0x221000,nodes=0x222000,markerPool=0x223000,ownerPool=0x224000;
        long vectors=0x225000,registryPage=0x226000,markerPage=0x228000,ownerPage=0x22a000;
        long payloads=0x22c000,payloadPage=0x22d000,control=0x22e000;
        int entity=0x100805,generation=entity&0xfffc0000;
        byte[] registryData=new byte[512],bucketData=new byte[16],nodeData=new byte[64];
        byte[] markerData=new byte[96],ownerData=new byte[96],vectorData=new byte[48];
        byte[] registrySparse=new byte[8192],markerSparse=new byte[8192],ownerSparse=new byte[8192];
        byte[] payloadVector=new byte[16],payloadData=new byte[1024];
        Arrays.fill(registrySparse,(byte)255);Arrays.fill(markerSparse,(byte)255);Arrays.fill(ownerSparse,(byte)255);
        put(c,0x200,0);put(c,576,registry);put(c,584,control);word(c,592,entity);put(p,3240,client);
        put(registryData,96,buckets);put(registryData,104,buckets+16);
        put(registryData,120,nodes);put(registryData,128,nodes+64);
        put(registryData,216,vectors);put(registryData,224,vectors+16);put(registryData,280,10);
        put(bucketData,0,0);put(bucketData,8,-1);
        put(nodeData,0,1);word(nodeData,8,0xacb47b38);put(nodeData,16,markerPool);
        put(nodeData,32,-1);word(nodeData,40,0x85b93800);put(nodeData,48,ownerPool);
        put(markerData,8,vectors+16);put(markerData,16,vectors+32);
        put(ownerData,8,vectors+32);put(ownerData,16,vectors+48);put(ownerData,80,payloads);
        put(vectorData,8,registryPage);put(vectorData,24,markerPage);put(vectorData,40,ownerPage);
        word(registrySparse,5*4,generation|2);word(markerSparse,5*4,generation|3);word(ownerSparse,5*4,generation|129);
        put(payloadVector,8,payloadPage);put(payloadData,8,0xb400000000000000L|player);
        memory.put(registry,registryData);memory.put(buckets,bucketData);memory.put(nodes,nodeData);
        memory.put(markerPool,markerData);memory.put(ownerPool,ownerData);memory.put(vectors,vectorData);
        memory.put(registryPage,registrySparse);memory.put(markerPage,markerSparse);memory.put(ownerPage,ownerSparse);
        memory.put(payloads,payloadVector);memory.put(payloadPage,payloadData);memory.put(control,new byte[24]);
        List<String> ecsLog=new ArrayList<>();
        EngineMemoryProbe.Result ecs=new EngineMemoryProbe(maps,reader,base,ecsLog::add).scan(globals,globals+64);
        check(ecs.verifiedPlayers==1);check(ecs.candidates.get("LocalPlayer")==1);
        check(ecs.candidates.get("SurvivalMode")==1);check(!ecs.limited);
        check(ecsLog.stream().anyMatch(s->s.contains("Player binding verified")));
        word(ownerSparse,20,(generation+0x40000)|129);
        EngineMemoryProbe.Result staleEntity=new EngineMemoryProbe(maps,reader,base,s->{}).scan(globals,globals+64);
        check(staleEntity.verifiedPlayers==0);check(!staleEntity.candidates.containsKey("LocalPlayer"));
        word(ownerSparse,20,generation|129);put(p,3240,client+8);
        check(new EngineMemoryProbe(maps,reader,base,s->{}).scan(globals,globals+64).verifiedPlayers==0);
        put(p,3240,client);word(markerSparse,20,-1);
        check(new EngineMemoryProbe(maps,reader,base,s->{}).scan(globals,globals+64).verifiedPlayers==0);
        word(markerSparse,20,generation|3);
        EngineMemoryProbe.Reader moving=(address,destination,count)->{
            boolean success=reader.read(address,destination,count);
            if(address==player)word(c,592,entity+0x40000);
            return success;
        };
        check(new EngineMemoryProbe(maps,moving,base,s->{}).scan(globals,globals+64).verifiedPlayers==0);
        word(c,592,entity);word(nodeData,8,1);put(nodeData,0,0);
        EngineMemoryProbe.Result cyclicHash=new EngineMemoryProbe(maps,reader,base,s->{}).scan(globals,globals+64);
        check(cyclicHash.verifiedPlayers==0);check(!cyclicHash.limited);
        put(nodeData,0,1);word(nodeData,8,0xacb47b38);word(c,592,0x3ffff);
        check(new EngineMemoryProbe(maps,reader,base,s->{}).scan(globals,globals+64).verifiedPlayers==0);
        word(c,592,entity);put(registryData,104,buckets+24);
        check(new EngineMemoryProbe(maps,reader,base,s->{}).scan(globals,globals+64).verifiedPlayers==0);
        byte[] dense=new byte[256*1024];
        for(int i=0;i<dense.length;i+=8)put(dense,i,0x10000000L+i);
        EngineMemoryProbe.Reader busy=(address,destination,count)->{
            if(address>=globals&&address+count<=globals+dense.length)
                System.arraycopy(dense,(int)(address-globals),destination,0,count);
            else Arrays.fill(destination,0,count,(byte)0);
            return true;
        };
        List<EngineMemoryProbe.Region> denseMaps=Arrays.asList(
                new EngineMemoryProbe.Region(globals,globals+dense.length,0,true,true,"globals"),
                new EngineMemoryProbe.Region(0x10000000L,0x10100000L,0,true,true,"heap"));
        EngineMemoryProbe.Result limited=new EngineMemoryProbe(denseMaps,busy,base,s->{}).scan(globals,globals+dense.length);
        check(limited.limited);check(limited.reads==20000);check(limited.candidates.isEmpty());
        boolean invalid=false;
        try{new EngineMemoryProbe(maps,reader,base,s->{}).scan(0,5*1024*1024L);}catch(IllegalArgumentException expected){invalid=true;}
        check(invalid);
        System.out.println("PASS: typed graph/tree, paged ECS player lookup, hash collisions/cycles, entity generations, back-reference, concurrent replacement and read bounds.");
    }
}
