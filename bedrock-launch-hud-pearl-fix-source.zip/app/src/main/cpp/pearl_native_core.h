#pragma once
#include "aim_core.h"
#include <algorithm>
#include <vector>

// Read-only layouts verified against the exact supported arm64 game binary.
// StateVector: fd80e28 returns Actor+552 -> +24 velocity; fd8e62c returns
// +0 position, fd8e658 interpolates +12 previous -> +0 current. Storage36.
// ProjectileComponent: storage760; c3eb7d0 copies definition gravity into
// +280. c3eb8dc copies air/liquid inertia into +436/+440. c3ef6c4 performs
// position += velocity; velocity *= inertia; velocity.y -= gravity (unless
// byte+1). fd8cf2c/101c0760 choose liquid inertia by WasInWaterFlag presence.
// c3edcb4 stores the thrower's ActorUniqueID at ProjectileComponent+8;
// fd89b58 resolves the 8-byte ActorUniqueIDComponent for the local actor.
namespace kulich_pearl {
using A=kulich_aim::A;
using kulich_aim::plain;
constexpr uint32_t STATE=0x1b5d5238U,PROJECTILE=0x94488499U,
                   UNIQUE_ID=0x18f957afU,WAS_IN_WATER=0x78e89f39U;
constexpr A PEARL_VTABLE=0x13d3adf8ULL;
constexpr unsigned MAX_PEARLS=8,MAX_ACTORS=16384;
struct Vector {float x=0,y=0,z=0;};
struct State {Vector position{},previous{},velocity{};};
static_assert(sizeof(Vector)==12&&sizeof(State)==36,"Exact-build state layout");
struct Snapshot {
 uint32_t id=0;
 int owner=-1; // 0 local thrower, 1 another known thrower, -1 unavailable.
 A actor=0,state=0,projectile=0;
 Vector position{},previous{},velocity{};
 float gravity=0,drag=1;
 bool inWater=false;
};
struct View {A registry=0,owners=0,states=0,projectiles=0,uniqueIds=0,water=0;};
struct ScanStats {unsigned candidates=0,pearlTypes=0,stateFailures=0;bool missingPool=false;};
template<class Read> View view(Read& read,A registry){
 registry=plain(registry);
 if(registry<4096||registry>0x00ffffffffffe000ULL)return {};
 return {registry,kulich_aim::pool(read,registry,kulich_aim::OWNER),
  kulich_aim::pool(read,registry,STATE),kulich_aim::pool(read,registry,PROJECTILE),
  kulich_aim::pool(read,registry,UNIQUE_ID),kulich_aim::pool(read,registry,WAS_IN_WATER)};
}
inline bool finite(Vector v,double limit){
 return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z)&&
        std::abs(v.x)<=limit&&std::abs(v.y)<=limit&&std::abs(v.z)<=limit;
}
inline bool valid(const State& s){
 if(!finite(s.position,32000000)||!finite(s.previous,32000000)||!finite(s.velocity,64))return false;
 return std::abs(double(s.position.x)-s.previous.x)<=128&&
        std::abs(double(s.position.y)-s.previous.y)<=128&&
        std::abs(double(s.position.z)-s.previous.z)<=128;
}
template<class Read> bool identity(Read& read,A base,const View& v,A address,A type,
                                 std::array<A,4>& header,uint32_t& entity){
 address=plain(address);
 if(address<4096||address>0x00ffffffffffe000ULL||!v.registry||!v.owners||
    !read(address,header.data(),sizeof header)||plain(header[0])!=base+type||
    plain(header[1])!=v.registry||plain(header[2])!=v.registry+40)return false;
 entity=uint32_t(header[3]);
 if((entity&0x3ffffU)==0x3ffffU||kulich_aim::sparse(read,v.registry+216,entity)<0)return false;
 A slot=kulich_aim::component(read,v.owners,entity,8);
 unsigned char removed=1;
 return slot&&kulich_aim::pointer(read,slot)==address&&
        read(address+617,&removed,1)&&removed==0;
}
template<class Read> bool localUniqueId(Read& read,A base,const View& v,A local,int64_t& uid){
 std::array<A,4> header{},again{};uint32_t entity=0;
 if(!identity(read,base,v,local,0x139f6ea0ULL,header,entity))return false;
 A component=kulich_aim::component(read,v.uniqueIds,entity,8);int64_t second=-1;
 if(!component||!read(component,&uid,8)||uid==-1||
    !read(component,&second,8)||uid!=second||
    !read(plain(local),again.data(),sizeof again)||header!=again)return false;
 return kulich_aim::component(read,v.uniqueIds,entity,8)==component&&
        kulich_aim::sparse(read,v.registry+216,entity)>=0;
}
template<class Read> bool pearl(Read& read,A base,const View& v,A address,
                               bool localKnown,int64_t localUid,Snapshot& out){
 std::array<A,4> header{},again{};uint32_t entity=0;address=plain(address);
 if(!identity(read,base,v,address,PEARL_VTABLE,header,entity))return false;
 A state=kulich_aim::component(read,v.states,entity,sizeof(State));
 A projectile=kulich_aim::component(read,v.projectiles,entity,760);
 if(!state||!projectile||kulich_aim::pointer(read,address+552)!=state)return false;
 State value{},second{};float gravity=NAN,drag=NAN;int64_t thrower=-1;
 unsigned char noGravity=0;
 bool inWater=v.water&&kulich_aim::sparse(read,v.water+8,entity)>=0;
 if(!read(state,&value,sizeof value)||!valid(value)||
    !read(projectile+1,&noGravity,1)||noGravity>1||
    !read(projectile+8,&thrower,8)||!read(projectile+280,&gravity,4)||
    !read(projectile+(inWater?440:436),&drag,4)||
    !std::isfinite(gravity)||gravity<0||gravity>1||
    !std::isfinite(drag)||drag<=0||drag>1)return false;
 // The component can disappear/recycle while another thread updates the
 // entity registry. Never publish a position from one generation and a
 // velocity/owner from another; a changed snapshot is retried next frame.
 if(!read(address,again.data(),sizeof again)||header!=again||
    kulich_aim::sparse(read,v.registry+216,entity)<0||
    kulich_aim::component(read,v.states,entity,sizeof(State))!=state||
    kulich_aim::component(read,v.projectiles,entity,760)!=projectile||
    kulich_aim::pointer(read,address+552)!=state||
    !read(state,&second,sizeof second)||std::memcmp(&value,&second,sizeof value))return false;
 unsigned char removed=1;
 A ownerSlot=kulich_aim::component(read,v.owners,entity,8);
 if(!ownerSlot||kulich_aim::pointer(read,ownerSlot)!=address||
    !read(address+617,&removed,1)||removed)return false;
 int owner=localKnown&&thrower!=-1?(thrower==localUid?0:1):-1;
 out={entity,owner,address,state,projectile,value.position,value.previous,value.velocity,
      noGravity?0.f:gravity,drag,inWater};
 return true;
}
// Iterate only the ACTIVE ProjectileComponent entity IDs. The real projectile
// system at c04c9ac..c04c9d8 uses these same packed vectors at +32/+40 and picks
// the smallest intersected pool. Walking every loaded ActorOwner (including
// all dropped items, players and mobs) used to exhaust the shared frame budget
// before a usable pearl snapshot could be published.
template<class Read> bool collect(Read& read,A base,A registry,A local,
                                 std::vector<Snapshot>& out,unsigned& checked,ScanStats* stats=nullptr){
 out.clear();checked=0;if(stats)*stats={};View v=view(read,registry);
 if(!v.owners||!v.states||!v.projectiles){if(stats)stats->missingPool=true;return false;}
 A bounds[3]{},again[3]{};
 if(!read(v.projectiles+32,bounds,sizeof bounds))return false;
 A begin=plain(bounds[0]),end=plain(bounds[1]),capacity=plain(bounds[2]);
 if((!begin&&(end||capacity))||end<begin||capacity<end||(end-begin)%4||
    (end-begin)/4>MAX_ACTORS)return false;
 int64_t uid=-1;bool localKnown=localUniqueId(read,base,v,local,uid);
 std::array<uint32_t,128> entities{};
 for(A at=begin;at<end&&out.size()<MAX_PEARLS;){
  size_t n=size_t(std::min<A>(entities.size(),(end-at)/4));
  if(!read(at,entities.data(),n*4)){out.clear();return false;}
  at+=n*4;
  for(size_t i=0;i<n&&out.size()<MAX_PEARLS;i++){
   ++checked;if(stats)++stats->candidates;uint32_t entity=entities[i];
   A slot=kulich_aim::component(read,v.owners,entity,8);
   A address=slot?kulich_aim::pointer(read,slot):0;Snapshot value{};
   if(!address||kulich_aim::pointer(read,address)!=base+PEARL_VTABLE)continue;
   if(stats)++stats->pearlTypes;
   if(pearl(read,base,v,address,localKnown,uid,value)&&value.id==entity){
    if(std::none_of(out.begin(),out.end(),[&](const Snapshot& p){return p.id==entity;}))out.push_back(value);
   }else if(stats)++stats->stateFailures;
  }
 }
 if(!read(v.projectiles+32,again,sizeof again)||std::memcmp(bounds,again,sizeof bounds)||
    kulich_aim::pool(read,v.registry,kulich_aim::OWNER)!=v.owners||
    kulich_aim::pool(read,v.registry,STATE)!=v.states||
    kulich_aim::pool(read,v.registry,PROJECTILE)!=v.projectiles){out.clear();return false;}
 return true;
}
// One exact native air/liquid physics step. Terrain collision is resolved
// separately for each start -> end segment, before committing the step.
inline void step(Vector& position,Vector& velocity,float gravity,float drag){
 position.x+=velocity.x;position.y+=velocity.y;position.z+=velocity.z;
 velocity.x*=drag;velocity.y=velocity.y*drag-gravity;velocity.z*=drag;
}
}
