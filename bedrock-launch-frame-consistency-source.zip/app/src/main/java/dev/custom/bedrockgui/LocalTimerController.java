package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

/** Wait for a current player binding; menus keep the requested local toggle. */
public final class LocalTimerController {
    private final Activity activity;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean requested,preparing,disposed;
    private int generation;
    private String message="Выключен";
    public LocalTimerController(Activity activity){this.activity=activity;}
    public boolean isEnabled(){return requested;}
    public String status(){return requested&&(LocalTimerBridge.isReady()||LocalTimerBridge.hasProblem())?LocalTimerBridge.describe():message;}
    public String displayStatus(){return status().split("\n",2)[0];}
    public void setEnabled(boolean value){
        if(disposed)return;
        generation++;requested=value;handler.removeCallbacksAndMessages(null);
        if(!value){LocalTimerBridge.setEnabled(false);message="Выключен";return;}
        if(LocalTimerBridge.isReady()){
            try{LocalTimerBridge.setEnabled(true);}
            catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить Timer. Причина в журнале";throw error;}
            return;
        }
        message="Подключаю Timer. Нужен загруженный мир";prepare(generation);
    }
    private void prepare(int epoch){
        if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
        if(preparing||!GameEngineProbe.begin()){handler.postDelayed(()->prepare(epoch),400);return;}
        preparing=true;
        Thread worker=new Thread(()->{
            try{GameEngineProbe.run();}
            catch(RuntimeException|LinkageError error){GameRuntime.log("Local Timer preparation failed: "+error);}
            finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{
                preparing=false;
                if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
                if(GameEngineProbe.playerFound()&&LocalTimerBridge.isReady()){
                    try{LocalTimerBridge.setEnabled(true);}
                    catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить Timer. Причина в журнале";GameRuntime.log("Local Timer enable failed: "+error);}
                }else if(GameEngineProbe.playerFound()){
                    requested=false;message="Timer не подключился\n"+LocalTimerBridge.describe();
                }else{
                    message="Войди в мир: Timer подключится автоматически";handler.postDelayed(()->prepare(epoch),8000);
                }
            });
        },"local-timer-prepare");worker.setDaemon(true);worker.start();
    }
    public void dispose(){setEnabled(false);disposed=true;handler.removeCallbacksAndMessages(null);}
}
