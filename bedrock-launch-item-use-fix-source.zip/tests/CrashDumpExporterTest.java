import dev.custom.bedrockgui.CrashDumpExporter;
import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.FileTime;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.GZIPInputStream;

public final class CrashDumpExporterTest {
    static void check(boolean value){if(!value)throw new AssertionError();}
    interface Failing {void run()throws Exception;}
    static void rejects(Failing action)throws Exception {
        try{action.run();throw new AssertionError("Expected an IOException");}
        catch(IOException expected){}
    }
    public static void main(String[] args)throws Exception {
        Path root=Files.createTempDirectory("crash-export-tests-");
        try {
            Path crash=Files.createDirectory(root.resolve("crash"));
            check(CrashDumpExporter.latest(crash.toFile())==null);
            check(CrashDumpExporter.latest(root.resolve("absent").toFile())==null);
            byte[] dump=new byte[180000];new Random(8675309).nextBytes(dump);
            System.arraycopy(new byte[]{'M','D','M','P'},0,dump,0,4);
            Path first=crash.resolve("first.dmp");Files.write(first,dump);
            Files.setLastModifiedTime(first,FileTime.fromMillis(10000));
            byte[] before=MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(first));
            ByteArrayOutputStream zipped=new ByteArrayOutputStream();
            check(CrashDumpExporter.writeGzip(crash.toFile(),"first.dmp",zipped)==dump.length);
            try(InputStream input=new GZIPInputStream(new ByteArrayInputStream(zipped.toByteArray()))){
                check(Arrays.equals(dump,input.readAllBytes()));
            }
            check(Arrays.equals(before,MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(first))));
            check(first.toFile().lastModified()==10000);
            OutputStream broken=new OutputStream(){
                public void write(int value)throws IOException{throw new IOException("Destination failed");}
                public void write(byte[] value,int offset,int count)throws IOException{throw new IOException("Destination failed");}
            };
            rejects(()->CrashDumpExporter.writeGzip(crash.toFile(),"first.dmp",broken));
            check(Arrays.equals(before,MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(first))));

            Path second=crash.resolve("second.dmp");Files.write(second,dump);
            Files.setLastModifiedTime(second,FileTime.fromMillis(20000));
            Path invalid=crash.resolve("newest-invalid.dmp");Files.write(invalid,new byte[128]);
            Files.setLastModifiedTime(invalid,FileTime.fromMillis(30000));
            Files.write(crash.resolve("unfinished.dmp"),new byte[]{'M','D','M','P'});
            Files.createDirectory(crash.resolve("directory.dmp"));
            Files.write(crash.resolve("other.txt"),dump);
            Path outside=root.resolve("outside.dmp");Files.write(outside,dump);
            Files.createSymbolicLink(crash.resolve("linked.dmp"),outside);
            check(CrashDumpExporter.latest(crash.toFile()).getName().equals("second.dmp"));
            rejects(()->CrashDumpExporter.validate(crash.toFile(),"../outside.dmp"));
            rejects(()->CrashDumpExporter.validate(crash.toFile(),outside.toString()));
            rejects(()->CrashDumpExporter.validate(crash.toFile(),"linked.dmp"));
            rejects(()->CrashDumpExporter.validate(crash.toFile(),"unfinished.dmp"));
            rejects(()->CrashDumpExporter.validate(crash.toFile(),"newest-invalid.dmp"));
            rejects(()->CrashDumpExporter.validate(crash.toFile(),"directory.dmp"));
            rejects(()->CrashDumpExporter.validate(crash.toFile(),"other.txt"));
            rejects(()->CrashDumpExporter.validate(crash.toFile(),null));
            Path huge=crash.resolve("huge.dmp");
            try(RandomAccessFile file=new RandomAccessFile(huge.toFile(),"rw")){
                file.write(new byte[]{'M','D','M','P'});file.setLength(256L*1024*1024+1);
            }
            rejects(()->CrashDumpExporter.validate(crash.toFile(),"huge.dmp"));
            check(CrashDumpExporter.latest(crash.toFile()).getName().equals("second.dmp"));
            check(Files.exists(first)&&Files.exists(second)&&Files.exists(outside));
            System.out.println("PASS: binary gzip round-trip, source bytes/mtime preserved, newest valid dump, missing/invalid/unfinished files, directory/symlink/traversal rejection and size bound");
        }finally{
            try(java.util.stream.Stream<Path> paths=Files.walk(root)){
                paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(IOException error){throw new UncheckedIOException(error);}});
            }
        }
    }
}
