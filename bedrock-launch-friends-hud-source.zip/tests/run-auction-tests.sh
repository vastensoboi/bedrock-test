#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
auction_test_dir=$(mktemp -d)
trap 'rm -rf "$auction_test_dir"' EXIT
sources=app/src/main/java/dev/custom/bedrockgui
if command -v javac >/dev/null 2>&1; then compiler=(javac); else compiler=(java com.sun.tools.javac.Main); fi
"${compiler[@]}" -d "$auction_test_dir" \
  "$sources"/{EngineMemoryProbe,AuctionMemoryProbe,NbtDisplayReader,AutoBuyCycle,AutoBuyMatcher,AutoBuyDefaultRules,SlotGrid,InventoryGrid}.java \
  tests/{AutoBuyCycleTest,AuctionActionTest,AuctionMemoryProbeTest,AutoBuyMatcherTest,NbtDisplayReaderTest,SlotGridTest,InventoryGridTest}.java
for test in AutoBuyCycleTest AuctionActionTest AuctionMemoryProbeTest AutoBuyMatcherTest NbtDisplayReaderTest; do
  java -cp "$auction_test_dir" "dev.custom.bedrockgui.$test"
done
java -cp "$auction_test_dir" SlotGridTest
java -cp "$auction_test_dir" InventoryGridTest

g++ -std=c++17 -Wall -Wextra -Werror tests/TransactionTraceTest.cpp -o "$auction_test_dir/transaction-trace-test"
"$auction_test_dir/transaction-trace-test"

g++ -std=c++17 -Wall -Wextra -Werror tests/NativeTransactionTest.cpp -o "$auction_test_dir/native-transaction-test"
"$auction_test_dir/native-transaction-test"

g++ -std=c++17 -Wall -Wextra -Werror tests/AimbotCoreTest.cpp -o "$auction_test_dir/aimbot-core-test"
"$auction_test_dir/aimbot-core-test"

g++ -std=c++17 -Wall -Wextra -Werror tests/FastExpCoreTest.cpp -o "$auction_test_dir/fast-exp-core-test"
"$auction_test_dir/fast-exp-core-test"

"${compiler[@]}" -d "$auction_test_dir" "$sources/TargetHudData.java" tests/TargetHudDataTest.java
java -cp "$auction_test_dir" dev.custom.bedrockgui.TargetHudDataTest

for test in CpsRangeTest AimStabilityTest; do
  g++ -std=c++17 -Wall -Wextra -Werror "tests/$test.cpp" -o "$auction_test_dir/$test"
  "$auction_test_dir/$test"
done

for test in FriendPolicyTest PlayerDisplayTest; do
  g++ -std=c++17 -Wall -Wextra -Werror "tests/$test.cpp" -o "$auction_test_dir/$test"
  "$auction_test_dir/$test"
done
"${compiler[@]}" -d "$auction_test_dir" "$sources/FriendCommands.java" tests/FriendCommandsTest.java
java -cp "$auction_test_dir" dev.custom.bedrockgui.FriendCommandsTest
