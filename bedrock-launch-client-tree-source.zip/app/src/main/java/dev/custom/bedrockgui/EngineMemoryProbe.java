package dev.custom.bedrockgui;

import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.function.Consumer;

/** Bounded, read-only structural probe. It never invokes game functions. */
public final class EngineMemoryProbe {
    public interface Reader { boolean read(long address, byte[] destination, int count) throws IOException; }
    public static final class Region {
        final long start, end, offset;final boolean readable, writable;final String path;
        public Region(long start, long end, long offset, boolean readable, boolean writable, String path) {
            this.start=start;this.end=end;this.offset=offset;this.readable=readable;this.writable=writable;this.path=path;
        }
        public static Region parse(String line) {
            String[] fields=line.trim().split("\\s+",6);
            if(fields.length<5)throw new IllegalArgumentException("Invalid maps entry");
            String[] range=fields[0].split("-",2);
            long start=Long.parseUnsignedLong(range[0],16),end=Long.parseUnsignedLong(range[1],16);
            if(start<0||end<=start)throw new IllegalArgumentException("Invalid maps range");
            return new Region(start,end,Long.parseUnsignedLong(fields[2],16),fields[1].charAt(0)=='r',
                    fields[1].charAt(1)=='w',fields.length==6?fields[5]:"");
        }
    }
    private static final class Type {
        final String name;final int bytes, toTop;
        Type(String name,int bytes,int toTop){this.name=name;this.bytes=bytes;this.toTop=toTop;}
    }
    private static final class Node {
        final long address;final Type type;
        Node(long address,Type type){this.address=address;this.type=type;}
    }
    public static final class Result {
        public final Map<String,Integer> candidates=new LinkedHashMap<>();
        public int reads, readFailures, links;
        public boolean limited;
        public String summary(){return "Кандидаты объектов: "+candidates+". Чтений: "+reads+
                ", ошибок чтения: "+readFailures+(limited?". Достигнут лимит проверки.":".");}
    }
    private final List<Region> regions;
    private final Reader reader;
    private final Consumer<String> log;
    private final Map<Long,Type> types=new HashMap<>();
    private final Set<Long> visited=new HashSet<>(),objects=new HashSet<>();
    private final Map<Long,Node> recognized=new HashMap<>();
    private final ArrayDeque<Node> queue=new ArrayDeque<>();
    private final Result result=new Result();
    private long deadline;
    public EngineMemoryProbe(List<Region> regions,Reader reader,long base,Consumer<String> log) {
        this.regions=new ArrayList<>(regions);this.regions.sort(Comparator.comparingLong(r->r.start));
        this.reader=reader;this.log=log;
        type(base,0x1388fe70L,"ClientInstance",3648,0);
        type(base,0x13890c20L,"ClientInstance",3648,-24);
        type(base,0x13890c38L,"ClientInstance",3648,-32);
        type(base,0x13890c78L,"ClientInstance",3648,-96);
        type(base,0x13890ce0L,"ClientInstance",3648,-104);
        type(base,0x13890d18L,"ClientInstance",3648,-112);
        type(base,0x1389f8b8L,"MinecraftGame",7664,0);
        type(base,0x139f6ea0L,"LocalPlayer",4304,0);
        type(base,0x13d227d0L,"GameMode",16,0);
        type(base,0x13d22900L,"SurvivalMode",16,0);
        type(base,0x13d43520L,"PlayerInventory",8,0);
        type(base,0x13d42b08L,"Inventory",8,0);
        type(base,0x13d95ff8L,"ItemStack",8,0);
        type(base,0x13d9eb70L,"ExperiencePotionItem",8,0);
    }
    private void type(long base,long offset,String name,int size,int toTop){types.put(base+offset,new Type(name,size,toTop));}
    public static long untag(long value){return value&0x00ffffffffffffffL;}
    private Region containing(long address,int count) {
        int low=0,high=regions.size()-1;
        while(low<=high){int mid=(low+high)>>>1;Region r=regions.get(mid);
            if(address<r.start)high=mid-1;else if(address>=r.end)low=mid+1;
            else return r.readable&&count>=0&&count<=r.end-address?r:null;
        }
        return null;
    }
    private boolean read(long address,byte[] data,int size)throws IOException {
        if(result.reads>=20000||System.nanoTime()>deadline){result.limited=true;return false;}
        if(containing(address,size)==null)return false;
        result.reads++;
        try {if(reader.read(address,data,size))return true;}
        catch(IOException error){result.readFailures++;return false;}
        result.readFailures++;return false;
    }
    private Node inspect(long tagged)throws IOException {
        long address=untag(tagged);
        if(address==0||(address&7)!=0)return null;
        Node cached=recognized.get(address);if(cached!=null)return cached;
        Region region=containing(address,8);
        if(region==null||!region.writable)return null;
        if(!visited.add(address))return null;
        if(visited.size()>30000){result.limited=true;return null;}
        byte[] bytes=new byte[8];if(!read(address,bytes,8))return null;
        Type type=types.get(untag(ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).getLong()));
        if(type==null)return null;
        long object=address+type.toTop;
        if(object<=0||containing(object,8)==null)return null;
        if(objects.size()>=64&&!objects.contains(object)){result.limited=true;return null;}
        Node node=new Node(object,new Type(type.name,type.bytes,0));
        recognized.put(address,node);recognized.put(object,node);
        if(objects.size()<64&&objects.add(object)) {
            result.candidates.merge(type.name,1,Integer::sum);queue.add(node);
            log.accept("Candidate "+type.name+" at 0x"+Long.toHexString(object));
        }
        return node;
    }
    private void clientTree(Node game,byte[] snapshot)throws IOException {
        // This exact-build layout is supported by the allocation/insertion code
        // at 0x9cdd280..0x9cdd4d8: root +0x980, 72-byte nodes, key +32,
        // interface pointers +40/+48 and owning ClientInstance pointer +56.
        long root=untag(ByteBuffer.wrap(snapshot).order(ByteOrder.LITTLE_ENDIAN).getLong(0x980));
        log.accept("Client tree root at MinecraftGame+0x980: 0x"+Long.toHexString(root));
        if(root==0)return;
        ArrayDeque<Long> pending=new ArrayDeque<>();Set<Long> seen=new HashSet<>();pending.add(root);
        while(!pending.isEmpty()&&!result.limited){
            long address=pending.remove();if(address==0||!seen.add(address))continue;
            if(seen.size()>64){result.limited=true;break;}
            Region mapping=containing(address,72);if(mapping==null||!mapping.writable)continue;
            byte[] data=new byte[72];if(!read(address,data,data.length))continue;
            if((data[24]&255)>1){log.accept("Client tree node rejected: invalid color");continue;}
            ByteBuffer values=ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
            boolean valid=false;
            for(int offset:new int[]{40,48,56}){
                long pointer=values.getLong(offset);Node client=inspect(pointer);
                if(client!=null&&client.type.name.equals("ClientInstance")){
                    valid=true;
                    if(result.links<96){result.links++;log.accept("Client tree key="+(data[32]&255)+
                            " node+"+offset+" -> ClientInstance at 0x"+Long.toHexString(client.address));}
                }
            }
            if(!valid){log.accept("Client tree node rejected: no matching ClientInstance vptr");continue;}
            long left=untag(values.getLong(0)),right=untag(values.getLong(8));
            if(left!=0)pending.add(left);if(right!=0)pending.add(right);
        }
    }
    public Result scan(long start,long end)throws IOException {
        if(end<start||end-start>4*1024*1024L)throw new IllegalArgumentException("Probe range exceeds 4 MiB");
        deadline=System.nanoTime()+4_000_000_000L;
        byte[] buffer=new byte[4096];
        for(long at=start;at<end&&!result.limited;){
            int count=(int)Math.min(buffer.length,end-at);
            if(read(at,buffer,count)){
                ByteBuffer values=ByteBuffer.wrap(buffer,0,count).order(ByteOrder.LITTLE_ENDIAN);
                while(values.remaining()>=8&&!result.limited)inspect(values.getLong());
            }
            at+=count;
        }
        while(!queue.isEmpty()&&!result.limited){
            Node node=queue.remove();byte[] bytes=new byte[node.type.bytes];
            if(!read(node.address,bytes,bytes.length))continue;
            if(node.type.name.equals("MinecraftGame"))clientTree(node,bytes);
            ByteBuffer values=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
            while(values.remaining()>=8&&!result.limited){
                int offset=values.position();Node child=inspect(values.getLong());
                if(child!=null&&result.links<96){result.links++;
                    log.accept("Link "+node.type.name+"+0x"+Integer.toHexString(offset)+" -> "+child.type.name+
                            " at 0x"+Long.toHexString(child.address));}
            }
        }
        log.accept(result.summary());return result;
    }
}
