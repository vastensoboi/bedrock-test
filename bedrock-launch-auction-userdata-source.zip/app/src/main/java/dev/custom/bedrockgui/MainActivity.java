package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.widget.*;
import dalvik.system.DexClassLoader;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Hosts preparation, a separate game-process launch attempt and crash reports. */
public final class MainActivity extends Activity {
    private static final String GAME = "com.mojang.minecraftpe";
    private static final int SAVE_REPORT = 41;
    private static final int SAVE_DUMP = 42;
    private static final int IMPORT_SCRIPT = 43;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final StringBuffer report = new StringBuffer();
    private TextView log;
    private Button test, launch,fastPlay;
    private Button exportDump;
    private String pendingDump;
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private static final class ProbeLoader extends DexClassLoader {
        ProbeLoader(String dexPath, String optimized, String libs, ClassLoader parent) {
            super(dexPath, optimized, libs, parent);
        }
        String library(String name) { return super.findLibrary(name); }
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if(saved!=null)pendingDump=saved.getString("pendingDump");
        if(getIntent()!=null&&getIntent().getBooleanExtra("showLaunchLog",false)){
            createJournalScreen(saved==null&&getIntent().getBooleanExtra("saveLaunchLog",false));return;
        }
        LinearLayout page = new LinearLayout(this); page.setOrientation(1);
        page.setPadding(dp(16), dp(16), dp(16), dp(12)); page.setBackgroundColor(Color.rgb(15,20,29));
        TextView title = new TextView(this); title.setText("Bedrock Crash Capture · 0.36"); title.setTextSize(25); title.setTextColor(Color.WHITE); page.addView(title);
        TextView info = new TextView(this);
        info.setText("Проверка входа Microsoft и игровых функций. Если после входа браузер предложит выбрать приложение, выбери Bedrock Crash Capture. При ошибке вернись сюда и сохрани журнал.");
        info.setTextColor(Color.LTGRAY); info.setPadding(0,dp(12),0,dp(12)); page.addView(info);
        fastPlay=new Button(this);fastPlay.setText("Включить Fast Exp и играть");
        fastPlay.setOnClickListener(v->startHosted(true));page.addView(fastPlay);
        TextView fastHint=new TextView(this);fastHint.setText("Fast Exp подключится автоматически после входа в мир. Для бросков возьми пузырьки опыта в руку.");
        fastHint.setTextColor(Color.LTGRAY);page.addView(fastHint);
        exportDump=new Button(this);exportDump.setText("Сохранить дамп падения");
        exportDump.setOnClickListener(v->chooseCrashDump());page.addView(exportDump);
        test = new Button(this); test.setText("Проверить Minecraft");
        test.setOnClickListener(v -> { if(launch!=null)launch.setEnabled(false); test.setEnabled(false); report.setLength(0); worker.execute(this::probe); }); page.addView(test);
        launch = new Button(this); launch.setText("Запустить Minecraft");
        launch.setOnClickListener(v -> startHosted()); page.addView(launch);
        Button importScript=new Button(this);importScript.setText("Импорт скрипта kulich (.js)");
        importScript.setOnClickListener(v->{
            Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
            try{startActivityForResult(intent,IMPORT_SCRIPT);}
            catch(ActivityNotFoundException error){Toast.makeText(this,"Системный выбор файла недоступен",Toast.LENGTH_LONG).show();}
        });page.addView(importScript);
        Button removeScripts=new Button(this);removeScripts.setText("Убрать импортированные скрипты");
        removeScripts.setOnClickListener(v->worker.execute(()->{
            try{int count=ScriptFiles.archive(new File(getFilesDir(),"scripts"),new File(getFilesDir(),"scripts-backup"));
                say("Убрано скриптов: "+count+". Копии сохранены. Изменение действует после перезапуска игры.");
            }catch(IOException error){say("Не удалось убрать скрипты: "+error.getMessage());}
        }));page.addView(removeScripts);
        Button journal = new Button(this); journal.setText("Показать журнал запуска");
        journal.setOnClickListener(v -> openJournal(false)); page.addView(journal);
        Button stop = new Button(this); stop.setText("Остановить тестовый процесс игры");
        stop.setOnClickListener(v -> {
            android.app.ActivityManager manager=getSystemService(android.app.ActivityManager.class);
            java.util.List<android.app.ActivityManager.RunningAppProcessInfo> processes=manager.getRunningAppProcesses();
            if(processes!=null) for(android.app.ActivityManager.RunningAppProcessInfo process:processes) {
                if(process.uid==android.os.Process.myUid()&&process.processName.equals(getPackageName()+":game")) {
                    android.os.Process.killProcess(process.pid);say("Тестовый процесс нашего приложения остановлен.");
                }
            }
        }); page.addView(stop);
        Button clear = new Button(this); clear.setText("Очистить подготовленные библиотеки");
        clear.setOnClickListener(v -> {
            if(!test.isEnabled()||gameRunning()) { Toast.makeText(this,"Дождись окончания проверки",Toast.LENGTH_SHORT).show(); return; }
            test.setEnabled(false);
            worker.execute(() -> {
                try { GameArchiveCache.clear(new File(getCodeCacheDir(),"game-probe")); GameArchiveCache.clear(new File(getCodeCacheDir(),"hosted-launch")); say("Кэш подготовленных библиотек очищен."); }
                catch(IOException error) { say("Ошибка очистки: " + error); }
                finally { runOnUiThread(() -> { if(!isFinishing()&&!isDestroyed()){test.setEnabled(true);if(launch!=null)launch.setEnabled(true);} }); }
            });
        }); page.addView(clear);
        Button save = new Button(this); save.setText("Сохранить журнал");
        save.setOnClickListener(v -> openJournal(true)); page.addView(save);
        ScrollView scroll = new ScrollView(this); log = new TextView(this);
        log.setTextColor(Color.rgb(180,230,220)); log.setTextIsSelectable(true); log.setTextSize(13); scroll.addView(log);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,dp(240)));
        ScrollView screen=new ScrollView(this);screen.setFillViewport(true);screen.addView(page);setContentView(screen);
        File previous = new File(getFilesDir(),"last-report.txt");
        try { if (previous.isFile()) report.append(new String(java.nio.file.Files.readAllBytes(previous.toPath()),java.nio.charset.StandardCharsets.UTF_8)); }
        catch (IOException ignored) {}
        log.setText(report.toString());
    }
    private void say(String text) {
        report.append(text).append('\n');
        runOnUiThread(() -> { if(!isFinishing()&&!isDestroyed()) log.setText(report.toString()); });
    }
    private File crashDirectory(){return new File(getApplicationInfo().dataDir,"crash");}
    private void chooseCrashDump(){
        if(gameRunning()){
            Toast.makeText(this,"Сначала выйди из игры или останови тестовый процесс",Toast.LENGTH_LONG).show();return;
        }
        exportDump.setEnabled(false);
        worker.execute(()->{
            try {
                File dump=CrashDumpExporter.latest(crashDirectory());
                if(dump==null)throw new IOException("В этой сборке пока нет дампа. После вылета вернись сюда.");
                String name=dump.getName();
                runOnUiThread(()->{
                    if(isFinishing()||isDestroyed())return;
                    pendingDump=name;
                    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/gzip")
                            .addCategory(Intent.CATEGORY_OPENABLE)
                            .putExtra(Intent.EXTRA_TITLE,"bedrock-crash-capture-0.36.dmp.gz");
                    try{startActivityForResult(intent,SAVE_DUMP);}
                    catch(ActivityNotFoundException error){
                        pendingDump=null;exportDump.setEnabled(true);
                        Toast.makeText(this,"Системный выбор файла недоступен",Toast.LENGTH_LONG).show();
                    }
                });
            }catch(IOException error){
                say("Экспорт дампа: "+error.getMessage());
                runOnUiThread(()->{if(!isFinishing()&&!isDestroyed()){
                    exportDump.setEnabled(true);Toast.makeText(this,error.getMessage(),Toast.LENGTH_LONG).show();
                }});
            }
        });
    }
    private void probe() {
        try {
            say("Устройство: " + Build.MANUFACTURER + " " + Build.MODEL);
            say("Android: " + Build.VERSION.RELEASE + " / API " + Build.VERSION.SDK_INT);
            say("ABI: " + String.join(", ",Build.SUPPORTED_ABIS));
            say("PAGE_SIZE: " + android.system.Os.sysconf(android.system.OsConstants._SC_PAGESIZE));
            if(!Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a")) throw new IOException("Нужен ARM64");
            PackageInfo info = getPackageManager().getPackageInfo(GAME,0);
            ApplicationInfo app = info.applicationInfo;
            if(app==null) throw new IOException("ApplicationInfo не получен");
            say("Minecraft: " + info.versionName + " (code " + info.getLongVersionCode() + ")");
            List<File> apks = new ArrayList<>(); apks.add(new File(app.sourceDir));
            if(app.splitSourceDirs!=null) for(String split:app.splitSourceDirs) apks.add(new File(split));
            say("APK-файлов: " + apks.size());
            for(File apk:apks) say("  " + apk.getName() + ": " + apk.length() + " байт");
            File cache = new File(getCodeCacheDir(),"game-probe");
            GameArchiveCache.Result result = GameArchiveCache.prepare(apks,cache,this::say);
            say("Заголовки ELF64 ARM64 проверены; библиотек: " + result.libraries.size());
            say("Каталог библиотек: " + result.directory.getName());
            StringBuilder dex = new StringBuilder();
            for(File apk:apks) { if(dex.length()>0)dex.append(File.pathSeparator); dex.append(apk.getAbsolutePath()); }
            File optimized = new File(cache,"optimized");
            if(!optimized.isDirectory()&&!optimized.mkdirs()) throw new IOException("Недоступен каталог optimized");
            ProbeLoader loader = new ProbeLoader(dex.toString(),optimized.getAbsolutePath(),result.directory.getAbsolutePath(),getClassLoader());
            String nativePath = loader.library("minecraftpe");
            if(nativePath==null) throw new IOException("ClassLoader не разрешил libminecraftpe.so");
            say("Разрешение native path: OK");
            Class<?> activity = Class.forName("com.mojang.minecraftpe.MainActivity",false,loader);
            if(!Activity.class.isAssignableFrom(activity)) throw new IOException("Игровой класс не является Activity");
            say("Игровой MainActivity найден, тип Activity проверен: OK");
            say("PASS: файлы и классы подготовлены. Инициализация игры, загрузка .so и запуск игры НЕ проверены.");
        } catch(PackageManager.NameNotFoundException error) {
            say("FAIL: Minecraft с пакетом com.mojang.minecraftpe не найден в этом профиле Android.");
        } catch(Exception | LinkageError error) {
            say("FAIL: " + error);
            StringWriter trace = new StringWriter(); error.printStackTrace(new PrintWriter(trace)); say(trace.toString());
        } finally {
            try(FileOutputStream out = new FileOutputStream(new File(getFilesDir(),"last-report.txt"))) {
                out.write(report.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            } catch(IOException ignored) {}
            runOnUiThread(() -> { if(!isFinishing()&&!isDestroyed()) {test.setEnabled(true);if(launch!=null)launch.setEnabled(true);} });
        }
    }
    private boolean gameRunning() {
        android.app.ActivityManager manager=getSystemService(android.app.ActivityManager.class);
        java.util.List<android.app.ActivityManager.RunningAppProcessInfo> processes=manager.getRunningAppProcesses();
        if(processes!=null)for(android.app.ActivityManager.RunningAppProcessInfo process:processes)
            if(process.uid==android.os.Process.myUid()&&process.processName.equals(getPackageName()+":game"))return true;
        return false;
    }
    private void startHosted() {
        startHosted(false);
    }
    private void startHosted(boolean autoFastExp) {
        if(!test.isEnabled()||!launch.isEnabled())return;
        if(gameRunning()) { Toast.makeText(this,"Сначала останови предыдущий тестовый процесс",Toast.LENGTH_LONG).show();return; }
        test.setEnabled(false);launch.setEnabled(false);
        worker.execute(() -> {
            try {
                PackageInfo info=getPackageManager().getPackageInfo(GAME,PackageManager.GET_PROVIDERS|PackageManager.GET_ACTIVITIES);
                ApplicationInfo app=info.applicationInfo;
                if(app==null)throw new IOException("ApplicationInfo отсутствует");
                if(info.activities!=null)for(ActivityInfo component:info.activities){
                    String name=component.name;
                    if(name!=null&&(name.startsWith("com.microsoft.")||name.toLowerCase(java.util.Locale.ROOT).contains("auth")))
                        say("Auth component in game: "+name+" exported="+component.exported+" launchMode="+component.launchMode+" theme=0x"+Integer.toHexString(component.getThemeResource()));
                }

                java.util.List<File> apks=new java.util.ArrayList<>();apks.add(new File(app.sourceDir));
                if(app.splitSourceDirs!=null)for(String path:app.splitSourceDirs)apks.add(new File(path));
                File cache=new File(getCodeCacheDir(),"hosted-launch");
                GameArchiveCache.Result prepared=GameArchiveCache.prepare(apks,cache,this::say);
                String[] sources=new String[apks.size()];for(int i=0;i<apks.size();i++)sources[i]=apks.get(i).getAbsolutePath();
                java.util.List<String> providerNames=new java.util.ArrayList<>();
                if(info.providers!=null)for(ProviderInfo provider:info.providers)providerNames.add(provider.name);
                String application=app.className;
                if(application!=null&&application.startsWith("."))application=GAME+application;
                File optimized=new File(cache,"optimized");
                if(!optimized.isDirectory()&&!optimized.mkdirs())throw new IOException("Нет каталога optimized");
                File journal=new File(getFilesDir(),"launch-log.txt");
                java.nio.file.Files.write(journal.toPath(),new byte[0]);
                String contentLogSetup;
                try{contentLogSetup=GameLogOptions.enable(getDataDir(),getFilesDir(),getExternalFilesDirs(null));}
                catch(IOException error){contentLogSetup="Content log setup failed: "+error.getMessage();}
                say(contentLogSetup);
                Intent intent=new Intent().setClassName(this,GameRuntime.ACTIVITY)
                    .putExtra("fastExpAuto",autoFastExp)
                    .putExtra("contentLogSetup",contentLogSetup)
                    .putExtra("apks",sources).putExtra("libs",prepared.directory.getAbsolutePath())
                    .putExtra("hostApk",getApplicationInfo().sourceDir)
                    .putExtra("hostLib",getApplicationInfo().nativeLibraryDir)
                    .putExtra("optimized",optimized.getAbsolutePath())
                    .putExtra("journal",journal.getAbsolutePath())
                    .putExtra("gameApplication",application)
                    .putExtra("gameProviders",providerNames.toArray(new String[0]));
                OwnLogCapture.start(getApplicationContext());
                getPreferences(0).edit().putLong("lastLaunch",System.currentTimeMillis()).apply();
                say("Передаю запуск в отдельный процесс нашего приложения. Это ещё не подтверждение запуска игры.");
                runOnUiThread(() -> {
                    if(isFinishing()||isDestroyed())return;
                    try { startActivity(intent); }
                    catch(RuntimeException error){say("Ошибка открытия тестовой Activity: "+error);}
                });
            }catch(Exception error){
                StringWriter trace=new StringWriter();error.printStackTrace(new PrintWriter(trace));say("Подготовка запуска остановилась:\n"+trace);
            }finally {
                runOnUiThread(() -> {if(!isFinishing()&&!isDestroyed()){test.setEnabled(true);launch.setEnabled(true);}});
            }
        });
    }
    private void openJournal(boolean save){
        startActivity(new Intent(this,MainActivity.class).putExtra("showLaunchLog",true).putExtra("saveLaunchLog",save));
    }
    private void chooseReportDestination(){
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain")
                .addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"bedrock-crash-capture-0.36.txt");
        try{startActivityForResult(intent,SAVE_REPORT);}
        catch(ActivityNotFoundException error){Toast.makeText(this,"Системный выбор файла недоступен",Toast.LENGTH_LONG).show();}
    }
    private void createJournalScreen(boolean saveAfterLoad){
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16),dp(12),dp(16),dp(12));page.setBackgroundColor(Color.rgb(15,20,29));
        TextView title=new TextView(this);title.setText("Журнал kulich · 0.36");title.setTextSize(22);title.setTextColor(Color.WHITE);page.addView(title);
        TextView state=new TextView(this);state.setText("Собираю журнал…");state.setTextColor(Color.LTGRAY);page.addView(state);
        LinearLayout buttons=new LinearLayout(this);
        Button save=new Button(this);save.setText("Сохранить журнал");save.setEnabled(false);
        buttons.addView(save,new LinearLayout.LayoutParams(0,-2,1));
        Button refresh=new Button(this);refresh.setText("Обновить");refresh.setEnabled(false);
        buttons.addView(refresh,new LinearLayout.LayoutParams(0,-2,1));page.addView(buttons);
        log=new TextView(this);log.setTextColor(Color.rgb(180,230,220));log.setTextSize(12);log.setTextIsSelectable(true);
        log.setText("Загрузка сообщений игры…");ScrollView scroll=new ScrollView(this);scroll.addView(log);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(page);
        save.setOnClickListener(v->chooseReportDestination());
        java.util.function.Consumer<Boolean> load=export->{
            save.setEnabled(false);refresh.setEnabled(false);state.setText("Собираю журнал…");
            worker.execute(()->{
                String value=collectLaunchLog();report.setLength(0);report.append(value);
                runOnUiThread(()->{
                    if(isFinishing()||isDestroyed())return;
                    log.setText(value);state.setText("Журнал собран: "+value.length()+" символов");
                    save.setEnabled(true);refresh.setEnabled(true);
                    if(export)chooseReportDestination();
                });
            });
        };
        refresh.setOnClickListener(v->load.accept(false));load.accept(saveAfterLoad);
    }
    private String collectLaunchLog() {
        StringBuilder text=new StringBuilder("Отчёт kulich · 0.36\n");
        java.util.function.Consumer<String> line=value->text.append(value).append('\n');
        try {
            File file=new File(getFilesDir(),"launch-log.txt");
            if(file.isFile()){
                try(RandomAccessFile input=new RandomAccessFile(file,"r")){
                    int size=(int)Math.min(input.length(),512*1024);byte[] bytes=new byte[size];
                    input.seek(input.length()-size);input.readFully(bytes);
                    line.accept("--- Журнал тестового процесса (последние "+size+" байт) ---\n"+
                            new String(bytes,java.nio.charset.StandardCharsets.UTF_8));
                }
            }
            else line.accept("Попыток запуска ещё не было.");
            long since=getPreferences(0).getLong("lastLaunch",Long.MAX_VALUE);
            android.app.ActivityManager manager=getSystemService(android.app.ActivityManager.class);
            for(android.app.ApplicationExitInfo exit:manager.getHistoricalProcessExitReasons(getPackageName(),0,5)) {
                if(exit.getTimestamp()>=since&&exit.getProcessName().equals(getPackageName()+":game")) {
                    line.accept("Завершение процесса: reason="+exit.getReason()+" status="+exit.getStatus()+
                            " timestamp="+exit.getTimestamp()+" elapsedMs="+(exit.getTimestamp()-since)+" / "+exit.getDescription());
                    try(java.io.InputStream trace=exit.getTraceInputStream()) {
                        if(trace==null)line.accept("Системный trace не предоставлен Android.");
                        else if(exit.getReason()==android.app.ApplicationExitInfo.REASON_ANR) line.accept("Получен ANR trace; protobuf-разбор пропущен.");
                        else line.accept("--- Native tombstone ---\n"+TombstoneSummary.read(trace));
                    }catch(java.io.IOException|RuntimeException error){line.accept("Не удалось прочитать native trace: "+error);}
                }
            }
            line.accept("--- Собственный logcat (UID приложения, последняя часть) ---\n"+OwnLogCapture.tail(this));
            line.accept("--- Журналы контента Minecraft ---\n"+
                    GameContentLogs.read(GameContentLogs.roots(getDataDir(),getFilesDir(),getExternalFilesDirs(null))));
        }catch(Exception error){line.accept("Не удалось прочитать журнал: "+error);}
        return text.toString();
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==IMPORT_SCRIPT){
            if(result!=RESULT_OK||data==null||data.getData()==null)return;
            android.net.Uri source=data.getData();
            worker.execute(()->{
                try(InputStream input=getContentResolver().openInputStream(source)){
                    if(input==null)throw new IOException("Файл недоступен");
                    ScriptFiles.store(new File(getFilesDir(),"scripts"),input);
                    say("Скрипт импортирован. Его модули появятся после следующего запуска Minecraft; изначально выключены.");
                }catch(IOException|RuntimeException error){say("Импорт скрипта: "+error.getMessage());}
            });return;
        }
        if(request==SAVE_DUMP){
            String selected=pendingDump;pendingDump=null;
            if(result!=RESULT_OK||data==null||data.getData()==null){exportDump.setEnabled(true);return;}
            if(selected==null){
                exportDump.setEnabled(true);
                Toast.makeText(this,"Выбери дамп ещё раз",Toast.LENGTH_LONG).show();return;
            }
            android.net.Uri destination=data.getData();
            worker.execute(()->{
                try(OutputStream output=getContentResolver().openOutputStream(destination)){
                    if(output==null)throw new IOException("Файл недоступен");
                    long bytes=CrashDumpExporter.writeGzip(crashDirectory(),selected,output);
                    say("Дамп сохранён: "+bytes+" байт до сжатия. Прикрепи файл .dmp.gz в чат.");
                    runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())
                        Toast.makeText(this,"Дамп сохранён",Toast.LENGTH_LONG).show();});
                }catch(IOException|RuntimeException error){say("Не удалось сохранить дамп: "+error.getMessage());}
                finally{runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())exportDump.setEnabled(true);});}
            });
            return;
        }
        if(request!=SAVE_REPORT||result!=RESULT_OK||data==null||data.getData()==null)return;
        android.net.Uri destination=data.getData();
        worker.execute(()->{
            try {
                String value=report.toString();if(value.isEmpty())throw new IOException("Журнал ещё не собран");
                try(OutputStream out=getContentResolver().openOutputStream(destination)){
                    if(out==null)throw new IOException("Файл недоступен");
                    out.write(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                }
                runOnUiThread(()->Toast.makeText(this,"Журнал сохранён",Toast.LENGTH_SHORT).show());
            }catch(IOException|RuntimeException error){
                runOnUiThread(()->Toast.makeText(this,"Ошибка сохранения: "+error.getMessage(),Toast.LENGTH_LONG).show());
            }
        });
    }
    @Override protected void onSaveInstanceState(Bundle state){
        super.onSaveInstanceState(state);state.putString("pendingDump",pendingDump);
    }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
}
