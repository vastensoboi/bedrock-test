.text
.p2align 2
.global kulich_response_read_hook
.type kulich_response_read_hook,%function
kulich_response_read_hook:
    hint #34
    .cfi_startproc
    sub sp, sp, #112
    .cfi_def_cfa_offset 112
    stp x29, x30, [sp]
    .cfi_offset x29, -112
    .cfi_offset x30, -104
    mov x29, sp
    stp x0, x8, [sp, #16]
    adrp x16, :got:kulich_original_response_read
    ldr x16, [x16, :got_lo12:kulich_original_response_read]
    ldar x16, [x16]
    blr x16
    stp x0, x1, [sp, #32]
    stp q0, q1, [sp, #48]
    stp q2, q3, [sp, #80]
    ldr x0, [sp, #16]
    bl kulich_response_decoded
    ldp x0, x1, [sp, #32]
    ldp q0, q1, [sp, #48]
    ldp q2, q3, [sp, #80]
    ldr x8, [sp, #24]
    ldp x29, x30, [sp]
    add sp, sp, #112
    .cfi_def_cfa_offset 0
    ret
    .cfi_endproc
.size kulich_response_read_hook, .-kulich_response_read_hook
.section .note.GNU-stack,"",%progbits
