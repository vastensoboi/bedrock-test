package dev.custom.bedrockgui;

/** Read-only in-flight pearl feed; unknown collision/FOV evidence stays unknown. */
public final class PearlBridge {
    private static volatile boolean ready,enabled;
    private PearlBridge(){}
    private static native String install(long base,long client);
    private static native void enable(boolean value);
    private static native void pulse(boolean active);
    private static native String snapshot();
    private static native String status();
    public static synchronized void prepare(long base,long client){
        if(!AimbotBridge.isReady())return;
        try{
            String error=install(base,client);
            if(error==null||!error.isEmpty())throw new IllegalStateException(error==null?"No native install result":error);
            ready=true;pulse(enabled);GameRuntime.log("Pearl Prediction: read-only projectile feed prepared");
        }catch(RuntimeException|LinkageError error){
            ready=false;enabled=false;GameRuntime.log("Pearl Prediction unavailable: "+error);
        }
    }
    public static boolean isReady(){return ready;}
    public static boolean isEnabled(){return enabled;}
    public static synchronized void setEnabled(boolean value){
        if(value&&!ready)throw new IllegalStateException("Нужен загруженный мир");
        if(ready){enable(value);pulse(value);}
        enabled=value;GameRuntime.log("Pearl Prediction: enabled="+value);
    }
    public static void heartbeat(){if(ready)pulse(enabled);}
    public static String predictionSnapshot(){
        if(!ready||!enabled)return "";
        try{String value=snapshot();return value==null?"":value;}
        catch(RuntimeException|LinkageError error){
            ready=false;enabled=false;GameRuntime.log("Pearl Prediction snapshot unavailable: "+error);return "";
        }
    }
    public static String describe(){
        if(!ready)return "Прогноз жемчуга ещё не подключён к миру";
        return (enabled?"Прогноз жемчуга включён":"Выключен")+"\n"+status();
    }
}
