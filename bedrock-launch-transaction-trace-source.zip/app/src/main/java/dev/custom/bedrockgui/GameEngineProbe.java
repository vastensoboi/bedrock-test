package dev.custom.bedrockgui;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Validates the exact game file, probes own memory, then prepares the optional native bridge. */
public final class GameEngineProbe {
    private static final String EXPECTED_SHA="4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4";
    private static final AtomicBoolean running=new AtomicBoolean();
    private static String verifiedFile;
    private static volatile boolean playerFound;
    private static volatile long lastBase,lastClient,lastPlayer;
    private static volatile AuctionMemoryProbe.TapToken refreshToken;
    private static volatile int auctionSlots;
    private static volatile AuctionMemoryProbe auctionProbe;
    private static volatile AutoBuyCycle.Snapshot auctionState;
    public static AutoBuyCycle.Snapshot auctionState(){return auctionState;}
    public static AuctionMemoryProbe.ActionToken actionToken(AutoBuyCycle.Snapshot state,int slot){
        AuctionMemoryProbe p=auctionProbe;return p==null?null:p.actionToken(state,slot);
    }
    public static boolean hasAuctionWindow(int slots){return auctionSlots==slots;}
    public static boolean tapReady(int slots){return slots==54&&refreshToken!=null;}
    public static final class TapSession implements AutoCloseable {
        private final RandomAccessFile memory;private final AuctionMemoryProbe probe;private final AuctionMemoryProbe.TapToken token;
        private boolean closed;private String failure="";private AuctionMemoryProbe.ActionToken action;
        public String failure(){return failure;}
        private TapSession(AuctionMemoryProbe.TapToken token,long base)throws IOException {
            List<EngineMemoryProbe.Region> regions=new ArrayList<>();
            for(String line:Files.readAllLines(Paths.get("/proc/self/maps")))regions.add(EngineMemoryProbe.Region.parse(line));
            memory=new RandomAccessFile("/proc/self/mem","r");this.token=token;
            EngineMemoryProbe.Reader reader=(address,destination,count)->{memory.seek(address);memory.readFully(destination,0,count);return true;};
            probe=new AuctionMemoryProbe(regions,reader,base,GameRuntime::log);
        }
        public boolean validate(){
            if(closed)return false;
            try{return action==null?probe.validateTap(token):probe.validateAction(action,true);}
            catch(IOException|RuntimeException error){failure=error.getClass().getSimpleName();return false;}
        }
        public int destinationSlot(){return token.destinationSlot();}
        public boolean validateDuringDrag(){
            if(closed)return false;
            try{return action==null?probe.validateDragWindow(token):probe.validateAction(action,false);}catch(IOException|RuntimeException error){failure=error.getClass().getSimpleName();return false;}
        }
        public void close(){if(!closed){closed=true;try{memory.close();}catch(IOException ignored){}}}
    }
    public static TapSession openTapSession()throws IOException {
        AuctionMemoryProbe.TapToken token=refreshToken;
        if(token==null)throw new IOException("Не найдены кнопка обновления или свободная ячейка. Открой аукцион и освободи место в инвентаре");
        return new TapSession(token,lastBase);
    }
    public static TapSession openActionSession(AuctionMemoryProbe.ActionToken token)throws IOException {
        if(token==null)throw new IOException("Лот или окно изменились");
        TapSession session=new TapSession(token.window,lastBase);session.action=token;return session;
    }
    public static boolean playerFound(){return playerFound;}
    public static String auctionSnapshot(){return auctionSnapshot(true);}
    public static String auctionSnapshot(boolean verbose){
        refreshToken=null;auctionSlots=0;auctionState=null;auctionProbe=null;
        if(!playerFound||lastBase==0||lastPlayer==0)return "Сначала войди в мир сервера и открой аукцион.";
        try {
            List<EngineMemoryProbe.Region> regions=new ArrayList<>();
            for(String line:Files.readAllLines(Paths.get("/proc/self/maps")))regions.add(EngineMemoryProbe.Region.parse(line));
            try(RandomAccessFile memory=new RandomAccessFile("/proc/self/mem","r")){
                EngineMemoryProbe.Reader reader=(address,destination,count)->{memory.seek(address);memory.readFully(destination,0,count);return true;};
                AuctionMemoryProbe probe=new AuctionMemoryProbe(regions,reader,lastBase,verbose?GameRuntime::log:value->{},verbose);
                String result=probe.scan(lastPlayer,lastClient);
                refreshToken=probe.token(54);auctionSlots=probe.windowSlots();auctionState=probe.snapshot();auctionProbe=probe;
                if(verbose)GameRuntime.log("Auto Buy snapshot: "+result);return result;
            }
        }catch(IOException|RuntimeException error){GameRuntime.log("Auto Buy snapshot failed: "+error);return "Не удалось считать контейнер. Причина записана в журнал.";}
    }
    public static String startTransactionTrace(){
        if(!playerFound||lastBase==0)throw new IllegalStateException("Сначала открой аукцион в загруженном мире");
        return TransactionTrace.start(lastBase);
    }
    private GameEngineProbe(){}
    public static boolean begin(){return running.compareAndSet(false,true);}
    public static void end(){running.set(false);}
    public static String run() {
        playerFound=false;
        GameRuntime.log("Engine probe: begin; inspect binding before native bridge preparation");
        try {
            if(GameRuntime.nativeDirectory==null)throw new IOException("Game library directory is unavailable");
            File library=new File(GameRuntime.nativeDirectory,"libminecraftpe.so");
            if(library.length()!=342231392L)throw new IOException("Unsupported Minecraft library size");
            if(!library.getAbsolutePath().equals(verifiedFile)){
                MessageDigest sha=MessageDigest.getInstance("SHA-256");
                try(InputStream input=new FileInputStream(library)){
                    byte[] buffer=new byte[128*1024];int count;
                    while((count=input.read(buffer))!=-1)sha.update(buffer,0,count);
                }
                StringBuilder value=new StringBuilder();for(byte b:sha.digest())value.append(String.format(Locale.ROOT,"%02x",b&255));
                if(!EXPECTED_SHA.equals(value.toString()))throw new IOException("Unsupported Minecraft library SHA-256");
                verifiedFile=library.getAbsolutePath();
            }
            GameRuntime.log("Engine probe: exact library SHA-256 verified");
            List<EngineMemoryProbe.Region> regions=new ArrayList<>();
            long base=-1;File canonical=library.getCanonicalFile();
            for(String line:Files.readAllLines(Paths.get("/proc/self/maps"))){
                EngineMemoryProbe.Region region=EngineMemoryProbe.Region.parse(line);regions.add(region);
                if(region.offset==0&&region.path.endsWith("/libminecraftpe.so")&&
                        new File(region.path).getCanonicalFile().equals(canonical))base=region.start;
            }
            if(base<0)throw new IOException("Loaded game library mapping not found");
            GameRuntime.log("Engine probe: load base 0x"+Long.toHexString(base));
            try(RandomAccessFile memory=new RandomAccessFile("/proc/self/mem","r")){
                EngineMemoryProbe.Reader reader=(address,destination,count)->{
                    memory.seek(address);memory.readFully(destination,0,count);return true;
                };
                EngineMemoryProbe probe=new EngineMemoryProbe(regions,reader,base,
                        line->GameRuntime.log("Engine probe: "+line));
                EngineMemoryProbe.Result result=probe.scan(base+0x1400a010L,base+0x14308e60L);
                if(result.reads==0||result.reads==result.readFailures)
                    throw new IOException("Reading this process's game memory was unavailable");
                if(result.verifiedClient!=0)FastExpBridge.prepare(base,result.verifiedClient);
                lastBase=base;lastClient=result.verifiedClient;lastPlayer=result.verifiedPlayer;
                playerFound=result.verifiedPlayers>0&&result.verifiedPlayer!=0;
                String player=result.verifiedPlayers>0?"Игрок найден через реестр сущностей.":
                        "Игрок пока не найден. Повтори проверку в загруженном мире.";
                return player+"\n"+result.hand+
                        "\n"+(FastExpBridge.isReady()?"Мост Fast Exp подготовлен. Включение — переключателем модуля.":"Мост Fast Exp недоступен; причина в журнале.");
            }
        }catch(Exception error){
            GameRuntime.log("Engine probe failed: "+error);
            return "Проверка недоступна: "+error.getMessage()+". Результат записан в журнал.";
        }
    }
}
