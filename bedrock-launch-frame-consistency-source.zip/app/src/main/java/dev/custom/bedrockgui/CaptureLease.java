package dev.custom.bedrockgui;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.util.HashSet;
import java.util.Set;

/** Parent-loaded helper owns one kernel lock, released automatically on process death. */
final class CaptureLease implements AutoCloseable {
    private static final Set<String> held=new HashSet<>();
    private final RandomAccessFile file;
    private final FileLock lock;
    private final String path;
    private boolean closed;

    private CaptureLease(RandomAccessFile file,FileLock lock,String path) {
        this.file=file;this.lock=lock;this.path=path;
    }
    static synchronized CaptureLease acquire(File directory) throws IOException {
        // Never delete this file: replacing its inode would allow two owners.
        String path=new File(directory,"own-logcat.lock").getCanonicalPath();
        // POSIX locks belong to the process. Closing even a second descriptor
        // can release its existing lock, so reject local contention before open.
        if(held.contains(path))return null;
        RandomAccessFile file=new RandomAccessFile(path,"rw");
        try {
            FileLock lock;
            try { lock=file.getChannel().tryLock(); }
            catch (OverlappingFileLockException busy) { file.close();return null; }
            if(lock==null){file.close();return null;}
            held.add(path);return new CaptureLease(file,lock,path);
        } catch(IOException|RuntimeException error) {
            try{file.close();}catch(IOException ignored){}
            throw error;
        }
    }
    @Override public void close() throws IOException {
        synchronized(CaptureLease.class){
            if(closed)return;
            closed=true;
            try{try{lock.release();}finally{file.close();}}
            finally{held.remove(path);}
        }
    }
}
