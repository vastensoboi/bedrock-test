# Startup class-loader correction in 0.74

The supplied `bedrock-crash-capture-0.73.txt` records a Java crash in the
hosted game process about one second after launch. At 23:53:35.712 Android
reports `NoClassDefFoundError: Failed resolution of:
Lcom/mojang/minecraftpe/MainActivity;`, with `HostedGameActivity.<init>:13`
at the top of the saved stack. The underlying `ClassNotFoundException`
searches only the launcher APK, not the game APK.

Line 13 initializes `captureRecovery=this::recoverCapture`, added in 0.73.
The hosted Activity itself is loaded through the game loader and inherits
the real Minecraft Activity. Android's D8-generated method-reference holder
also needs that Activity type. The old exact-name routing selected the
Activity and NativeStartup classes, but delegated their generated or nested
companions to the parent loader. That parent deliberately cannot load the
compile-only Minecraft superclass from the launcher APK. The saved stack
identifies this constructor dependency; it does not by itself establish
which scheduled callback first triggered the failed resolution.

## Correction

Keep the existing child-first game-package rule and include the two narrow
host class families: `HostedGameActivity$...` and `NativeStartup$...` as well
as their owner classes. This includes D8 `$$ExternalSyntheticLambda...`
names and anonymous/nested companions. `GameClassPolicy` supplies the rule
used by the existing game DexClassLoader.

Keep shared runtime and capture helpers parent-loaded, including GameRuntime,
OwnLogCapture, OwnLogRecorder and CaptureLease. Their state and process-local
file-lock ownership must not be duplicated. Classes with a similar prefix
but without the `$` family boundary retain the normal parent-first route.
The real game superclass remains absent from the launcher APK; the existing
APK packaging check is preserved. No game/native movement code changes.

## Validation

`GameClassPolicyTest` creates separate real JVM class directories and loaders.
The parent contains the hosted Activity and a D8-shaped generated Runnable
with a typed Activity receiver, but not its game superclass. The child also
has access to the separately compiled game superclass. The old exact-name
rule reproduces a linkage failure; the corrected family rule instantiates
the Activity and runs its callback. It also exercises a nested NativeStartup
helper and verifies that a shared capture helper keeps its parent identity.

All 41 host suites and full Android35/Rhino Java17 typechecking pass. Native
files remain unchanged from 0.72. These checks model the verified loader
boundary, but do not replace APK/ART testing on the phone. The workspace has
no Android SDK/NDK APK build available.
