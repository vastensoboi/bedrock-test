package dev.custom.bedrockgui;

/** The native bridge calls the native client air-use wrapper only from the game's own LocalPlayer update. */
public final class FastExpBridge {
    private static volatile boolean loaded,ready,enabled,foreground;
    private static volatile int interval=3;
    private FastExpBridge(){}
    private static native String install(long base,long client);
    private static native void enable(boolean value);
    private static native void pulse(boolean active);
    private static native void configure(int ticks);
    private static native String status();
    public static synchronized void prepare(long base,long client) {
        try {
            if(!loaded){System.loadLibrary("kulichbridge");loaded=true;}
            String error=install(base,client);
            if(!error.isEmpty())throw new IllegalStateException(error);
            configure(interval);ready=true;GameRuntime.log("Fast Exp: native LocalPlayer update bridge installed; disabled by default");
        }catch(RuntimeException|LinkageError error){GameRuntime.log("Fast Exp bridge unavailable: "+error);}
    }
    public static boolean isReady(){return ready;}
    public static boolean isEnabled(){return enabled;}
    public static void setEnabled(boolean value){
        if(value&&!ready)throw new IllegalStateException("Native bridge is not prepared");
        if(loaded)enable(value);
        enabled=value;GameRuntime.log("Fast Exp: requested enabled="+value);
        if(ready)GameRuntime.log(describe());
    }
    public static void foreground(boolean value){
        foreground=value;
        if(!value&&loaded)setEnabled(false);
    }
    public static void heartbeat(boolean menuClosed){if(ready)pulse(enabled&&foreground&&menuClosed);}
    public static int tickInterval(){return interval;}
    public static void setTickInterval(int value){
        interval=Math.max(1,Math.min(10,value));if(ready)configure(interval);
    }
    public static String describe(){
        if(!ready)return "Мост Fast Exp не подготовлен. Сначала проверь подключение.";
        String raw=status();String explanation;
        if(raw.contains("entered=0 "))explanation="Обновления LocalPlayer ещё не перехвачены. Нужен журнал после теста с закрытым kulich.";
        else if(raw.contains("ticks=0 "))explanation="Вход в обновление игрока есть, но возврат ещё не зарегистрирован. Нужен журнал.";
        else if(raw.contains("inFlight=1 "))explanation="Вызов использования ещё не завершился. Нужен журнал запуска.";
        else if(raw.contains("localTicks=0 "))explanation="Обновления получены, но привязка к локальному игроку ещё не сработала. Нужен журнал.";
        else if(raw.contains("reason=0"))explanation=raw.contains("clientUse calls=0 ")?
                "Вызов использования ещё не выполнен. Закрой kulich и проверь повторно через 5 секунд.":
                "Есть клиентские вызовы использования. Фактический бросок проверяем в мире.";
        else {
            String[] reasons={"","Неизвестный тип GameMode","Не совпал метод использования",
                "Не совпала связь GameMode — игрок — клиент","Не найден PlayerInventory",
                "Выбранный слот вне диапазона","Инвентарь временно заблокирован",
                "Не найден контейнер Inventory","Некорректные границы массива предметов",
                "Не совпал тип ItemStack","Выбранный слот пуст","В руке не пузырьки опыта или предмет недоступен",
                "Предмет или слот изменился во время проверки",
                "Нужно повторное обновление игрока; одиночного события недостаточно для запуска"};
            explanation="Проверка отклонила действие. Нужен журнал.";
            for(int i=1;i<reasons.length;i++)if(raw.endsWith("reason="+i)){explanation=reasons[i]+".";break;}
        }
        return explanation+"\n"+raw;
    }
}
