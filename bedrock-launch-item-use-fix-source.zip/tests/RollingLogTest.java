import dev.custom.bedrockgui.RollingLog;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.nio.charset.StandardCharsets;

public final class RollingLogTest {
    static void check(boolean condition) { if (!condition) throw new AssertionError(); }
    public static void main(String[] args) throws Exception {
        Path directory = Files.createTempDirectory("rolling-log-test");
        try {
            RollingLog log = new RollingLog(directory.toFile(), 64);
            log.reset();
            check(log.tail(100).length == 0);
            ByteArrayOutputStream reference = new ByteArrayOutputStream();
            Random random = new Random(72);
            for (int step = 0; step < 80; step++) {
                byte[] chunk = new byte[1 + random.nextInt(64)];random.nextBytes(chunk);
                log.append(chunk, chunk.length);reference.write(chunk);
                long retained = 0;
                for (String name : new String[]{"own-logcat.txt", "own-logcat.previous.txt"}) {
                    File file = directory.resolve(name).toFile();
                    check(file.length() <= 64);retained += file.length();
                }
                check(retained <= 128);
                byte[] all = reference.toByteArray();
                for (int maximum : new int[]{0, 1, 17, 64, 1000}) {
                    int count = (int)Math.min(retained, maximum);
                    check(Arrays.equals(log.tail(maximum), Arrays.copyOfRange(all, all.length-count, all.length)));
                }
            }
            byte[] fatal = "JNI DETECTED ERROR: test crash".getBytes(StandardCharsets.UTF_8);
            log.append(fatal, fatal.length);
            check(new String(log.tail(fatal.length),StandardCharsets.UTF_8).equals("JNI DETECTED ERROR: test crash"));
            // A new reader instance must see both retained files without clearing them.
            check(Arrays.equals(log.tail(90),new RollingLog(directory.toFile(),64).tail(90)));
            log.reset();check(log.tail(100).length == 0);
            check(!Files.exists(directory.resolve("own-logcat.previous.txt")));
            boolean rejected=false;
            try {log.append(new byte[65],65);}catch(IllegalArgumentException expected){rejected=true;}
            check(rejected);
            System.out.println("PASS: bounded rotation, cross-file tails, latest crash retention, independent readers and reset.");
        } finally {
            Files.deleteIfExists(directory.resolve("own-logcat.txt"));
            Files.deleteIfExists(directory.resolve("own-logcat.previous.txt"));
            Files.deleteIfExists(directory);
        }
    }
}
