package dev.custom.bedrockgui;

/** UI-thread startup request: wait for a verified world, never re-enable after success/cancel. */
public final class FastExpStart {
    private boolean requested,busy;private long next;
    public FastExpStart(boolean requested,long now){this.requested=requested;next=now+5000;}
    public boolean due(long now,boolean alive){return requested&&!busy&&alive&&now>=next;}
    public void begin(){busy=true;}
    public boolean result(long now,boolean worldReady,boolean alive){
        busy=false;
        if(!requested)return false;
        if(worldReady&&alive){requested=false;return true;}
        next=now+8000;return false;
    }
    public void cancel(){requested=false;}
}
