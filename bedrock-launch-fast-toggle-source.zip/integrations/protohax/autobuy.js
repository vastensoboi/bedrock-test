import { defineModule } from "@protohax/userscript";

// ================= СПИСОК ПОКУПОК =================
// name   - часть названия предмета (маленькими буквами; "" = без проверки названия)
// kind   - необязательно: "armor" или "sword"
// need   - ВСЕ эти зачарования обязательны: ["название", мин.уровень]
// any    - список зачарований; нужно anyMin из них (по умолчанию 1)
// ratio  - покупать, если цена не выше ratio * рыночной
// cap    - абсолютный потолок цены за лот
// market - рыночная цена за 1 шт. (пока нет статистики с аукциона)
// label  - необязательно: как писать в чат
const LORD_ARMOR = {
  kind: "armor",
  need: [["защита", 5], ["броненосец", 1], ["поглощение", 1]],
  market: 500000, ratio: 0.5, cap: 250000,
};
const SWORD_CUSTOM = [
  ["вампиризм", 1], ["иссушение", 1], ["крит", 1],
  ["противоядие", 1], ["опытный", 1], ["отравление", 1],
];

const WANTED = [
  // --- сферы ---
  { name: "сфера полубога", market: 7000000, ratio: 0.43, cap: 3000000 },
  { name: "сфера виверны", market: 130000, ratio: 0.45, cap: 60000 },
  // --- талисманы и амулет ---
  { name: "талисман ориона",     market: 600000,   ratio: 0.5,  cap: 180000 },
  { name: "талисман фантома",    market: 2500000,  ratio: 0.45, cap: 1100000 },
  { name: "талисман властелина", market: 16000000, ratio: 0.45, cap: 7200000 },
  { name: "талисман карателя",   ratio: 0.5, cap: 300000 },
  { name: "амулет дуэли",        market: 4100000,  ratio: 0.45, cap: 1800000 },
{ name: "НЕРУШИМКА", market:1800000,  ratio: 0.5, cap: 1100000 },
  // --- меч ---
  { name: "меч властелина", kind: "sword", need: [["острота", 7]], any: SWORD_CUSTOM, anyMin: 2,
    market: 780000, ratio: 0.5, cap: 390000 },
  // --- броня Властелина (баффы одинаковые у всех частей) ---
  { ...LORD_ARMOR, name: "шлем властелина", market: 580000, ratio: 0.45, cap:
290000 },
  { ...LORD_ARMOR, name: "нагрудник властелина", market: 580000, ratio: 0.45, cap: 290000 },
  { ...LORD_ARMOR, name: "поножи властелина", market: 580000,
ratio: 0.45, cap: 290000 },
  { ...LORD_ARMOR, name: "ботинки властелина", market: 580000, ratio: 0.45, cap: 290000 },
  // --- нерушимая броня (по зачарованиям) ---
  { name: "", label: "нерушимая броня", kind: "armor",
    need: [["защита", 5], ["нерушимость", 1], ["броненосец", 1], ["поглощение", 1]],
    market: 2000000, ratio: 0.5, cap: 1000000 },
  // --- кастомные зелья ---
  { name: "battlepass", market: 7000000, ratio: 0.43, cap: 3000000 },
  { name: "сила iii",   market: 1000000, ratio: 0.45, cap: 450000 },
  { name: "черепашка",  market: 500000,  ratio: 0.45, cap: 225000 },
];

// НИКОГДА не покупать (часть названия, маленькими буквами)
const BLOCKED = ["цербер", "сфинкс", "кронос", "илиад", "артемид"];
// ===================================================

const KINDS = { armor: ["helmet", "chestplate", "leggings", "boots"], sword: ["sword"] };
const ROMAN = { i: 1, v: 5, x: 10, l: 50, c: 100 };
// ванильные чары: название на сервере -> номер чара в предмете
const VANILLA = {
  "защита": 0, "огнеупорность": 1, "невесомость": 2, "взрывоустойчивость": 3, "защита от снарядов": 4,
  "шипы": 5, "дыхание": 6, "странник глубин": 7, "родство с водой": 8, "острота": 9,
  "небесная кара": 10, "бич членистоногих": 11, "отбрасывание": 12, "облик огня": 13,
  "добыча": 14, "неразрушимость": 17, "починка": 26,
};

defineModule(
  { name: "AutoBuy", defaultState: false },
  {
    dryRun:      { type: "boolean", name: "Dry run (no buying)", def: true },
    diag:        { type: "boolean", name: "Diag (why sword/armor not bought)", def: true },
    learn:       { type: "boolean", name: "Study auction first", def: true },
    learnPages:  { type: "number", name: "Pages to study", def: 3, min: 1, max: 10, step: 1 },
    minSamples:  { type: "number", name: "Min lots to trust market", def: 3, min: 1, max: 20, step: 1 },
    refreshMin:  { type: "number", name: "Refresh min (sec)", def: 0.7, min: 0.3, max: 30, step: 0.1 },
    refreshMax:  { type: "number", name: "Refresh max (sec)", def: 1.2, min: 0.3, max: 30, step: 0.1 },
    verifyPrice: { type: "boolean", name: "Check price/seller in purchase window", def: true },
    previewSlot: { type: "number", name: "Item slot in purchase window", def: 13, min: 0, max: 26, step: 1 },
    buySlot:     { type: "number", name: "Green glass slot (fallback)", def: 10, min: 0, max: 26, step: 1 },
    cancelSlot:  { type: "number", name: "Red 'Back' slot", def: 16, min: 0, max: 26, step: 1 },
    inspect:     { type: "boolean", name: "Inspect (show names/enchants)", def: false },
  },
  (ctx) => {
    const samples = WANTED.map(() => []);
    const seenLots = new Set(), tried = new Set(), announced = new Set(), shownNames = new Set(), diagSeen = new Set();
    let tick = 0, reqId = -1, state = "idle", stateTick = 0, pending = null, spent = 0, said = 0, diagN = 0, diagDump = 0;
    let nextRefresh = 0, scanBlock = 0, learnStarted = false, lastLearn = 0, page = 0, dir = 1;

    const say = (m) => {
      try { ctx.session.connection.sendIncomingPacket("text", { type: "raw", message: "[AutoBuy] " + m }); } catch (_) {}
    };
    const js = (v) => { try { return JSON.stringify(v, (k, x) => typeof x === "bigint" ? String(x) : x); } catch (_) { return ""; } };
    const strip = (s) => String(s).replace(/§./g, "");
    const lc = (s) => String(s || "").toLowerCase();
    const lbl = (e) => e.label || e.name;
    const q25 = (a) => { const s = a.slice().sort((x, y) => x - y); return s[Math.floor(s.length * 0.25)]; };

    // уровень чара в тексте: 0 = нет, иначе уровень (без цифры = 1)
    const rom = (s) => { let r = 0; for (let i = 0; i < s.length; i++) { const a = ROMAN[s[i]], b = ROMAN[s[i + 1]] || 0; r += a < b ? -a : a; } return r; };
    const enchLevel = (t, name) => {
      const n = lc(name); let best = 0, found = false, from = 0;
      for (;;) {
        const i = t.indexOf(n, from); if (i < 0) break;
        found = true; from = i + n.length;
        const m = t.slice(from, from + 12).match(/^[\s:]*([ivxlc]{1,4}|\d{1,2})(?![a-zа-яё])/);
        if (m) { const v = /^\d/.test(m[1]) ? Number(m[1]) : rom(m[1]); if (v > best) best = v; }
      }
      return found ? Math.max(best, 1) : 0;
    };

    // ванильные чары из данных предмета (nbt): { номер: уровень }
    const unwrap = (x) => { while (x && typeof x === "object" && !Array.isArray(x) && "value" in x && "type" in x) x = x.value; return x; };
    const collectEnch = (node, out, depth) => {
      if (depth > 8 || node == null) return;
      node = unwrap(node);
      if (Array.isArray(node)) { node.forEach((x) => collectEnch(x, out, depth + 1)); return; }
      if (typeof node !== "object") return;
      const id = unwrap(node.id), lv = unwrap(node.lvl);
      if (id !== undefined && lv !== undefined && !isNaN(Number(id)) && !isNaN(Number(lv))) {
        out[Number(id)] = Math.max(out[Number(id)] || 0, Number(lv));
      }
      for (const k in node) collectEnch(node[k], out, depth + 1);
    };
    const levelOf = (text, ench, name) => {
      let v = enchLevel(text, name);
      const id = VANILLA[lc(name)];
      if (id !== undefined && ench && ench[id]) v = Math.max(v, ench[id]);
      return v;
    };

    const parse = (slot) => {
      if (!slot || !slot.definition) return null;
      const text = strip(js(slot));
      const m = text.match(/Цена:[^\d]{0,12}([\d][\d,. ]*)\$/);
      if (!m) return null;
      const price = Number(m[1].replace(/\D/g, ""));
      if (!Number.isSafeInteger(price) || price <= 0) return null;
      const amount = slot.amount;
      if (!Number.isSafeInteger(amount) || amount <= 0) return null;
      const def = slot.definition.name;
      const dm = text.match(/"Name":"([^"]{2,60})"/);
      const sm = text.match(/Игрок:[^A-Za-z0-9_]{0,12}([A-Za-z0-9_]{3,20})/);
      const seller = sm ? sm[1] : "?";
      const ench = {}; try { collectEnch(slot.nbt, ench, 0); } catch (_) {}
      return { def, display: dm ? dm[1] : "", text: lc(text), nbt: slot.nbt, ench, price, amount, seller, unit: price / amount,
               key: def + "|" + (dm ? dm[1] : "") + "|" + price + "|" + amount + "|" + seller };
    };

    // null = лот подходит, иначе причина отказа
    const why = (it, e) => {
      if (BLOCKED.some((x) => it.text.includes(x))) return "blocked word";
      if (it.def.includes("book") || lc(it.display).includes("книг")) return "book";
      if (!it.text.includes(lc(e.name))) return "name '" + e.name + "' not in text";
      if (e.kind && !KINDS[e.kind].some((k) => it.def.includes(k))) return "kind " + it.def;
      for (const [n, l] of (e.need || [])) {
        const have = levelOf(it.text, it.ench, n);
        if (have < (l || 1)) return "missing '" + n + "' " + (l || 1) + " (have " + have + ")";
      }
      const any = e.any || [];
      if (any.length) {
        const got = any.filter(([n, l]) => levelOf(it.text, it.ench, n) >= (l || 1)).length;
        if (got < (e.anyMin || 1)) return "custom enchants " + got + "/" + (e.anyMin || 1);
      }
      return null;
    };
    const qualityOk = (it, e) => why(it, e) === null;

    // разбор лота с запоминанием (ks = номера подходящих записей списка)
    const parseC = (slot) => {
      if (!slot || typeof slot !== "object") return null;
      const r = parse(slot);
      if (r) { r.ks = []; for (let k = 0; k < WANTED.length; k++) if (qualityOk(r, WANTED[k])) r.ks.push(k); }
      return r;
    };

    const marketOf = (idx) => {
      const l = samples[idx];
      if (l.length >= ctx.options.minSamples.value) return q25(l);
      return WANTED[idx].market || null;
    };

    const click = (c, i) => {
      if (ctx.options.dryRun.value) return;
      const it = Array.from(c.content)[i];
      const id = reqId; reqId -= 2;
      ctx.session.connection.sendOutgoingPacket("item_stack_request", {
        requests: [{
          request_id: id,
          actions: [{
            type_id: "take",
            count: it && it.amount ? it.amount : 1,
            source: { slot_type: { container_id: "level_entity" }, slot: i, stack_id: it && it.stackId !== undefined ? it.stackId : 0 },
            destination: { slot_type: { container_id: "cursor" }, slot: 0, stack_id: 0 },
          }],
          custom_names: [],
          cause: -1,
        }],
      });
    };

    const findGreen = (arr) => {
      for (let i = 0; i < arr.length; i++) {
        const d = arr[i] && arr[i].definition ? lc(arr[i].definition.name) : "";
        if (d.includes("glass") && (d.includes("lime") || d.includes("green"))) return i;
      }
      return ctx.options.buySlot.value;
    };

    const rnd = () => {
      const a = ctx.options.refreshMin.value, b = Math.max(a, ctx.options.refreshMax.value);
      return Math.max(3, Math.round((a + Math.random() * (b - a)) * 20));
    };
    const chunks = (label, s) => { for (let i = 0; i < 300 && i < s.length && said < 60; i += 75) { said++; say(label + s.slice(i, i + 75)); } };

    // диагностика: почему меч/броня Властелина не куплены
    const diag = (arr) => {
      if (!ctx.options.diag.value) return;
      for (let i = 0; i < arr.length && diagN < 15; i++) {
        const it = parseC(arr[i]);
        if (!it || diagSeen.has(it.key)) continue;
        const kinds = Object.keys(KINDS).filter((kd) => KINDS[kd].some((x) => it.def.includes(x)));
        if (!kinds.length || !it.text.includes("властелин")) continue;
        diagSeen.add(it.key);
        const cands = WANTED.filter((e) => e.kind && kinds.includes(e.kind) && e.name && it.text.includes(lc(e.name)));
        if (!cands.length) { diagN++; say("DIAG " + it.def.replace("minecraft:", "") + " " + it.display + ": no list entry matches the name"); continue; }
        const e = cands[0], k = WANTED.indexOf(e), r = why(it, e);
        let msg;
        if (r) msg = "rejected: " + r;
        else {
          const m = marketOf(k);
          if (!m) msg = "no market price";
          else {
            const lim = Math.min(e.cap || 1e12, m * it.amount * (e.ratio || 0.5));
            msg = it.price > lim ? "price " + it.price + " > limit " + Math.round(lim) + " (market " + Math.round(m) + ")"
                                 : "OK, would buy (" + it.price + " <= " + Math.round(lim) + ")";
          }
        }
        diagN++; say("DIAG " + lbl(e) + " " + it.price + "$: " + msg);
        if (r && diagDump < 2) {
          diagDump++;
          const d = strip(js(it.nbt));
          for (let j = 0; j < 225 && j < d.length; j += 75) say("nbt: " + d.slice(j, j + 75));
        }
      }
    };

    // запоминаем цены подходящих лотов (только из списка)
    const record = (arr) => {
      for (let i = 0; i < arr.length; i++) {
        const it = parseC(arr[i]);
        if (!it) continue;
        if (ctx.options.inspect.value) {
          const nm = it.display || it.def;
          if (shownNames.size < 25 && !shownNames.has(nm)) { shownNames.add(nm); say("item: " + nm.replace("minecraft:", "")); }
        }
        if (seenLots.has(it.key)) continue;
        seenLots.add(it.key);
        for (const k of it.ks) {
          samples[k].push(it.unit);
          if (samples[k].length > 200) samples[k].shift();
          if (ctx.options.inspect.value && samples[k].length === 1) {
            say("lot " + lbl(WANTED[k]) + ": " + it.price + "$");
            chunks("data: ", it.text);
          }
        }
      }
    };

    const report = () => {
      for (let k = 0; k < WANTED.length; k++) {
        const m = marketOf(k), e = WANTED[k];
        if (m) say("MARKET " + lbl(e) + " = " + Math.round(m) + " (лотов " + samples[k].length + "), куплю до " +
                   Math.round(Math.min(e.cap || 1e12, m * (e.ratio || 0.5))));
        else say("MARKET " + lbl(e) + " - нет данных, не покупаю");
      }
    };

    ctx.onEnable(() => {
      tick = 0; state = ctx.options.learn.value && !ctx.options.dryRun.value ? "learn" : "idle"; pending = null; spent = 0; said = 0;
      nextRefresh = 40; scanBlock = 0; learnStarted = false; page = 0; dir = 1;
      diagN = 0; diagDump = 0; diagSeen.clear();
      seenLots.clear(); tried.clear(); announced.clear(); shownNames.clear();
      samples.forEach((a) => { a.length = 0; });
      say("ready, items=" + WANTED.length + ", dryRun=" + ctx.options.dryRun.value + (state === "learn" ? ", open the auction: studying" : ""));
    });

    ctx.on("movement_tick", () => {
      try {
        tick++;
        const c = ctx.session.itemState && ctx.session.itemState.openContainer;
        if (!c || !c.content) return;
        const len = c.content.length;

        // ===== стадия 2: окно "Покупка" =====
        // кастомных чаров в этом окне нет, они проверены по лоту на стадии 1.
        // здесь сверяем то, что видно: тип, количество, цену и продавца.
        if (state === "wait_confirm") {
          if (len === 27) {
            const arr = Array.from(c.content);
            const pv = arr[ctx.options.previewSlot.value];
            if (!pv || !pv.definition) {
              if (tick - stateTick > 40) { click(c, ctx.options.cancelSlot.value); say("preview not loaded, went back"); state = "after"; stateTick = tick; }
              return;
            }
            const pt = strip(js(pv));
            let ok = pv.definition.name === pending.def && (pv.amount || 1) === pending.amount;
            let why2 = ok ? "" : "type/amount differ (" + pv.definition.name + " x" + (pv.amount || 1) +
                                 " vs " + pending.def + " x" + pending.amount + ")";
            if (ok && ctx.options.verifyPrice.value) {
              const pm = pt.match(/Цена:[^\d]{0,12}([\d][\d,. ]*)\$/);
              const sm = pt.match(/Игрок:[^A-Za-z0-9_]{0,12}([A-Za-z0-9_]{3,20})/);
              if (!pm || Number(pm[1].replace(/\D/g, "")) !== pending.price) { ok = false; why2 = "price in window " + (pm ? pm[1] : "missing") + " != " + pending.price; }
              else if (pending.seller === "?" || !sm || sm[1] !== pending.seller) { ok = false; why2 = "seller in window " + (sm ? sm[1] : "missing") + " != " + pending.seller; }
            }
            if (ok) {
              click(c, findGreen(arr));
              spent += pending.price; // Submitted amount; server purchase success is not yet confirmed.
              say("BUY REQUEST " + lbl(pending.entry) + " x" + pending.amount + " = " + pending.price + "$ (всего " + spent +
                  "$, окно открылось за " + (tick - pending.clickTick) * 50 + " мс)");
            } else {
              click(c, ctx.options.cancelSlot.value);
              say("CANCEL: " + why2);
            }
            state = "after"; stateTick = tick;
          } else if (tick - stateTick > 40) {
            say("purchase window timeout"); state = "idle";
          }
          return;
        }
        if (state === "after") {
          if ((len === 54 && tick - stateTick > 3) || tick - stateTick > 60) {
            state = "idle"; scanBlock = tick + 2; nextRefresh = tick + rnd();
          }
          return;
        }

        if (len !== 54) return;
        const arr = Array.from(c.content);
        if (tick % 4 === 0) { record(arr); diag(arr); }

        // ===== изучение аукциона =====
        if (state === "learn") {
          if (!learnStarted) { learnStarted = true; lastLearn = tick; return; }
          if (tick - lastLearn < 28) return;
          lastLearn = tick;
          const pages = ctx.options.learnPages.value;
          if (dir > 0) { if (page < pages - 1) { click(c, 50); page++; } else dir = -1; }
          else if (page > 0) { click(c, 48); page--; }
          else { state = "idle"; report(); nextRefresh = tick + rnd(); scanBlock = tick + 6; }
          return;
        }

        // ===== стадия 1: поиск и тык (каждый тик) =====
        if (tick < scanBlock) return;
        let best = null, bestProfit = -1;
        for (let i = 0; i < arr.length; i++) {
          const it = parseC(arr[i]);
          if (!it || !it.ks.length || tried.has(it.key)) continue;
          for (const k of it.ks) {
            const e = WANTED[k];
            const m = marketOf(k);
            if (!m) continue;
            const limit = Math.min(e.cap || 1e12, m * it.amount * (e.ratio || 0.5));
            if (it.price > limit) continue;
            const profit = m * it.amount - it.price;
            if (profit > bestProfit) { bestProfit = profit; best = Object.assign({ i, entry: e, market: m }, it); }
            break;
          }
        }
        if (best) {
          if (!announced.has(best.key)) {
            announced.add(best.key);
            say("FOUND " + lbl(best.entry) + " x" + best.amount + " = " + best.price + "$ (рынок " + Math.round(best.market) + "/шт)");
          }
          if (!ctx.options.dryRun.value) {
            const again = parse(arr[best.i]); // свежий разбор прямо перед кликом
            if (again && again.key === best.key) {
              tried.add(best.key);
              click(c, best.i);
              pending = Object.assign({}, best, { clickTick: tick });
              state = "wait_confirm"; stateTick = tick;
              return;
            }
          }
        }

        // быстрое обновление
        if (tick >= nextRefresh) {
          click(c, 49);
          nextRefresh = tick + rnd();
          scanBlock = tick + 3;
        }
      } catch (err) {
        if (tick % 40 === 0) say("ERR " + String(err && err.message).slice(0, 70));
      }
    });
  }
);
