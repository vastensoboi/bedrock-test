package dev.custom.bedrockgui;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class NbtDisplayReaderTest {
    static final long BASE=0x10000000;static byte[] memory=new byte[20000];
    static void q(int at,long v){ByteBuffer.wrap(memory).order(ByteOrder.LITTLE_ENDIAN).putLong(at,v);}
    static void integer(int at,int v){ByteBuffer.wrap(memory).order(ByteOrder.LITTLE_ENDIAN).putInt(at,v);}
    static void str(int at,String s,int heap){
        byte[] bytes=s.getBytes(StandardCharsets.UTF_8);
        if(bytes.length<=22){memory[at]=(byte)(bytes.length*2);System.arraycopy(bytes,0,memory,at+1,bytes.length);}
        else{memory[at]=1;q(at+8,bytes.length);q(at+16,heap);System.arraycopy(bytes,0,memory,heap,bytes.length);}
    }
    static void check(boolean v){if(!v)throw new AssertionError();}
    public static void main(String[] args)throws Exception {
        q(1000,BASE+0x13ebe0b0L);q(1016,2000);
        str(2032,"display",0);q(2056,BASE+0x13ebe0b0L);q(2072,3000);integer(2096,10);
        str(3032,"Name",0);q(3056,BASE+0x13ebe5f8L);integer(3096,8);str(3064,"§6Талисман ориона",8000);q(3008,4000);
        str(4032,"Lore",0);q(4056,BASE+0x13ebe350L);integer(4096,9);q(4064,5000);q(4072,5016);q(4080,5016);
        q(5000,6000);q(5008,6100);q(6000,BASE+0x13ebe5f8L);q(6100,BASE+0x13ebe5f8L);
        str(6008,"Цена: 12000$",0);str(6108,"Игрок: Seller",0);
        // Actual standard ench: List<CompoundTag{id: ShortTag, lvl: ShortTag}>.
        q(2008,9000);str(9032,"ench",0);q(9056,BASE+0x13ebe350L);integer(9096,9);
        q(9064,10000);q(9072,10008);q(9080,10008);q(10000,11000);
        q(11000,BASE+0x13ebe0b0L);q(11016,12000);
        str(12032,"id",0);q(12056,BASE+0x13ebe588L);memory[12064]=9;integer(12096,2);q(12008,13000);
        str(13032,"lvl",0);q(13056,BASE+0x13ebe588L);memory[13064]=7;integer(13096,2);
        NbtDisplayReader.Reader reader=(addr,size)->addr<=0||addr+size>memory.length?null:Arrays.copyOfRange(memory,(int)addr,(int)addr+size);
        NbtDisplayReader parser=new NbtDisplayReader(reader,BASE);byte[] before=memory.clone();
        NbtDisplayReader.Display display=parser.read(1000);
        check(display!=null&&display.name.equals("§6Талисман ориона")&&display.lore.size()==2&&display.lore.get(0).equals("Цена: 12000$"));
        check(display.ench.get(9)==7);
        check(Arrays.equals(before,memory));
        memory[13065]=1;check(parser.read(1000).ench.isEmpty());memory=before.clone();
        q(3056,0);q(4056,0);check(parser.read(1000)==null);memory=before.clone();
        q(3072,999999); // Long name length exceeds limit; lore can still be read.
        display=parser.read(1000);check(display!=null&&display.name.isEmpty()&&display.lore.size()==2);memory=before.clone();
        str(2032,"missing",0);q(2000,2000);q(2008,2000);check(parser.read(1000)==null);memory=before.clone();
        final int[] count={0};NbtDisplayReader.Reader moving=(addr,size)->{
            if(addr==1000&&size==32&&count[0]++==1)q(1016,9999);
            return reader.read(addr,size);
        };
        check(new NbtDisplayReader(moving,BASE).read(1000)==null);
        memory=before.clone();str(2032,"no_display",0);
        check(parser.read(1000)==null&&parser.readItem(1000)!=null&&parser.readItem(1000).ench.get(9)==7);
        System.out.println("PASS: typed display map, inline/long UTF-8 strings, lore vector, read-only behavior, type/size/cycle/concurrent-map rejection");
    }
}
