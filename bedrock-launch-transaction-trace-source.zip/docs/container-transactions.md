# Exact-build container transaction investigation

Game SHA-256: 4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4.
This document records verified disassembly, not a completed action sender.

## Confirmed

- ItemStackRequestPacket vptr 0x13b13840, getId slot 2 function 0xc644e78:
  mov w0,#147; ret. Response vptr 0x13b9cd18, getId 0xdba64b8 returns 148.
- Request packet ctor 0xc644df0, vector at +48/+56/+64. RequestData stride 72
  confirmed by destructor 0xc64b094 and conversion 0xc649818.
- RequestData action vector +16/+24/+32, cereal action-variant stride 104
  confirmed by conversion 0xc649818. The recorder copies raw first-row and
  first-action data; no claim of decoded stack IDs is made.
- Response payload vector +48, response record stride 48 from request-manager
  response application 0x1008fd20. A getId observation may happen before
  deserialization; it is never treated as an acceptance acknowledgement.
- ItemStackRequestActionTake vptr 0x13dafa08. Native constructor 0x10856f3c
  receives (this, count, sourceSlotInfo, destinationSlotInfo); allocation size 96
  confirmed by callers 0xd39bb48, 0x10134cbc and 0x10136f64.
- Source/destination SlotInfo: first 13 bytes copied, net-ID variant at +16.
  Action source slot byte +28, destination slot byte +68. These are native
  object layouts, not a declaration that a zero-filled structure is valid.
- ItemStack net-ID variant at +128, discriminator +144. Copy from +128 is
  visible in 0x1016e2b4..0x1016e2d0; prediction code 0x1008cc54 confirms +144.
- LocalPlayer +2592 owns ItemStackNetManagerClient vptr 0x13d21c98, 14 slots.
  Native player update calls its flush 0x1008f834 at 0xaf5ee5c.
- Scoped action owner helpers: ctor 0x10858744, dtor 0x10858794,
  add action 0x108587cc delegates to manager 0x1008fa6c. That manager validates
  the action and uses current request context +96 before consuming ownership.
  Calling it with an invented request context is not valid.

## Current implementation

libkulichtransactions installs pass-through hooks on only the two getId vtable
entries after verifying the exact original targets, two ARM64 instructions and
read-only game mappings. The forwarding function has the confirmed integer
return ABI. No packet is rewritten, created, replayed or sent. Recording is
explicit and bounded to a 16-sample ring; own-memory reads use pread, no direct
untrusted dereferences. Original targets remain available after publication.

## Required next evidence

A genuine manual refresh transfer on the target phone, with Auto Buy and
Fast Exp disabled, establishes actual request fields and response observations.
Capture request count, raw RequestData/action and correlation details before
building a live native action bridge. Do not guess container full-name dynamic
fields, variant alternatives, request context ownership, request IDs or cursor
state. Native construction and context lifetime must be verified before sending.
The current ProtoHax script's take-to-cursor operation is the intended semantic
reference, but its JavaScript packet API is not present in the launcher.
