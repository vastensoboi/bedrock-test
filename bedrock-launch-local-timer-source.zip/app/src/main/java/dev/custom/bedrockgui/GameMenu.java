package dev.custom.bedrockgui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Categorized in-window menu. Gameplay entries only enable when a real handler is registered. */
public final class GameMenu {
    public interface Toggle { void setEnabled(boolean enabled) throws Exception; }
    private static final String TARGET = "target", UTILITY = "utility", CUSTOM = "customization";
    private int INK,MUTED,ACCENT,PANEL,BUTTON,CATEGORY,SELECTED,LINE,ICON,WARNING;
    private int[] palette;private boolean lightTheme;
    private final Activity activity;
    private final SharedPreferences preferences;
    private final FrameLayout root;
    private final HudLayout hudLayout;
    private final HudDataPanels hudPanels;
    private final StaffListModel staffModel;
    private final BuffTimerModel buffModel=new BuffTimerModel();
    private final Map<String,String> hudTitles=new LinkedHashMap<>();
    private final Map<String,Button> shortcuts=new LinkedHashMap<>();
    private boolean hudPreparing;private long nextHudPrepare;
    private final Button floating,friendPick;private final TargetHud targetHud;
    private final View shade;
    private final LinearLayout panel, body, categories, moduleList, details;
    private final ScrollView moduleScroll, detailScroll;
    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final Drag iconDrag, panelDrag,friendDrag;
    private final Resize resize;
    private String category, selected;
    private boolean wide = true;
    private boolean resizing;
    private KulichScripts scripts;
    private final FastExpStart fastStart;
    private final AuctionTapInput auctionInput;
    private final AutoBuyController autoBuy;private TextView autoBuyStatus;
    private final NoSlowController noSlow;private TextView noSlowStatus;
    private final LocalTimerController localTimer;private TextView localTimerStatus;private int localTimerHundredths;
    private final BlockTrapController blockTrap;private TextView blockTrapStatus;private int blockTrapRangeTenths,blockTrapTicks;
    private final StaticItemsController staticItems;private TextView staticItemsStatus;
    private final PearlController pearl;private final PearlTrajectoryView pearlTrajectory;private TextView pearlStatus;
    private final AimbotController aimbot;private TextView aimbotStatus;private int aimRangeTenths,aimAttackTenths,aimCpsMin,aimCpsMax;
    private float widthRatio, heightRatio;
    private TextView friendsList,friendProtection;
    private boolean friendPicking,friendPreparing,disposed;
    private String friendPreview="",friendPressedPreview="";private boolean friendPressed;private long nextFriendPrepare;

    private static final class Entry {
        final String id, category;
        String title, description;
        Toggle callback;
        boolean enabled;
        Entry(String id, String category, String title, String description) {
            this.id = id;this.category = category;this.title = title;this.description = description;
        }
    }

    public GameMenu(Activity activity) {
        this.activity = activity;
        FriendStore.initialize(activity);
        fastStart=new FastExpStart(activity.getIntent()!=null&&activity.getIntent().getBooleanExtra("fastExpAuto",false),android.os.SystemClock.uptimeMillis());
        preferences = activity.getSharedPreferences("game-menu-ui", 0);
        setPalette("white".equals(preferences.getString("menu.theme","black")));
        FastExpBridge.setTickInterval(preferences.getInt("fast_exp_ticks",3));
        widthRatio = preferences.getFloat("panel.widthRatio", 0.86f);
        heightRatio = preferences.getFloat("panel.heightRatio", 0.86f);
        category = preferences.getString("category", UTILITY);
        if (!TARGET.equals(category) && !UTILITY.equals(category) && !CUSTOM.equals(category)) category = UTILITY;
        root = new FrameLayout(activity);
        pearlTrajectory=new PearlTrajectoryView(activity);pearlTrajectory.setEnabledPrediction(false);
        root.addView(pearlTrajectory,new FrameLayout.LayoutParams(-1,-1));
        hudLayout=new HudLayout(activity,root,preferences);hudPanels=new HudDataPanels(activity);
        staffModel=new StaffListModel(preferences.getString("hud.staff.names",""));
        targetHud=new TargetHud(activity);
        registerHud("target","Цель",targetHud.view(),236,100,.65f,.65f);
        registerHud("staff","Staff List",hudPanels.staffView(),220,126,.04f,.24f);
        registerHud("buffs","Buff Timer",hudPanels.buffsView(),240,140,.96f,.90f);
        registerHud("modules","Список функций",hudPanels.activeView(),180,120,.02f,.03f);

        shade = new View(activity);
        shade.setBackgroundColor(Color.argb(85, 0, 0, 0));shade.setClickable(true);
        shade.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        shade.setVisibility(View.GONE);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        panel = new LinearLayout(activity);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(background(PANEL, 18));panel.setElevation(dp(8));
        panel.setPadding(dp(12), dp(8), dp(12), dp(12));panel.setClickable(true);panel.setVisibility(View.GONE);
        LinearLayout header = new LinearLayout(activity);header.setGravity(Gravity.CENTER_VERTICAL);header.setClickable(true);
        LinearLayout brand = new LinearLayout(activity);brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = label("kulich", 23);title.setTypeface(Typeface.DEFAULT_BOLD);title.setTextColor(ACCENT);
        brand.addView(title);TextView hint = label("Перемещение — за заголовок", 11);hint.setTextColor(MUTED);brand.addView(hint);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        Button journal = button("Журнал");journal.setTextSize(13);
        header.addView(journal, new LinearLayout.LayoutParams(dp(86), dp(40)));
        journal.setOnClickListener(v -> {
            TransactionTrace.flush();GameRuntime.log("Menu: opening diagnostics from game");
            android.content.Intent intent = new android.content.Intent(activity, MainActivity.class)
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
                    .putExtra("showLaunchLog", true);
            try { activity.startActivity(intent); }
            catch (RuntimeException error) {
                GameRuntime.log("Menu: diagnostics unavailable: " + error.getClass().getSimpleName());
                Toast.makeText(activity, "Не удалось открыть журнал", Toast.LENGTH_LONG).show();
            }
        });
        panel.addView(header, new LinearLayout.LayoutParams(-1, dp(54)));
        body = new LinearLayout(activity);panel.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout footer = new LinearLayout(activity);footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView sizeHint = label("Размер окна", 12);sizeHint.setTextColor(MUTED);
        footer.addView(sizeHint, new LinearLayout.LayoutParams(0, -2, 1));
        TextView grip = label("◢", 27);grip.setGravity(Gravity.CENTER);grip.setTextColor(ACCENT);
        grip.setClickable(true);grip.setContentDescription("Изменить размер меню: потяни за угол");
        footer.addView(grip, new LinearLayout.LayoutParams(dp(48), -1));
        panel.addView(footer, new LinearLayout.LayoutParams(-1, dp(40)));
        categories = new LinearLayout(activity);
        moduleList = new LinearLayout(activity);moduleList.setOrientation(LinearLayout.VERTICAL);
        details = new LinearLayout(activity);details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(18), dp(12), dp(12), dp(12));
        moduleScroll = new ScrollView(activity);moduleScroll.setFillViewport(true);moduleScroll.addView(moduleList);
        detailScroll = new ScrollView(activity);detailScroll.setFillViewport(true);detailScroll.addView(details);
        root.addView(panel, new FrameLayout.LayoutParams(dp(740), dp(340)));
        panelDrag = new Drag(panel, "panel.", 0.5f, 0.5f, null);
        header.setOnTouchListener((v, event) -> resizing || panelDrag.touch(event));
        resize = new Resize();grip.setOnTouchListener((v, event) -> resize.touch(event));

        floating = button("kulich");floating.setTextSize(13);floating.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable circle = new GradientDrawable();circle.setShape(GradientDrawable.OVAL);
        circle.setColor(ICON);circle.setStroke(dp(2), ACCENT);floating.setBackground(circle);
        floating.setStateListAnimator(null);floating.setElevation(dp(16));
        floating.setContentDescription("kulich: нажми для меню или перетащи круглую иконку");
        root.addView(floating, new FrameLayout.LayoutParams(dp(68), dp(68)));
        floating.setOnClickListener(v -> toggle());
        iconDrag = new Drag(floating, "", 0.04f, 0.2f, () -> floating.performClick());
        floating.setOnTouchListener((v, event) -> iconDrag.touch(event));
        friendPick=button("Друг +");friendPick.setTextSize(10);friendPick.setMaxLines(3);friendPick.setGravity(Gravity.CENTER);
        friendPick.setTypeface(Typeface.DEFAULT_BOLD);friendPick.setPadding(dp(2),0,dp(2),0);
        GradientDrawable friendCircle=new GradientDrawable();friendCircle.setShape(GradientDrawable.OVAL);friendCircle.setColor(ICON);friendCircle.setStroke(dp(2),ACCENT);
        friendPick.setBackground(friendCircle);friendPick.setStateListAnimator(null);friendPick.setElevation(dp(16));
        friendPick.setContentDescription("Друзья: наведи прицел на игрока и нажми. Кнопку можно перетащить.");
        root.addView(friendPick,new FrameLayout.LayoutParams(dp(76),dp(76)));
        friendDrag=new Drag(friendPick,"friend.pick.",.94f,.40f,()->friendPick.performClick());
        friendPick.setOnTouchListener((v,event)->{
            if(event.getActionMasked()==MotionEvent.ACTION_DOWN){friendPressed=true;friendPressedPreview=friendPreview;}
            boolean handled=friendDrag.touch(event);
            if(event.getActionMasked()==MotionEvent.ACTION_UP||event.getActionMasked()==MotionEvent.ACTION_CANCEL){friendPressed=false;updateFriendPreview();}
            return handled;
        });friendPick.setOnClickListener(v->pickFriend());
        friendPicking=preferences.getBoolean("friend.crosshair",false);friendPick.setVisibility(friendPicking?View.VISIBLE:View.GONE);
        AimbotBridge.setFriendPicking(friendPicking);
        auctionInput=new AuctionTapInput(activity,root,floating,this::close);
        autoBuy=new AutoBuyController(activity,auctionInput,text->GameRuntime.log("Auto Buy: "+text),()->!auctionInput.calibrating()&&!activity.isFinishing()&&!activity.isDestroyed());
        pearl=new PearlController(activity);staticItems=new StaticItemsController(activity);noSlow=new NoSlowController(activity);localTimer=new LocalTimerController(activity);blockTrap=new BlockTrapController(activity);aimbot=new AimbotController(activity);int legacyRange=Math.max(1,Math.min(5,preferences.getInt("aim.radius",3)))*10;
        localTimerHundredths=Math.max(100,Math.min(200,Math.round(preferences.getInt("local_timer.hundredths",110)/5f)*5));
        LocalTimerBridge.configure(localTimerHundredths);
        blockTrapRangeTenths=Math.max(20,Math.min(50,preferences.getInt("block_trap.rangeTenths",40)));
        blockTrapTicks=Math.max(2,Math.min(10,preferences.getInt("block_trap.intervalTicks",3)));
        BlockTrapBridge.configure(blockTrapRangeTenths,blockTrapTicks);
        aimRangeTenths=Math.max(10,Math.min(60,preferences.getInt("aim.rangeTenths",legacyRange)));
        aimAttackTenths=Math.max(10,Math.min(aimRangeTenths,preferences.getInt("aim.attackTenths",legacyRange)));
        int legacyCps=Math.max(1,Math.min(40,preferences.getInt("aim.cps",15)));
        aimCpsMin=Math.max(1,Math.min(40,preferences.getInt("aim.cps.min",legacyCps)));
        aimCpsMax=Math.max(aimCpsMin,Math.min(40,preferences.getInt("aim.cps.max",legacyCps)));
        AimbotBridge.settings(aimRangeTenths,aimAttackTenths,aimCpsMin,aimCpsMax);
        addToggle("aimbot",TARGET,"Aimbot","Резкое наведение и удары по выбранному игроку. Дистанция и CPS настраиваются ниже.",aimbot::setEnabled);
        entries.put("friends",new Entry("friends",TARGET,"Друзья","Aimbot исключает друзей из целей и проверяет список перед автоударом. Список сохраняется."));

        addCatalog("auto_buy", "Auto Buy", "Обновление аукциона → подбор по правилам → проверка окна покупки → покупка → проверка получения предмета.");
        addToggle("auto_buy","Auto Buy", "Обновление, подбор и покупка по правилам из твоего скрипта. Работает при открытом kulich и другом окне поверх игры.",autoBuy::setEnabled);
        addToggle("no_slow", "No Slow", "Убирает клиентское замедление движения при еде и натяжении лука. Использование предмета продолжается. Нужен загруженный мир.",noSlow::setEnabled);
        addToggle("local_timer", "Timer", "Локальное ускорение движения, использования предметов и взмаха руки твоего игрока. Общий таймер мира не меняется. Нужен загруженный мир.",localTimer::setEnabled);
        addToggle("pearl_prediction", "Pearl Prediction", "Следы полёта своих и чужих жемчугов. Если доступны параметры полёта, дополнительно показываются прогноз и примерное время до столкновения. Нужен загруженный мир.",pearl::setEnabled);
        addToggle("static_items", "No Item Physics", "Выпавшие мечи и другие плоские предметы лежат плашмя, без покачивания и вращения. Блоки сохраняют объём. Падение и подбор работают. Нужен загруженный мир.",staticItems::setEnabled);
        addToggle("block_trap", "Block Trap", "Ставит выбранный блок из руки вокруг ближайшего игрока. Друзья исключаются из целей. Нужен загруженный мир.",blockTrap::setEnabled);
        addCatalog("fast_exp", "Fast Exp", "Ускоренное использование пузырьков опыта из руки.");
        entries.put("hud_menu",new Entry("hud_menu",CUSTOM,"Менюшка","Панели на экране: функции, Staff List, Buff Timer и цель. Перемещение, размеры и сохранение расположения."));
        entries.put("menu_theme",new Entry("menu_theme",CUSTOM,"Цвет меню","Белая или чёрная тема. Выбор сохраняется автоматически."));
        root.postDelayed(fastHeartbeat,400);root.postDelayed(pearlHeartbeat,100);
        arrange(true);
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> fit());
        activity.getWindow().addContentView(root, new ViewGroup.LayoutParams(-1, -1));root.post(this::fit);
        root.post(this::loadScripts);
    }

    private void registerHud(String id,String title,View content,int width,int height,float x,float y){
        hudTitles.put(id,title);hudLayout.register(id,title,content,width,height,x,y);
        hudLayout.visible(id,preferences.getBoolean("hud.show."+id,true));
    }
    private void ensureShortcut(Entry entry){
        if(entry.callback==null||shortcuts.containsKey(entry.id))return;
        String id="shortcut_"+entry.id;
        if(!preferences.getBoolean("hud.show."+id,false))return;
        Button shortcut=button(entry.title);shortcut.setTextSize(13);shortcut.setMaxLines(2);
        shortcuts.put(entry.id,shortcut);hudTitles.put(id,"Кнопка: "+entry.title);
        hudLayout.register(id,"Кнопка: "+entry.title,shortcut,124,48,.02f,Math.min(.92f,.30f+shortcuts.size()*.12f));
        hudLayout.showHiddenInEditor(id,false);
        hudLayout.visible(id,preferences.getBoolean("hud.show."+id,false));
        shortcut.setOnClickListener(v->{
            if(entry.callback==null)return;
            try{if(entry.id.equals("fast_exp"))fastStart.cancel();boolean active=entry.id.equals("fast_exp")?FastExpBridge.isEnabled():entry.enabled;entry.callback.setEnabled(!active);entry.enabled=!active;renderModules();renderDetails();updateShortcutLabels();}
            catch(Exception|LinkageError error){Toast.makeText(activity,error.getMessage()==null?"Не удалось переключить модуль":error.getMessage(),Toast.LENGTH_LONG).show();GameRuntime.log("HUD shortcut failed: "+entry.id+" / "+error);}
        });
        updateShortcutLabels();
    }
    private void updateShortcutLabels(){
        for(Map.Entry<String,Button> item:shortcuts.entrySet()){
            Entry entry=entries.get(item.getKey());if(entry==null)continue;
            item.getValue().setText(entry.title+"\n"+(entry.enabled?"● Включён":"○ Выключен"));
            item.getValue().setContentDescription(entry.title+": "+(entry.enabled?"выключить":"включить"));
        }
    }
    private void renderShortcutSetting(Entry entry){
        ensureShortcut(entry);String id="shortcut_"+entry.id;
        Switch show=new Switch(activity);show.setText("Кнопка на экране");show.setTextSize(14);show.setTextColor(INK);tintControl(show);
        show.setChecked(preferences.getBoolean("hud.show."+id,false));details.addView(show,new LinearLayout.LayoutParams(-1,dp(44)));
        show.setOnCheckedChangeListener((button,value)->{
            preferences.edit().putBoolean("hud.show."+id,value).apply();
            if(value)ensureShortcut(entry);
            if(shortcuts.containsKey(entry.id))hudLayout.visible(id,value);
        });
    }
    private void renderHudSettings(){
        Button edit=button("Редактировать HUD");details.addView(edit,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView help=label("Перетаскивай панели, тяни за угол для размера. Нажми фон или «Готово», чтобы выйти. Настройки сохраняются. Модули продолжают работать.",12);help.setTextColor(MUTED);details.addView(help);
        edit.setOnClickListener(v->{close();hudLayout.beginEditing(()->open());});
        for(String id:new String[]{"target","modules","staff","buffs"}){
            Switch show=new Switch(activity);show.setText(hudTitles.get(id));show.setTextSize(15);show.setTextColor(INK);tintControl(show);
            show.setChecked(preferences.getBoolean("hud.show."+id,true));details.addView(show,new LinearLayout.LayoutParams(-1,dp(44)));
            show.setOnCheckedChangeListener((button,value)->{preferences.edit().putBoolean("hud.show."+id,value).apply();hudLayout.visible(id,value);});
        }
        TextView staffTitle=label("Staff List — ники хелперов и модераторов",14);staffTitle.setPadding(0,dp(12),0,0);details.addView(staffTitle);
        EditText names=new EditText(activity);names.setText(staffModel.encoded());names.setTextColor(INK);names.setHintTextColor(MUTED);names.setHint("По одному нику на строке");
        names.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        names.setMinLines(2);names.setMaxLines(4);names.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(2176)});
        details.addView(names,new LinearLayout.LayoutParams(-1,dp(104)));
        TextView result=label("Показываются совпадения с данными игры. Если общий список сервера недоступен, панель отметит только игроков рядом.",12);result.setTextColor(MUTED);
        Button save=button("Сохранить Staff List");details.addView(save,new LinearLayout.LayoutParams(-1,dp(48)));details.addView(result);
        save.setOnClickListener(v->{String old=staffModel.encoded();if(!staffModel.setNames(names.getText().toString())){result.setText("Ники: 1–16 английских букв, цифр или _, максимум 128.");return;}
            if(!preferences.edit().putString("hud.staff.names",staffModel.encoded()).commit()){staffModel.setNames(old);result.setText("Не удалось сохранить список");return;}names.setText(staffModel.encoded());result.setText("Staff List сохранён: "+staffModel.configuredNames().length+" ников");updateHudData(android.os.SystemClock.uptimeMillis());});
        TextView sizes=label("Размер панели",14);sizes.setPadding(0,dp(14),0,0);details.addView(sizes);
        List<String> ids=new ArrayList<>();List<String> titles=new ArrayList<>();
        for(String id:hudTitles.keySet())if(!id.startsWith("shortcut_")||preferences.getBoolean("hud.show."+id,false)){ids.add(id);titles.add(hudTitles.get(id));}
        Spinner choose=new Spinner(activity);ArrayAdapter<String> adapter=new ArrayAdapter<>(activity,android.R.layout.simple_spinner_item,titles);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);choose.setAdapter(adapter);details.addView(choose,new LinearLayout.LayoutParams(-1,dp(44)));
        TextView width=label("",13),height=label("",13);SeekBar widthBar=new SeekBar(activity),heightBar=new SeekBar(activity);tintControl(widthBar);tintControl(heightBar);widthBar.setMax(520);heightBar.setMax(360);
        details.addView(width);details.addView(widthBar,new LinearLayout.LayoutParams(-1,dp(40)));details.addView(height);details.addView(heightBar,new LinearLayout.LayoutParams(-1,dp(40)));
        String[] current={ids.isEmpty()?"target":ids.get(0)};
        Runnable load=()->{String id=current[0];int w=Math.round(hudLayout.widthDp(id)),h=Math.round(hudLayout.heightDp(id));widthBar.setProgress(Math.max(0,w-80));heightBar.setProgress(Math.max(0,h-40));width.setText("Ширина: "+w);height.setText("Высота: "+h);};
        choose.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> a,View v,int pos,long row){current[0]=ids.get(pos);load.run();}public void onNothingSelected(AdapterView<?> a){}});
        widthBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean user){if(user){hudLayout.setSize(current[0],p+80,hudLayout.heightDp(current[0]));width.setText("Ширина: "+hudLayout.widthDp(current[0]));}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        heightBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean user){if(user){hudLayout.setSize(current[0],hudLayout.widthDp(current[0]),p+40);height.setText("Высота: "+hudLayout.heightDp(current[0]));}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        load.run();Button reset=button("Сбросить расположение и размеры");details.addView(reset,new LinearLayout.LayoutParams(-1,dp(48)));reset.setOnClickListener(v->{hudLayout.resetAll();load.run();});
    }
    private void updateHudData(long now){
        Entry fast=entries.get("fast_exp");if(fast!=null&&FastExpBridge.isReady()){if(fast.callback==null)fast.callback=FastExpBridge::setEnabled;fast.enabled=FastExpBridge.isEnabled();}
        List<String> active=new ArrayList<>();
        for(Entry entry:entries.values())if(entry.callback!=null){ensureShortcut(entry);if(entry.enabled)active.add(entry.title);}
        hudPanels.updateActive(active);hudPanels.activeView().setVisibility(active.isEmpty()?View.GONE:View.VISIBLE);updateShortcutLabels();
        boolean requested=preferences.getBoolean("hud.show.staff",true)||preferences.getBoolean("hud.show.buffs",true);
        HudDataBridge.heartbeat(requested);
        staffModel.update(HudDataBridge.rosterNames(),HudDataBridge.rosterIsGlobal(),now);hudPanels.updateStaff(staffModel.lines(now));
        buffModel.update(HudDataBridge.effectsSnapshot(),now);hudPanels.updateBuffs(buffModel.lines(now));
        if(requested)prepareHudBridge(now);
    }
    private void prepareHudBridge(long now){
        if(disposed||hudPreparing||HudDataBridge.isReady()||now<nextHudPrepare)return;
        if(!GameEngineProbe.begin()){nextHudPrepare=now+800;return;}
        hudPreparing=true;nextHudPrepare=now+8000;
        Thread worker=new Thread(()->{try{GameEngineProbe.run();}catch(RuntimeException|LinkageError error){GameRuntime.log("HUD preparation failed: "+error);}finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{hudPreparing=false;if(!disposed&&!activity.isFinishing()&&!activity.isDestroyed())updateHudData(android.os.SystemClock.uptimeMillis());});},"hud-prepare");worker.setDaemon(true);worker.start();
    }

    private void loadScripts(){
        if(activity.isFinishing()||activity.isDestroyed())return;
        scripts=new KulichScripts(new KulichScripts.Host(){
            public void register(String id,String name,String description,KulichScripts.Toggle callback){
                addToggle(id,name,description,callback::set);
            }
            public void log(String value){GameRuntime.log(value);}
            public Object fast(String operation,Object value){
                switch(operation){
                    case "ready":return FastExpBridge.isReady();
                    case "status":return FastExpBridge.describe();
                    case "enable":FastExpBridge.setEnabled(Boolean.TRUE.equals(value));return null;
                    case "interval":FastExpBridge.setTickInterval(((Number)value).intValue());return null;
                    default:throw new IllegalArgumentException("Unsupported Fast Exp operation");
                }
            }
            public void failed(String id){
                Entry entry=entries.get(id);if(entry!=null)entry.enabled=false;
                FastExpBridge.setEnabled(false);renderModules();renderDetails();
            }
        });
        try(java.io.InputStream input=activity.getAssets().open("kulich-api.js")){
            String bootstrap=ScriptFiles.read(input,ScriptFiles.MAX_BYTES);
            long start=android.os.SystemClock.uptimeMillis();
            for(java.io.File file:ScriptFiles.list(new java.io.File(activity.getFilesDir(),"scripts"))){
                if(android.os.SystemClock.uptimeMillis()-start>2000){GameRuntime.log("Scripts: startup time limit reached");break;}
                try(java.io.InputStream source=new java.io.FileInputStream(file)){
                    scripts.load(bootstrap,ScriptFiles.read(source,ScriptFiles.MAX_BYTES),file.getName());
                }catch(java.io.IOException error){GameRuntime.log("Script read failed: "+error.getClass().getSimpleName());}
            }
        }catch(java.io.IOException|RuntimeException error){GameRuntime.log("Scripts unavailable: "+error);}
    }

    private void addCatalog(String id, String title, String description) {
        entries.put(id, new Entry(id, UTILITY, title, description));
    }
    /** Bind implemented gameplay behavior to a catalog ID, or add a new utility module. UI thread only. */
    public void addToggle(String id, String title, String description, Toggle callback) {
        addToggle(id, UTILITY, title, description, callback);
    }
    public void addToggle(String id, String category, String title, String description, Toggle callback) {
        if (id == null || id.isEmpty() || callback == null || (!TARGET.equals(category) && !UTILITY.equals(category) && !CUSTOM.equals(category)))
            throw new IllegalArgumentException("Module requires an ID, category and real callback");
        Entry entry = entries.get(id);
        if (entry != null && entry.callback != null) throw new IllegalArgumentException("Duplicate module ID: " + id);
        if (entry == null) { entry = new Entry(id, category, title, description);entries.put(id, entry); }
        else if (!entry.category.equals(category)) throw new IllegalArgumentException("Module category does not match catalog");
        entry.title = title;entry.description = description;entry.callback = callback;
        ensureShortcut(entry);renderModules();renderDetails();
    }
    private void arrange(boolean wide) {
        this.wide = wide;body.removeAllViews();detach(categories);detach(moduleScroll);detach(detailScroll);
        categories.setOrientation(wide ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        body.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        if (wide) {
            body.addView(categories, new LinearLayout.LayoutParams(dp(136), -1));
            body.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            body.addView(moduleScroll, new LinearLayout.LayoutParams(dp(180), -1));
            body.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            body.addView(detailScroll, new LinearLayout.LayoutParams(0, -1, 1));
        } else {
            body.addView(categories, new LinearLayout.LayoutParams(-1, dp(76)));
            LinearLayout content = new LinearLayout(activity);
            content.addView(moduleScroll, new LinearLayout.LayoutParams(0, -1, 0.43f));
            content.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            content.addView(detailScroll, new LinearLayout.LayoutParams(0, -1, 0.57f));
            body.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        }
        renderCategories();renderModules();renderDetails();
    }
    private void renderCategories() {
        categories.removeAllViews();
        categoryRow(TARGET, "01", "Таргет");categoryRow(UTILITY, "02", "Вспомогательные\nфункции");categoryRow(CUSTOM,"03","Кастомизация");
    }
    private void categoryRow(String id, String number, String title) {
        LinearLayout row = new LinearLayout(activity);row.setOrientation(LinearLayout.VERTICAL);
        row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10), dp(8), dp(6), dp(8));
        boolean chosen = id.equals(category);
        row.setBackground(background(chosen ? SELECTED : CATEGORY, 10));
        TextView index = label(number, 11);index.setTextColor(chosen ? ACCENT : MUTED);row.addView(index);
        TextView name = label(title, 14);name.setTextColor(chosen ? INK : MUTED);row.addView(name);
        row.setOnClickListener(v -> {
            category = id;selected = null;preferences.edit().putString("category", id).apply();
            renderCategories();renderModules();renderDetails();
        });
        LinearLayout.LayoutParams bounds = wide ? new LinearLayout.LayoutParams(-1, 0, 1) :
                new LinearLayout.LayoutParams(0, -1, 1);
        bounds.setMargins(dp(3), dp(3), dp(3), dp(3));categories.addView(row, bounds);
    }
    private void renderModules() {
        moduleList.removeAllViews();
        boolean any = false;
        for (Entry entry : entries.values()) {
            if (!entry.category.equals(category)) continue;
            any = true;
            LinearLayout row = new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(14), dp(8), dp(14));
            if (entry.id.equals(selected)) row.setBackground(background(SELECTED, 10));
            TextView dot = label("●", 11);dot.setTextColor(entry.enabled ? ACCENT : MUTED);
            row.addView(dot, new LinearLayout.LayoutParams(dp(20), -2));
            LinearLayout text = new LinearLayout(activity);text.setOrientation(LinearLayout.VERTICAL);
            text.addView(label(entry.title, 16));
            TextView status = label(entry.id.equals("friends") ? (FriendStore.names().length+" в списке") : entry.id.equals("hud_menu") ? "Панели и редактор" : entry.id.equals("menu_theme") ? (lightTheme?"Белая тема":"Чёрная тема") : entry.callback == null ? "Не подключён" : entry.enabled ? "Включён" : "Выключен", 11);
            status.setTextColor(MUTED);text.addView(status);row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
            TextView arrow = label("›", 23);arrow.setTextColor(MUTED);row.addView(arrow);
            row.setOnClickListener(v -> { selected = entry.id;renderModules();renderDetails(); });
            moduleList.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        if (!any) {
            TextView empty = label("Пока нет модулей", 14);empty.setTextColor(MUTED);empty.setPadding(dp(12), dp(20), dp(8), 0);
            moduleList.addView(empty);
        }
    }
    private void renderDetails() {
        Entry fast=entries.get("fast_exp");
        if(fast!=null&&fast.callback==null&&FastExpBridge.isReady()){fast.callback=FastExpBridge::setEnabled;renderModules();}
        autoBuyStatus=null;aimbotStatus=null;noSlowStatus=null;localTimerStatus=null;blockTrapStatus=null;staticItemsStatus=null;pearlStatus=null;friendsList=null;friendProtection=null;details.removeAllViews();Entry entry = entries.get(selected);
        if (entry == null || !entry.category.equals(category)) {
            details.setGravity(Gravity.CENTER);
            TextView icon = label("◇", 54);icon.setTextColor(MUTED);details.addView(icon);
            TextView hint = label("Выбери модуль", 18);hint.setTextColor(MUTED);details.addView(hint);return;
        }
        details.setGravity(Gravity.TOP);
        TextView title = label(entry.title, 23);title.setTypeface(Typeface.DEFAULT_BOLD);details.addView(title);
        TextView description = label(entry.description, 14);description.setTextColor(MUTED);
        description.setPadding(0, dp(14), 0, dp(20));details.addView(description);
        if(entry.id.equals("menu_theme")){renderThemeSettings();return;}
        if(entry.id.equals("hud_menu")){renderHudSettings();return;}
        if(entry.id.equals("friends")){renderFriendsSettings();return;}
        if(entry.callback!=null)renderShortcutSetting(entry);
        if(entry.id.equals("aimbot")){renderToggle(entry);renderAimbotSettings();}
        if(entry.id.equals("auto_buy")){
            renderToggle(entry);
            autoBuyStatus=label(autoBuy.status(),13);autoBuyStatus.setTextColor(ACCENT);details.addView(autoBuyStatus);
            Button wanted=button("Предметы и цены");details.addView(wanted);
            TextView wantedList=label(AutoBuyDefaultRules.buyingList(),12);wantedList.setTextColor(MUTED);wantedList.setVisibility(View.GONE);details.addView(wantedList);
            wanted.setOnClickListener(v->wantedList.setVisibility(wantedList.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
            Button refreshTest=button("Проверить нативное обновление");details.addView(refreshTest,new LinearLayout.LayoutParams(-1,dp(52)));
            refreshTest.setOnClickListener(v->{close();autoBuy.testNativeRefresh();});
            TextView rules=label("Используются цены и зачарования из твоего скрипта. Броня с неподтверждённым типом и предметы без рыночной цены пропускаются. Интервал обновления — от 0,3 с с ожиданием ответа сервера. Открытие kulich, касания экрана и другое окно не ставят модуль на паузу.",12);rules.setTextColor(MUTED);details.addView(rules);
            Button extra=button("Диагностика");details.addView(extra);
            LinearLayout advanced=new LinearLayout(activity);advanced.setOrientation(LinearLayout.VERTICAL);advanced.setVisibility(View.GONE);details.addView(advanced);
            extra.setOnClickListener(v->advanced.setVisibility(advanced.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
            Button trace=button("Записать настоящее действие контейнера");advanced.addView(trace);
            TextView traceState=label("Необязательная запись запросов для диагностики.",12);traceState.setTextColor(MUTED);advanced.addView(traceState);
            trace.setOnClickListener(v->{
                autoBuy.setEnabled(false);fastStart.cancel();FastExpBridge.setEnabled(false);entry.enabled=false;renderModules();
                for(int i=0;i<details.getChildCount();i++)if(details.getChildAt(i) instanceof Switch)((Switch)details.getChildAt(i)).setChecked(false);
                if(!GameEngineProbe.begin()){traceState.setText("Дождись завершения чтения");return;}
                trace.setEnabled(false);traceState.setText("Подключаю запись действий…");
                Thread recorder=new Thread(()->{
                    String result;
                    try{GameEngineProbe.run();result=GameEngineProbe.startTransactionTrace();}
                    catch(RuntimeException|LinkageError error){result="Запись не включена: "+error.getMessage();GameRuntime.log("Transaction trace unavailable: "+error);}
                    finally{GameEngineProbe.end();}
                    String message=result;activity.runOnUiThread(()->{if(!activity.isDestroyed()){trace.setEnabled(true);traceState.setText(message);}});
                },"inventory-trace-install");recorder.setDaemon(true);recorder.start();
            });
            Button saveTrace=button("Сохранить запись действий");advanced.addView(saveTrace);
            saveTrace.setOnClickListener(v->{try{traceState.setText(TransactionTrace.save()+"\nЗапись добавлена в журнал kulich.");}catch(RuntimeException|LinkageError error){traceState.setText("Не удалось сохранить: "+error.getMessage());}});
            Button snapshot=button("Считать открытый аукцион");advanced.addView(snapshot,new LinearLayout.LayoutParams(-1,dp(52)));
            TextView output=label("Открой аукцион сервера. Эта кнопка только читает лоты; автоматическая покупка включается переключателем Auto Buy.",12);
            output.setTextColor(MUTED);advanced.addView(output);
            snapshot.setOnClickListener(v->{
                if(!GameEngineProbe.begin()){Toast.makeText(activity,"Чтение уже выполняется",Toast.LENGTH_SHORT).show();return;}
                snapshot.setEnabled(false);output.setText("Считываю контейнер…");
                Thread worker=new Thread(()->{
                    String result;
                    try{GameEngineProbe.run();result=GameEngineProbe.auctionSnapshot();}
                    finally{GameEngineProbe.end();}
                    String text=result;
                    activity.runOnUiThread(()->{if(!activity.isFinishing()&&!activity.isDestroyed()){snapshot.setEnabled(true);output.setText(text);}});
                },"auction-snapshot");worker.setDaemon(true);worker.start();
            });
        }
        if(entry.id.equals("fast_exp"))renderFastExpInterval();
        if (entry.callback != null&&!entry.id.equals("auto_buy")&&!entry.id.equals("aimbot")) renderToggle(entry);
        if(entry.id.equals("no_slow")){noSlowStatus=label(noSlow.displayStatus(),12);details.addView(noSlowStatus);}
        if(entry.id.equals("local_timer"))renderLocalTimerSettings();
        if(entry.id.equals("block_trap"))renderBlockTrapSettings();
        if(entry.id.equals("static_items")){staticItemsStatus=label(staticItems.displayStatus(),12);details.addView(staticItemsStatus);}
        if(entry.id.equals("pearl_prediction")){
            TextView note=label("После броска: зелёный — твой жемчуг, оранжевый — другого игрока. Подпись «след» означает уже пройденный путь. Прогноз вперёд и время появляются, когда известны параметры полёта и точка столкновения.",12);note.setTextColor(MUTED);details.addView(note);
            pearlStatus=label(pearl.displayStatus(),12);details.addView(pearlStatus);
            Button stats=button("Статус Pearl Prediction");details.addView(stats);
            TextView report=label("",11);report.setTextColor(MUTED);report.setVisibility(View.GONE);details.addView(report);
            stats.setOnClickListener(v->{String value=pearl.status();report.setText(value);report.setVisibility(View.VISIBLE);GameRuntime.log(value);});
        }
        if(entry.id.equals("fast_exp")&&entry.callback!=null){
            TextView note=label("Использует только пузырьки опыта из руки. Открытие меню и другого окна не выключает модуль. Работает вместе с Auto Buy.",12);
            note.setTextColor(MUTED);details.addView(note);
            Button stats=button("Статус Fast Exp");details.addView(stats);
            TextView nativeState=label(FastExpBridge.describe(),12);nativeState.setTextColor(MUTED);details.addView(nativeState);
            stats.setOnClickListener(v->{String value=FastExpBridge.describe();nativeState.setText(value);GameRuntime.log(value);});
        }
        TextView state = label(entry.callback == null ? "Модуль ещё не подключён к игре" : entry.id.equals("fast_exp") ? "Мост установлен; работу проверяем в мире" : "Готов к работе", 13);
        state.setTextColor(entry.callback == null ? WARNING : ACCENT);state.setPadding(0, dp(12), 0, 0);details.addView(state);
        if (entry.id.equals("fast_exp") && entry.callback == null) {
            Button probe = button("Включить Fast Exp");
            details.addView(probe, new LinearLayout.LayoutParams(-1, dp(52)));
            TextView output = label("Подключение проверится автоматически в загруженном мире. Меню можно оставить открытым.", 12);
            output.setTextColor(MUTED);output.setPadding(0, dp(10), 0, 0);details.addView(output);
            probe.setOnClickListener(v -> {
                fastStart.cancel();
                if (!GameEngineProbe.begin()) {
                    Toast.makeText(activity, "Проверка уже выполняется", Toast.LENGTH_SHORT).show();return;
                }
                probe.setEnabled(false);output.setText("Включаю Fast Exp…");
                Thread worker = new Thread(() -> {
                    String result;
                    try { result = GameEngineProbe.run(); }
                    finally { GameEngineProbe.end(); }
                    activity.runOnUiThread(() -> {
                        if (activity.isFinishing() || activity.isDestroyed()) return;
                        probe.setEnabled(true);output.setText(result);
                        if(FastExpBridge.isReady()){
                            try{FastExpBridge.setEnabled(true);}
                            catch(RuntimeException|LinkageError error){GameRuntime.log("Fast Exp enable failed: "+error);}
                            renderModules();renderDetails();
                        }else output.setText("Не удалось подключиться. Войди в мир и нажми «Включить Fast Exp» ещё раз.\n"+result);
                    });
                }, "game-engine-probe");
                worker.setDaemon(true);worker.start();
            });
        }
    }
    private void setFriendPicking(boolean value){
        friendPicking=value;friendPreview="";nextFriendPrepare=0;
        preferences.edit().putBoolean("friend.crosshair",value).apply();
        AimbotBridge.setFriendPicking(value);friendPick.setVisibility(value?View.VISIBLE:View.GONE);
        if(value){friendPick.bringToFront();updateFriendPreview();prepareFriendPicking(android.os.SystemClock.uptimeMillis());}
    }
    private void updateFriendPreview(){
        if(!friendPicking||friendPressed)return;
        String name=AimbotBridge.friendTargetName();friendPreview=name==null?"":name;
        String shown=friendPreview.length()>8?friendPreview.substring(0,8)+"\n"+friendPreview.substring(8):friendPreview;
        friendPick.setText(friendPreview.isEmpty()?"Друг +\n"+(AimbotBridge.isReady()?"Наведи прицел":"Войди в мир"):(FriendStore.contains(friendPreview)?"Убрать друга\n":"Друг +\n")+shown);
        friendPick.setContentDescription(friendPreview.isEmpty()?"Наведи прицел на игрока":(FriendStore.contains(friendPreview)?"Убрать друга ":"Добавить друга ")+friendPreview);
    }
    private void pickFriend(){
        if(!friendPicking)return;
        if(panel.getVisibility()==View.VISIBLE){Toast.makeText(activity,"Закрой kulich и наведи прицел на игрока",Toast.LENGTH_SHORT).show();return;}
        if(!AimbotBridge.isReady()){prepareFriendPicking(android.os.SystemClock.uptimeMillis());Toast.makeText(activity,"Подключаю выбор друзей. Нужен загруженный мир",Toast.LENGTH_SHORT).show();return;}
        String fresh=AimbotBridge.friendTargetName();fresh=fresh==null?"":fresh;
        if(fresh.isEmpty()){updateFriendPreview();Toast.makeText(activity,"Игрок не выбран: наведи прицел на него",Toast.LENGTH_SHORT).show();return;}
        String expected=friendPressed?friendPressedPreview:friendPreview;
        if(expected.isEmpty()||!fresh.equalsIgnoreCase(expected)){updateFriendPreview();Toast.makeText(activity,"Цель изменилась — проверь ник и нажми ещё раз",Toast.LENGTH_SHORT).show();return;}
        try{String message=FriendStore.toggle(fresh);Toast.makeText(activity,message,Toast.LENGTH_SHORT).show();GameRuntime.log("Friend touch: "+message);}
        catch(RuntimeException|LinkageError error){
            aimbot.setEnabled(false);Entry aim=entries.get("aimbot");if(aim!=null)aim.enabled=false;
            Toast.makeText(activity,"Не удалось обновить защиту друзей. Aimbot выключен.",Toast.LENGTH_LONG).show();GameRuntime.log("Friend touch failed: "+error);
        }
        updateFriendPreview();if(friendsList!=null)friendsList.setText(FriendStore.summary());renderModules();
    }
    private void prepareFriendPicking(long now){
        if(!friendPicking||disposed||friendPreparing||AimbotBridge.isReady()||now<nextFriendPrepare)return;
        if(!GameEngineProbe.begin()){nextFriendPrepare=now+800;return;}
        friendPreparing=true;nextFriendPrepare=now+8000;
        Thread worker=new Thread(()->{
            try{GameEngineProbe.run();}
            catch(RuntimeException|LinkageError error){GameRuntime.log("Friend picking preparation failed: "+error);}
            finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{friendPreparing=false;if(disposed||!friendPicking||activity.isFinishing()||activity.isDestroyed())return;AimbotBridge.setFriendPicking(true);updateFriendPreview();});
        },"friend-pick-prepare");worker.setDaemon(true);worker.start();
    }
    private void renderFriendsSettings(){
        Switch crosshair=new Switch(activity);crosshair.setText("Добавление через прицел");crosshair.setTextSize(15);crosshair.setTextColor(INK);
        crosshair.setChecked(friendPicking);tintControl(crosshair);details.addView(crosshair,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView touchHint=label("Включи кнопку, закрой kulich и наведи стрелочку прицела на игрока. На круглой кнопке появится ник: нажми, чтобы добавить его в друзья; повторное нажатие убирает друга. Саму кнопку можно перетащить.",12);
        touchHint.setTextColor(MUTED);details.addView(touchHint);
        crosshair.setOnCheckedChangeListener((button,value)->setFriendPicking(value));
        TextView hint=label("Добавить: .add Ник\nУдалить: .remove Ник\nРегистр букв не важен. Указывай сам ник без привилегии.",13);
        hint.setTextColor(MUTED);details.addView(hint);
        EditText command=new EditText(activity);command.setSingleLine(true);command.setTextColor(INK);command.setHintTextColor(MUTED);
        command.setHint(".add Ник / .remove Ник");
        command.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        command.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE|android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        command.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(64)});
        details.addView(command,new LinearLayout.LayoutParams(-1,dp(48)));
        Button submit=button("Выполнить");details.addView(submit,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView feedback=label("Команда выполняется локально в kulich.",12);feedback.setTextColor(MUTED);details.addView(feedback);
        friendProtection=label(AimbotBridge.friendProtectionStatus(),12);friendProtection.setTextColor(ACCENT);details.addView(friendProtection);
        friendsList=label(FriendStore.summary(),14);friendsList.setPadding(0,dp(14),0,0);details.addView(friendsList);
        Runnable execute=()->{
            try{feedback.setText(FriendStore.execute(command.getText().toString()));}
            catch(RuntimeException|LinkageError error){
                aimbot.setEnabled(false);Entry aim=entries.get("aimbot");if(aim!=null)aim.enabled=false;
                feedback.setText("Не удалось обновить защиту друзей. Aimbot выключен.");GameRuntime.log("Friend sync failed: "+error);
            }
            friendsList.setText(FriendStore.summary());renderModules();
        };
        submit.setOnClickListener(v->execute.run());
        command.setOnEditorActionListener((v,action,event)->{
            boolean enter=event!=null&&event.getKeyCode()==KeyEvent.KEYCODE_ENTER&&event.getAction()==KeyEvent.ACTION_UP;
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE||enter){execute.run();return true;}return false;
        });
    }
    private void renderFastExpInterval(){
        TextView caption=label("Интервал: "+FastExpBridge.tickInterval()+" тик(ов) на бросок",14);
        caption.setTextColor(INK);details.addView(caption);
        SeekBar slider=new SeekBar(activity);tintControl(slider);slider.setMax(9);slider.setProgress(FastExpBridge.tickInterval()-1);
        slider.setContentDescription("Интервал Fast Exp от 1 до 10 тиков");
        details.addView(slider,new LinearLayout.LayoutParams(-1,dp(44)));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int progress,boolean fromUser){
                if(!fromUser)return;
                int ticks=progress+1;FastExpBridge.setTickInterval(ticks);
                preferences.edit().putInt("fast_exp_ticks",ticks).apply();
                caption.setText("Интервал: "+ticks+" тик(ов) на бросок");
            }
            public void onStartTrackingTouch(SeekBar bar){}
            public void onStopTrackingTouch(SeekBar bar){GameRuntime.log("Fast Exp: interval="+FastExpBridge.tickInterval()+" game ticks");}
        });
    }
    private void renderBlockTrapSettings(){
        TextView help=label("Для первой проверки выбери обсидиан в панели быстрого доступа. Block Trap ставит блоки вокруг ближайшего противника, когда клетка свободна и видна подходящая твёрдая опора. Друзья исключаются. Слот автоматически не меняется.",12);help.setTextColor(MUTED);details.addView(help);
        TextView rangeLabel=label("Радиус выбора цели: "+aimDistanceLabel(blockTrapRangeTenths)+" блоков",14);details.addView(rangeLabel);
        SeekBar range=new SeekBar(activity);range.setMax(30);range.setProgress(blockTrapRangeTenths-20);tintControl(range);details.addView(range,new LinearLayout.LayoutParams(-1,dp(44)));
        range.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int value,boolean user){if(!user)return;blockTrapRangeTenths=value+20;saveBlockTrapSettings();rangeLabel.setText("Радиус выбора цели: "+aimDistanceLabel(blockTrapRangeTenths)+" блоков");}
            public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}
        });
        TextView intervalLabel=label("Интервал: "+blockTrapTicks+" тик(ов) на попытку",14);details.addView(intervalLabel);
        SeekBar interval=new SeekBar(activity);interval.setMax(8);interval.setProgress(blockTrapTicks-2);tintControl(interval);details.addView(interval,new LinearLayout.LayoutParams(-1,dp(44)));
        interval.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int value,boolean user){if(!user)return;blockTrapTicks=value+2;saveBlockTrapSettings();intervalLabel.setText("Интервал: "+blockTrapTicks+" тик(ов) на попытку");}
            public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}
        });
        blockTrapStatus=label(blockTrap.displayStatus(),12);details.addView(blockTrapStatus);
        Button stats=button("Статус Block Trap");details.addView(stats);
        TextView report=label("",11);report.setTextColor(MUTED);report.setVisibility(View.GONE);details.addView(report);
        stats.setOnClickListener(v->{String value=blockTrap.status();report.setText(value);report.setVisibility(View.VISIBLE);GameRuntime.log(value);});
    }
    private void renderLocalTimerSettings(){
        TextView speedLabel=label("Множитель: ×"+String.format(java.util.Locale.ROOT,"%.2f",localTimerHundredths/100.0),14);details.addView(speedLabel);
        SeekBar multiplier=new SeekBar(activity);multiplier.setMax(20);multiplier.setProgress((localTimerHundredths-100)/5);tintControl(multiplier);details.addView(multiplier,new LinearLayout.LayoutParams(-1,dp(44)));
        multiplier.setContentDescription("Множитель локального Timer от 1 до 2, шаг 0,05");
        multiplier.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar bar,int value,boolean user){if(!user)return;localTimerHundredths=100+value*5;LocalTimerBridge.configure(localTimerHundredths);preferences.edit().putInt("local_timer.hundredths",localTimerHundredths).apply();speedLabel.setText("Множитель: ×"+String.format(java.util.Locale.ROOT,"%.2f",localTimerHundredths/100.0));}
            public void onStartTrackingTouch(SeekBar bar){}public void onStopTrackingTouch(SeekBar bar){}
        });
        TextView help=label("×1,00 — обычный темп. Мировой TPS, падение и CPS других модулей сохраняются. Сервер может корректировать движение и длительность действий; обход Nevertime пока не подтверждён.",12);help.setTextColor(MUTED);details.addView(help);
        localTimerStatus=label(localTimer.displayStatus(),12);details.addView(localTimerStatus);
        Button stats=button("Статус Timer");details.addView(stats);
        TextView report=label("",11);report.setTextColor(MUTED);report.setVisibility(View.GONE);details.addView(report);
        stats.setOnClickListener(v->{String value=localTimer.status();report.setText(value);report.setVisibility(View.VISIBLE);GameRuntime.log(value);});
    }
    private void saveBlockTrapSettings(){
        BlockTrapBridge.configure(blockTrapRangeTenths,blockTrapTicks);
        preferences.edit().putInt("block_trap.rangeTenths",blockTrapRangeTenths).putInt("block_trap.intervalTicks",blockTrapTicks).apply();
    }
    private void renderAimbotSettings(){
        details.addView(label("Резкое наведение",16));
        TextView reach=label("Дистанция наведения: "+aimDistanceLabel(aimRangeTenths)+" блоков",14);details.addView(reach);
        SeekBar range=new SeekBar(activity);range.setMax(50);range.setProgress(aimRangeTenths-10);tintControl(range);details.addView(range,new LinearLayout.LayoutParams(-1,dp(44)));
        TextView attackReach=label("Дистанция автоудара: "+aimDistanceLabel(aimAttackTenths)+" блоков",14);details.addView(attackReach);
        SeekBar attackRange=new SeekBar(activity);attackRange.setMax(50);attackRange.setProgress(aimAttackTenths-10);tintControl(attackRange);details.addView(attackRange,new LinearLayout.LayoutParams(-1,dp(44)));
        range.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int value,boolean user){
                if(!user)return;aimRangeTenths=value+10;aimAttackTenths=Math.min(aimAttackTenths,aimRangeTenths);
                attackRange.setProgress(aimAttackTenths-10);saveAimDistances();
                reach.setText("Дистанция наведения: "+aimDistanceLabel(aimRangeTenths)+" блоков");attackReach.setText("Дистанция автоудара: "+aimDistanceLabel(aimAttackTenths)+" блоков");
            }
            public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}
        });
        attackRange.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int value,boolean user){
                if(!user)return;aimAttackTenths=value+10;aimRangeTenths=Math.max(aimRangeTenths,aimAttackTenths);
                range.setProgress(aimRangeTenths-10);saveAimDistances();
                reach.setText("Дистанция наведения: "+aimDistanceLabel(aimRangeTenths)+" блоков");attackReach.setText("Дистанция автоудара: "+aimDistanceLabel(aimAttackTenths)+" блоков");
            }
            public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}
        });
        TextView distanceHint=label("Шаг 0,1 блока, максимум 6,0. Например: наведение с 3,9, автоудары с 2,0. Наведение всегда не меньше дистанции удара.",12);distanceHint.setTextColor(MUTED);details.addView(distanceHint);
        LinearLayout clicksCard=new LinearLayout(activity);clicksCard.setOrientation(LinearLayout.VERTICAL);
        clicksCard.setPadding(dp(14),dp(8),dp(14),dp(8));clicksCard.setBackground(background(CATEGORY,14));
        LinearLayout rateRow=new LinearLayout(activity);rateRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView rateTitle=label("CPS",15);rateRow.addView(rateTitle,new LinearLayout.LayoutParams(0,dp(34),1));
        TextView rate=label(cpsRangeLabel(),14);rate.setTypeface(Typeface.DEFAULT_BOLD);rate.setGravity(Gravity.CENTER);
        rate.setPadding(dp(10),0,dp(10),0);rate.setBackground(background(SELECTED,8));rateRow.addView(rate,new LinearLayout.LayoutParams(-2,dp(30)));
        clicksCard.addView(rateRow,new LinearLayout.LayoutParams(-1,-2));
        CpsRangeView clicks=new CpsRangeView(activity);clicks.setColors(ACCENT,LINE);clicks.setValues(aimCpsMin,aimCpsMax);
        clicksCard.addView(clicks,new LinearLayout.LayoutParams(-1,dp(48)));
        clicks.setListener((minimum,maximum)->{aimCpsMin=minimum;aimCpsMax=maximum;AimbotBridge.settings(aimRangeTenths,aimAttackTenths,aimCpsMin,aimCpsMax);preferences.edit().putInt("aim.cps.min",aimCpsMin).putInt("aim.cps.max",aimCpsMax).apply();rate.setText(cpsRangeLabel());});
        details.addView(clicksCard,new LinearLayout.LayoutParams(-1,-2));
        TextView rateHint=label("Левый круг — минимум, правый — максимум (1–40). Совмести круги, чтобы зафиксировать CPS.",12);rateHint.setTextColor(MUTED);details.addView(rateHint);
        details.addView(label("Наведение выбирает цель в первом радиусе, автоудары начинаются во втором. Попадания и урон зависят от игры и сервера.",12));
        aimbotStatus=label(aimbot.displayStatus(),12);details.addView(aimbotStatus);
    }
    private static String aimDistanceLabel(int tenths){return String.format(java.util.Locale.ROOT,"%.1f",tenths/10.0);}
    private void saveAimDistances(){
        AimbotBridge.settings(aimRangeTenths,aimAttackTenths,aimCpsMin,aimCpsMax);
        preferences.edit().putInt("aim.rangeTenths",aimRangeTenths).putInt("aim.attackTenths",aimAttackTenths).apply();
    }
    private String cpsRangeLabel(){return aimCpsMin==aimCpsMax?aimCpsMin+" · фикс.":aimCpsMin+" – "+aimCpsMax;}
    private void renderToggle(Entry entry) {
        if(entry.id.equals("fast_exp"))entry.enabled=FastExpBridge.isEnabled();
        Switch control = new Switch(activity);control.setText("Включить");control.setTextSize(17);control.setTextColor(INK);
        control.setChecked(entry.enabled);tintControl(control);details.addView(control, new LinearLayout.LayoutParams(-1, dp(48)));
        boolean[] reverting = {false};
        control.setOnCheckedChangeListener((button, enabled) -> {
            if (reverting[0] || entry.callback == null) return;
            if(entry.id.equals("fast_exp"))fastStart.cancel();
            try { entry.callback.setEnabled(enabled);entry.enabled = enabled;renderModules(); }
            catch (Exception | LinkageError error) {
                reverting[0] = true;control.setChecked(entry.enabled);reverting[0] = false;
                GameRuntime.log("Menu module failed: " + entry.id + " / " + error);
                Toast.makeText(activity, error.getMessage()==null?"Не удалось изменить модуль":error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private final Runnable pearlHeartbeat=new Runnable(){public void run(){
        if(disposed||activity.isFinishing()||activity.isDestroyed())return;
        PearlBridge.heartbeat();pearlTrajectory.setEnabledPrediction(pearl.isEnabled());
        if(pearl.isEnabled())pearlTrajectory.updateSnapshot(PearlBridge.predictionSnapshot());
        root.postDelayed(this,100);
    }};
    private long lastFastLog;
    private final Runnable fastHeartbeat=new Runnable(){public void run(){
        if(activity.isFinishing()||activity.isDestroyed())return;
        Entry buy=entries.get("auto_buy");if(buy!=null&&buy.enabled!=autoBuy.isEnabled()){buy.enabled=autoBuy.isEnabled();renderModules();if("auto_buy".equals(selected))renderDetails();}
        Entry aim=entries.get("aimbot");if(aim!=null&&aim.enabled!=aimbot.isEnabled()){aim.enabled=aimbot.isEnabled();renderModules();if("aimbot".equals(selected))renderDetails();}
        Entry slow=entries.get("no_slow");if(slow!=null&&slow.enabled!=noSlow.isEnabled()){slow.enabled=noSlow.isEnabled();renderModules();if("no_slow".equals(selected))renderDetails();}
        Entry timer=entries.get("local_timer");if(timer!=null&&timer.enabled!=localTimer.isEnabled()){timer.enabled=localTimer.isEnabled();renderModules();if("local_timer".equals(selected))renderDetails();}
        Entry trap=entries.get("block_trap");if(trap!=null&&trap.enabled!=blockTrap.isEnabled()){trap.enabled=blockTrap.isEnabled();renderModules();if("block_trap".equals(selected))renderDetails();}
        Entry still=entries.get("static_items");if(still!=null&&still.enabled!=staticItems.isEnabled()){still.enabled=staticItems.isEnabled();renderModules();if("static_items".equals(selected))renderDetails();}
        Entry prediction=entries.get("pearl_prediction");if(prediction!=null&&prediction.enabled!=pearl.isEnabled()){prediction.enabled=pearl.isEnabled();renderModules();if("pearl_prediction".equals(selected))renderDetails();}
        if(pearlStatus!=null)pearlStatus.setText(pearl.displayStatus());
        if(noSlowStatus!=null)noSlowStatus.setText(noSlow.displayStatus());
        if(localTimerStatus!=null)localTimerStatus.setText(localTimer.displayStatus());
        if(blockTrapStatus!=null)blockTrapStatus.setText(blockTrap.displayStatus());
        if(staticItemsStatus!=null)staticItemsStatus.setText(staticItems.displayStatus());
        if(autoBuyStatus!=null)autoBuyStatus.setText(autoBuy.status());
        if(aimbotStatus!=null)aimbotStatus.setText(aimbot.displayStatus());
        if(friendProtection!=null)friendProtection.setText(AimbotBridge.friendProtectionStatus());
        if(friendsList!=null)friendsList.setText(FriendStore.summary());
        FastExpBridge.heartbeat();
        AimbotBridge.heartbeat();
        NoSlowBridge.heartbeat();
        LocalTimerBridge.heartbeat();
        BlockTrapBridge.heartbeat();
        StaticItemsBridge.heartbeat();
        targetHud.updateSnapshot(AimbotBridge.targetSnapshot());
        updateHudData(android.os.SystemClock.uptimeMillis());
        if(friendPicking){prepareFriendPicking(android.os.SystemClock.uptimeMillis());updateFriendPreview();}
        if(scripts!=null)scripts.tick();
        long now=android.os.SystemClock.uptimeMillis();
        if(fastStart.due(now,true)&&GameEngineProbe.begin()){
            fastStart.begin();
            Thread worker=new Thread(()->{
                try{GameEngineProbe.run();}
                catch(RuntimeException|LinkageError error){GameRuntime.log("Fast Exp startup failed: "+error);}
                finally{GameEngineProbe.end();}
                activity.runOnUiThread(()->{
                    boolean alive=!activity.isFinishing()&&!activity.isDestroyed();
                    if(fastStart.result(android.os.SystemClock.uptimeMillis(),GameEngineProbe.playerFound()&&FastExpBridge.isReady(),alive)){
                        try{FastExpBridge.setEnabled(true);renderModules();renderDetails();GameRuntime.log("Fast Exp: startup request enabled in verified world");}
                        catch(RuntimeException|LinkageError error){GameRuntime.log("Fast Exp startup enable failed: "+error);}
                    }
                });
            },"fast-exp-startup");worker.setDaemon(true);worker.start();
        }
        if(now-lastFastLog>3000){lastFastLog=now;if(FastExpBridge.isEnabled())GameRuntime.log(FastExpBridge.describe());if(aimbot.isEnabled())GameRuntime.log(aimbot.status());if(noSlow.isEnabled())GameRuntime.log(noSlow.status());if(localTimer.isEnabled())GameRuntime.log(localTimer.status());if(blockTrap.isEnabled())GameRuntime.log(blockTrap.status());if(staticItems.isEnabled())GameRuntime.log(staticItems.status());if(pearl.isEnabled())GameRuntime.log(pearl.status());}
        root.postDelayed(this,400);
    }};
    private void toggle() { if (panel.getVisibility() == View.VISIBLE) close();else open(); }
    public void open() { if(hudLayout.isEditing())return;shade.setVisibility(View.VISIBLE);panel.setVisibility(View.VISIBLE);floating.bringToFront();if(friendPicking)friendPick.bringToFront(); }
    public void close() { panel.setVisibility(View.GONE);shade.setVisibility(View.GONE);floating.bringToFront();if(friendPicking)friendPick.bringToFront(); }
    public void dispose() {
        disposed=true;friendPicking=false;AimbotBridge.setFriendPicking(false);HudDataBridge.heartbeat(false);hudLayout.dispose();
        fastStart.cancel();
        pearl.dispose();pearlTrajectory.setEnabledPrediction(false);root.removeCallbacks(pearlHeartbeat);staticItems.dispose();noSlow.dispose();localTimer.dispose();blockTrap.dispose();aimbot.dispose();autoBuy.dispose();auctionInput.dispose();
        if(scripts!=null){scripts.close();scripts=null;}
        root.removeCallbacks(fastHeartbeat);FastExpBridge.setEnabled(false);
        for (Entry entry : entries.values()) if (entry.enabled && entry.callback != null) {
            try { entry.callback.setEnabled(false);entry.enabled = false; }
            catch (Exception | LinkageError error) { GameRuntime.log("Menu module cleanup failed: " + entry.id + " / " + error); }
        }
        detach(root);
    }
    private void fit() {
        if (root.getWidth() == 0 || root.getHeight() == 0) return;
        FrameLayout.LayoutParams bounds = (FrameLayout.LayoutParams) panel.getLayoutParams();
        int width = menuWidth(root.getWidth() * widthRatio);
        int height = menuHeight(root.getHeight() * heightRatio);
        if (bounds.width != width || bounds.height != height) { bounds.width = width;bounds.height = height;panel.setLayoutParams(bounds); }
        boolean useWide = width >= dp(620);if (useWide != wide) arrange(useWide);
        iconDrag.apply();friendDrag.apply();if (!resizing) panelDrag.apply();
    }
    private int menuWidth(float value) {
        int maximum = Math.max(1, root.getWidth() - dp(24));
        return Math.max(Math.min(dp(360), maximum), Math.min(Math.round(value), maximum));
    }
    private int menuHeight(float value) {
        int maximum = Math.max(1, root.getHeight() - dp(24));
        return Math.max(Math.min(dp(264), maximum), Math.min(Math.round(value), maximum));
    }
    private final class Resize {
        float rawX, rawY, anchorX, anchorY;int startWidth, startHeight, pointer = -1;
        boolean touch(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pointer = event.getPointerId(0);rawX = event.getRawX(0);rawY = event.getRawY(0);
                    anchorX = panel.getX();anchorY = panel.getY();startWidth = panel.getWidth();startHeight = panel.getHeight();
                    resizing = true;root.requestDisallowInterceptTouchEvent(true);return true;
                case MotionEvent.ACTION_MOVE: move(event);return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerId(event.getActionIndex()) == pointer) {
                        int next = event.getActionIndex() == 0 ? 1 : 0;pointer = event.getPointerId(next);
                        rawX = event.getRawX(next);rawY = event.getRawY(next);
                        startWidth = panel.getLayoutParams().width;startHeight = panel.getLayoutParams().height;
                    }
                    return true;
                case MotionEvent.ACTION_UP: move(event);finish();return true;
                case MotionEvent.ACTION_CANCEL: finish();return true;
                default: return true;
            }
        }
        void move(MotionEvent event) {
            int index = event.findPointerIndex(pointer);if (index < 0) return;
            int width = menuWidth(startWidth + event.getRawX(index) - rawX);
            int height = menuHeight(startHeight + event.getRawY(index) - rawY);
            // Limit growth to the space after the anchored top-left corner.
            width = Math.min(width, Math.max(1, (int) (root.getWidth() - anchorX)));
            height = Math.min(height, Math.max(1, (int) (root.getHeight() - anchorY)));
            widthRatio = width / (float) Math.max(1, root.getWidth());
            heightRatio = height / (float) Math.max(1, root.getHeight());
            FrameLayout.LayoutParams bounds = (FrameLayout.LayoutParams) panel.getLayoutParams();
            if (bounds.width != width || bounds.height != height) { bounds.width = width;bounds.height = height;panel.setLayoutParams(bounds); }
            panel.setX(anchorX);panel.setY(anchorY);
            panelDrag.x = anchorX / Math.max(1, root.getWidth() - width);
            panelDrag.y = anchorY / Math.max(1, root.getHeight() - height);
            boolean useWide = width >= dp(620);if (useWide != wide) arrange(useWide);
        }
        void finish() {
            pointer = -1;resizing = false;root.requestDisallowInterceptTouchEvent(false);
            preferences.edit().putFloat("panel.widthRatio", widthRatio).putFloat("panel.heightRatio", heightRatio).apply();
            panelDrag.save();
        }
    }
    private final class Drag {
        final View target;final String prefix;final Runnable tap;
        float x, y, rawX, rawY, startX, startY;int pointer = -1;boolean moved;
        Drag(View target, String prefix, float x, float y, Runnable tap) {
            this.target = target;this.prefix = prefix;this.tap = tap;
            this.x = preferences.getFloat(prefix + "x", x);this.y = preferences.getFloat(prefix + "y", y);
        }
        boolean touch(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pointer = event.getPointerId(0);rawX = event.getRawX(0);rawY = event.getRawY(0);
                    startX = target.getX();startY = target.getY();moved = false;root.requestDisallowInterceptTouchEvent(true);return true;
                case MotionEvent.ACTION_MOVE: move(event);return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerId(event.getActionIndex()) == pointer) {
                        int next = event.getActionIndex() == 0 ? 1 : 0;pointer = event.getPointerId(next);
                        rawX = event.getRawX(next);rawY = event.getRawY(next);startX = target.getX();startY = target.getY();moved = true;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    move(event);if (moved) save();else if (tap != null) tap.run();finish();return true;
                case MotionEvent.ACTION_CANCEL: if (moved) save();finish();return true;
                default: return true;
            }
        }
        void move(MotionEvent event) {
            int index = event.findPointerIndex(pointer);if (index < 0) return;
            float dx = event.getRawX(index) - rawX, dy = event.getRawY(index) - rawY;
            if (Math.hypot(dx, dy) > ViewConfiguration.get(activity).getScaledTouchSlop()) moved = true;
            if (!moved) return;
            int spanX = Math.max(0, root.getWidth() - target.getWidth()), spanY = Math.max(0, root.getHeight() - target.getHeight());
            target.setX(Math.max(0, Math.min(startX + dx, spanX)));target.setY(Math.max(0, Math.min(startY + dy, spanY)));
            if (spanX > 0) x = target.getX() / spanX;if (spanY > 0) y = target.getY() / spanY;
        }
        void apply() { target.setX(x * Math.max(0, root.getWidth() - target.getWidth()));target.setY(y * Math.max(0, root.getHeight() - target.getHeight())); }
        void save() { preferences.edit().putFloat(prefix + "x", x).putFloat(prefix + "y", y).apply(); }
        void finish() { pointer = -1;root.requestDisallowInterceptTouchEvent(false); }
    }
    private void setPalette(boolean light){
        lightTheme=light;
        palette=light?new int[]{0xff171717,0xff5c5c5c,0xff171717,0xfffafafa,0xffe4e4e4,0xfff0f0f0,0xffd6d6d6,0xffc7c7c7,0xffffffff,0xff806000}:
                new int[]{0xfff5f5f5,0xffababab,0xfff5f5f5,0xff101010,0xff292929,0xff1b1b1b,0xff383838,0xff444444,0xff151515,0xffd2b57b};
        INK=palette[0];MUTED=palette[1];ACCENT=palette[2];PANEL=palette[3];BUTTON=palette[4];CATEGORY=palette[5];SELECTED=palette[6];LINE=palette[7];ICON=palette[8];WARNING=palette[9];
    }
    private int remap(int color,int[] previous){for(int i=0;i<previous.length;i++)if(previous[i]==color)return palette[i];return color;}
    private void recolor(View view,int[] previous){
        if(view instanceof TextView){TextView text=(TextView)view;text.setTextColor(remap(text.getCurrentTextColor(),previous));}
        android.graphics.drawable.Drawable drawable=view.getBackground();
        if(drawable instanceof GradientDrawable){GradientDrawable shape=(GradientDrawable)drawable;android.content.res.ColorStateList color=shape.getColor();if(color!=null)shape.setColor(remap(color.getDefaultColor(),previous));}
        else if(drawable instanceof android.graphics.drawable.ColorDrawable){android.graphics.drawable.ColorDrawable color=(android.graphics.drawable.ColorDrawable)drawable;color.setColor(remap(color.getColor(),previous));}
        tintControl(view);
        if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++)recolor(group.getChildAt(i),previous);}
    }
    private void tintControl(View view){
        if(view instanceof CpsRangeView)((CpsRangeView)view).setColors(ACCENT,LINE);
        if(view instanceof Switch){Switch toggle=(Switch)view;
            toggle.setThumbTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{ACCENT,MUTED}));
            toggle.setTrackTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{SELECTED,LINE}));
        }
        if(view instanceof SeekBar){SeekBar bar=(SeekBar)view;bar.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));bar.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(LINE));}
    }
    private void changeTheme(boolean light){
        int[] previous=palette;setPalette(light);preferences.edit().putString("menu.theme",light?"white":"black").apply();
        recolor(root,previous);((GradientDrawable)floating.getBackground()).setStroke(dp(2),ACCENT);((GradientDrawable)friendPick.getBackground()).setStroke(dp(2),ACCENT);
        renderCategories();renderModules();renderDetails();GameRuntime.log("Menu theme: "+(light?"white":"black"));
    }
    private void renderThemeSettings(){
        Button white=button((lightTheme?"✓ ":"")+"Белая");details.addView(white,new LinearLayout.LayoutParams(-1,dp(52)));white.setOnClickListener(v->changeTheme(true));
        Button black=button((!lightTheme?"✓ ":"")+"Чёрная");details.addView(black,new LinearLayout.LayoutParams(-1,dp(52)));black.setOnClickListener(v->changeTheme(false));
        TextView hint=label("Тема меняется сразу: фон, текст, кнопки и круглая иконка kulich. Скрипт импортировать не нужно.",13);hint.setTextColor(MUTED);details.addView(hint);
    }
    private static void detach(View view) { if (view.getParent() instanceof ViewGroup) ((ViewGroup) view.getParent()).removeView(view); }
    private int dp(int value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }
    private TextView label(String text, int size) { TextView view = new TextView(activity);view.setText(text);view.setTextSize(size);view.setTextColor(INK);view.setGravity(Gravity.CENTER_VERTICAL);return view; }
    private Button button(String text) { Button view = new Button(activity);view.setText(text);view.setTextColor(INK);view.setTextSize(18);view.setAllCaps(false);view.setMinWidth(0);view.setMinimumWidth(0);view.setPadding(dp(4), 0, dp(4), 0);view.setBackground(background(BUTTON, 12));return view; }
    private View separator() { View view = new View(activity);view.setBackgroundColor(LINE);return view; }
    private GradientDrawable background(int color, int radius) { GradientDrawable shape = new GradientDrawable();shape.setColor(color);shape.setCornerRadius(dp(radius));return shape; }
}
