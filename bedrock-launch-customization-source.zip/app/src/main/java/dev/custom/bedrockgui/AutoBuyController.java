package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.SystemClock;
import android.os.Handler;
import android.os.Looper;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** UI-thread coordinator; reads on one worker, injects only in the hosted Activity. */
public final class AutoBuyController {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final BooleanSupplier available;
    private final Runnable pulse=new Runnable(){public void run(){
        if(!enabled||disposed)return;
        tick(available.getAsBoolean());
        if(enabled&&!disposed)handler.postDelayed(this,25);
    }};
    private final Activity activity;private final AuctionTapInput input;private final Consumer<String> notify;
    private AutoBuyCycle cycle;private boolean enabled,started,busy,disposed,initial;private int generation;
    private long nextRead;private String status="Выключен. Используются правила из твоего Auto Buy";
    public AutoBuyController(Activity activity,AuctionTapInput input,Consumer<String> notify,BooleanSupplier available){this.activity=activity;this.input=input;this.notify=notify;this.available=available;}
    public boolean isEnabled(){return enabled;}
    public String status(){return status;}
    private void report(String value){if(!status.equals(value)){status=value;GameRuntime.log("Auto Buy cycle: "+value);}}
    public void setEnabled(boolean value){
        if(!value){stop("Выключен");return;}
        if(disposed)throw new IllegalStateException("Игра закрывается");
        if(!input.readyForAutomation())throw new IllegalStateException("Готовый профиль недоступен: открой игру горизонтально");
        generation++;cycle=new AutoBuyCycle();enabled=true;started=false;initial=true;nextRead=0;
        report("Включён · обновление 0,3 с. Открой аукцион и закрой меню kulich");
        handler.removeCallbacks(pulse);handler.post(pulse);
    }
    private void stop(String reason){
        enabled=false;started=false;generation++;handler.removeCallbacks(pulse);input.cancelAutomatic();report(reason);notify.accept(reason);
    }
    public void inactive(){if(enabled)stop("Остановлен: игра потеряла фокус");}
    public void menuOpened(){if(enabled&&started)stop("Остановлен при открытии меню. Для продолжения включи снова");}
    public void tick(boolean available){
        if(!enabled||disposed)return;
        if(!available){if(started)stop("Остановлен: меню, калибровка или потеря фокуса");return;}
        if(busy||input.inputBusy()||SystemClock.uptimeMillis()<nextRead)return;
        if(!GameEngineProbe.begin())return;
        started=true;busy=true;int epoch=generation;boolean prepare=initial;initial=false;
        Thread worker=new Thread(()->{
            AutoBuyCycle.Snapshot state=null;
            try{
                if(prepare)GameEngineProbe.run();
                GameEngineProbe.auctionSnapshot(false);state=GameEngineProbe.auctionState();
            }catch(RuntimeException|LinkageError error){GameRuntime.log("Auto Buy worker failed: "+error.getClass().getSimpleName());}
            finally{GameEngineProbe.end();}
            AutoBuyCycle.Snapshot snapshot=state;
            activity.runOnUiThread(()->{
                busy=false;if(disposed||!enabled||epoch!=generation)return;
                if(activity.isFinishing()||activity.isDestroyed()||!activity.hasWindowFocus()){stop("Остановлен: игра не активна");return;}
                AutoBuyCycle.Action action=cycle.next(snapshot,SystemClock.uptimeMillis());report(action.message);nextRead=Math.max(SystemClock.uptimeMillis()+150,cycle.pollAfter());
                if(action.kind==AutoBuyCycle.Kind.STOP){stop(action.message);return;}
                if(action.kind==AutoBuyCycle.Kind.WAIT)return;
                AuctionMemoryProbe.ActionToken token=GameEngineProbe.actionToken(snapshot,action.slot);
                input.automatic(token,complete->{
                    if(disposed||!enabled||epoch!=generation)return;
                    if(!complete){
                        if(action.kind==AutoBuyCycle.Kind.REFRESH&&input.transientRefreshFailure()){
                            report("Перечитываю аукцион после изменения окна");nextRead=SystemClock.uptimeMillis()+AutoBuyCycle.REFRESH_INTERVAL_MS;
                        }else stop("Ввод отменён: окно или лот изменились. Проверь экран перед повторным включением");
                    }
                    else nextRead=Math.max(SystemClock.uptimeMillis()+(action.kind==AutoBuyCycle.Kind.REFRESH?20:600),cycle.pollAfter());
                });
            });
        },"auto-buy-cycle");worker.setDaemon(true);worker.start();
    }
    public void dispose(){disposed=true;stop("Auto Buy завершён вместе с игрой");}
}
