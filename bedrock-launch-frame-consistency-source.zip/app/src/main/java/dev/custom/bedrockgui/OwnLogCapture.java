package dev.custom.bedrockgui;

import android.content.Context;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/** Own UID only; record up to 20 minutes, retaining at most two 2 MiB segments. */
public final class OwnLogCapture {
    private static final int SEGMENT = 2 * 1024 * 1024;
    private static final OwnLogRecorder recorder=new OwnLogRecorder(20*60*1000L,SEGMENT,
            ()->new ProcessBuilder("/system/bin/logcat","--uid="+android.os.Process.myUid(),
                    "-v","threadtime","-T","1").redirectErrorStream(true).start(),
            android.os.SystemClock::elapsedRealtime);
    private OwnLogCapture() {}

    public static void start(Context context) {recorder.start(context.getFilesDir(),true);}
    public static boolean ensure(Context context) {return recorder.start(context.getFilesDir(),false);}
    public static void stop() {recorder.stop();}
    public static String tail(Context context) throws IOException {
        File directory = context.getFilesDir();
        File status = new File(directory, "own-logcat-status.txt");
        String state = status.isFile() ? new String(Files.readAllBytes(status.toPath()), StandardCharsets.UTF_8) :
                "Состояние записи недоступно.";
        byte[] bytes = new RollingLog(directory, SEGMENT).tail(256 * 1024);
        String problem=recorder.problem();
        return state + (problem.isEmpty()?"":"\n"+problem)+"\n" + (bytes.length == 0 ? "Собственный logcat не записан." :
                new String(bytes, StandardCharsets.UTF_8));
    }
}
