package dev.custom.bedrockgui;
import java.nio.charset.StandardCharsets;
/** A fresh native ray pick; never accepts a stale HUD or a decorated alias. */
public final class FriendPickData {
 private FriendPickData(){}
 public static String parse(String snapshot){
  try{
   if(snapshot==null||snapshot.length()>46)return "";
   String[] fields=snapshot.split("\\|",-1);if(fields.length!=2)return "";
   long age=Long.parseLong(fields[0]);String hex=fields[1];if(age<0||age>150||hex.length()%2!=0||hex.length()>32)return "";
   byte[] raw=new byte[hex.length()/2];for(int i=0;i<raw.length;i++){int a=Character.digit(hex.charAt(i*2),16),b=Character.digit(hex.charAt(i*2+1),16);if(a<0||b<0)return "";raw[i]=(byte)(a*16+b);}
   String nick=new String(raw,StandardCharsets.UTF_8);return FriendCommands.normalize(nick).isEmpty()?"":nick;
  }catch(RuntimeException error){return "";}
 }
}
