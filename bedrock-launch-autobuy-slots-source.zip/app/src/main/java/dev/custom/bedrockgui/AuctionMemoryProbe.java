package dev.custom.bedrockgui;

import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.function.Consumer;

/** Read-only candidate container snapshot. It never calls game methods or clicks slots. */
public final class AuctionMemoryProbe {
    public static final class TapToken {
        final long player,client,manager,node,model,vector,vptr,tag;final int slots;final EmptyTarget destination;
        TapToken(long player,long client,long manager,long node,long model,long vector,long vptr,long tag,int slots){
            this.player=player;this.client=client;this.manager=manager;this.node=node;this.model=model;this.vector=vector;this.vptr=vptr;this.tag=tag;this.slots=slots;this.destination=null;
        }
        private TapToken(TapToken p,EmptyTarget d){player=p.player;client=p.client;manager=p.manager;node=p.node;model=p.model;vector=p.vector;vptr=p.vptr;tag=p.tag;slots=p.slots;destination=d;}
        public int destinationSlot(){return destination==null?-1:destination.slot;}
    }
    /** Bound to one stable LevelContainerModel, never a player inventory window. */
    public static final class ActionToken {
        final TapToken window;final AutoBuyCycle.Lot source,preview,back;final EmptyTarget inventory;
        public final int slot,slots;
        public long[] nativeFields(){
            return new long[]{window.player,window.client,window.manager,window.node,window.model,window.vector,window.slots,slot,
                    source.tag,source.count,source.item,inventory.node,inventory.model,inventory.vector,inventory.slot,
                    preview==null?0:preview.tag,preview==null?0:preview.count,preview==null?0:preview.item,back==null?0:back.tag};
        }
        ActionToken(TapToken window,AutoBuyCycle.Lot source,AutoBuyCycle.Lot preview,AutoBuyCycle.Lot back,EmptyTarget inventory){
            this.window=window;this.source=source;this.preview=preview;this.back=back;this.inventory=inventory;
            slot=source.slot;slots=window.slots;
        }
    }
    private final Map<Integer,AutoBuyCycle.Lot> windowLots=new TreeMap<>();
    private final Map<String,Integer> inventoryCounts=new HashMap<>();
    private TapToken windowToken;private boolean inventoryRead,invalidSnapshot;private final Set<Integer> skippedLots=new HashSet<>();
    public AutoBuyCycle.Snapshot snapshot(){
        return new AutoBuyCycle.Snapshot(windowSlots,windowLots,inventoryCounts,
                !invalidSnapshot&&windowToken!=null&&inventoryRead,inventoryTarget!=null,windowToken,skippedLots.size());
    }
    public ActionToken actionToken(AutoBuyCycle.Snapshot snapshot,int slot){
        if(snapshot==null||!snapshot.complete||!snapshot.space||snapshot.handle!=windowToken)return null;
        AutoBuyCycle.Lot source=snapshot.at(slot);if(source==null)return null;
        boolean refresh=windowSlots==54&&slot==49&&source.control("Обновить");
        boolean open=windowSlots==54&&slot>=0&&slot<45&&source.verdict.accepted;
        boolean buy=windowSlots==27&&slot==10&&source.control("Купить")&&snapshot.at(16)!=null&&snapshot.at(16).control("Вернуться")&&snapshot.at(13)!=null&&snapshot.at(13).verdict.accepted;
        boolean back=windowSlots==27&&slot==16&&source.control("Вернуться")&&snapshot.at(13)!=null&&snapshot.at(13).verdict.accepted;
        if(!refresh&&!open&&!buy&&!back)return null;
        return new ActionToken(windowToken,source,buy||back?snapshot.at(13):null,buy||back?snapshot.at(16):null,inventoryTarget);
    }
    private AutoBuyCycle.Lot lot(byte[] stacks,int index)throws IOException {
        int offset=index*152,count=stacks[offset+34]&255;if(count==0)return null;
        long tag=q(stacks,offset+16),handle=q(stacks,offset+8),item=pointer(handle),type=pointer(item);
        NbtDisplayReader.Display d=tag==0?null:new NbtDisplayReader(this::read,base).readItem(tag);
        if(tag!=0&&d==null)return null;
        String kind=type==base+0x13d89030L?"sword":type==base+0x13d9de58L?"book":"";
        return new AutoBuyCycle.Lot(index,count,item,tag,d==null?"":d.name,kind,d==null?Collections.emptyList():d.lore,d==null?Collections.emptyMap():d.ench);
    }
    private AutoBuyCycle.Lot liveLot(TapToken w,int slot)throws IOException {
        byte[] data=read(w.vector+slot*152L,152);if(data==null||q(data,0)!=base+0x13d95ff8L)return null;
        AutoBuyCycle.Lot value=lot(data,0);return value==null?null:relocate(value,slot);
    }
    private AutoBuyCycle.Lot relocate(AutoBuyCycle.Lot lot,int slot){return new AutoBuyCycle.Lot(slot,lot.count,lot.item,lot.tag,lot.name,lot.kind,lot.lore,lot.ench);}
    private boolean sameSlot(AutoBuyCycle.Lot expected,AutoBuyCycle.Lot actual){
        if(expected==null||actual==null||expected.tag!=actual.tag||expected.item!=actual.item||expected.count!=actual.count||!expected.name.equals(actual.name)||!expected.ench.equals(actual.ench))return false;
        return expected.verdict.accepted?expected.sameOffer(actual):expected.lore.equals(actual.lore);
    }
    private boolean ownsNode(TapToken w)throws IOException {
        long first=pointer(w.manager+192),node=first;Set<Long> seen=new HashSet<>();
        for(int n=0;node!=0&&n<32&&seen.add(node);n++){
            if(node==w.node)return pointer(node+40)==w.model&&pointer(w.manager+192)==first;
            node=pointer(node);
        }
        return false;
    }
    public boolean validateAction(ActionToken token,boolean full)throws IOException {
        reads=0;deadline=System.nanoTime()+100000000L;
        if(token==null)return false;TapToken w=token.window;
        if(pointer(w.player)!=base+0x139f6ea0L||pointer(w.player+3240)!=w.client||pointer(w.player+0x578)!=w.manager||
                pointer(w.manager)!=base+0x137e8f20L||pointer(w.node+40)!=w.model)return false;
        byte[] model=read(w.model,240);
        if(model==null||q(model,0)!=base+0x13d34298L||q(model,216)!=w.vector||q(model,224)-w.vector!=w.slots*152L)return false;
        TapToken withInventory=new TapToken(w,token.inventory);
        if(!ownsNode(w)||!inventoryValid(withInventory,full))return false;
        if(full){
            if(!sameSlot(token.source,liveLot(w,token.slot)))return false;
            if(token.preview!=null&&(!sameSlot(token.preview,liveLot(w,13))||!sameSlot(token.back,liveLot(w,16))))return false;
        }
        return Arrays.equals(model,read(w.model,240))&&pointer(w.player+0x578)==w.manager&&ownsNode(w);
    }
    private static final class EmptyTarget {
        final long model,node,vector;final int slot;
        EmptyTarget(long model,long node,long vector,int slot){this.model=model;this.node=node;this.vector=vector;this.slot=slot;}
    }
    private EmptyTarget inventoryTarget;
    private TapToken refreshToken;private int windowSlots;
    public int windowSlots(){return windowSlots;}
    public TapToken token(int slots){return slots==54&&refreshToken!=null&&inventoryTarget!=null?new TapToken(refreshToken,inventoryTarget):null;}
    private static String plain(String name){return name.replaceAll("§.","").trim().toLowerCase(Locale.ROOT);}
    public boolean validateTap(TapToken token)throws IOException {
        reads=0;deadline=System.nanoTime()+100000000L;
        if(token==null||token.slots!=54||token.destination==null||!inventoryValid(token,true)||pointer(token.player)!=base+0x139f6ea0L||
                pointer(token.player+3240)!=token.client||pointer(token.player+0x578)!=token.manager||
                pointer(token.manager)!=base+0x137e8f20L||pointer(token.node+40)!=token.model)return false;
        byte[] model=read(token.model,240);int slot=49;
        if(model==null||q(model,0)!=token.vptr||q(model,216)!=token.vector||q(model,224)-token.vector!=token.slots*152L)return false;
        byte[] stack=read(token.vector+slot*152L,152);
        if(stack==null||q(stack,0)!=base+0x13d95ff8L||q(stack,16)!=token.tag)return false;
        NbtDisplayReader.Display display=new NbtDisplayReader(this::read,base).read(token.tag);
        return display!=null&&plain(display.name).equals("обновить")&&Arrays.equals(model,read(token.model,240))&&
                pointer(token.player+0x578)==token.manager&&pointer(token.node+40)==token.model;
    }
    private boolean inventoryValid(TapToken token,boolean empty)throws IOException {
        EmptyTarget d=token.destination;if(d==null||pointer(d.node+40)!=d.model)return false;
        byte[] model=read(d.model,240);
        if(model==null||q(model,0)!=base+0x13d341b0L||q(model,216)!=d.vector||q(model,224)-d.vector!=27*152L)return false;
        byte[] slot=read(d.vector+d.slot*152L,152);
        return slot!=null&&q(slot,0)==base+0x13d95ff8L&&(!empty||(slot[34]&255)==0);
    }
    public boolean validateDragWindow(TapToken token)throws IOException {
        reads=0;deadline=System.nanoTime()+100000000L;
        if(token==null||token.slots!=54||pointer(token.player)!=base+0x139f6ea0L||pointer(token.player+3240)!=token.client||
                pointer(token.player+0x578)!=token.manager||pointer(token.manager)!=base+0x137e8f20L||pointer(token.node+40)!=token.model)return false;
        byte[] model=read(token.model,240);
        return model!=null&&q(model,0)==token.vptr&&q(model,216)==token.vector&&q(model,224)-token.vector==54*152L&&inventoryValid(token,false);
    }
    private final List<EngineMemoryProbe.Region> regions;
    private final EngineMemoryProbe.Reader reader;private final long base;private final Consumer<String> log;private final boolean diagnostics;
    private int reads;private long deadline;
    public AuctionMemoryProbe(List<EngineMemoryProbe.Region> regions,EngineMemoryProbe.Reader reader,long base,Consumer<String> log){
        this(regions,reader,base,log,true);
    }
    public AuctionMemoryProbe(List<EngineMemoryProbe.Region> regions,EngineMemoryProbe.Reader reader,long base,Consumer<String> log,boolean diagnostics){
        this.regions=new ArrayList<>(regions);this.regions.sort(Comparator.comparingLong(r->r.start));this.reader=reader;this.base=base;this.log=log;this.diagnostics=diagnostics;
    }
    private static long ptr(long p){return EngineMemoryProbe.untag(p);}
    private byte[] read(long address,int size)throws IOException {
        address=ptr(address);
        if(address==0||size<0||reads>=8000||System.nanoTime()>deadline)return null;
        int low=0,high=regions.size()-1;EngineMemoryProbe.Region mapping=null;
        while(low<=high){int mid=(low+high)>>>1;EngineMemoryProbe.Region r=regions.get(mid);
            if(address<r.start)high=mid-1;else if(address>=r.end)low=mid+1;else{mapping=r;break;}}
        if(mapping==null||!mapping.readable||!mapping.writable||size>mapping.end-address)return null;
        reads++;byte[] data=new byte[size];
        try{return reader.read(address,data,size)?data:null;}catch(IOException error){return null;}
    }
    private static long q(byte[] data,int offset){return ptr(ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).getLong(offset));}
    private static boolean sameStack(byte[] before,byte[] after,int index){
        if(before==null||after==null||before.length!=after.length)return false;
        int start=index*152;return Arrays.equals(before,start,start+152,after,start,start+152);
    }
    private long pointer(long address)throws IOException {byte[] bytes=read(address,8);return bytes==null?0:q(bytes,0);}
    public String scan(long player,long client)throws IOException {
        refreshToken=null;inventoryTarget=null;windowSlots=0;windowToken=null;windowLots.clear();inventoryCounts.clear();skippedLots.clear();inventoryRead=false;invalidSnapshot=false;
        reads=0;deadline=System.nanoTime()+2000000000L;player=ptr(player);client=ptr(client);
        byte[] actor=read(player,4304);
        if(actor==null||q(actor,0)!=base+0x139f6ea0L||q(actor,3240)!=client||client==0)
            return "Игрок изменился. Открой аукцион и повтори чтение.";
        Set<Long> managers=new LinkedHashSet<>();
        if(!diagnostics){
            // Exact build already checked by SHA: current owner field is known.
            long manager=q(actor,0x578);
            if(manager!=0&&pointer(manager)==base+0x137e8f20L)managers.add(manager);
        }else{
        for(int offset=0;offset+8<=actor.length;offset+=8){
            long candidate=q(actor,offset);
            if(candidate!=0&&pointer(candidate)==base+0x137e8f20L){
                managers.add(candidate);log.accept("Auto Buy: ChestContainerManagerModel at player+0x"+Integer.toHexString(offset));
            }
        }
        }
        if(managers.isEmpty())return "Открытый сундуковый контейнер пока не найден. Покупки не выполнялись.";
        List<String> candidates=new ArrayList<>();Set<Long> seen=new HashSet<>();
        for(long manager:managers){
            byte[] state=read(manager,216);if(state==null||q(state,0)!=base+0x137e8f20L)continue;
            // Exact build: model map at +176; libc++ first-node link at +16.
            long node=q(state,192);
            log.accept("Auto Buy: model map first="+Long.toHexString(node)+" size="+q(state,200));
            for(int n=0;node!=0&&n<32&&seen.add(node);n++){
                byte[] entry=read(node,56);if(entry==null){invalidSnapshot=true;break;}
                long model=q(entry,40);
                byte[] object=read(model,240);
                long modelVptr=object==null?0:q(object,0);
                log.accept("Auto Buy: map model vptr offset=0x"+Long.toHexString(modelVptr-base));
                // These derived vtables retain exactly the same vector size/index getters.
                if(object!=null&&(modelVptr==base+0x13d35930L||modelVptr==base+0x13d34298L||
                        modelVptr==base+0x13d341b0L||modelVptr==base+0x13d34468L)){
                    // Disassembly 0x10169ba4/0x10169bd0: vector at +216,
                    // indexing uses 152-byte ItemStack objects. Do not infer names/prices.
                    long begin=q(object,216),end=q(object,224),capacity=q(object,232);
                    long bytes=end-begin;
                    if(begin!=0&&end>=begin&&capacity>=end&&capacity-begin<=152L*4096&&bytes%152==0&&(bytes/152==27||bytes/152==54)){
                        int slots=(int)(bytes/152);byte[] stacks=read(begin,(int)bytes);boolean valid=stacks!=null;
                        // Only the auction LIST tolerates independently changing cells.
                        // Confirmation and receipt/inventory snapshots stay all-or-nothing.
                        boolean perSlot=modelVptr==base+0x13d34298L&&slots==54;
                        StringBuilder amounts=new StringBuilder();int nonEmpty=0;
                        if(valid)for(int i=0;i<slots;i++){
                            if(q(stacks,i*152)!=base+0x13d95ff8L){valid=false;break;}
                            int count=stacks[i*152+34]&255;
                            if(count>0){nonEmpty++;if(amounts.length()>0)amounts.append(", ");amounts.append(i).append(':').append(count);}
                        }
                        byte[] current=read(model,240),currentStacks=read(begin,(int)bytes);
                        if(valid&&current!=null&&currentStacks!=null&&Arrays.equals(object,current)&&(perSlot||Arrays.equals(stacks,currentStacks))&&
                                pointer(player)==base+0x139f6ea0L&&pointer(player+3240)==client&&pointer(manager)==base+0x137e8f20L&&pointer(node+40)==model&&pointer(manager+192)==q(state,192)){
                            String value="Container candidate: slots="+slots+" nonEmpty="+nonEmpty+" slotCounts={"+amounts+"}";
                            log.accept("Auto Buy: "+value);candidates.add(value);
                            if(modelVptr==base+0x13d34298L){
                                if(windowToken!=null)invalidSnapshot=true;
                                windowSlots=slots;windowToken=new TapToken(player,client,manager,node,model,begin,modelVptr,0,slots);
                            }
                            if(modelVptr==base+0x13d341b0L&&slots==27){if(inventoryRead)invalidSnapshot=true;inventoryRead=true;}
                            for(int index=0;index<slots;index++)if((stacks[index*152+34]&255)>0){
                                if(perSlot&&!sameStack(stacks,currentStacks,index)){skippedLots.add(index);continue;}
                                AutoBuyCycle.Lot decodedLot=lot(stacks,index);
                                if(decodedLot==null){if(perSlot)skippedLots.add(index);else invalidSnapshot=true;continue;}
                                if(modelVptr==base+0x13d34298L)windowLots.put(index,decodedLot);
                                if(modelVptr==base+0x13d341b0L&&slots==27)inventoryCounts.merge(decodedLot.itemKey(),decodedLot.count,Integer::sum);
                            }
                            byte[] finalStacks=read(begin,(int)bytes);
                            if(finalStacks==null||!Arrays.equals(object,read(model,240)))invalidSnapshot=true;
                            else if(perSlot){
                                // Keep only cells unchanged across all three vector reads.
                                // A changing/undecodable neighbour cannot authorize its own action.
                                for(int index=0;index<slots;index++)if(!sameStack(stacks,currentStacks,index)||!sameStack(stacks,finalStacks,index)){
                                    windowLots.remove(index);skippedLots.add(index);
                                }
                            }else if(!Arrays.equals(stacks,finalStacks))invalidSnapshot=true;
                            if(modelVptr==base+0x13d341b0L&&slots==27&&inventoryTarget==null){
                                for(int i=0;i<27;i++)if((stacks[i*152+34]&255)==0){inventoryTarget=new EmptyTarget(model,node,begin,i);log.accept("Auto Buy input: empty player inventory slot="+i);break;}
                            }
                            if(diagnostics){NbtDisplayReader nbt=new NbtDisplayReader(this::read,base);int decoded=0,typed=0,matches=0,listed=0;
                            List<AutoBuyMatcher.Rule> rules=AutoBuyDefaultRules.rules();
                            for(int i=0;i<slots;i++)if((stacks[i*152+34]&255)>0){
                                // Exact ItemStackBase copy/destructor use userdata at +16.
                                // +24 is a different copied field; require CompoundTag before decoding.
                                long tag=q(stacks,i*152+16);
                                byte[] type=read(tag,8);
                                if(type==null||q(type,0)!=base+0x13ebe0b0L)continue;
                                typed++;
                                NbtDisplayReader.Display display=nbt.read(tag);
                                if(display!=null){
                                    decoded++;int count=stacks[i*152+34]&255;
                                    log.accept("Auto Buy lot: slot="+i+" count="+count+" "+display.log());
                                    if(modelVptr==base+0x13d34298L&&slots==54&&i==49&&plain(display.name).equals("обновить")){
                                        TapToken token=new TapToken(player,client,manager,node,model,begin,modelVptr,tag,slots);
                                        refreshToken=token;
                                    }
                                    if(modelVptr==base+0x13d34298L&&slots==54&&i<45){
                                        long handle=q(stacks,i*152+8),item=pointer(handle),itemType=pointer(item);
                                        String kind=itemType==base+0x13d89030L?"sword":itemType==base+0x13d9de58L?"book":"";
                                        AutoBuyMatcher.Verdict verdict=AutoBuyMatcher.evaluate(display.name,display.lore,count,kind,display.ench,rules);
                                        if(verdict.candidate){listed++;if(verdict.accepted)matches++;log.accept("Auto Buy decision: slot="+i+" "+verdict.log());}
                                    }
                                }
                            }
                            log.accept("Auto Buy: CompoundTag userdata="+typed+" display entries decoded="+decoded);
                            if(modelVptr==base+0x13d34298L&&slots==54){
                                String selection="Подбор: лотов из списка="+listed+", подходят="+matches+". Оценка по правилам.";
                                candidates.add(selection);log.accept("Auto Buy: "+selection);
                            }
                        }}else {invalidSnapshot=true;log.accept("Auto Buy: changed/invalid container snapshot rejected");}
                    }else log.accept("Auto Buy: vector rejected begin="+Long.toHexString(begin)+" bytes="+bytes+" capacityBytes="+(capacity-begin));
                }
                node=q(entry,0);
            }
            if(reads>=8000||System.nanoTime()>deadline){invalidSnapshot=true;log.accept("Auto Buy: read/time budget reached; diagnostic output may be partial");break;}
            if(pointer(manager+192)!=q(state,192)){invalidSnapshot=true;return "Окно контейнера изменилось. Повтори чтение. Покупки не выполнялись.";}
        }
        return candidates.isEmpty()?"Менеджер контейнера найден, но лоты пока не прочитаны. Покупки не выполнялись.":
                String.join("\n",candidates)+"\nСнимок и доступные названия/описания записаны в журнал. Автоматические действия управляются переключателем Auto Buy.";
    }
}
