package dev.custom.bedrockgui;
public final class FriendPickDataTest {
 static void check(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] a){
  check(FriendPickData.parse("20|416c65785f31").equals("Alex_1"));
  check(FriendPickData.parse("150|416e6e").equals("Ann"));
  for(String value:new String[]{"151|416e6e","-1|416e6e","0|zz","0|a","0|5b5649505d416e6e","0|","0|00","","1|41|42"})check(FriendPickData.parse(value).isEmpty());
  check(FriendPickData.parse(null).isEmpty());System.out.println("PASS: fresh crosshair pick decoding, exact nick, expiry and malformed snapshots");
 }
}
