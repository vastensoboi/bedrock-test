# Block placement binding for 0.69

Verified against the supplied exact Minecraft 1.26.60.4 ARM64 library. Native
calls run only during the current local player's game-thread callback after
entity ownership, friend, held stack, support collision and distance checks.

`GameMode` primary vptr is `0x13d227d0`; `SurvivalMode` is `0x13d22900`.
Slot 6 (+48), `0x1009e28c`, starts building by clearing the native build state
and forwarding to slot 7 (+56), `0x1009e2a0`, with final boolean false. The
Survival wrappers are `0x100a13d8` and `0x100a1408`. The latter accepts
`(mode, clickedSupportPosition, face, hand, repeat)`; hand zero selects the
main hand through `Actor::getItemInHand` at `0xfd9c620`.

The high-level build path also reads the game's current global hit result.
For an explicit trap placement, use the same lower-level virtual slot 14
(+112) that this high-level path invokes. Its exact ABI is:

```
uint32_t useOn(GameMode*, ItemStack*, const BlockPos* clickedSupport,
               uint8_t face, const Vec3* worldHit, uint32_t hand,
               const Block* optionalExpected, bool firstUse)
```

The vanilla first-use lambda at `0x100a3d98..0x100a3dcc` supplies the selected
stack, clicked support position, face and world hit coordinates, with hand
zero, optional expected block null and `firstUse=true`. `0x1009f3e8..0x1009f430`
subtracts the support position from the world hit coordinates. Consequently
the helper supplies the support face centre in world coordinates, rather
than passing a local `.5,.5,.5` coordinate. The position is the SUPPORT block,
not the adjacent empty cell that the placed block occupies.

The slot 14 function is `0x1009f214` for GameMode and `0x100a1480` for Survival.
Use the actual bound virtual callback so the Survival wrapper's native
restrictions remain active. The native returned bit 0 means the local use
action was accepted; bit 1 requests a swing (vanilla animation branch at
`0x100a40d0..0x100a40fc`). Neither proves a server-confirmed placement.

Read the selected hotbar slot from verified PlayerInventory+16, reject
suspended state +176, and obtain its Inventory+184 vector of 152-byte stacks
at +320/+328. ItemStack count is byte +34. The same native
`ItemStack` block-state callback `0x107772cc` used by the item renderer obtains
a held `Block*`. The earlier `0x10777338` callback returns `BlockType*`, which
must not be passed to the `Block` state classifier. The state getter checks
Item virtual +80 and calls virtual +56 for the type, then `0x10919948` returns
its default state at type+512; the fallback reads ItemStack+24. Reject a null block instead of dispatching a general item
interaction. Re-read slot, count, item handle, vector and GameMode bindings
after classification. Raw MTE allocation tags are preserved for native calls.

Terrain and support classification are described in `block-query-0.69.md`.
Only explicit air targets and supported inert block types are candidates;
the collision ray and original placement path still decide actual validity.
There is no raw packet fabrication, global hit-result overwrite, direct world
mutation or silent hotbar switching. Host guards can be tested without calling
game functions. APK linking and on-device placement still require validation.
