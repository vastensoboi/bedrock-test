#pragma once
#include "aim_camera.h"
#include <array>
namespace kulich_pearl_camera {
using namespace kulich_aim;
constexpr A RENDER_CAMERA_GETTER=0x9c708ecULL;
constexpr uint32_t RENDER_CAMERA=0x119e772bU;
constexpr uint32_t LIQUID_OFFSET=0x94f91476U;
constexpr double DEGREES=180.0/3.14159265358979323846;
// Exact arm64 image only. The renderer at 0xb7cf720 resolves CameraComponent
// stride280 from getRenderCamera (0x9c708ec), not the input/active camera.
// 0xb7cf854..974 builds V = extra(+84) * inverse(mat4(quaternion(+40))).
// 0xb7cf990..9fc builds P00=1/(aspect*tan(fov/2)), P11=1/tan(fov/2).
struct NativeFields {
 float quaternion[4]{},origin[3]{},aspect=0,verticalFov=0,nearPlane=0,farPlane=0,extra[16]{};
};
static_assert(sizeof(NativeFields)==108&&offsetof(NativeFields,origin)==16&&
 offsetof(NativeFields,verticalFov)==32&&offsetof(NativeFields,extra)==44,"Render camera field layout");
struct Camera {
 A component=0;Vec origin{};Angles pose{};double aspect=0,verticalFov=0,nearPlane=0;
 // Column-major view transform of world-origin, including native bob/roll.
 std::array<double,16> view{};
};
inline bool decode(const NativeFields& f,Camera& out){
 for(float v:f.quaternion)if(!std::isfinite(v))return false;
 double x=f.quaternion[0],y=f.quaternion[1],z=f.quaternion[2],w=f.quaternion[3];
 double norm=x*x+y*y+z*z+w*w;if(norm<.90||norm>1.10)return false;
 for(float v:f.origin)if(!std::isfinite(v)||std::abs(v)>32000000)return false;
 if(!std::isfinite(f.aspect)||f.aspect<.05f||f.aspect>20||!std::isfinite(f.verticalFov)||
  f.verticalFov<.0174532925f||f.verticalFov>3.12413936f||!std::isfinite(f.nearPlane)||
  f.nearPlane<=0||f.nearPlane>100||!std::isfinite(f.farPlane)||f.farPlane<=f.nearPlane||f.farPlane>1e8)return false;
 for(float v:f.extra)if(!std::isfinite(v)||std::abs(v)>1e6)return false;
 if(std::abs(f.extra[15])<1e-6)return false;
 // Native quaternion->matrix (0x9c75908), followed by the actual inverse.
 double r[9]={1-2*y*y-2*z*z,2*x*y+2*w*z,2*x*z-2*w*y,
  2*x*y-2*w*z,1-2*x*x-2*z*z,2*y*z+2*w*x,
  2*x*z+2*w*y,2*y*z-2*w*x,1-2*x*x-2*y*y};
 double det=r[0]*(r[4]*r[8]-r[7]*r[5])-r[3]*(r[1]*r[8]-r[7]*r[2])+r[6]*(r[1]*r[5]-r[4]*r[2]);
 if(!std::isfinite(det)||std::abs(det)<.5||std::abs(det)>1.5)return false;
 double inv[16]={(r[4]*r[8]-r[7]*r[5])/det,(r[7]*r[2]-r[1]*r[8])/det,(r[1]*r[5]-r[4]*r[2])/det,0,
  (r[6]*r[5]-r[3]*r[8])/det,(r[0]*r[8]-r[6]*r[2])/det,(r[3]*r[2]-r[0]*r[5])/det,0,
  (r[3]*r[7]-r[6]*r[4])/det,(r[6]*r[1]-r[0]*r[7])/det,(r[0]*r[4]-r[3]*r[1])/det,0,0,0,0,1};
 Camera value{};value.origin={f.origin[0],f.origin[1],f.origin[2]};
 value.aspect=f.aspect;value.verticalFov=f.verticalFov*DEGREES;value.nearPlane=f.nearPlane;
 for(int c=0;c<4;c++)for(int row=0;row<4;row++)for(int k=0;k<4;k++)value.view[c*4+row]+=double(f.extra[k*4+row])*inv[c*4+k];
 // Kept for top-down fallback and old six-value consumers. Perspective should
 // use view, since pitch/yaw alone cannot represent native bob or camera roll.
 double fx=-r[6],fy=-r[7],fz=-r[8];
 value.pose={float(-std::atan2(fy,std::hypot(fx,fz))*DEGREES),float(std::atan2(-fx,fz)*DEGREES)};
 out=value;return true;
}
template<class Read> bool readCamera(Read& read,const CameraContext& context,Camera& out){
 A registry=plain(context.registry);if(context.present!=1||registry<4096||plain(context.storage)!=registry+40||
  (context.entity&0x3ffffU)==0x3ffffU||sparse(read,registry+216,context.entity)<0)return false;
 A rendered=pool(read,registry,RENDER_CAMERA);
 if(!rendered||sparse(read,rendered+8,context.entity)<0)return false;
 A camera=taggedComponent(read,pool(read,registry,CAMERA),context.entity,280);NativeFields fields{};
 if(!camera||!read(plain(camera)+40,&fields,sizeof fields))return false;
 Camera value{};if(!decode(fields,value))return false;
 // Renderer 0xb7cfa20..faf8 adds the optional liquid-camera offset to origin Y.
 A liquid=component(read,pool(read,registry,LIQUID_OFFSET),context.entity,4);
 if(liquid){float y=0;if(!read(liquid,&y,sizeof y)||!std::isfinite(y)||std::abs(y)>1000)return false;value.origin.y+=y;}
 value.component=camera;out=value;return true;
}
}
