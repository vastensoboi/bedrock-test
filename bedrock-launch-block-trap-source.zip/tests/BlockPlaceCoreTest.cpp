#include "../app/src/main/cpp/block_place_core.h"
#include <cassert>
#include <iostream>
#include <unordered_map>
using namespace kulich_block_place;
struct Memory {
 std::unordered_map<A,unsigned char> bytes;
 template<class T> void put(A at,T value){auto* p=reinterpret_cast<unsigned char*>(&value);for(size_t i=0;i<sizeof value;i++)bytes[plain(at)+i]=p[i];}
 bool operator()(A at,void* out,size_t size){auto* p=static_cast<unsigned char*>(out);at=plain(at);for(size_t i=0;i<size;i++){auto it=bytes.find(at+i);if(it==bytes.end())return false;p[i]=it->second;}return true;}
};
struct Fixture {
 Memory m;static constexpr A base=0x10000000,client=0x200000,player=0x210000,mode=0x220000,proxy=0x230000,inventory=0x240000,begin=0x250000,handle=0x260000,item=0x270000,block=0x280000,tag=0xb400000000000000ULL;
 static constexpr int slot=4;A stack=begin+slot*152;
 Fixture(){
  m.put(client,base+0x1388fe70ULL);m.put(player,base+0x139f6ea0ULL);m.put(player+3240,client|tag);m.put(player+2568,mode|tag);m.put(mode,base+0x13d227d0ULL);m.put(mode+8,player|tag);m.put(base+0x13d227d0ULL+112,base+USE_ON);
  m.put(player+1424,proxy|tag);m.put(proxy,base+0x13d43520ULL);m.put(proxy+16,int32_t(slot));m.put<uint8_t>(proxy+176,0);m.put(proxy+184,inventory|tag);m.put(inventory,base+0x13d42b08ULL);m.put(inventory+320,begin|tag);m.put(inventory+328,(begin+36*152)|tag);
  m.put(stack,base+0x13d95ff8ULL);m.put<uint8_t>(stack+34,32);m.put(stack+8,handle|tag);m.put(handle,item|tag);m.put(item,base+0x13d9a028ULL);m.put(base+0x13d9a028ULL+56,base+0x107a0ba8ULL);
 }
};
struct Call {A mode=0,stack=0;Position support{};uint8_t face=0;Vec3 hit{};unsigned calls=0;};
static Call observed;
uint32_t use(void* mode,void* stack,const Position* support,uint8_t face,const Vec3* hit,uint32_t hand,const void* expected,bool first){
 observed={reinterpret_cast<A>(mode),reinterpret_cast<A>(stack),*support,face,*hit,observed.calls+1};
 assert(hand==0&&expected==nullptr&&first);return 3;
}
int main(){
 Fixture f;Held held{};int reason=0;A captured=0;auto before=f.m.bytes;
 auto getter=[&](A stack){captured=stack;return Fixture::block|Fixture::tag;};
 assert(resolveHeld(f.m,Fixture::base,Fixture::client,Fixture::player|Fixture::tag,held,getter,&reason));
 assert(reason==0&&held.slot==Fixture::slot&&held.count==32&&held.mode==(Fixture::mode|Fixture::tag)&&held.stack==(f.stack|Fixture::tag)&&held.player==(Fixture::player|Fixture::tag)&&held.block==(Fixture::block|Fixture::tag)&&captured==held.stack&&f.m.bytes==before);
 Vec3 centre{};assert(faceCentre({5,64,-7},1,centre)&&centre.x==5.5f&&centre.y==65&&centre.z==-6.5f);
 assert(dispatchPlace(&use,held.mode,held.stack,{5,64,-7},1,centre)==3&&observed.calls==1&&observed.mode==held.mode&&observed.stack==held.stack&&observed.face==1&&observed.support.y==64&&observed.hit.y==65);
 assert(!faceCentre({0,0,0},6,centre));
 assert(dispatchPlace(&use,held.mode,held.stack,{0,0,0},6,{0,0,0})==0&&observed.calls==1);
 assert(dispatchPlace(&use,held.mode,held.stack,{0,0,0},1,{0,100,0})==0&&observed.calls==1);
 assert(dispatchPlace(&use,held.mode,held.stack,{0,0,0},1,{NAN,1,.5f})==0&&observed.calls==1);
 // Non-block items are refused before a native placement can be attempted.
 assert(!resolveHeld(f.m,Fixture::base,Fixture::client,Fixture::player|Fixture::tag,held,[](A){return A(0);},&reason)&&reason==9);
 f.m.put<uint8_t>(f.stack+34,0);assert(!inventoryHeld(f.m,Fixture::base,Fixture::client,Fixture::player,held,&reason)&&reason==6);f.m.put<uint8_t>(f.stack+34,32);
 f.m.put<uint8_t>(Fixture::proxy+176,1);assert(!inventoryHeld(f.m,Fixture::base,Fixture::client,Fixture::player,held,&reason)&&reason==3);f.m.put<uint8_t>(Fixture::proxy+176,0);
 f.m.put( Fixture::proxy+16,int32_t(9));assert(!inventoryHeld(f.m,Fixture::base,Fixture::client,Fixture::player,held,&reason));f.m.put(Fixture::proxy+16,int32_t(Fixture::slot));
 f.m.put(Fixture::mode+8,Fixture::player+8);assert(!inventoryHeld(f.m,Fixture::base,Fixture::client,Fixture::player,held,&reason)&&reason==1);f.m.put(Fixture::mode+8,Fixture::player|Fixture::tag);
 f.m.put(Fixture::base+0x13d227d0ULL+112,Fixture::base+USE_ON+4);assert(!inventoryHeld(f.m,Fixture::base,Fixture::client,Fixture::player,held,&reason));f.m.put(Fixture::base+0x13d227d0ULL+112,Fixture::base+USE_ON);
 auto changed=[&](A){f.m.put<uint8_t>(f.stack+34,31);return Fixture::block|Fixture::tag;};
 assert(!resolveHeld(f.m,Fixture::base,Fixture::client,Fixture::player,held,changed,&reason)&&reason==8);f.m.put<uint8_t>(f.stack+34,32);
 // Survival's actual wrapper is retained, rather than bypassing its gates.
 f.m.put(Fixture::mode,Fixture::base+0x13d22900ULL);f.m.put(Fixture::base+0x13d22900ULL+112,Fixture::base+SURVIVAL_USE_ON);
 assert(resolveHeld(f.m,Fixture::base,Fixture::client,Fixture::player|Fixture::tag,held,getter,&reason));
 assert(placeFunction(f.m,Fixture::base,held.mode,held.player)==Fixture::base+SURVIVAL_USE_ON);
 std::cout<<"PASS: exact held block inventory/slot/count/binding guards, tagged native arguments, support world face-centre, first-use mainhand ABI, native result flags, changed inventory and Survival wrapper checks\n";
}
