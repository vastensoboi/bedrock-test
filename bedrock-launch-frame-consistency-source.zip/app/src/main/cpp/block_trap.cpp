#include "block_trap_core.h"
#include "block_place_core.h"
#include "world_collision_core.h"
#include "aim_profile.h"
#include <jni.h>
#include <atomic>
#include <chrono>
#include <mutex>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>
#include <string>

extern "C" int kulich_block_trap_enemy(uint64_t);
namespace {
using namespace kulich_aim;
namespace plan=kulich_trap;
namespace place=kulich_block_place;
namespace query=kulich_block_query;
namespace terrain=kulich_world_collision;
std::mutex gate;int memory=-1;A gameBase=0,boundClient=0;
bool ready=false,enabled=false;std::atomic<int64_t> lease{0};
int rangeTenths=40,interval=3,reason=1,heldReason=0;
int64_t deadline=0;unsigned reads=0,checked=0,playerCount=0,rayCount=0;
uint64_t ticks=0,attempts=0,accepted=0,observed=0,unobserved=0,friendSkips=0,unknownSkips=0,budgetStops=0;
bool budgetExceeded=false;
plan::TargetLock targetLock;plan::Cadence cadence;
uint32_t selectedTarget=0xffffffffU;int selectedSlot=-1,selectedCount=0;
struct Pending {bool active=false;A registry=0,type=0;plan::Cell cell{};int64_t until=0;} pending;
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(A at,void* out,size_t size){
 at=plain(at);if(memory<0||at<4096||size>65536||at>0x00ffffffffffffffULL-size)return false;
 if(++reads>12288||(deadline&&now()>deadline)){if(!budgetExceeded)++budgetStops;budgetExceeded=true;return false;}
 ssize_t n;do{n=pread(memory,out,size,static_cast<off_t>(at));}while(n<0&&errno==EINTR);return n==ssize_t(size);
}
void reset(){targetLock.reset();cadence.reset();pending={};selectedTarget=0xffffffffU;selectedSlot=-1;}
std::string install(A base,A client){
 std::lock_guard<std::mutex> lock(gate);reads=0;deadline=0;client=plain(client);
 if(gameBase&&gameBase!=base)return "Game library base changed";
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0||pointer(readMemory,client)!=base+0x1388fe70ULL)return "Block Trap client binding unavailable";
 if(!place::profiles(readMemory,base)||!terrain::profile(readMemory,base))return "Block Trap code profile mismatch";
 // Reuse the verified local-hand animation only when its exact implementation
 // matches. Placement itself goes through the original selected-hand API.
 for(const auto& profile:aimProfiles)if(profile.offset==SWING){
  uint32_t code[8]{};if(!readMemory(base+SWING,code,sizeof code)||std::memcmp(code,profile.words,sizeof code))return "Block Trap swing profile mismatch";
 }
 gameBase=base;boundClient=client;ready=true;reset();return {};
}
bool localBinding(A self,View& viewOut,Actor& local){
 if(pointer(readMemory,self)!=gameBase+0x139f6ea0ULL||pointer(readMemory,self+3240)!=boundClient)return false;
 A weak[3]{};if(!readMemory(boundClient+576,weak,sizeof weak)||!plain(weak[0])||!plain(weak[1]))return false;
 A registry=plain(weak[0]);auto v=view(readMemory,registry);
 if(!actor(readMemory,gameBase,v,self,true,local)||local.entity!=uint32_t(weak[2]))return false;
 A owner=pointer(readMemory,boundClient+424),lifetime=owner?pointer(readMemory,owner+8):0;uint8_t alive=0;
 if(!lifetime||!readMemory(lifetime,&alive,1)||!(alive&1))return false;
 viewOut=v;return true;
}
// Read owner payload pages in batches, then type/generation-check only player
// candidates. Kernel reads are bounded; no stale payload is used for an action.
bool players(const View& v,const Actor& local,std::vector<Actor>& out){
 out.clear();checked=0;A bounds[3]{},again[3]{};
 if(!v.owners||!readMemory(v.owners+80,bounds,sizeof bounds))return false;
 A begin=plain(bounds[0]),end=plain(bounds[1]),capacity=plain(bounds[2]);
 if(!begin||end<begin||capacity<end||(end-begin)%8||(end-begin)/8>32)return false;
 std::array<A,128> values{};
 for(A at=begin;at<end;at+=8){
  A page=pointer(readMemory,at);if(!page||!readMemory(page,values.data(),sizeof values))return false;
  for(A raw:values){
   ++checked;A address=plain(raw);if(!address||address==local.address||pointer(readMemory,address)!=gameBase+0x139f76b0ULL)continue;
   Actor other{};if(!actor(readMemory,gameBase,v,address,false,other))continue;
   if(std::any_of(out.begin(),out.end(),[&](const Actor& p){return p.entity==other.entity;}))continue;
   if(out.size()>=plan::MAX_PLAYERS)return false;
   out.push_back(other);
  }
 }
 if(!readMemory(v.owners+80,again,sizeof again)||std::memcmp(bounds,again,sizeof bounds))return false;
 return true;
}
bool enemy(const Actor& actor){
 int decision=kulich_block_trap_enemy(actor.address);
 if(decision==0)++friendSkips;
 if(decision<0)++unknownSkips;
 return decision==1;
}
query::Position position(plan::Cell cell){return {cell.x,cell.y,cell.z};}
bool sameCell(const terrain::Hit& hit,plan::Cell cell){return hit.block[0]==cell.x&&hit.block[1]==cell.y&&hit.block[2]==cell.z;}
bool visibleFace(A source,A taggedPlayer,Vec eye,plan::Support support){
 if(rayCount>=48||!plan::reachable(eye,support,5.0))return false;
 Vec hit=plan::hitPoint(support);plan::Cell normal=plan::normal(support.face);
 // End just inside the support so a boundary rounding difference cannot turn
 // a real face into an artificial miss. Require the exact first-hit face.
 terrain::Vec3 end{float(hit.x-normal.x*.02),float(hit.y-normal.y*.02),float(hit.z-normal.z*.02)};
 terrain::Hit result{};++rayCount;
 return terrain::trace(readMemory,gameBase,source,taggedPlayer,{float(eye.x),float(eye.y),float(eye.z)},end,0,result)==terrain::Result::Block&&
        result.face==support.face&&sameCell(result,support.block);
}
void pollPending(A registry,A source){
 if(!pending.active)return;
 if(pending.registry!=registry){pending={};return;}
 query::Cell current{};auto result=query::query(readMemory,gameBase,source,position(pending.cell),current);
 if(result==query::Result::Block&&plain(current.type)==pending.type){++observed;pending={};}
 else if(now()>=pending.until){++unobserved;pending={};}
}
}

extern "C" void kulich_block_trap_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);if(!lock.owns_lock()||!ready||!enabled)return;
 ++ticks;if(now()>lease.load()){reason=1;reset();return;}
 bool due=cadence.due(interval);if(!due&&!pending.active)return;
 reads=0;deadline=now()+6;budgetExceeded=false;rayCount=0;playerCount=0;
 struct Finish {~Finish(){deadline=0;if(budgetExceeded)reason=10;}} finish;
 View v{};Actor local{};
 if(!localBinding(plain(taggedPlayer),v,local)){reason=2;reset();return;}
 A source=terrain::region(readMemory,gameBase,taggedPlayer);if(!source){reason=5;return;}
 pollPending(v.registry,source);if(!due)return;
 if(pending.active){reason=8;return;}
 place::Held held{};
 if(!place::resolveHeld(readMemory,gameBase,boundClient,taggedPlayer,held,&heldReason)){selectedSlot=-1;reason=3;return;}
 selectedSlot=held.slot;selectedCount=held.count;
 query::Cell heldBlock{};
 if(query::inspect(readMemory,gameBase,held.block,heldBlock)!=query::Result::Block||!query::inertSupport(readMemory,gameBase,heldBlock)){reason=3;return;}
 std::vector<Actor> nearby;
 if(!players(v,local,nearby)){reason=4;return;}
 playerCount=unsigned(nearby.size());Actor target{};
 if(!plan::chooseTarget(local,nearby,rangeTenths/10.0,targetLock,target,enemy)){selectedTarget=0xffffffffU;reason=6;return;}
 float hp=health(readMemory,gameBase,v.registry,target.entity);
 if(std::isfinite(hp)&&hp<=0){targetLock.reset();reason=6;return;}
 selectedTarget=target.entity;
 auto candidates=plan::proposals(local,target,nearby);Vec eye=point(local.box,true);
 if(!terrain::filterBinding(readMemory,gameBase)){reason=11;return;}
 for(plan::Cell cell:candidates){
  if(now()>deadline||now()>lease.load())return;
  query::Cell dest{};if(query::query(readMemory,gameBase,source,position(cell),dest)!=query::Result::Air)continue;
  for(plan::Support support:plan::supports(cell)){
   if(!plan::valid(support.block)||!plan::reachable(eye,support,5.0))continue;
   query::Cell anchor{};
   if(query::query(readMemory,gameBase,source,position(support.block),anchor)!=query::Result::Block||!query::inertSupport(readMemory,gameBase,anchor)||
      !visibleFace(source,taggedPlayer,eye,support))continue;
   // Re-read ownership, selected slot/count, friend policy and every player
   // shape immediately before issuing a single native placement attempt.
   Actor freshLocal{},freshTarget{};
   place::Held freshHeld{};
   if(!actor(readMemory,gameBase,v,local.address,true,freshLocal)||
      !actor(readMemory,gameBase,v,target.address,false,freshTarget)||freshTarget.entity!=target.entity||
      distance2(freshLocal.box,freshTarget.box)>(rangeTenths/10.0)*(rangeTenths/10.0)||!enemy(freshTarget)||
      plan::intersects(cell,freshLocal.box)||plan::intersects(cell,freshTarget.box)||
      !place::resolveHeld(readMemory,gameBase,boundClient,taggedPlayer,freshHeld,&heldReason)||
      freshHeld.stack!=held.stack||freshHeld.block!=held.block||freshHeld.mode!=held.mode||freshHeld.slot!=held.slot||freshHeld.count!=held.count){reason=9;return;}
   for(const Actor& old:nearby){
    Actor current{};
    if(!actor(readMemory,gameBase,v,old.address,false,current)||current.entity!=old.entity||plan::intersects(cell,current.box)){reason=9;return;}
   }
   query::Cell finalDest{},finalSupport{};
   if(query::query(readMemory,gameBase,source,position(cell),finalDest)!=query::Result::Air||
      query::query(readMemory,gameBase,source,position(support.block),finalSupport)!=query::Result::Block||
      finalSupport.block!=anchor.block||!query::inertSupport(readMemory,gameBase,finalSupport)||
      !visibleFace(source,taggedPlayer,point(freshLocal.box,true),support)||
      now()>deadline||now()>lease.load()){reason=9;return;}
   ++attempts;uint32_t result=place::place(readMemory,gameBase,freshHeld,position(support.block),support.face);
   if(result&2U){
    if(pointer(readMemory,gameBase+0x139f6ea0ULL+880)==gameBase+SWING)
     reinterpret_cast<bool(*)(void*,int,int)>(gameBase+SWING)(reinterpret_cast<void*>(taggedPlayer),3,0);
   }
   if(result&1U){++accepted;pending={true,v.registry,plain(heldBlock.type),cell,now()+700};reason=0;}
   else reason=7;
   return;
  }
 }
 reason=12;
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_BlockTrapBridge_install(JNIEnv* env,jclass,jlong base,jlong client){auto error=install(A(base),A(client));return env->NewStringUTF(error.c_str());}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_BlockTrapBridge_enable(JNIEnv*,jclass,jboolean value){std::lock_guard<std::mutex> lock(gate);enabled=bool(value);lease.store(0);reset();}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_BlockTrapBridge_pulse(JNIEnv*,jclass,jboolean value){lease.store(value?now()+1200:0);}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_BlockTrapBridge_settings(JNIEnv*,jclass,jint range,jint ticksValue){std::lock_guard<std::mutex> lock(gate);rangeTenths=std::max(20,std::min(50,int(range)));interval=plan::clampInterval(int(ticksValue));cadence.reset();}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_BlockTrapBridge_status(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);char text[600];
 snprintf(text,sizeof text,"Block Trap: enabled=%d range=%.1f interval=%d ticks=%llu attempts=%llu accepted=%llu observed=%llu unobserved=%llu pending=%d target=%u slot=%d count=%d players=%u checked=%u rays=%u friends=%llu unknown=%llu budgetStops=%llu heldReason=%d reason=%d route=selected-block/use-item-on; evidence=client-world-not-server-ack",enabled,rangeTenths/10.0,interval,static_cast<unsigned long long>(ticks),static_cast<unsigned long long>(attempts),static_cast<unsigned long long>(accepted),static_cast<unsigned long long>(observed),static_cast<unsigned long long>(unobserved),pending.active,selectedTarget,selectedSlot,selectedCount,playerCount,checked,rayCount,static_cast<unsigned long long>(friendSkips),static_cast<unsigned long long>(unknownSkips),static_cast<unsigned long long>(budgetStops),heldReason,reason);
 return env->NewStringUTF(text);
}
