package dev.custom.bedrockgui;
import java.util.*;
public final class HudPanelsTest {
    static void check(boolean value){if(!value)throw new AssertionError();}
    static boolean has(List<String> values,String text){for(String s:values)if(s.contains(text))return true;return false;}
    public static void main(String[] args){
        StaffListModel staff=new StaffListModel("Helper_A\nModer_1\nHELPER_A");
        check(staff.configuredNames().length==2&&staff.encoded().equals("Helper_A\nModer_1"));
        String saved=staff.encoded();check(!staff.setNames("Helper_A\n../x")&&staff.encoded().equals(saved));
        check(has(staff.lines(1000),"недоступен"));
        staff.update(new String[]{"helper_a","Other"},true,1000);check(has(staff.lines(1000),"Helper_A · в сети")&&!has(staff.lines(1000),"Moder_1"));
        check(staff.globalKnown(4000)&&!staff.globalKnown(4001)&&has(staff.lines(4001),"недоступен"));
        staff.update(new String[0],true,5000);check(has(staff.lines(5000),"Сотрудников в сети нет"));
        staff.update(new String[0],false,5000);check(has(staff.lines(5000),"Полный список")&&!has(staff.lines(5000),"в сети нет"));
        staff.update(new String[]{"HELPER_A"},false,5000);check(has(staff.lines(5000),"Helper_A · рядом")&&has(staff.lines(5000),"недоступен"));
        staff.update(null,true,5000);check(!staff.globalKnown(5000)&&has(staff.lines(5000),"недоступен"));
        check(new StaffListModel(saved).encoded().equals(saved));
        check(staff.setNames("")&&has(staff.lines(5000),"Добавь"));
        StringBuilder limit=new StringBuilder();for(int i=0;i<128;i++)limit.append(i==0?"":"\n").append("Staff").append(i);
        check(staff.setNames(limit.toString())&&!staff.setNames(limit+"\nExtra"));
        BuffTimerModel buffs=new BuffTimerModel();check(has(buffs.lines(5000),"недоступны"));
        buffs.update("0|1,1,1800;5,0,9600;12,0,-1",5000);
        check(has(buffs.lines(5000),"Скорость II\t1:30")&&has(buffs.lines(5000),"Сила I\t8:00")&&has(buffs.lines(5000),"Огнестойкость I\t∞"));
        check(has(buffs.lines(6000),"1:29")&&has(buffs.lines(8000),"1:27")&&has(buffs.lines(8001),"недоступны"));
        buffs.update("1000|1,0,40",10000);check(has(buffs.lines(10000),"0:01"));check(has(buffs.lines(11000),"Нет активных"));
        buffs.update("0|",12000);check(has(buffs.lines(12000),"Нет активных"));
        buffs.update("0|99,10,20",12000);check(has(buffs.lines(12000),"Эффект №99 11\t0:01"));
        buffs.update("0|1,0,72000",12000);check(has(buffs.lines(12000),"1:00:00"));
        for(String invalid:new String[]{"","0","3001|1,0,30","-1|1,0,30","0|0,0,30","0|1,-1,30","0|1,0,-2","0|1,0,3;1,0,4","0|1,0,20;","0|1,0,2147483648"}){
            buffs.update(invalid,12000);check(has(buffs.lines(12000),"недоступны"));
        }
        buffs.update(null,12000);check(has(buffs.lines(12000),"недоступны"));
        buffs.update("0|1,0,-1",100);check(has(buffs.lines(99),"недоступны"));
        System.out.println("PASS: configured staff exact matching, full/nearby/unknown roster confidence and monotonic real-effect timers, levels, expiry and malformed input");
    }
}
