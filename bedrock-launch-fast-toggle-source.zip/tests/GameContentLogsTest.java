import dev.custom.bedrockgui.GameContentLogs;
import java.io.File;
import java.nio.file.*;

public final class GameContentLogsTest {
    private static void require(boolean value) { if(!value)throw new AssertionError(); }
    public static void main(String[] args) throws Exception {
        Path root=Files.createTempDirectory("content-logs");
        Path outside=Files.createTempDirectory("account-data");
        try {
            require(GameContentLogs.read(new File[]{null,root.toFile()}).contains("не найдены"));
            Files.writeString(root.resolve("account.txt"),"PRIVATE_ACCOUNT_DATA");
            Path content=Files.createDirectories(root.resolve("games/com.mojang/logs"));
            Files.writeString(content.resolve("ContentLog__test.txt"),"UI_LAYOUT_ERROR");
            Files.writeString(outside.resolve("secrets.txt"),"PRIVATE_SYMLINK_DATA");
            Files.createSymbolicLink(content.resolve("ContentLog__secret.txt"),outside.resolve("secrets.txt"));
            Files.createSymbolicLink(root.resolve("loop"),root);
            String result=GameContentLogs.read(new File[]{root.toFile(),content.toFile()});
            require(result.contains("UI_LAYOUT_ERROR"));
            require(!result.contains("PRIVATE_ACCOUNT_DATA")&&!result.contains("PRIVATE_SYMLINK_DATA"));
            // Minecraft can select the data directory itself, not data/files.
            Path files=Files.createDirectories(root.resolve("files"));
            require(GameContentLogs.read(new File[]{files.toFile()}).contains("не найдены"));
            require(GameContentLogs.read(GameContentLogs.roots(root.toFile(),files.toFile(),new File[]{null}))
                    .contains("UI_LAYOUT_ERROR"));
            Path cache=Files.createDirectories(root.resolve("cache"));
            for(int i=0;i<2100;i++)Files.createFile(cache.resolve("cached"+i));
            require(GameContentLogs.read(GameContentLogs.roots(root.toFile(),files.toFile(),null))
                    .contains("UI_LAYOUT_ERROR"));
            for(int i=0;i<5;i++)Files.writeString(content.resolve("ContentLog__large"+i+".log"),"X".repeat(200000));
            result=GameContentLogs.read(new File[]{root.toFile()});
            require(result.length()<264000);
            require(result.split("--- ContentLog",-1).length-1<=3);
            System.out.println("PASS: content log discovery, account-file exclusion, symlink/loop rejection, bounded export");
        } finally {
            try(var paths=Files.walk(root)){for(Path path:paths.sorted(java.util.Comparator.reverseOrder()).toList())Files.delete(path);}
            Files.deleteIfExists(outside.resolve("secrets.txt"));Files.delete(outside);
        }
    }
}
