#pragma once
#include "aim_core.h"
namespace kulich_input {
struct Profile {kulich_aim::A offset;uint32_t words[8];size_t count;};
constexpr Profile profiles[]={
 {0xcc8934cULL,{0xd10143ffU,0xa9037bfdU,0xf90023f3U,0x9100c3fdU,0xd53bd053U,0xf9401669U,0xf81f83a9U,0xb9402809U},8},
 {0xdaa483cULL,{0x52801200U,0xd65f03c0U},2},
 {0xaf64584ULL,{0xf943e274U},1},
 {0xaf64764ULL,{0x9101e3e0U,0x8b080d3cU,0x94acfffaU},3},
 {0xaf64890ULL,{0x528181c8U,0x72b31c88U},2},
 {0xaf6499cULL,{0xf9400a60U,0xb9401a77U,0x528a4701U,0x72a36ba1U,0x976c2aabU},5},
 {0xaf64a28ULL,{0x5280048bU,0xf8696949U,0xd503201fU,0x9bab2508U,0x9101e3eeU,0xb9400909U,0xf940010aU},7},
 {0xaf64a44ULL,{0xb900bbe9U,0xf9001dcaU,0xb9402109U,0xf9400d08U,0xb900cbe9U,0xf90025c8U},6},
 {0xaf64b8cULL,{0x528db34bU,0x3940b12aU,0xf9400929U,0x72abfb6bU,0x6b0b011fU,0x9a9f0128U,0x7100115fU,0xfa401904U},8},
 {0xaf64bb0ULL,{0xf9400101U,0x9101e3e8U,0x9102a100U,0x94ad82deU},4},
 {0xdac5734ULL,{0xf9000001U,0xd65f03c0U},2},
 {0xaf64d94ULL,{0xf9400288U,0xf9400d08U,0x9101e3e1U,0xaa1403e0U,0xd63f0100U},5},
};
template<class Read>bool profileValid(Read& read,kulich_aim::A base){
 if(kulich_aim::pointer(read,base+0x13b95240ULL+16)!=base+0xdaa483cULL)return false;
 for(const auto& profile:profiles){uint32_t words[8]{};size_t bytes=profile.count*4;
  if(!read(base+profile.offset,words,bytes)||std::memcmp(words,profile.words,bytes))return false;
 }return true;
}
}
