#pragma once
#include "aim_combat.h"
namespace kulich_aim {
struct FriendRayChoice {
 A actor=0;uint32_t entity=0xffffffffU;double best=7;bool ambiguous=false;
 void consider(A address,uint32_t id,Vec eye,const DirectLook& look,const Box& box){
  Vec hit{};if(!rayHitView(eye,look,box,6,hit))return;
  double dx=hit.x-eye.x,dy=hit.y-eye.y,dz=hit.z-eye.z,distance=std::sqrt(dx*dx+dy*dy+dz*dz);
  if(distance<best-.05){actor=address;entity=id;best=distance;ambiguous=false;}
  else if(std::abs(distance-best)<=.05){if(distance<best){actor=address;entity=id;best=distance;}ambiguous=true;}
 }
 bool valid()const{return actor&&!ambiguous;}
};
template<class Read> bool pickFriendRay(Read& read,A base,const View& v,const Actor& self,const DirectLook& look,Actor& target){
 A h[3]{};if(!v.owners||!read(v.owners+80,h,sizeof h))return false;
 A begin=plain(h[0]),end=plain(h[1]),cap=plain(h[2]);
 if(!begin||end<begin||cap<end||(end-begin)%8||(end-begin)/8>2048)return false;
 FriendRayChoice choice;unsigned checked=0;Vec eye=point(self.box,true);
 for(A p=0;p<(end-begin)/8&&checked<4096;p++){
  A page=pointer(read,begin+p*8);if(!page)continue;std::array<A,128> owners{};
  if(!read(page,owners.data(),sizeof owners))continue;
  for(A raw:owners){if(++checked>4096)break;A address=plain(raw);if(!address||address==self.address)continue;
   Actor candidate{};if(!actor(read,base,v,address,false,candidate))continue;
   choice.consider(address,candidate.entity,eye,look,candidate.box);
  }
 }
 return choice.valid()&&actor(read,base,v,choice.actor,false,target)&&target.entity==choice.entity;
}
}
