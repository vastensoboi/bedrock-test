#include "../app/src/main/cpp/world_collision_core.h"
#include <cassert>
#include <iostream>
#include <map>
#include <vector>
using namespace kulich_world_collision;
struct Memory {
 std::map<Address,std::vector<unsigned char>> rows;
 template<class T>void put(Address at,T value){auto& row=rows[at];row.resize(sizeof value);std::memcpy(row.data(),&value,sizeof value);}
 bool operator()(Address at,void* out,size_t n){auto it=rows.find(plain(at));if(it==rows.end()||it->second.size()<n)return false;std::memcpy(out,it->second.data(),n);return true;}
};
void nativeField(NativeHit& hit,size_t offset,const void* data,size_t n){std::memcpy(hit.bytes+offset,data,n);}
int main(){
 NativeHit native{};Hit hit{};int kind=3;nativeField(native,24,&kind,4);
 assert(decode(native,{0,1,0},{4,1,0},hit)==Result::Miss);
 kind=0;Vec3 point{2,1,0};int block[]{2,1,0};nativeField(native,24,&kind,4);nativeField(native,32,block,12);nativeField(native,44,&point,12);native.bytes[28]=4;
 assert(decode(native,{0,1,0},{4,1,0},hit)==Result::Block&&hit.fraction==.5f&&hit.block[0]==2&&hit.face==4);
 point={5,1,0};nativeField(native,44,&point,12);assert(decode(native,{0,1,0},{4,1,0},hit)==Result::Unavailable);
 point={2,2,0};nativeField(native,44,&point,12);assert(decode(native,{0,1,0},{4,1,0},hit)==Result::Unavailable);
 point={2,1,0};nativeField(native,44,&point,12);native.bytes[28]=6;assert(decode(native,{0,1,0},{4,1,0},hit)==Result::Unavailable);
 native.bytes[28]=4;assert(decode(native,{0,1,0},{0,1,0},hit)==Result::Unavailable);
 kind=1;nativeField(native,24,&kind,4);assert(decode(native,{0,1,0},{4,1,0},hit)==Result::Unavailable);
 Memory memory;constexpr Address base=0x10000000ULL,source=0x20000000ULL;
 memory.put(source,base+SOURCE_TABLE);memory.put(base+SOURCE_TABLE+51*8,base+CLIP);
 assert(sourceBinding(memory,base,source));memory.put(base+SOURCE_TABLE+51*8,base+CLIP+4);assert(!sourceBinding(memory,base,source));
 memory.put(base+SOURCE_TABLE+51*8,base+CLIP);
 constexpr Address taggedSource=source|0xab00000000000000ULL;
 assert(sourceBinding(memory,base,taggedSource));
 constexpr Address impl=0x20001000ULL,table=base+0x13e00000ULL;
 assert(!filterBinding(memory,base));memory.put(base+PROJECTILE_FILTER+32,impl);memory.put(impl,table);memory.put(table+48,base+0xc000000ULL);assert(filterBinding(memory,base));
 memory.put(table+48,Address(0x500));assert(!filterBinding(memory,base));
 int released=0;static int* releases=nullptr;releases=&released;auto release=+[](void*){++*releases;};
 {WeakRelease weak(impl,reinterpret_cast<Address>(release));}assert(released==1);
 {WeakRelease weak(0,reinterpret_cast<Address>(release));}assert(released==1);
 static Address observed=0;auto record=+[](void* count){observed=reinterpret_cast<Address>(count);};
 constexpr Address taggedCount=impl|0xab00000000000000ULL;
 {WeakRelease weak(taggedCount,reinterpret_cast<Address>(record));}
 assert(observed==taggedCount);
 std::cout<<"World collision bounds, hit decoding and weak lifetime passed\n";
}
