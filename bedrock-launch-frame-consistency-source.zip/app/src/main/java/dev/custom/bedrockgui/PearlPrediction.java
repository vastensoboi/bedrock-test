package dev.custom.bedrockgui;

import java.util.*;

/** Bounded free-flight math. A landing ETA is accepted only as supplied collision evidence. */
public final class PearlPrediction {
    public static final long FRESH_MS=500;
    public static final int MAX_PEARLS=32,MAX_TICKS=160,MAX_TRAIL_POINTS=64;
    private PearlPrediction(){}
    public static final class Vec {
        public final double x,y,z;
        public Vec(double x,double y,double z){this.x=x;this.y=y;this.z=z;}
        public Vec plus(Vec value){return new Vec(x+value.x,y+value.y,z+value.z);}
        public Vec scale(double value){return new Vec(x*value,y*value,z*value);}
        public boolean valid(){return finite(x)&&finite(y)&&finite(z)&&Math.abs(x)<=32000000&&Math.abs(y)<=32000000&&Math.abs(z)<=32000000;}
    }
    public static final class Camera {
        public final Vec position;public final double pitch,yaw,verticalFov,aspect,nearPlane;
        // Column-major native render view of world-position. Includes roll/bob.
        private final double[] view;
        public Camera(Vec position,double pitch,double yaw,double verticalFov){this(position,pitch,yaw,verticalFov,0,null,.05);}
        public Camera(Vec position,double pitch,double yaw,double verticalFov,double aspect,double[] view,double nearPlane){
            this.position=position;this.pitch=pitch;this.yaw=yaw;this.verticalFov=verticalFov;this.aspect=aspect;this.view=view==null?null:view.clone();this.nearPlane=nearPlane;
        }
        public boolean valid(){
            if(position==null||!position.valid()||!finite(pitch)||Math.abs(pitch)>90.01||!finite(yaw)||Math.abs(yaw)>1e8||!finite(verticalFov)||!(verticalFov==0||verticalFov>=1&&verticalFov<=179))return false;
            if(view==null)return true;
            if(verticalFov==0||!finite(aspect)||aspect<.05||aspect>20||!finite(nearPlane)||nearPlane<=0||nearPlane>100||view.length!=16)return false;
            for(double value:view)if(!finite(value)||Math.abs(value)>1e6)return false;
            double determinant=view[0]*(view[5]*view[10]-view[9]*view[6])-view[4]*(view[1]*view[10]-view[9]*view[2])+view[8]*(view[1]*view[6]-view[5]*view[2]);
            return finite(determinant)&&Math.abs(determinant)>1e-12;
        }
        public boolean projectsWorld(){return verticalFov>0;}
        public boolean hasRenderView(){return view!=null;}
    }
    public static final class Pearl {
        public final long id;public final int owner;public final Vec position,velocity;public final double gravity,drag,impactTicks;
        public Pearl(long id,int owner,Vec position,Vec velocity,double gravity,double drag,double impactTicks){this.id=id;this.owner=owner;this.position=position;this.velocity=velocity;this.gravity=gravity;this.drag=drag;this.impactTicks=impactTicks;}
        public boolean valid(){return id>=0&&owner>=-1&&owner<=1&&position!=null&&position.valid()&&velocity!=null&&velocity.valid()&&Math.abs(velocity.x)<=64&&Math.abs(velocity.y)<=64&&Math.abs(velocity.z)<=64&&finite(gravity)&&gravity>=0&&gravity<=1&&finite(drag)&&drag>0&&drag<=1&&finite(impactTicks)&&(impactTicks==-1||impactTicks>=0&&impactTicks<=MAX_TICKS);}
        public boolean hasLanding(){return impactTicks>=0;}
    }
    /** Measured past positions only; this type has no flight physics or ETA. */
    public static final class Trail {
        public final long id;public final int owner;public final List<Vec> points;
        public Trail(long id,int owner,List<Vec> points){
            this.id=id;this.owner=owner;this.points=Collections.unmodifiableList(new ArrayList<>(points));
        }
        public boolean valid(){
            if(id<0||owner< -1||owner>1||points.isEmpty()||points.size()>MAX_TRAIL_POINTS)return false;
            Vec previous=null;
            for(Vec point:points){
                if(point==null||!point.valid())return false;
                if(previous!=null){
                    double dx=point.x-previous.x,dy=point.y-previous.y,dz=point.z-previous.z;
                    // Recycled identities and teleports must not produce a
                    // giant cross-world line between unrelated observations.
                    if(dx*dx+dy*dy+dz*dz>128.0*128.0)return false;
                }
                previous=point;
            }
            return true;
        }
    }
    public static final class Frame {
        public final Camera camera;public final List<Pearl> pearls;public final List<Trail> trails;public final long capturedAt;public final int discardedPearls;
        public Frame(Camera camera,List<Pearl> pearls,long capturedAt){this(camera,pearls,capturedAt,0);}
        public Frame(Camera camera,List<Pearl> pearls,long capturedAt,int discardedPearls){this(camera,pearls,Collections.emptyList(),capturedAt,discardedPearls);}
        public Frame(Camera camera,List<Pearl> pearls,List<Trail> trails,long capturedAt,int discardedPearls){this.camera=camera;this.pearls=Collections.unmodifiableList(new ArrayList<>(pearls));this.trails=Collections.unmodifiableList(new ArrayList<>(trails));this.capturedAt=capturedAt;this.discardedPearls=discardedPearls;}
        public boolean fresh(long now){return now>=capturedAt&&now-capturedAt<=FRESH_MS;}
    }
    public static final class Point {
        public final double x,y;public Point(double x,double y){this.x=x;this.y=y;}
    }
    /** Clip long off-screen projected segments before passing them to Canvas. */
    public static Point[] clipSegment(Point start,Point end,int width,int height){
        if(start==null||end==null||width<=0||height<=0||!finite(start.x)||!finite(start.y)||!finite(end.x)||!finite(end.y))return null;
        double dx=end.x-start.x,dy=end.y-start.y;if(!finite(dx)||!finite(dy))return null;
        double[] p={-dx,dx,-dy,dy},q={start.x,width-start.x,start.y,height-start.y};double low=0,high=1;
        for(int i=0;i<4;i++){
            if(p[i]==0){if(q[i]<0)return null;continue;}
            double t=q[i]/p[i];if(p[i]<0)low=Math.max(low,t);else high=Math.min(high,t);
            if(low>high)return null;
        }
        // The final clamp absorbs floating-point cancellation for very long
        // near-plane segments; it does not invent an off-screen trajectory.
        return new Point[]{new Point(Math.max(0,Math.min(width,start.x+low*dx)),Math.max(0,Math.min(height,start.y+low*dy))),new Point(Math.max(0,Math.min(width,start.x+high*dx)),Math.max(0,Math.min(height,start.y+high*dy)))};
    }
    /** Short user-facing state derived from native evidence, also used in diagnostics. */
    public static String feedStatus(String nativeStatus){
        long reason=statusNumber(nativeStatus,"reason"),pearls=statusNumber(nativeStatus,"pearls"),trails=statusNumber(nativeStatus,"trails"),frames=statusNumber(nativeStatus,"frames");
        if(statusNumber(nativeStatus,"enabled")==0)return "Выключен";
        if(reason==1)return "Ожидаю обновление интерфейса";
        if(reason==2)return "Войди в мир для прогноза жемчуга";
        if(reason==3)return "Не удалось прочитать данные полёта";
        if(reason==4)return "Не удалось получить игровую камеру";
        if(reason==5)return "Чтение мира не уложилось в лимит; повторяю";
        if(reason==6)return "Ожидаю данные жемчуга: брось жемчуг";
        if(reason==7)return "Жемчуг найден, но данные полёта ещё недоступны";
        if(trails>0)return "Наблюдаемые следы жемчуга: "+trails;
        if(pearls>0)return "Жемчугов найдено: "+pearls;
        if(frames==0)return "Ожидаю обновление игрового мира";
        if(frames>0)return "Ожидаю бросок жемчуга";
        return "Прогноз включён; ожидаю данные";
    }
    private static long statusNumber(String text,String key){
        if(text==null)return -1;
        for(String field:text.split("[\\s;]+"))if(field.startsWith(key+"="))try{return Long.parseLong(field.substring(key.length()+1));}catch(NumberFormatException ignored){return -1;}
        return -1;
    }
    private static boolean finite(double value){return Double.isFinite(value);}
    /** Native tick order: position += velocity, velocity *= drag, then vertical gravity. */
    public static List<Vec> simulate(Pearl pearl,int requestedTicks){
        if(pearl==null||!pearl.valid())return Collections.emptyList();
        int maximum=Math.max(0,Math.min(MAX_TICKS,requestedTicks));double end=pearl.hasLanding()?Math.min(maximum,pearl.impactTicks):maximum;
        ArrayList<Vec> points=new ArrayList<>();Vec position=pearl.position,velocity=pearl.velocity;points.add(position);
        for(int tick=0;tick<Math.ceil(end);tick++){
            double fraction=Math.min(1,end-tick);if(fraction<=0)break;
            position=position.plus(velocity.scale(fraction));if(!position.valid())break;points.add(position);
            velocity=new Vec(velocity.x*pearl.drag,velocity.y*pearl.drag-pearl.gravity,velocity.z*pearl.drag);
        }
        return Collections.unmodifiableList(points);
    }
    public static double secondsToLanding(Pearl pearl,long captureAgeMs){
        return pearl!=null&&pearl.valid()&&pearl.hasLanding()&&captureAgeMs>=0?Math.max(0,pearl.impactTicks/20.0-captureAgeMs/1000.0):Double.NaN;
    }
    /** Uses the full native render view when supplied; old six-value feeds retain yaw/pitch projection. */
    public static Point project(Vec world,Camera camera,int width,int height){
        if(world==null||!world.valid()||camera==null||!camera.valid()||!camera.projectsWorld()||width<=0||height<=0)return null;
        double dx=world.x-camera.position.x,dy=world.y-camera.position.y,dz=world.z-camera.position.z,right,up,depth;
        if(camera.hasRenderView()){
            double[] m=camera.view;
            right=m[0]*dx+m[4]*dy+m[8]*dz+m[12];
            up=m[1]*dx+m[5]*dy+m[9]*dz+m[13];
            depth=-(m[2]*dx+m[6]*dy+m[10]*dz+m[14]);
        }else{
            double yaw=Math.toRadians(camera.yaw),pitch=Math.toRadians(camera.pitch);
            right=dx*Math.cos(yaw)+dz*Math.sin(yaw);
            up=-dx*Math.sin(yaw)*Math.sin(pitch)+dy*Math.cos(pitch)+dz*Math.cos(yaw)*Math.sin(pitch);
            depth=-dx*Math.sin(yaw)*Math.cos(pitch)-dy*Math.sin(pitch)+dz*Math.cos(yaw)*Math.cos(pitch);
        }
        if(!finite(depth)||depth<=camera.nearPlane)return null;
        double tangent=Math.tan(Math.toRadians(camera.verticalFov)/2),verticalScale=height/(2*tangent);
        double horizontalScale=camera.hasRenderView()?width/(2*camera.aspect*tangent):verticalScale;
        double x=width*.5+right*horizontalScale/depth,y=height*.5-up*verticalScale/depth;
        return finite(x)&&finite(y)?new Point(x,y):null;
    }
    /** Explicit top-down fallback: no guessed world FOV is ever presented as aligned. */
    public static Point topDown(Vec world,Camera camera,double centreX,double centreY,double pixelsPerBlock){
        if(world==null||!world.valid()||camera==null||!camera.valid()||!finite(pixelsPerBlock)||pixelsPerBlock<=0)return null;
        double yaw=Math.toRadians(camera.yaw),dx=world.x-camera.position.x,dz=world.z-camera.position.z;
        return new Point(centreX+(dx*Math.cos(yaw)+dz*Math.sin(yaw))*pixelsPerBlock,centreY-(-dx*Math.sin(yaw)+dz*Math.cos(yaw))*pixelsPerBlock);
    }
    /**
     * age|cameraX,Y,Z,pitch,yaw,verticalFov[,aspect,16 view values[,nearPlane]]|rows
     * Prediction row: id,owner,posXYZ,velXYZ,gravity,drag,impactTicks.
     * Observed trail row: T,id,owner,x:y:z/x:y:z/... (no invented physics).
     */
    public static Frame parse(String snapshot,long now){
        try{
            if(snapshot==null||snapshot.length()>32768||now<0)return null;
            String[] fields=snapshot.split("\\|",-1);if(fields.length!=3)return null;
            long age=Long.parseLong(fields[0]);if(age<0||age>FRESH_MS||age>now)return null;
            String[] values=fields[1].split(",",-1);if(values.length!=6&&values.length!=23&&values.length!=24)return null;
            double[] view=null;double aspect=0,nearPlane=.05;
            if(values.length>6){aspect=number(values[6]);view=new double[16];for(int i=0;i<16;i++)view[i]=number(values[7+i]);if(values.length==24)nearPlane=number(values[23]);}
            Camera camera=new Camera(new Vec(number(values[0]),number(values[1]),number(values[2])),number(values[3]),number(values[4]),number(values[5]),aspect,view,nearPlane);if(!camera.valid())return null;
            ArrayList<Pearl> pearls=new ArrayList<>();ArrayList<Trail> trails=new ArrayList<>();HashSet<Long> ids=new HashSet<>();int discarded=0;
            if(!fields[2].isEmpty()){
                String[] rows=fields[2].split(";",-1);if(rows.length>MAX_PEARLS)return null;
                for(String row:rows){
                    try{
                        String[] v=row.split(",",-1);
                        if(v.length==4&&"T".equals(v[0])){
                            String[] samples=v[3].split("/",-1);
                            if(samples.length<1||samples.length>MAX_TRAIL_POINTS){discarded++;continue;}
                            ArrayList<Vec> positions=new ArrayList<>();
                            for(String sample:samples){String[] xyz=sample.split(":",-1);if(xyz.length!=3)throw new IllegalArgumentException("Invalid trail point");positions.add(new Vec(number(xyz[0]),number(xyz[1]),number(xyz[2])));}
                            Trail trail=new Trail(Long.parseLong(v[1]),Integer.parseInt(v[2]),positions);
                            if(!trail.valid()||!ids.add(trail.id)){discarded++;continue;}
                            trails.add(trail);continue;
                        }
                        if(v.length!=11){discarded++;continue;}
                        Pearl pearl=new Pearl(Long.parseLong(v[0]),Integer.parseInt(v[1]),new Vec(number(v[2]),number(v[3]),number(v[4])),new Vec(number(v[5]),number(v[6]),number(v[7])),number(v[8]),number(v[9]),number(v[10]));
                        if(!pearl.valid()||!ids.add(pearl.id)){discarded++;continue;}pearls.add(pearl);
                    }catch(RuntimeException ignored){discarded++;}
                }
            }
            return new Frame(camera,pearls,trails,now-age,discarded);
        }catch(RuntimeException ignored){return null;}
    }
    private static double number(String value){double result=Double.parseDouble(value);if(!finite(result))throw new IllegalArgumentException("Nonfinite projectile value");return result;}
}
