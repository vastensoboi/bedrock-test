#include "../app/src/main/cpp/aim_core.h"
#include <vector>
#include <cassert>
#include <iostream>
#include <algorithm>
using namespace kulich_aim;
struct Memory {
 static constexpr A root=0x200000;std::vector<unsigned char> bytes=std::vector<unsigned char>(0x80000);A next=root+0x10000;unsigned reads=0;
 A alloc(size_t n){A p=next;next=(next+n+7)&~A(7);assert(next-root<bytes.size());return p;}
 template<class T> void put(A p,T v){assert(p>=root&&p-root+sizeof v<=bytes.size());std::memcpy(bytes.data()+p-root,&v,sizeof v);}
 bool operator()(A p,void* out,size_t n){reads++;if(p<root||p-root>bytes.size()||n>bytes.size()-(p-root))return false;std::memcpy(out,bytes.data()+p-root,n);return true;}
};
struct Storage{A pool=0,sparse=0,pages=0;std::array<A,2> data{};unsigned stride=0;};
Storage storage(Memory& m,unsigned stride){
 Storage s;s.pool=m.alloc(104);s.stride=stride;A sparseVector=m.alloc(8);s.sparse=m.alloc(8192);
 std::fill(m.bytes.begin()+s.sparse-Memory::root,m.bytes.begin()+s.sparse-Memory::root+8192,255);
 m.put(s.pool+8,sparseVector);m.put(s.pool+16,sparseVector+8);m.put(sparseVector,s.sparse);
 s.pages=m.alloc(16);m.put(s.pool+80,s.pages);m.put(s.pool+88,s.pages+16);m.put(s.pool+96,s.pages+16);
 for(unsigned i=0;i<2;i++){s.data[i]=m.alloc(128*stride);m.put(s.pages+i*8,s.data[i]);}return s;
}
A bind(Memory& m,const Storage& s,uint32_t id,unsigned index){m.put(s.sparse+(id&2047)*4,(id&0xfffc0000U)|index);return s.data[index>>7]+(index&127)*s.stride;}
void near(double a,double b,double eps=.001){assert(std::abs(a-b)<eps);}
Box box(float x,float y,float z){return {{x-.3f,y,z-.3f},{x+.3f,y+1.8f,z+.3f},.6f,1.8f};}
int main(){
 Angles aim{};
 assert(angles({0,0,0},{0,0,3},0,aim));near(aim.pitch,0);near(aim.yaw,0);
 assert(angles({0,0,0},{3,0,0},0,aim));near(aim.yaw,-90);
 assert(angles({0,0,0},{0,0,-3},179,aim));near(aim.yaw,180);
 assert(angles({0,0,0},{0,0,-3},-179,aim));near(aim.yaw,-180);
 assert(angles({0,0,0},{0,5,0},17,aim));near(aim.pitch,-89.9);near(aim.yaw,17);
 assert(!angles({0,0,0},{0,0,0},0,aim));assert(!angles({NAN,0,0},{0,0,1},0,aim));assert(!angles({0,0,0},{0,0,1},INFINITY,aim));
 auto a=box(0,0,0),b=box(0,0,3);assert(valid(a));near(point(b,true).y,1.62);near(point(b,false).y,.9);
 assert(angles(point(a,true),point(b,true),0,aim));near(aim.pitch,0);
 assert(angles(point(a,true),point(b,false),0,aim));assert(aim.pitch>10);
 Box bad=a;bad.hi[0]=NAN;assert(!valid(bad));bad=a;bad.hi[1]=bad.lo[1];assert(!valid(bad));
 Memory m;constexpr A base=0x10000000,registry=Memory::root+0x1000,self=Memory::root+0x3000,one=Memory::root+0x5000,two=Memory::root+0x7000;
 constexpr uint32_t localId=0x40001,oneId=0x40002,twoId=0x40003;
 auto owners=storage(m,8),shapes=storage(m,32),rotations=storage(m,16),heads=storage(m,8);
 A buckets=m.alloc(64),nodes=m.alloc(128);for(int i=0;i<8;i++)m.put<int64_t>(buckets+i*8,-1);
 std::array<uint32_t,4> keys{OWNER,SHAPE,ROTATION,HEAD};std::array<A,4> pools{owners.pool,shapes.pool,rotations.pool,heads.pool};
 for(int i=0;i<4;i++){
  int64_t previous=-1;m(buckets+(keys[i]&7)*8,&previous,8);m.put(nodes+i*32,previous);m.put(nodes+i*32+8,keys[i]);m.put(nodes+i*32+16,pools[i]);m.put<int64_t>(buckets+(keys[i]&7)*8,i);
 }
 m.put(registry+96,buckets);m.put(registry+104,buckets+64);m.put(registry+120,nodes);m.put(registry+128,nodes+128);
 A entityPages=m.alloc(8),entitySparse=m.alloc(8192);std::fill(m.bytes.begin()+entitySparse-Memory::root,m.bytes.begin()+entitySparse-Memory::root+8192,255);
 m.put(registry+216,entityPages);m.put(registry+224,entityPages+8);m.put(entityPages,entitySparse);
 for(uint32_t id:{localId,oneId,twoId})m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|(id&2047));
 auto add=[&](A address,uint32_t id,unsigned ownerIndex,unsigned shapeIndex,bool local,Box value){
  m.put(address,base+(local?0x139f6ea0ULL:0x139f76b0ULL));m.put(address+8,registry|0xb400000000000000ULL);m.put(address+16,registry+40);m.put(address+24,id);
  m.put(bind(m,owners,id,ownerIndex),address|0xb400000000000000ULL);
  A shape=bind(m,shapes,id,shapeIndex);m.put(address+560,shape);m.put(shape,value);
  if(local){A rot=bind(m,rotations,id,0);m.put(address+568,rot);m.put(rot,Angles{0,0});bind(m,heads,id,0);}
 };
 add(self,localId,0,5,true,a);add(one,oneId,129,7,false,b);add(two,twoId,130,130,false,box(0,0,5));
 auto v=view(m,registry);assert(v.owners==owners.pool&&v.shapes==shapes.pool&&v.rotations==rotations.pool&&v.heads==heads.pool);
 Actor local{},target{};assert(actor(m,base,v,self,true,local));assert(component(m,owners.pool,oneId,8)==owners.data[1]+8);
 auto before=m.bytes;Lock lock;unsigned checked=0;assert(acquire(m,base,v,local,6,lock,target,checked));assert(target.address==one&&lock.entity==oneId&&checked==256&&m.bytes==before);
 m.put(component(m,shapes.pool,twoId,32),box(0,0,1));assert(retain(m,base,v,local,6,lock,target)&&target.address==one); // sticky, never switches just because another player moved closer
 m.put<unsigned char>(one+617,1);assert(!retain(m,base,v,local,6,lock,target)&&lock.actor==0);
 assert(acquire(m,base,v,local,6,lock,target,checked)&&target.address==two);
 m.put(two+24,twoId+0x40000U);assert(!retain(m,base,v,local,6,lock,target));m.put(two+24,twoId);
 m.put(two+8,registry+0x200);assert(!actor(m,base,v,two,false,target));m.put(two+8,registry);
 A shape=component(m,shapes.pool,twoId,32);m.put(two+560,shape+8);assert(!actor(m,base,v,two,false,target));m.put(two+560,shape);
 m.put(shape,box(0,0,13));assert(!acquire(m,base,v,local,6,lock,target,checked));
 m.put(shape,box(0,0,1));m.put(two,base+0x13cf56e8ULL);assert(!acquire(m,base,v,local,6,lock,target,checked)); // generic actors/mobs are not players
 m.put(two,base+0x139f76b0ULL);m.put(shape,bad);assert(!acquire(m,base,v,local,6,lock,target,checked));
 m.put(shape,box(0,0,1));m.put(component(m,rotations.pool,localId,16),Angles{0,NAN});assert(!actor(m,base,v,self,true,local));
 // Corrupt chains and missing payloads fail without any write or unbounded walk.
 m.put(nodes+3*32,int64_t(3));unsigned reads=m.reads;assert(pool(m,registry,0x12345671U)==0&&m.reads-reads<70);
 std::cout<<"PASS: camera angles/head-body geometry, wrap/clamp/NaN, exact ECS owner/generation and MTE tags, paged components, nearest player/sticky lock, removal/range/world/type changes, corrupt read bounds, read-only selection\n";
}
