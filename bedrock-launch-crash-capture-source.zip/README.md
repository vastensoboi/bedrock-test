# Bedrock Crash Capture 0.22

This is a separate diagnostic install for capturing the native crash observed
in Bedrock Launch Test 0.21. Its purpose is to reproduce the failure once and
export the game's saved Breakpad minidump using an ordinary Android file picker.
It does not require Termux, Shizuku, adb or access to another app's private files.

## Separate install and retained old data

The debug APK uses application ID
`dev.custom.bedrocklaunchtest.crashcapture` and label **Bedrock Crash Capture**.
It is installed alongside `dev.custom.bedrocklaunchtest`; the old application,
its worlds and its saved minidump do not need to be removed. No old data is
copied into this separate application's UID or storage. A new test world and
one new reproduction are needed. The old 0.21 dump cannot be exported by this
app because it remains in a different app's private storage.

The default applicationId literal remains `dev.custom.bedrocklaunchtest` solely
for compatibility with the user's existing archive-selector workflow. The
debug build type adds `.crashcapture`, and a Gradle variant assertion refuses
a debug applicationId that differs from the separate diagnostic ID. Build only
`:app:assembleDebug`. The supplied direct workflow also checks the built APK's
actual manifest application ID. No release build is provided or requested.

VersionCode is 21 and versionName is 0.22, so the existing **Build latest launch
test** archive workflow selects this source ZIP over 0.21's versionCode 20.
The existing workflow names the APK BedrockLaunchTest-0.22.apk, but the installed
app is **Bedrock Crash Capture**, with the distinct application ID above.

## Device steps

1. Build/install the debug APK alongside the existing launcher.
2. Open **Bedrock Crash Capture**, use **Тест запуска Minecraft**, create a small
   single-player test world and select XP bottles.
3. In kulich select Fast Exp, run **Проверить подключение**, enable the module
   and close kulich. This build intentionally retains 0.21's experimental native
   client-use path to reproduce its failure; it does not claim the crash is fixed.
4. After a crash, reopen **Bedrock Crash Capture**'s launcher screen. Do not start
   another game process before exporting. Tap **Сохранить дамп падения**.
5. Choose Downloads in the Android picker and save
   **bedrock-crash-capture-0.22.dmp.gz**. Send that file for analysis. The ordinary
   **Сохранить журнал** button remains available for supplemental text logs.

If a crash does not recur, disable Fast Exp and export the text log instead.
The dump button reports no saved dump until a valid minidump exists in this app.

## Export implementation

The launcher process reads only `<its own dataDir>/crash`. It selects the
newest regular `.dmp` whose first four bytes are `MDMP` and whose size is between
32 bytes and 256 MiB. It rejects directory entries, symlinks and path traversal.
It writes the original bytes into a gzip stream via ACTION_CREATE_DOCUMENT on
a worker thread. It compares source size/time before and after the copy and
never deletes or edits the source dump. An export error can leave a partial
user-selected destination; the original remains available for retry.

The selected dump basename is saved across Activity recreation while the
system file picker is open. Exports are blocked while the hosted game process
is running. No storage-management or external-storage permission is added.
No file upload occurs automatically. The user selects and attaches the file.

The original launch/class-loader/resource/library setup and native Fast Exp
code are unchanged from 0.21. Fast Exp starts disabled. It is enabled manually
only for the reproduction. Opening the launcher itself does not load the bridge
or start the hosted game. Auto Buy and Block Trap are still unimplemented.

Native debug symbols for libkulichbridge.so are retained in the diagnostic APK
so that the same build can be symbolized if that module appears in the crash.
The installed game's library is not packaged; it is prepared from the installed
Minecraft as before. Its exact size/SHA-256 guard remains in place.

## Validation

The standalone Java export tests pass for binary gzip round-trip, preservation
of source bytes/mtime, failure of the output stream, newest-valid-file selection,
missing/invalid/unfinished files, directories, symlinks, traversal and size limits.
All Java sources have been syntax-parsed. The native bridge sources match 0.21
byte for byte. This new APK has not been built with an Android SDK or tested on
the phone in this workspace. GitHub Actions supplies the Android/NDK build.

JDK17, Gradle8.7, AGP8.6.1, SDK35/build-tools35.0.0, NDK27.0.12077973,
CMake3.22.1; ARM64 only. Minimum Android11, target34, compile35.
