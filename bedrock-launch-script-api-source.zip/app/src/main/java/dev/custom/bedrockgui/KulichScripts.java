package dev.custom.bedrockgui;

import org.mozilla.javascript.*;
import java.util.*;

/** Interpreted JS modules. All host callbacks run on the menu's UI thread. */
public final class KulichScripts implements AutoCloseable {
    public interface Toggle { void set(boolean enabled); }
    public interface Host {
        void register(String id,String name,String description,Toggle callback);
        void log(String value);
        Object fast(String operation,Object value);
        void failed(String id);
    }
    private static final class Timeout extends Error {}
    private static final class Module {
        String id,name,description;Function toggle,tick;boolean enabled;
    }
    private final Host host;
    private final List<Module> modules=new ArrayList<>();
    private final ThreadLocal<Long> deadline=new ThreadLocal<>();
    private long logWindow;private int logCount;
    private final ContextFactory factory=new ContextFactory(){
        @Override protected Context makeContext(){
            Context cx=super.makeContext();cx.setOptimizationLevel(-1);
            cx.setMaximumInterpreterStackDepth(128);
            cx.setLanguageVersion(Context.VERSION_ES6);cx.setInstructionObserverThreshold(10000);
            cx.setClassShutter(name->false);return cx;
        }
        @Override protected void observeInstructionCount(Context cx,int count){
            Long end=deadline.get();if(end!=null&&System.nanoTime()>end)throw new Timeout();
        }
    };
    public KulichScripts(Host host){this.host=host;}
    private interface NativeCall { Object call(Object[] args); }
    private static void bind(ScriptableObject scope,String name,NativeCall action){
        BaseFunction fn=new BaseFunction(){
            @Override public Object call(Context cx,Scriptable s,Scriptable self,Object[] args){return action.call(args);}
        };
        fn.setParentScope(scope);fn.setPrototype(ScriptableObject.getFunctionPrototype(scope));
        ScriptableObject.putProperty(scope,name,fn);
    }
    private <T> T budget(int millis,ContextAction<T> action){
        deadline.set(System.nanoTime()+millis*1000000L);
        try{return factory.call(action);}finally{deadline.remove();}
    }
    private void invoke(Function fn,Object...args){
        budget(50,cx->fn.call(cx,fn.getParentScope(),fn.getParentScope(),args));
    }
    public void load(String bootstrap,String source,String filename){
        List<Module> pending=new ArrayList<>();
        try {
            // A single convenience import is supported; other imports need an adapter.
            source=source.replaceFirst("(?m)^\\s*import\\s*\\{\\s*defineModule\\s*}\\s*from\\s*['\"]@kulich/api['\"];?\\s*$", "");
            final String code=source;
            budget(500,cx->{
                ScriptableObject scope=cx.initSafeStandardObjects();
                bind(scope,"__log",a->{
                    long now=System.nanoTime();if(now-logWindow>1000000000L){logWindow=now;logCount=0;}
                    if(logCount++<16)host.log("Script "+Context.toString(a[0])+": "+Context.toString(a[1]));
                    return Undefined.instance;
                });
                bind(scope,"__fast",a->host.fast(Context.toString(a[0]),a.length>1?a[1]:null));
                bind(scope,"__register",a->{
                    if(pending.size()+modules.size()>=32)throw new IllegalStateException("Too many script modules");
                    String id="script_"+Context.toString(a[0]);
                    for(Module m:modules)if(m.id.equals(id))throw new IllegalArgumentException("Duplicate script id");
                    for(Module m:pending)if(m.id.equals(id))throw new IllegalArgumentException("Duplicate script id");
                    Module m=new Module();m.id=id;m.name=Context.toString(a[1]);m.description=Context.toString(a[2]);m.toggle=(Function)a[3];m.tick=(Function)a[4];pending.add(m);
                    return Undefined.instance;
                });
                cx.evaluateString(scope,bootstrap,"kulich-api.js",1,null);
                cx.evaluateString(scope,code,filename,1,null);
                return null;
            });
            // UI registration happens after the entire script has evaluated successfully.
            for(Module m:pending){
                modules.add(m);
                host.register(m.id,m.name,m.description,value->{
                    try{invoke(m.toggle,value);m.enabled=value;}
                    catch(RuntimeException|Timeout error){
                        try{invoke(m.toggle,false);}catch(RuntimeException|Timeout ignored){}
                        m.enabled=false;throw new IllegalStateException("Script callback failed",error);
                    }
                });
            }
            host.log("Scripts: loaded "+filename+"; modules="+pending.size());
        }catch(RuntimeException|Timeout error){host.log("Script load failed: "+filename+" / "+error.getClass().getSimpleName()+": "+error.getMessage());}
    }
    public void tick(){
        for(Module m:modules)if(m.enabled){
            try{invoke(m.tick);}catch(RuntimeException|Timeout error){
                m.enabled=false;
                try{invoke(m.toggle,false);}catch(RuntimeException|Timeout ignored){}
                host.failed(m.id);host.log("Script stopped: "+m.id+" / "+error.getClass().getSimpleName());
            }
        }
    }
    @Override public void close(){
        for(Module m:modules)if(m.enabled){try{invoke(m.toggle,false);}catch(RuntimeException|Timeout ignored){}m.enabled=false;}
        modules.clear();
    }
}
