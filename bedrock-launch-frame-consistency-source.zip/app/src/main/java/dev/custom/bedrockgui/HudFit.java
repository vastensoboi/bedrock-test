package dev.custom.bedrockgui;

/** Uniformly fit a fully measured HUD into its viewport, including its text. */
public final class HudFit {
    private HudFit(){}
    public static final class Result {
        public final float scale,left,top;
        Result(float scale,float left,float top){this.scale=scale;this.left=left;this.top=top;}
    }
    public static Result fit(int viewportWidth,int viewportHeight,int contentWidth,int contentHeight,int headerHeight){
        int width=Math.max(1,viewportWidth),height=Math.max(1,viewportHeight);
        int header=Math.max(0,Math.min(height-1,headerHeight));
        int childWidth=Math.max(1,contentWidth),childHeight=Math.max(1,contentHeight);
        float scale=Math.min(width/(float)childWidth,(height-header)/(float)childHeight);
        return new Result(scale,Math.max(0,(width-childWidth*scale)*.5f),
                header+Math.max(0,(height-header-childHeight*scale)*.5f));
    }
}
