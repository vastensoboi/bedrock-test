# Aimbot · 0.53: ввод активной камеры

Проверка на телефоне показала: в 0.51/0.52 изменение углов Actor не поворачивает
экран. Счётчик `applied` подтверждал вызовы, а не видимое наведение.

В 0.53 модуль больше не вызывает Actor::setRot/setYHeadRot. Он получает активную
камеру клиента и передаёт ограниченный поворот обработчику обзора Minecraft.
Игра сама обновляет камеру и направление игрока. Голова/тело, радиус, удержание
цели и настройка скорости 60–360°/с сохранены.

Собери BedrockLaunchTest-0.53 через Build latest launch test, открой
kulich → Таргет → Aimbot и проверь рядом с другим игроком в выбранном радиусе.
Проверь сначала «Голова», затем «Тело»; после выключения управление должно
оставаться ручным. На телефоне новый путь ещё не проверен.

Если экран неподвижен, сохрани журнал 0.53. `phase=camera-input` отличает новую
версию; `camera` показывает ID привязанной камеры; `applied` считает принятые
изменения ввода; `cameraChanges` считает изменения ориентации CameraComponent
между обновлениями. Они не заменяют наблюдение за экраном. `reason=7` означает,
что активная камера/её ввод не прошли проверку, `reason=8` — обработчик не
подтвердил ожидаемые значения ввода. Причины флагов Nevertime журнал клиента
не устанавливает.

## Camera path evidence for the supplied ARM64 library

The existing exact SHA-256 gate remains in place. Native code prefixes are
pinned alongside the older Actor profiles.

- ClientInstance virtual 165 points to 0x9b8bbf8. Client +424 owns the registry
  interface; its +8 lifetime pointer is checked alive before native dispatch.
  The original tagged client pointer comes from LocalPlayer +3240.
- 0x9c706c0 returns optional<StrictEntityContext> for the active camera using
  the native AArch64 x8 aggregate-result ABI. Layout: registry +0, registry+40
  at +8, entity ID +16, present byte +24; total 32 bytes. Context construction
  is visible at 0x134686b8; optional construction at 0x13469160.
- Require matching entity generation, ActiveCameraComponent (0x113040a1) and
  CurrentInputCameraComponent (0xf6c60b46) in the returned camera registry.
  CameraComponent (0x4f6047c7) stride 280; CameraDirectLookComponent
  (0xceb578f1) stride 20. These are FNV-1a of MinecraftCamera::qualified names.
- CameraDirectLook has yaw radians +0, pitch radians +4, pending yaw delta +8,
  minimum pitch +12 and maximum pitch +16. Its system at 0x11e6e530 consumes
  pending yaw, builds a unit quaternion at CameraComponent +40, then clears
  the pending yaw. Payload strides and offsets appear at 0x11e6e6e8..0x11e6e7b4.
- The input callback 0x11e5dcb4 takes context, camera, direct-look and a pointer
  to a two-float degree delta. It adds delta.x * pi/180 to pitch, subtracts
  delta.y * pi/180 from pending yaw, then normalizes/clamps pitch. The registry
  dispatcher at 0x11e5dd18 passes this callback and delta into 0x11e6df64.
- Native input dispatch runs on the existing game-update callback. Both native
  payload arguments retain the allocation tags from their storage pages.
  All read-only lookups still use untagged addresses. Revalidate components,
  finite pitch limits, unit quaternion and lease immediately before dispatch;
  read back input state afterwards. No direct rotation or packet writes.

Validation: eleven gameplay suites, including active camera identity/generation,
input-vs-render camera tags, MTE payload tags, invalid quaternion/limits and a
native-input/camera-consumption model; all app Java typechecks with Android 35
and Rhino; C++ syntax with warnings as errors; address/undefined sanitizers
(leak check disabled under the sandbox debugger). Full ARM64 APK linking and
visible camera behaviour require GitHub Actions and the phone.

## Earlier implementation (superseded)

# Aimbot · 0.52: плавный поворот

В журнале 0.51 цель найдена, привязка корректна, вызовы поворота выполняются.
Сообщений сервера, объясняющих «флаги», в журнале нет. Совместимость с Nevertime
по этому отчёту подтвердить нельзя.

В 0.52 поворот перенесён перед обновлением игрока и ограничен по скорости.
Настройка «Скорость поворота» — 60–360°/с, по умолчанию 180°/с. При обычном
обновлении раз в 50 мс это до 9° суммарного изменения pitch/yaw за обновление.
При задержке не накапливается большой разворот: учитывается максимум 100 мс.
Голова/тело, радиус и удержание одной цели сохранены. При захвате модуль сначала
плавно доворачивает камеру, затем следует за целью в пределах выбранной скорости.

Собери BedrockLaunchTest-0.52 через Build latest launch test. Проверь рядом
с другим игроком. Если снова возникают рывки или откаты, выключи модуль и сохрани
журнал 0.52. В нём добавлены maxTurn, speed и phase=before-update. Они помогают
проверить клиентские повороты, но не заменяют сообщение/журнал самого сервера.

## Предыдущая версия и схема данных

# Aimbot · 0.51

1. Собери исходники через Build latest launch test и установи BedrockLaunchTest-0.51.
2. Войди в мир, где рядом есть другой игрок. Открой kulich → Таргет → Aimbot.
3. Выбери «Голова» или «Тело», радиус (по умолчанию 6 блоков) и включи модуль.
4. Поверни камеру: при найденной цели модуль должен возвращать её к выбранной
   точке и следовать за движением игрока. Переключи голову/тело для проверки.
5. Выключи модуль — камера должна сразу снова управляться вручную. Если нет
   наведения или возник вылет, сохрани журнал kulich 0.51.

Меню можно держать открытым; модуль сохраняет состояние при другом окне.
Если Android/Minecraft останавливает саму игру, наведение ждёт её обновлений.
При выключении и закрытии игрового процесса наведение прекращается.

Первая версия выбирает ближайшего RemotePlayer по расстоянию и удерживает
именно его, даже если другой игрок подошёл ближе. При исчезновении/смене мира
или выходе из радиуса ищется новая цель. Мобы не выбираются. Фильтра друзей,
команд и проверки стены пока нет. Камера и голова поворачиваются явно; ударов
и отдельной подмены поворота в пакетах нет. Реальная работа на телефоне ещё
не подтверждена: локальные тесты не заменяют эту проверку.

## Exact-build layout evidence

The existing GameEngineProbe verifies SHA-256
4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4.

- RemotePlayer RTTI primary vptr is 0x139f76b0; constructors store it at
  0xaf694a8/0xaf694ac and 0xaf699d4/0xaf699d8. LocalPlayer remains 0x139f6ea0.
- Actor EntityContext is registry at +8, registry+40 at +16, 32-bit entity at +24.
  ActorOwnerComponent FNV-1a key 0x85b93800 is already established by player lookup.
  Actor removed flag +617 is checked by native resolver 0xfdb3c24..0xfdb3c38.
- Registry buckets/nodes and sparse generation scheme are the same as the
  existing player probe: map header +96/+104/+120/+128, 32-byte nodes;
  root entity sparse pages +216. Component sparse pages begin at storage+8,
  payload-page vector at +80/+88/+96; 128 payloads per page. Owner payload size 8.
- Component hashes are FNV-1a of their names. ActorRotationComponent = 0x75df36b7,
  AABBShapeComponent = 0xbac1b3cf, ActorHeadRotationComponent = 0xbabe7211.
  Rotation data is 16 bytes (current and previous Vec2), shape is 32 bytes
  (min/max Vec3, width/height), head is 8 bytes (current/previous yaw).
- Actor +552 is position, +560 shape and +568 rotation. Position getter
  0xfd8e62c loads current XYZ; shape getter 0xfd9b14c loads width at +24;
  yaw getter 0xfdaf960 reads rotation+4. Component addresses must match the
  local/remote cached shape and local cached rotation before gameplay use.
- Actor setRot 0xfd8f694 loads two floats from x1 and writes current rotation;
  setYHeadRot 0xfdafa3c resolves hash 0xbabe7211 and writes s0 to current yaw.
  Both signatures and the first eight instructions are pinned in aim_profile.h.
  Original MTE-tagged local this pointer is retained for native calls.

Native acquisition is bounded to 4096 owner entries and a five-millisecond/read
budget. Targets are revalidated immediately before native calls; stale entity
indices/pointers never authorize rotation. Journal records binding rejection,
scanned entries, target ID, angle values and applied-call count. An applied call
count proves native dispatch; actual camera behaviour still requires device
observation. There is no raw memory-write backend or arbitrary target setter API.
