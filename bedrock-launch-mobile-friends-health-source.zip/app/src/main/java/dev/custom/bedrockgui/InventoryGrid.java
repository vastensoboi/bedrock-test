package dev.custom.bedrockgui;

/** Chest grid plus explicitly calibrated origin of the 27-slot player inventory. */
public final class InventoryGrid {
    public final SlotGrid chest;public final float x,y;
    public InventoryGrid(SlotGrid chest,float x,float y){
        this.chest=chest;this.x=x;this.y=y;
        float last=chest.y+(chest.slots/9-1)*chest.dy;
        if(!Float.isFinite(x)||!Float.isFinite(y)||Math.abs(x-chest.x)>chest.dx*0.75f||
                y<last+chest.dy*0.7f||y>last+chest.dy*2.7f||x<chest.dx/3||
                x+8*chest.dx>chest.width-chest.dx/3||y+2*chest.dy>chest.height-chest.dy/3)
            throw new IllegalArgumentException("Четвёртая точка должна быть первой ячейкой инвентаря под сундуком");
    }
    public float[] point(int index){if(index<0||index>=27)throw new IllegalArgumentException("Нет такой ячейки инвентаря");return new float[]{x+(index%9)*chest.dx,y+(index/9)*chest.dy};}
}
