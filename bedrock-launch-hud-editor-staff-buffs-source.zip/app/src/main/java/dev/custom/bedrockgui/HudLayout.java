package dev.custom.bedrockgui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** HUD containers are transparent to game input except during explicit editing. */
public final class HudLayout {
    private final Activity activity;
    private final FrameLayout root;
    private final SharedPreferences preferences;
    private final float density;
    private final Map<String,Widget> widgets=new LinkedHashMap<>();
    private final View.OnLayoutChangeListener layoutListener;
    private View shade;private TextView hint;private Button done;
    private boolean editing,disposed;private Runnable onExit;

    public HudLayout(Activity activity,FrameLayout root,SharedPreferences preferences){
        this.activity=activity;this.root=root;this.preferences=preferences;
        density=activity.getResources().getDisplayMetrics().density;
        layoutListener=(v,l,t,r,b,ol,ot,or,ob)->{if(r-l!=or-ol||b-t!=ob-ot)applyAll();};
        root.addOnLayoutChangeListener(layoutListener);
    }
    private int dp(float value){return Math.max(1,Math.round(value*density));}
    public void register(String id,String title,View content,int widthDp,int heightDp,float x,float y){
        if(disposed)throw new IllegalStateException("HUD is disposed");
        if(id==null||!id.matches("[A-Za-z0-9_.-]{1,64}")||content==null||widgets.containsKey(id))throw new IllegalArgumentException("HUD ID must be unique");
        if(content.getParent() instanceof ViewGroup)((ViewGroup)content.getParent()).removeView(content);
        HudBounds defaults=new HudBounds(x,y,widthDp,heightDp);
        String key="hud."+id+".";
        HudBounds saved=new HudBounds(preferences.getFloat(key+"x",defaults.xFraction),preferences.getFloat(key+"y",defaults.yFraction),
                preferences.getFloat(key+"widthDp",defaults.widthDp),preferences.getFloat(key+"heightDp",defaults.heightDp));
        Widget widget=new Widget(id,title,content,defaults,saved);widgets.put(id,widget);
        content.setTranslationX(0);content.setTranslationY(0);
        widget.addView(content,new FrameLayout.LayoutParams(-1,-1));
        root.addView(widget,new FrameLayout.LayoutParams(dp(saved.widthDp),dp(saved.heightDp)));
        apply(widget);widget.syncVisibility();editorChromeTop();
        root.post(()->{if(!disposed)apply(widget);});
    }
    public List<String> registeredIds(){return Collections.unmodifiableList(new ArrayList<>(widgets.keySet()));}
    private Widget widget(String id){Widget widget=widgets.get(id);if(widget==null)throw new IllegalArgumentException("Unknown HUD: "+id);return widget;}
    public void visible(String id,boolean value){Widget w=widget(id);w.shown=value;w.syncVisibility();}
    public boolean visible(String id){return widget(id).shown;}
    public float widthDp(String id){return widget(id).bounds.widthDp;}
    public float heightDp(String id){return widget(id).bounds.heightDp;}
    public void setSize(String id,float widthDp,float heightDp){Widget w=widget(id);HudBounds b=w.bounds;w.bounds=new HudBounds(b.xFraction,b.yFraction,widthDp,heightDp);apply(w);save(w);}
    public void reset(String id){Widget w=widget(id);w.bounds=w.defaults;apply(w);save(w);}
    public void resetAll(){for(String id:registeredIds())reset(id);}
    public boolean isEditing(){return editing;}
    public void beginEditing(Runnable callback){
        if(disposed)return;
        if(editing){onExit=callback;return;}
        editing=true;onExit=callback;
        shade=new View(activity);shade.setElevation(dp(24));shade.setBackgroundColor(0x65000000);shade.setClickable(true);
        shade.setElevation(dp(30));shade.setContentDescription("Закончить редактирование HUD");shade.setOnClickListener(v->endEditing());root.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        for(Widget w:widgets.values()){w.syncVisibility();w.bringToFront();w.invalidate();}
        hint=new TextView(activity);hint.setElevation(dp(40));hint.setText("Редактор HUD\nПеретаскивай панели; тяни за нижний угол для размера");hint.setTextColor(Color.WHITE);hint.setTextSize(15);hint.setGravity(Gravity.CENTER);hint.setShadowLayer(dp(2),0,dp(1),Color.BLACK);
        FrameLayout.LayoutParams hintBounds=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);hintBounds.topMargin=dp(10);root.addView(hint,hintBounds);
        done=new Button(activity);done.setElevation(dp(40));done.setText("Готово");done.setOnClickListener(v->endEditing());
        FrameLayout.LayoutParams doneBounds=new FrameLayout.LayoutParams(dp(100),dp(48),Gravity.TOP|Gravity.END);doneBounds.topMargin=dp(8);doneBounds.rightMargin=dp(8);root.addView(done,doneBounds);
        applyAll();
    }
    private void editorChromeTop(){if(hint!=null)hint.bringToFront();if(done!=null)done.bringToFront();}
    public void endEditing(){
        if(!editing)return;
        editing=false;
        root.removeView(shade);root.removeView(hint);root.removeView(done);shade=null;hint=null;done=null;
        for(Widget w:widgets.values()){w.finishGesture();save(w);w.syncVisibility();w.invalidate();}
        Runnable callback=onExit;onExit=null;if(callback!=null)callback.run();
    }
    private void applyAll(){if(disposed)return;for(Widget w:widgets.values())apply(w);}
    private void apply(Widget w){
        if(root.getWidth()<=0||root.getHeight()<=0)return;
        HudBounds.Rect r=w.bounds.project(root.getWidth(),root.getHeight(),density);
        FrameLayout.LayoutParams params=(FrameLayout.LayoutParams)w.getLayoutParams();
        if(params.width!=r.width||params.height!=r.height){params.width=r.width;params.height=r.height;w.setLayoutParams(params);}
        w.setX(r.left);w.setY(r.top);w.invalidate();
    }
    private void save(Widget w){String key="hud."+w.id+".";HudBounds b=w.bounds;preferences.edit().putFloat(key+"x",b.xFraction).putFloat(key+"y",b.yFraction).putFloat(key+"widthDp",b.widthDp).putFloat(key+"heightDp",b.heightDp).apply();}
    public void dispose(){
        if(disposed)return;onExit=null;endEditing();disposed=true;root.removeOnLayoutChangeListener(layoutListener);
        for(Widget w:widgets.values())root.removeView(w);widgets.clear();
    }
    private final class Widget extends FrameLayout {
        final String id,title;final View content;final HudBounds defaults;HudBounds bounds;
        final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);boolean shown=true;
        int pointer=-1;boolean resize;float rawX,rawY;HudBounds.Rect anchor;
        Widget(String id,String title,View content,HudBounds defaults,HudBounds saved){
            super(activity);this.id=id;this.title=title==null?id:title;this.content=content;this.defaults=defaults;bounds=saved;
            setClickable(false);setFocusable(false);setClipChildren(true);setClipToPadding(true);
        }
        void syncVisibility(){setElevation(editing?dp(32):0);setVisibility(editing||shown?View.VISIBLE:View.GONE);}
        @Override public boolean dispatchTouchEvent(MotionEvent event){return editing?editTouch(event):super.dispatchTouchEvent(event);}
        @Override protected void dispatchDraw(Canvas canvas){
            super.dispatchDraw(canvas);if(!editing)return;
            float stroke=dp(2),pad=stroke/2;paint.setColor(0xff7be6ff);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(stroke);
            canvas.drawRoundRect(pad,pad,getWidth()-pad,getHeight()-pad,dp(8),dp(8),paint);
            String label=(!shown||content.getVisibility()!=View.VISIBLE?"Пример: ":"")+title;
            paint.setStyle(Paint.Style.FILL);paint.setTextSize(dp(11));paint.setColor(0xe611252b);
            canvas.drawRect(dp(3),dp(3),Math.min(getWidth()-dp(3),dp(10)+paint.measureText(label)),dp(20),paint);
            paint.setColor(Color.WHITE);canvas.drawText(label,dp(6),dp(16),paint);
            Path grip=new Path();grip.moveTo(getWidth()-dp(21),getHeight()-dp(4));grip.lineTo(getWidth()-dp(4),getHeight()-dp(21));grip.lineTo(getWidth()-dp(4),getHeight()-dp(4));grip.close();paint.setColor(0xff7be6ff);canvas.drawPath(grip,paint);
        }
        boolean editTouch(MotionEvent event){
            switch(event.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    pointer=event.getPointerId(0);rawX=event.getRawX(0);rawY=event.getRawY(0);anchor=bounds.project(root.getWidth(),root.getHeight(),density);
                    resize=event.getX()>=getWidth()-dp(28)&&event.getY()>=getHeight()-dp(28);root.requestDisallowInterceptTouchEvent(true);bringToFront();editorChromeTop();return true;
                case MotionEvent.ACTION_MOVE:move(event);return true;
                case MotionEvent.ACTION_UP:move(event);finishGesture();save(this);return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if(event.getPointerId(event.getActionIndex())==pointer){finishGesture();save(this);}return true;
                case MotionEvent.ACTION_CANCEL:finishGesture();save(this);return true;
                default:return true;
            }
        }
        void move(MotionEvent event){
            int index=event.findPointerIndex(pointer);if(index<0||anchor==null)return;
            float dx=event.getRawX(index)-rawX,dy=event.getRawY(index)-rawY;
            bounds=resize?bounds.resized(anchor,anchor.width+dx,anchor.height+dy,root.getWidth(),root.getHeight(),density):
                    bounds.moved(anchor.left+dx,anchor.top+dy,root.getWidth(),root.getHeight(),density);
            apply(this);
        }
        void finishGesture(){pointer=-1;anchor=null;root.requestDisallowInterceptTouchEvent(false);}
    }
}
