package dev.custom.bedrockgui;

/** Persisted HUD geometry: normalized free-space position and density-independent size. */
public final class HudBounds {
    public static final float MIN_WIDTH_DP=80,MIN_HEIGHT_DP=40;
    public final float xFraction,yFraction,widthDp,heightDp;
    public HudBounds(float x,float y,float width,float height){
        xFraction=unit(x);yFraction=unit(y);
        widthDp=size(width,MIN_WIDTH_DP,220);heightDp=size(height,MIN_HEIGHT_DP,90);
    }
    private static float unit(float value){return Float.isFinite(value)?Math.max(0,Math.min(1,value)):.5f;}
    private static float size(float value,float minimum,float fallback){return Math.max(minimum,Math.min(8192,Float.isFinite(value)?value:fallback));}
    private static float density(float value){return Float.isFinite(value)&&value>0?Math.max(.1f,Math.min(10,value)):1;}
    private static int viewport(int value){return Math.max(1,value);}
    private static int clamp(float value,int minimum,int maximum){return Math.max(minimum,Math.min(maximum,Math.round(Float.isFinite(value)?value:minimum)));}
    public static final class Rect {
        public final int left,top,width,height;
        private Rect(int left,int top,int width,int height){this.left=left;this.top=top;this.width=width;this.height=height;}
    }
    public Rect project(int viewportWidth,int viewportHeight,float scale){
        int vw=viewport(viewportWidth),vh=viewport(viewportHeight);float d=density(scale);
        int w=clamp(widthDp*d,Math.min(vw,Math.round(MIN_WIDTH_DP*d)),vw);
        int h=clamp(heightDp*d,Math.min(vh,Math.round(MIN_HEIGHT_DP*d)),vh);
        return new Rect(Math.round(xFraction*(vw-w)),Math.round(yFraction*(vh-h)),w,h);
    }
    public HudBounds moved(float left,float top,int viewportWidth,int viewportHeight,float scale){
        Rect rect=project(viewportWidth,viewportHeight,scale);
        int sx=viewport(viewportWidth)-rect.width,sy=viewport(viewportHeight)-rect.height;
        return new HudBounds(sx>0?clamp(left,0,sx)/(float)sx:xFraction,
                sy>0?clamp(top,0,sy)/(float)sy:yFraction,widthDp,heightDp);
    }
    /** Resize from a fixed top-left corner, limiting growth to the remaining screen. */
    public HudBounds resized(Rect anchor,float width,float height,int viewportWidth,int viewportHeight,float scale){
        int vw=viewport(viewportWidth),vh=viewport(viewportHeight);float d=density(scale);
        int left=clamp(anchor.left,0,vw-1),top=clamp(anchor.top,0,vh-1),availableWidth=vw-left,availableHeight=vh-top;
        int w=clamp(width,Math.min(availableWidth,Math.round(MIN_WIDTH_DP*d)),availableWidth);
        int h=clamp(height,Math.min(availableHeight,Math.round(MIN_HEIGHT_DP*d)),availableHeight);
        int sx=vw-w,sy=vh-h;
        return new HudBounds(sx>0?left/(float)sx:xFraction,sy>0?top/(float)sy:yFraction,w/d,h/d);
    }
}
