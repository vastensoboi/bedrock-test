package dev.custom.bedrockgui;

import java.io.File;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import javax.tools.ToolProvider;

/** Real separated loaders reproduce a generated callback's game-superclass dependency. */
public final class GameClassPolicyTest {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    private static Path source(Path root,String name,String body)throws Exception{
        Path path=root.resolve(name.replace('.','/')+".java");Files.createDirectories(path.getParent());Files.writeString(path,body);return path;
    }
    private static void compile(Path output,String classpath,Path... sources){
        List<String> args=new ArrayList<>(List.of("-d",output.toString()));
        if(classpath!=null)args.addAll(List.of("-cp",classpath));
        for(Path path:sources)args.add(path.toString());
        check(ToolProvider.getSystemJavaCompiler().run(null,null,null,args.toArray(String[]::new))==0,"Fixture compilation failed");
    }
    private static final class GameLoader extends URLClassLoader {
        private final boolean legacy;
        GameLoader(URL[] urls,ClassLoader parent,boolean legacy){super(urls,parent);this.legacy=legacy;}
        @Override protected Class<?> loadClass(String name,boolean resolve)throws ClassNotFoundException{
            boolean child=legacy?(name.equals(GameClassPolicy.ACTIVITY)||name.equals(GameClassPolicy.STARTUP)||name.startsWith("com.mojang.")):GameClassPolicy.childFirst(name);
            if(!child)return super.loadClass(name,resolve);
            synchronized(getClassLoadingLock(name)){
                Class<?> found=findLoadedClass(name);
                if(found==null){try{found=findClass(name);}catch(ClassNotFoundException missing){found=super.loadClass(name,false);}}
                if(resolve)resolveClass(found);return found;
            }
        }
    }
    public static void main(String[] args)throws Exception{
        String activity=GameClassPolicy.ACTIVITY,startup=GameClassPolicy.STARTUP;
        check(GameClassPolicy.childFirst(activity)&&GameClassPolicy.childFirst(activity+"$1")&&GameClassPolicy.childFirst(activity+"$$ExternalSyntheticLambda0"),"Activity family not child-first");
        check(GameClassPolicy.childFirst(startup+"$Helper")&&GameClassPolicy.childFirst(startup+"$$ExternalSyntheticLambda7"),"Startup family not child-first");
        for(String name:List.of("dev.custom.bedrockgui.OwnLogCapture","dev.custom.bedrockgui.CaptureLease","dev.custom.bedrockgui.OwnLogRecorder","dev.custom.bedrockgui.GameRuntime","dev.custom.bedrockgui.GameMenu",activity+"Other","java.lang.String"))
            check(!GameClassPolicy.childFirst(name),"Shared/lookalike class became child-first: "+name);
        Path root=Files.createTempDirectory("game-class-policy"),game=root.resolve("game"),host=root.resolve("host"),src=root.resolve("src");
        Files.createDirectories(game);Files.createDirectories(host);
        try{
            Path gameActivity=source(src,"com.mojang.minecraftpe.MainActivity","package com.mojang.minecraftpe; public class MainActivity { public int count; public void recover(){count++;} }");
            compile(game,null,gameActivity);
            Path hosted=source(src,activity,"package dev.custom.bedrockgui; public class HostedGameActivity extends com.mojang.minecraftpe.MainActivity { public Runnable callback=new HostedGameActivity$$ExternalSyntheticLambda0(this); }");
            Path companion=source(src,activity+"$$ExternalSyntheticLambda0","package dev.custom.bedrockgui; public final class HostedGameActivity$$ExternalSyntheticLambda0 implements Runnable { private final HostedGameActivity owner; public HostedGameActivity$$ExternalSyntheticLambda0(HostedGameActivity owner){this.owner=owner;} public void run(){owner.recover();} }");
            Path bootstrap=source(src,startup,"package dev.custom.bedrockgui; public class NativeStartup { public int count; public Runnable callback=new Helper(this); public static class Helper implements Runnable { private final NativeStartup owner; public Helper(NativeStartup owner){this.owner=owner;} public void run(){owner.count++;} } }");
            Path shared=source(src,"dev.custom.bedrockgui.OwnLogCapture","package dev.custom.bedrockgui; public final class OwnLogCapture { public static final Object OWNER=new Object(); }");
            compile(host,game.toString(),hosted,companion,bootstrap,shared);
            URL[] childPaths={host.toUri().toURL(),game.toUri().toURL()};
            // The app APK contains host classes but deliberately excludes the
            // compile-only game superclass. A generated companion must not
            // resolve its Activity type against this parent APK.
            try(URLClassLoader parent=new URLClassLoader(new URL[]{host.toUri().toURL()},ClassLoader.getPlatformClassLoader());
                GameLoader broken=new GameLoader(childPaths,parent,true)){
                boolean reproduced=false;
                try{
                    Class<?> type=broken.loadClass(activity);Object value=type.getConstructor().newInstance();
                    ((Runnable)type.getField("callback").get(value)).run();
                }catch(LinkageError error){reproduced=true;}
                catch(java.lang.reflect.InvocationTargetException error){reproduced=error.getCause() instanceof LinkageError;}
                check(reproduced,"Legacy exact-name loader did not reproduce the failure");
            }
            try(URLClassLoader parent=new URLClassLoader(new URL[]{host.toUri().toURL()},ClassLoader.getPlatformClassLoader());
                GameLoader fixed=new GameLoader(childPaths,parent,false)){
                Class<?> type=fixed.loadClass(activity);Object value=type.getConstructor().newInstance();
                Runnable callback=(Runnable)type.getField("callback").get(value);callback.run();
                check(type.getField("count").getInt(value)==1,"Activity callback did not run");
                check(type.getClassLoader()==fixed&&callback.getClass().getClassLoader()==fixed&&type.getSuperclass().getClassLoader()==fixed,"Game class family split between loaders");
                Class<?> boot=fixed.loadClass(startup);Object bootValue=boot.getConstructor().newInstance();
                Runnable helper=(Runnable)boot.getField("callback").get(bootValue);helper.run();
                check(boot.getField("count").getInt(bootValue)==1&&helper.getClass().getClassLoader()==fixed,"Startup helper lost owner loader");
                Class<?> capture=fixed.loadClass("dev.custom.bedrockgui.OwnLogCapture");
                check(capture==parent.loadClass(capture.getName())&&capture.getClassLoader()==parent,"Shared capture state was duplicated");
                check(capture.getField("OWNER").get(null)==parent.loadClass(capture.getName()).getField("OWNER").get(null),"Shared capture identity diverged");
            }
        }finally{
            try(var paths=Files.walk(root)){for(Path path:paths.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(path);}
        }
        System.out.println("PASS: legacy generated-callback loader failure reproduced; Activity/startup companions share game superclass loader, shared capture helpers retain parent identity");
    }
}
