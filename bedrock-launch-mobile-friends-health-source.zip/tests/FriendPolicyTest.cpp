#include "../app/src/main/cpp/friend_core.h"
#include <cassert>
#include <iostream>
using namespace kulich_aim;
int main(){
 FriendPolicy p;assert(p.empty()&&p.check(nullptr)==FriendPolicy::Enemy);
 assert(p.replace("Steve_1\nAnn"));assert(p.size()==2);
 assert(p.check("STEVE_1")==FriendPolicy::Friend&&p.check("ann")==FriendPolicy::Friend);
 assert(p.check("Anna")==FriendPolicy::Enemy&&p.check("NotSteve_1")==FriendPolicy::Enemy);
 assert(p.check(nullptr)==FriendPolicy::Unknown&&p.check("")==FriendPolicy::Unknown);
 assert(p.check("[VIP] Ann")==FriendPolicy::Unknown&&p.check("§aAnn")==FriendPolicy::Unknown);
 assert(!p.replace("Ann\n../x")&&p.size()==2&&p.check("Ann")==FriendPolicy::Friend);
 assert(!p.replace(std::string("Ann\0Bob",7))&&p.size()==2);
 assert(!p.replace(std::string(17,'a'))&&p.size()==2);
 assert(friendKey("User_01234567890")=="user_01234567890");
 // Display aliases protect an existing friend even if its internal account
 // name differs. Raw identity protection wins over a changed display alias.
 assert(p.check("Account7","§6[VIP] §aAnn")==FriendPolicy::Friend);
 assert(p.check("Account7","§l[VIP]§bANN")==FriendPolicy::Friend);
 assert(p.check("Ann","Enemy")==FriendPolicy::Friend);
 assert(p.check("Anna","[VIP] Anna")==FriendPolicy::Enemy);
 assert(p.check("Account7","NotAnn")==FriendPolicy::Enemy);
 assert(p.check(nullptr,"[VIP] Ann\n7/18 ♥")==FriendPolicy::Friend);
 assert(p.check(nullptr,"[VIP] Other")==FriendPolicy::Unknown);
 assert(p.check("Account7","яAnn")==FriendPolicy::Enemy);
 assert(p.check("Account7","Annя")==FriendPolicy::Enemy);
 assert(p.check("Account7","日本Ann")==FriendPolicy::Enemy);
 assert(p.check("Account7","Ann日本")==FriendPolicy::Enemy);
 assert(p.check("Account7","[Ann] Other")==FriendPolicy::Enemy);
 assert(p.replace("VIP\n7\n18"));
 assert(p.check("Account7","§a[VIP] Other\n7/18 ♥")==FriendPolicy::Enemy);
 assert(p.check("7","Other")==FriendPolicy::Friend); // exact raw numeric nick remains valid
 assert(p.check(nullptr,"7/18 ♥")==FriendPolicy::Unknown);
 assert(p.replace("Ann"));
 assert(p.check("Account7",std::string(385,'a').c_str())==FriendPolicy::Enemy);
 // Updating the list while a lock exists changes the final dispatch decision.
 assert(p.check("Enemy")==FriendPolicy::Enemy);assert(p.replace("Enemy"));assert(p.check("Enemy")==FriendPolicy::Friend);
 assert(p.replace("")&&p.empty()&&p.check("Enemy")==FriendPolicy::Enemy);
 std::string maximum;for(int i=0;i<128;i++){if(i)maximum+='\n';maximum+="User"+std::to_string(i);}assert(p.replace(maximum)&&p.size()==128);
 assert(!p.replace(maximum+"\nExtra")&&p.size()==128&&p.check("USER127")==FriendPolicy::Friend);
 std::cout<<"PASS: exact friend identity, display alias veto, UTF-8/format/rank/health boundaries, unknown fail-closed and live list updates\n";
}
