package dev.custom.bedrockgui;

import android.content.*;
import android.os.*;
import java.io.*;

/** Loaded child-first from this app's APK; superclass comes only from game APK. */
public final class HostedGameActivity extends com.mojang.minecraftpe.MainActivity {
    @Override protected void attachBaseContext(Context base) {
        try { super.attachBaseContext(GameRuntime.attachResources(base)); }
        catch(IOException error){ GameRuntime.log("Resource attachment failed: "+error);throw new IllegalStateException(error); }
    }
    @Override public ClassLoader getClassLoader(){return GameRuntime.loader!=null?GameRuntime.loader:super.getClassLoader();}
    @Override public android.content.res.Resources getResources(){
        return GameRuntime.resources!=null?GameRuntime.resources:super.getResources();
    }
    @Override public android.content.res.AssetManager getAssets(){
        return GameRuntime.resources!=null?GameRuntime.resources.getAssets():super.getAssets();
    }
    @Override public void onCreate(Bundle state) {
        GameRuntime.log("Activity: entering game onCreate");
        try {
            String gamePackage = "com.mojang.minecraftpe";
            android.content.pm.ActivityInfo original = getPackageManager().getActivityInfo(
                    new ComponentName(gamePackage, gamePackage + ".MainActivity"), 0);
            int originalTheme = original.getThemeResource();
            if (originalTheme == 0) throw new IllegalStateException("Minecraft Activity has no theme");
            GameRuntime.log("Activity: applying original game theme " +
                    getResources().getResourceName(originalTheme) + " / 0x" + Integer.toHexString(originalTheme));
            setTheme(originalTheme);
            super.onCreate(state);
            GameRuntime.log("Activity: game onCreate returned (not a gameplay success check)");
        }catch(Exception|LinkageError error) {
            StringWriter trace=new StringWriter();error.printStackTrace(new PrintWriter(trace));
            GameRuntime.log("Activity onCreate failed\n"+trace);
            finish();
        }
    }
    @Override public void onResume(){super.onResume();GameRuntime.log("Activity: resumed");}
    @Override public void onDestroy(){
        GameRuntime.log("Activity: destroying");
        try {super.onDestroy();}
        finally { new Handler(Looper.getMainLooper()).postDelayed(()->android.os.Process.killProcess(android.os.Process.myPid()),100); }
    }
}
