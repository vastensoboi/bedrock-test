package dev.custom.bedrockgui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.*;

/** Passive cards used by the HUD editor and real data models; no gameplay samples are injected. */
public final class HudDataPanels {
    private final Panel staff,buffs,active;
    public HudDataPanels(Context context){
        staff=new Panel(context,"STAFF LIST");buffs=new Panel(context,"Buff Timer");active=new Panel(context,"Функции");
        updateStaff(Collections.singletonList("Список игроков недоступен"));updateBuffs(Collections.singletonList("Эффекты недоступны"));updateActive(Collections.emptyList());
    }
    public View staffView(){return staff.card;}
    public View buffsView(){return buffs.card;}
    public View activeView(){return active.card;}
    public void updateStaff(List<String> lines){staff.set(lines==null?Collections.singletonList("Список игроков недоступен"):lines);}
    public void updateBuffs(List<String> lines){buffs.set(lines==null?Collections.singletonList("Эффекты недоступны"):lines);}
    public void updateActive(List<String> enabled){
        ArrayList<String> lines=new ArrayList<>();if(enabled!=null)for(String name:enabled)if(name!=null&&!name.trim().isEmpty())lines.add("● "+name);
        if(lines.isEmpty())lines.add("Нет включённых функций");active.set(lines);
    }
    private static final class Panel {
        final Context context;final float density;final LinearLayout card,body;String last;
        Panel(Context context,String title){
            this.context=context;density=context.getResources().getDisplayMetrics().density;
            card=new LinearLayout(context);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(8));card.setClickable(false);card.setFocusable(false);
            card.setBackgroundColor(Color.TRANSPARENT);card.setElevation(0);
            TextView caption=text(title,13,Color.WHITE);caption.setTypeface(Typeface.DEFAULT,Typeface.BOLD);card.addView(caption,new LinearLayout.LayoutParams(-1,-2));
            body=new LinearLayout(context);body.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams bounds=new LinearLayout.LayoutParams(-1,-2);bounds.topMargin=dp(4);card.addView(body,bounds);
        }
        int dp(int n){return Math.round(n*density);}
        TextView text(String value,int size,int color){TextView t=new TextView(context);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setShadowLayer(dp(1),0,dp(1),0xd0000000);t.setClickable(false);t.setFocusable(false);return t;}
        void set(List<String> lines){
            String key=String.join("\n",lines);if(key.equals(last))return;last=key;body.removeAllViews();
            for(String value:lines){
                String line=value==null?"":value;int split=line.indexOf('\t');
                if(split<0)body.addView(text(line,12,Color.WHITE),new LinearLayout.LayoutParams(-1,-2));
                else{
                    LinearLayout row=new LinearLayout(context);row.setGravity(Gravity.CENTER_VERTICAL);
                    TextView name=text(line.substring(0,split),12,Color.WHITE),time=text(line.substring(split+1),12,Color.WHITE);time.setGravity(Gravity.RIGHT);
                    row.addView(name,new LinearLayout.LayoutParams(0,-2,1));row.addView(time,new LinearLayout.LayoutParams(-2,-2));body.addView(row,new LinearLayout.LayoutParams(-1,-2));
                }
            }
        }
    }
}
