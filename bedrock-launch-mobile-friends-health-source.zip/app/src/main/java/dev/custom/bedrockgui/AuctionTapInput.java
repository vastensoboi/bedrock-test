package dev.custom.bedrockgui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Calibration and one explicit refresh test in this app's own game window only. */
public final class AuctionTapInput {
    private final Activity activity;private final FrameLayout root;private final Runnable closeMenu;private final View floating;
    private final SharedPreferences prefs;private FrameLayout layer;private View marker;private boolean busy,disposed;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int generation,dragGeneration;private float[] lastPoint;private long downTime,sequenceTime;
    private boolean fingerDown;private int downsAccepted,upsAccepted;
    private long firstReleased,firstHold,secondHold,secondStarted;
    private java.util.function.Consumer<Boolean> completion;private String actionLabel="refresh";
    private long lastRefreshLog;
    private String lastFailure="";
    public boolean transientRefreshFailure(){return lastFailure.equals("source changed before first tap")||lastFailure.equals("first tap cancelled")||lastFailure.equals("second tap cancelled")||lastFailure.equals("window/source changed or second tap delayed");}
    private GameEngineProbe.TapSession touchSession;
    private void closeSession(){if(touchSession!=null){touchSession.close();touchSession=null;}}
    public AuctionTapInput(Activity activity,FrameLayout root,View floating,Runnable closeMenu){
        this.activity=activity;this.root=root;this.floating=floating;this.closeMenu=closeMenu;prefs=activity.getSharedPreferences("auction-grid",0);
    }
    public boolean calibrating(){return layer!=null||marker!=null;}
    private void message(String text){Toast.makeText(activity,text,Toast.LENGTH_LONG).show();GameRuntime.log("Auto Buy input: "+text);}
    private boolean active(){return !disposed&&!activity.isFinishing()&&!activity.isDestroyed()&&activity.hasWindowFocus();}
    private SlotGrid chestProfile(int slots){
        View decor=activity.getWindow().getDecorView();int width=decor.getWidth(),height=decor.getHeight();
        String p="grid"+slots+".";
        if(prefs.contains(p+"width"))try{
            SlotGrid saved=new SlotGrid(slots,prefs.getInt(p+"width",0),prefs.getInt(p+"height",0),prefs.getFloat(p+"x",0),prefs.getFloat(p+"y",0),prefs.getFloat(p+"rx",0),prefs.getFloat(p+"ry",0),prefs.getFloat(p+"nx",0),prefs.getFloat(p+"ny",0));
            if(saved.fits(slots,width,height))return saved;
        }catch(IllegalArgumentException ignored){}
        try{return SlotGrid.preconfigured(slots,width,height);}
        catch(IllegalArgumentException error){return null;}
    }
    private SlotGrid fittedGrid(){
        SlotGrid grid=chestProfile(54);View decor=activity.getWindow().getDecorView();
        if(grid==null||!grid.fits(54,decor.getWidth(),decor.getHeight())){message("Готовый профиль недоступен для этого размера экрана. Открой игру горизонтально");return null;}
        return grid;
    }
    public void showRefreshPoint(){
        prepare(54,()->{
            SlotGrid grid=fittedGrid();if(grid==null)return;closeMenu.run();
            float[] point=grid.point(49);int[] offset=new int[2];root.getLocationInWindow(offset);
            float x=point[0]-offset[0],y=point[1]-offset[1],radius=grid.dx*0.35f;
            View view=new View(activity){
                final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
                @Override protected void onDraw(Canvas canvas){
                    super.onDraw(canvas);paint.setColor(Color.GREEN);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4);
                    canvas.drawCircle(x,y,radius,paint);canvas.drawLine(x-radius,y,x+radius,y,paint);canvas.drawLine(x,y-radius,x,y+radius,paint);
                    paint.setStyle(Paint.Style.FILL);paint.setTextSize(14*getResources().getDisplayMetrics().scaledDensity);
                    canvas.drawText("49: ОБНОВИТЬ",x+radius+8,y-8,paint);
                }
            };
            view.setClickable(false);view.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            marker=view;root.addView(view,new FrameLayout.LayoutParams(-1,-1));
            GameRuntime.log("Auto Buy input: marker source="+Arrays.toString(point)+" squarePitch="+grid.dx);
            handler.postDelayed(()->{if(marker==view){root.removeView(view);marker=null;}},3000);
        });
    }
    private void prepare(int slots,Runnable action){
        if(busy||disposed||calibrating()||lastPoint!=null)return;
        if(!GameEngineProbe.begin()){message("Дождись окончания текущего чтения");return;}
        busy=true;int token=generation;message("Проверяю открытое окно…");
        Thread worker=new Thread(()->{
            try{GameEngineProbe.run();GameEngineProbe.auctionSnapshot();}
            catch(RuntimeException|LinkageError error){GameRuntime.log("Auto Buy input prepare failed: "+error);}
            finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{
                busy=false;if(!active()||generation!=token)return;
                if(!GameEngineProbe.hasAuctionWindow(slots)){message(slots==54?"Открой список аукциона на 54 слота":"Открой окно покупки на 27 слотов");return;}
                action.run();
            });
        },"auction-input-prepare");worker.setDaemon(true);worker.start();
    }
    public void calibrate(int slots){prepare(slots,()->beginCalibration(slots));}
    private void beginCalibration(int slots){
        closeMenu.run();View decor=activity.getWindow().getDecorView();int width=decor.getWidth(),height=decor.getHeight();
        layer=new FrameLayout(activity);layer.setBackgroundColor(Color.argb(20,0,0,0));
        TextView hint=new TextView(activity);hint.setTextColor(Color.WHITE);hint.setTextSize(16);hint.setBackgroundColor(Color.argb(210,0,0,0));
        hint.setPadding(12,8,12,8);hint.setText("1/4: нажми в центр верхнего ЛЕВОГО слота (0)");
        FrameLayout.LayoutParams textBounds=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);layer.addView(hint,textBounds);
        Button cancel=new Button(activity);cancel.setText("Отмена настройки");
        FrameLayout.LayoutParams cancelBounds=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);layer.addView(cancel,cancelBounds);
        cancel.setOnClickListener(v->cancelCalibration());
        float[] points=new float[8];int[] index={0};
        layer.setOnTouchListener((v,event)->{
            if(event.getPointerCount()!=1)return true;
            if(event.getActionMasked()!=MotionEvent.ACTION_UP)return true;
            int[] origin=new int[2];decor.getLocationOnScreen(origin);
            points[index[0]*2]=event.getRawX()-origin[0];points[index[0]*2+1]=event.getRawY()-origin[1];index[0]++;
            if(index[0]==1)hint.setText("2/4: центр верхнего ПРАВОГО слота (8)");
            else if(index[0]==2)hint.setText("3/4: центр ЛЕВОГО слота второй строки (9)");
            else if(index[0]==3)hint.setText("4/4: центр ПЕРВОЙ ячейки своего инвентаря под сундуком (не хотбар)");
            else{
                try{
                    SlotGrid grid=new SlotGrid(slots,width,height,points[0],points[1],points[2],points[3],points[4],points[5]);
                    new InventoryGrid(grid,points[6],points[7]);
                    String p="grid"+slots+".";
                    prefs.edit().putInt(p+"width",width).putInt(p+"height",height).putFloat(p+"x",points[0]).putFloat(p+"y",points[1])
                            .putFloat(p+"rx",points[2]).putFloat(p+"ry",points[3]).putFloat(p+"nx",points[4]).putFloat(p+"ny",points[5]).putFloat(p+"ix",points[6]).putFloat(p+"iy",points[7]).apply();
                    GameRuntime.log("Auto Buy input: calibrated slots="+slots+" viewport="+width+"x"+height+" origin="+grid.x+","+grid.y+" pitch="+grid.dx+","+grid.dy+" inventoryOrigin="+points[6]+","+points[7]);
                    message("Сетка настроена: "+slots+" слотов");
                }catch(IllegalArgumentException error){message(error.getMessage());}
                cancelCalibration();
            }
            return true;
        });
        root.addView(layer,new FrameLayout.LayoutParams(-1,-1));layer.bringToFront();
    }
    private void cancelCalibration(){if(layer!=null){root.removeView(layer);layer=null;}}
    public boolean readyForAutomation(){
        View decor=activity.getWindow().getDecorView();
        for(int slots:new int[]{54,27}){SlotGrid grid=chestProfile(slots);if(grid==null||!grid.fits(slots,decor.getWidth(),decor.getHeight()))return false;}
        return true;
    }
    public boolean inputBusy(){return busy||calibrating()||lastPoint!=null;}
    public void cancelAutomatic(){if(lastPoint!=null&&completion!=null)finishSequence(false,"automation stopped");}
    public void automatic(AuctionMemoryProbe.ActionToken token,java.util.function.Consumer<Boolean> done){
        lastFailure="preparation rejected";
        if(token==null||inputBusy()||!active()){done.accept(false);return;}
        SlotGrid grid=chestProfile(token.slots);View decor=activity.getWindow().getDecorView();
        if(grid==null||!grid.fits(token.slots,decor.getWidth(),decor.getHeight())){done.accept(false);return;}
        try{startSequence(GameEngineProbe.openActionSession(token),grid,token.slot,done);}
        catch(java.io.IOException|RuntimeException error){GameRuntime.log("Auto Buy input failed: "+error.getClass().getSimpleName());done.accept(false);}
    }
    public void testRefresh(){
        prepare(54,()->{
            SlotGrid grid=fittedGrid();if(grid==null)return;closeMenu.run();
            handler.post(()->{
                try{startSequence(GameEngineProbe.openTapSession(),grid,49,null);}
                catch(java.io.IOException|RuntimeException error){message("Не удалось подготовить ввод: "+error.getMessage());}
            });
        });
    }
    private void startSequence(GameEngineProbe.TapSession session,SlotGrid grid,int slot,java.util.function.Consumer<Boolean> done){
        float[] point=grid.point(slot);View decor=activity.getWindow().getDecorView();int[] origin=new int[2];decor.getLocationOnScreen(origin);
        android.graphics.Rect icon=new android.graphics.Rect();floating.getGlobalVisibleRect(icon);
        String rejection=!active()||lastPoint!=null?"inactive/input busy":
                icon.contains(Math.round(point[0]+origin[0]),Math.round(point[1]+origin[1]))?"icon covers slot":
                !session.validate()?"source changed before first tap":null;
        if(rejection!=null){
            lastFailure=rejection;session.close();if(done!=null)done.accept(false);else message("Окно изменилось или иконка перекрывает слот");return;
        }
        touchSession=session;completion=done;actionLabel="slots="+grid.slots+" slot="+slot;
        int sequence=++dragGeneration;lastPoint=point;downsAccepted=0;upsAccepted=0;firstReleased=0;firstHold=0;secondHold=0;secondStarted=0;sequenceTime=SystemClock.uptimeMillis();
        if(!tapDown()){finishSequence(false,"first DOWN rejected");return;}
        handler.postDelayed(()->{
            if(lastPoint==null||dragGeneration!=sequence)return;
            if(!tapUp()){finishSequence(false,"first tap cancelled");return;}
        },55);
        handler.postDelayed(()->{
            if(lastPoint==null||dragGeneration!=sequence)return;
            if(fingerDown||!active()||touchSession==null||!touchSession.validate()||firstReleased==0||SystemClock.uptimeMillis()-firstReleased>250||!tapDown()){
                finishSequence(false,"window/source changed or second tap delayed");return;
            }
            secondStarted=downTime;
            handler.postDelayed(()->{
                if(lastPoint==null||dragGeneration!=sequence)return;
                boolean released=tapUp();finishSequence(released,released?"two taps delivered; server response unconfirmed":"second tap cancelled");
            },55);
        },180);
    }
    private boolean tapDown(){
        downTime=SystemClock.uptimeMillis();fingerDown=true;
        boolean accepted=dispatch(MotionEvent.ACTION_DOWN,lastPoint,downTime);if(accepted)downsAccepted++;return accepted;
    }
    private boolean tapUp(){
        if(!fingerDown||!active()||touchSession==null||!touchSession.validateDuringDrag()||SystemClock.uptimeMillis()-downTime>180)return false;
        long held=SystemClock.uptimeMillis()-downTime;
        boolean accepted=dispatch(MotionEvent.ACTION_UP,lastPoint,downTime);fingerDown=false;
        if(accepted){upsAccepted++;if(upsAccepted==1){firstReleased=SystemClock.uptimeMillis();firstHold=held;}else secondHold=held;}
        return accepted;
    }
    private void finishSequence(boolean complete,String reason){
        if(lastPoint==null)return;lastFailure=complete?"":reason;dragGeneration++;
        if(fingerDown&&!activity.isDestroyed())dispatch(MotionEvent.ACTION_CANCEL,lastPoint,downTime);
        fingerDown=false;
        if(completion==null||!actionLabel.equals("slots=54 slot=49")||SystemClock.uptimeMillis()-lastRefreshLog>=3000){lastRefreshLog=SystemClock.uptimeMillis();GameRuntime.log("Auto Buy input: "+actionLabel+" double-tap completed="+complete+" downsAccepted="+downsAccepted+" upsAccepted="+upsAccepted+
                " durationMs="+(SystemClock.uptimeMillis()-sequenceTime)+" point="+Arrays.toString(lastPoint)+" reason="+reason);}
        lastPoint=null;closeSession();
        java.util.function.Consumer<Boolean> callback=completion;completion=null;
        if(callback!=null){callback.accept(complete);return;}
        if(active())message(complete?"Два нажатия «Обновить» отправлены. Проверь обновление лотов":"Нажатия отменены: окно или ввод изменились");
    }
    private boolean dispatch(int action,float[] point,long down){
        MotionEvent.PointerProperties property=new MotionEvent.PointerProperties();property.id=0;property.toolType=MotionEvent.TOOL_TYPE_FINGER;
        MotionEvent.PointerCoords coords=new MotionEvent.PointerCoords();coords.x=point[0];coords.y=point[1];coords.pressure=(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_MOVE)?1:0;coords.size=0.05f;
        MotionEvent event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,1,new MotionEvent.PointerProperties[]{property},new MotionEvent.PointerCoords[]{coords},0,0,1,1,0,0,InputDevice.SOURCE_TOUCHSCREEN,0);
        try{return activity.dispatchTouchEvent(event);}finally{event.recycle();}
    }
    public void dispose(){
        cancelAutomatic();disposed=true;generation++;dragGeneration++;cancelCalibration();handler.removeCallbacksAndMessages(null);
        if(fingerDown&&lastPoint!=null&&!activity.isDestroyed())dispatch(MotionEvent.ACTION_CANCEL,lastPoint,downTime);
        if(marker!=null){root.removeView(marker);marker=null;}
        fingerDown=false;lastPoint=null;closeSession();
    }
}
