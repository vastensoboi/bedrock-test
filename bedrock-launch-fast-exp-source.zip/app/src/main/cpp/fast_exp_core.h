#pragma once
#include <cstdint>
#include <cstring>
namespace kulich {
using Address=uint64_t;
inline Address untag(Address p){return p&0x00ffffffffffffffULL;}
struct Held { Address stack=0; int slot=-1,count=0; };
// Exact supplied ARM64 build only. All memory access is delegated to a bounded
// reader. This function never calls or writes to the game.
template<class Reader> Held resolve(Reader& read,Address base,Address client,Address mode){
 base=untag(base);client=untag(client);mode=untag(mode);
 auto ptr=[&](Address at){Address v=0;return read(at,&v,8)?untag(v):Address(0);};
 auto word=[&](Address at,int32_t& v){return read(at,&v,4);};
 Held no;Address table=ptr(mode),use=0;
 if(table==base+0x13d227d0ULL)use=base+0x100a0060ULL;
 else if(table==base+0x13d22900ULL)use=base+0x100a142cULL;
 else return no;
 if(ptr(table+96)!=use)return no;
 Address player=ptr(mode+8);
 if(!player||ptr(player)!=base+0x139f6ea0ULL||ptr(player+2568)!=mode||
    ptr(player+3240)!=client||ptr(client)!=base+0x1388fe70ULL)return no;
 Address proxy=ptr(player+1424);if(!proxy||ptr(proxy)!=base+0x13d43520ULL)return no;
 int32_t slot=-1;uint8_t suspended=1;
 if(!word(proxy+16,slot)||slot<0||slot>8||!read(proxy+176,&suspended,1)||suspended)return no;
 Address inventory=ptr(proxy+184);if(!inventory||ptr(inventory)!=base+0x13d42b08ULL)return no;
 Address taggedBegin=0;if(!read(inventory+320,&taggedBegin,8))return no;
 Address begin=untag(taggedBegin),end=ptr(inventory+328);
 if(!begin||end<begin||(end-begin)%152||(end-begin)/152<9||(end-begin)/152>256)return no;
 Address stack=begin+uint32_t(slot)*152;
 if(ptr(stack)!=base+0x13d95ff8ULL)return no;
 uint8_t count=0;if(!read(stack+34,&count,1)||!count)return no;
 Address handle=ptr(stack+8),item=handle?ptr(handle):0;
 if(!item||ptr(item)!=base+0x13d9eb70ULL)return no;
 int32_t again=-1;uint8_t now=0;
 if(!word(proxy+16,again)||again!=slot||ptr(player+1424)!=proxy||
    ptr(proxy+184)!=inventory||ptr(inventory+320)!=begin||ptr(inventory+328)!=end||
    ptr(stack+8)!=handle||ptr(handle)!=item||!read(stack+34,&now,1)||now!=count||
    !read(proxy+176,&now,1)||now||ptr(player+2568)!=mode||ptr(mode+8)!=player)return no;
 // Preserve the allocation's top-byte tag for the actual native ItemStack
 // argument. Kernel reads use untagged addresses, engine calls must not lose it.
 return Held{stack|(taggedBegin&0xff00000000000000ULL),slot,count};
}
}
