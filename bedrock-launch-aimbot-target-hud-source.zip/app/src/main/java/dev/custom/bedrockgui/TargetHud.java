package dev.custom.bedrockgui;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
/** Passive rectangular target card. Its data API can also be used by future modules. */
public final class TargetHud {
    private final LinearLayout card;private final TextView name,rank,hp;private final float density;
    public TargetHud(Context context){
        density=context.getResources().getDisplayMetrics().density;
        card=new LinearLayout(context);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(10),dp(14),dp(10));
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xe6172220);bg.setStroke(dp(1),0xff82d9b3);card.setBackground(bg);
        card.setClickable(false);card.setFocusable(false);card.setVisibility(View.GONE);
        name=line(context,17,Color.WHITE);name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);rank=line(context,12,0xffb9c7c1);hp=line(context,15,0xff82d9b3);
        card.addView(name);card.addView(rank);card.addView(hp);
    }
    private int dp(int value){return Math.round(value*density);}
    private TextView line(Context context,int size,int color){TextView text=new TextView(context);text.setTextSize(size);text.setTextColor(color);text.setMaxLines(2);return text;}
    public View view(){return card;}
    public FrameLayout.LayoutParams bounds(){FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(dp(230),-2,Gravity.RIGHT|Gravity.BOTTOM);p.rightMargin=dp(18);p.bottomMargin=dp(22);return p;}
    public void updateSnapshot(String snapshot){show(TargetHudData.parse(snapshot));}
    public void show(TargetHudData target){
        if(target==null){card.setVisibility(View.GONE);return;}
        name.setText(target.name);rank.setText("Привилегия: "+target.rank);
        hp.setText(Float.isNaN(target.hp)?"HP: недоступно":String.format(java.util.Locale.ROOT,"HP: %.1f",target.hp));card.setVisibility(View.VISIBLE);
    }
}
