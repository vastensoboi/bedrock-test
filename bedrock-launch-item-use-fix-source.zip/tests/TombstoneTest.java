import dev.custom.bedrockgui.TombstoneSummary;
import java.io.*;
import java.nio.charset.StandardCharsets;
public final class TombstoneTest {
    static byte[] join(byte[]... values)throws Exception{var out=new ByteArrayOutputStream();for(byte[] b:values)out.write(b);return out.toByteArray();}
    static byte[] var(long value){var out=new ByteArrayOutputStream();while((value&~127L)!=0){out.write((int)(value&127)|128);value>>>=7;}out.write((int)value);return out.toByteArray();}
    static byte[] num(int id,long value)throws Exception{return join(var((long)id<<3),var(value));}
    static byte[] data(int id,byte[] value)throws Exception{return join(var(((long)id<<3)|2),var(value.length),value);}
    static byte[] text(int id,String value)throws Exception{return data(id,value.getBytes(StandardCharsets.UTF_8));}
    static void check(boolean ok){if(!ok)throw new AssertionError();}
    public static void main(String[] args)throws Exception{
        byte[] frame=join(num(1,0x1234),text(4,"test_function"),num(5,16),text(6,"libminecraftpe.so"),text(8,"abc123"));
        byte[] thread=join(num(1,77),text(2,"GameThread"),data(4,frame));
        byte[] entry=join(num(1,77),data(2,thread));
        byte[] root=join(num(6,77),text(14,"Test abort: пример"),data(10,join(num(1,6),text(2,"SIGABRT"))),data(16,entry),num(1000,999));
        String result=TombstoneSummary.read(new ByteArrayInputStream(root));
        check(result.contains("Test abort: пример"));check(result.contains("SIGABRT"));check(result.contains("GameThread"));
        check(result.contains("pc 1234 libminecraftpe.so (test_function+16) build=abc123"));
        check(TombstoneSummary.read(new ByteArrayInputStream(num(6,1))).contains("не предоставлено"));
        for(byte[] malformed:new byte[][]{new byte[]{(byte)0x80},new byte[]{0x72,0x05,0x01},new byte[]{0x0f}}){
            boolean failed=false;try{TombstoneSummary.read(new ByteArrayInputStream(malformed));}catch(IOException e){failed=true;}check(failed);
        }
        System.out.println("PASS: abort message, Unicode, signal, crashed-thread backtrace, unknown fields and malformed tombstone data.");
    }
}
