import dev.custom.bedrockgui.ResourceNames;
public final class ResourceNamesTest {
    private static void equal(Object a,Object b) {
        if(!java.util.Objects.equals(a,b))throw new AssertionError(a+" != "+b);
    }
    public static void main(String[] args) {
        String host="dev.custom.bedrocklaunchtest";
        equal(ResourceNames.gameName("popup","layout",host),null);
        equal(ResourceNames.gameName("popup",host,host),"popup");
        equal(ResourceNames.gameName("popup","com.mojang.minecraftpe",host),"popup");
        equal(ResourceNames.gameName("popup",null,host),"popup");
        equal(ResourceNames.gameName(host+":layout/popup",null,host),"com.mojang.minecraftpe:layout/popup");
        equal(ResourceNames.gameName("com.mojang.minecraftpe:layout/popup",host,host),"com.mojang.minecraftpe:layout/popup");
        equal(ResourceNames.gameName("android:layout/simple_list_item_1",host,host),null);
        equal(ResourceNames.gameName("popup","android",host),null);
        equal(ResourceNames.gameName("other.app:layout/popup",host,host),null);
        equal(ResourceNames.gameName(null,host,host),null);
        equal(ResourceNames.gameName("",host,host),null);
        System.out.println("PASS: resource fallback names, qualified names, framework/other-package isolation, empty input.");
    }
}
