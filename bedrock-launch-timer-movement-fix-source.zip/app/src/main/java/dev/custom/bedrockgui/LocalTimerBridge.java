package dev.custom.bedrockgui;

/** Local-player timing bridge; the shared world clock is not a setting here. */
public final class LocalTimerBridge {
    private static volatile boolean ready,enabled;
    private static volatile String problem="";
    private static volatile int hundredths=110;
    private LocalTimerBridge(){}
    private static native String install(long base,long client);
    private static native void enable(boolean value);
    private static native void pulse(boolean active);
    private static native void settings(int hundredths);
    private static native String status();
    public static synchronized void prepare(long base,long client){
        if(!FastExpBridge.isReady())return;
        try{
            String error=install(base,client);
            if(error==null||!error.isEmpty())throw new IllegalStateException(error==null?"No native install result":error);
            settings(hundredths);ready=true;problem="";pulse(enabled);
            GameRuntime.log("Local Timer: local-player timing bridge prepared");
        }catch(RuntimeException|LinkageError error){
            if(ready)try{enable(false);pulse(false);}catch(RuntimeException|LinkageError ignored){}
            ready=false;enabled=false;problem=error.toString();GameRuntime.log("Local Timer unavailable: "+error);
        }
    }
    public static boolean isReady(){return ready;}
    public static boolean isEnabled(){return enabled;}
    public static boolean hasProblem(){return !problem.isEmpty();}
    public static int multiplierHundredths(){return hundredths;}
    public static synchronized void configure(int value){
        hundredths=Math.max(100,Math.min(200,value));
        if(ready)settings(hundredths);
    }
    public static synchronized void setEnabled(boolean value){
        if(value&&!ready)throw new IllegalStateException("Нужен загруженный мир");
        if(ready){settings(hundredths);enable(value);pulse(value);}
        enabled=value;GameRuntime.log("Local Timer: enabled="+value+" multiplier="+hundredths/100.0);
    }
    public static void heartbeat(){if(ready)pulse(enabled);}
    public static String describe(){
        if(!ready)return "Timer ещё не подключён к миру"+(problem.isEmpty()?"":"\n"+problem);
        try{return (enabled?"Timer включён · ×"+String.format(java.util.Locale.ROOT,"%.2f",hundredths/100.0):"Выключен")+"\n"+status();}
        catch(RuntimeException|LinkageError error){
            ready=false;enabled=false;problem=error.toString();GameRuntime.log("Local Timer status unavailable: "+error);
            return "Статус Timer недоступен; причина в журнале\n"+problem;
        }
    }
}
