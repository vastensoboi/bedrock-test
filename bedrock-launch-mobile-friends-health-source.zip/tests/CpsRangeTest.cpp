#include "../app/src/main/cpp/aim_combat.h"
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>
using kulich_aim::ClickClock;
int main(){
 // Every fixed rate reaches its requested average at the actual 20 Hz game
 // callback, including two attempts per tick above 20 CPS.
 for(int rate=1;rate<=40;rate++){
  ClickClock fixed,equal;int total=0;
  for(int ms=0;ms<10000;ms+=50){
   int n=fixed.take(ms,rate),same=equal.take(ms,rate,rate);
   assert(n==same&&n>=0&&n<=2);total+=n;
  }
  assert(std::abs(total-rate*10)<=1);
  assert(fixed.take(30000,rate)==1&&fixed.take(30000,rate)==0);
 }
 // The same seed/settings reproduce the schedule. Reversed endpoints and
 // bounds clamping normalize identically rather than making an invalid range.
 ClickClock a,b,clamped,one;
 for(int ms=0;ms<60000;ms++){
  assert(a.take(ms,6,17)==b.take(ms,17,6));
  assert(clamped.take(ms,-20,90)==one.take(ms,1,40));
 }
 // Fine sampling exposes each generated interval. Its integer-ms observation
 // may differ by <1 ms from 1000 / sampledRate; no interval exceeds the range.
 for(auto endpoints:std::vector<std::pair<int,int>>{{1,40},{6,17},{39,40},{12,12}}){
  ClickClock clock;int last=-1,total=0;bool varied=false;int previousGap=-1;
  for(int ms=0;ms<120000;ms++){
   int n=clock.take(ms,endpoints.first,endpoints.second);assert(n==0||n==1);
   if(!n)continue;
   total++;
   if(last>=0){
    int gap=ms-last;
    assert(gap+1>=1000.0/endpoints.second&&gap-1<=1000.0/endpoints.first);
    if(previousGap>=0&&gap!=previousGap)varied=true;
    previousGap=gap;
   }
   last=ms;
  }
  assert(total>=120*endpoints.first-1&&total<=120*endpoints.second+1);
  if(endpoints.first!=endpoints.second)assert(varied);
 }
 // An hours-long pause produces only a fresh attempt, no backlog. A setting
 // change or backwards monotonic sample resets the schedule immediately.
 ClickClock clock;assert(clock.take(0,39,40)==1);assert(clock.take(3600000,39,40)==1);
 assert(clock.take(3600000,39,40)==0);assert(clock.take(3600001,1,1)==1);
 assert(clock.take(3600002,1,1)==0);assert(clock.take(5,1,1)==1);
 clock.reset();assert(clock.take(0,1,1)==1&&clock.take(999,1,1)==0&&clock.take(1000,1,1)==1);
 // Ranged operation stays within endpoint budgets even when quantized to ticks.
 for(auto endpoints:std::vector<std::pair<int,int>>{{1,40},{6,17},{39,40}}){
  ClickClock ticked;int total=0;
  for(int ms=0;ms<120000;ms+=50){int n=ticked.take(ms,endpoints.first,endpoints.second);assert(n<=2);total+=n;}
  assert(total>=120*endpoints.first-1&&total<=120*endpoints.second+1);
 }
 std::cout<<"CPS range: fixed 1-40, ranged cadence, normalization and pause checks passed\n";
}
