package dev.custom.bedrockgui;

/** Only these host classes and their generated companions belong to the game loader. */
public final class GameClassPolicy {
    public static final String ACTIVITY="dev.custom.bedrockgui.HostedGameActivity";
    public static final String STARTUP="dev.custom.bedrockgui.NativeStartup";
    private GameClassPolicy(){}
    public static boolean childFirst(String name){
        return family(name,ACTIVITY)||family(name,STARTUP)||name.startsWith("com.mojang.");
    }
    private static boolean family(String name,String owner){
        // Includes anonymous/nested classes and D8's $$ExternalSyntheticLambda*.
        return name.equals(owner)||name.startsWith(owner+"$");
    }
}
