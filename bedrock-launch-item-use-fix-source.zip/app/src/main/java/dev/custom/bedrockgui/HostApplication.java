package dev.custom.bedrockgui;

/** Keeps Application-based SDK lookups in the same loader as the hosted game. */
public final class HostApplication extends android.app.Application {
    @Override public ClassLoader getClassLoader() {
        ClassLoader gameLoader = GameRuntime.loader;
        return gameLoader != null ? gameLoader : super.getClassLoader();
    }
}
