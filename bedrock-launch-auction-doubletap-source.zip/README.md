# Bedrock Crash Capture 0.40 — square-grid fit and Refresh double tap

The 0.39 report shows completed 483/484 ms gestures with all MOVE return flags
accepted. The user says the auction did not refresh; Android event delivery
was not a server acknowledgement. Their manual workflow also supports tapping
Refresh twice. Implement this stated alternative rather than assuming that
the prior drag succeeded or enabling purchases.

The report also reveals noisy calibration: horizontal step ~93 px vs vertical
~83 px (and ~89 vs ~72 in the confirmation profile). Classic chest cells in the
provided screenshot are square. The old code multiplied the one-row vertical
sample across five rows. Fit a square grid using the span over eight columns,
average the two left-column observations, and fit origin Y over three samples.
Saved raw calibration points are reused. Add regression tests where row-tap
jitter formerly displaced the footer by one cell. This corrects an observed
geometry weakness; it does not prove that it caused the reported failure.

Add Show Refresh Point, a noninteractive green marker over computed slot 49
for three seconds. It neither clicks nor consumes game touches. The explicit
input test now sends two short DOWN/UP pairs at that same point. Second DOWN
is scheduled ~180 ms from the first, and each UP ~55 ms from its own DOWN.
A delayed second tap (>250 ms after first release), overlong press, changed
window/focus, or rejected input aborts. Before the second DOWN, validate the
current Refresh source again. Live owner/window checks remain between events.
Reader/maps are reused for the sequence; no journal fsync while held down.
Logs record both accepted pairs, hold durations, gap and coordinate. Those are
input diagnostics, not successful-refresh or purchase claims.

The test no longer needs calibrated inventory coordinates, although the
existing four-point configuration UI/profile is retained for compatibility.
The current native token still requires an empty inventory cell. Calibration,
marker, disposal, late-callback and icon-over-target guards remain. Marker
visibility pauses Fast Exp leases and script UI ticks like calibration.

Validation: square-fit noisy-point regressions, original screenshot geometry,
viewport/range checks and destination geometry; Android-source Java syntax.
No Android build, touch simulation or server refresh is validated locally.
The native bridge, auth/resource fix, read-only matcher, script API and journal
remain unchanged. Purchases/green-confirm actions are still not enabled.

# Bedrock Crash Capture 0.39 — refresh transfer gesture

The user reports that a tap highlights Refresh but the server action needs a
transfer/drag into the player's inventory. 0.38 recorded accepted DOWN/UP but
that was never proof of a refresh. Its old gesture also did repeated maps/file
work and journal fsync during the hold. Preserve the distinction between an
Android dispatch flag and an actual server response.

Replace the explicit Refresh tap test with a DOWN, six MOVE samples, then UP
over roughly 480 ms, aimed at a freshly observed empty player-inventory slot.
Both DOWN and MOVE have finger pressure; release has zero pressure. Native
memory checks still gate the start and window identity throughout the drag.
During dragging, the source may be locally cleared/cursor-held and destination
may be predicted as filled, so require the same typed model/vector/ownership
rather than incorrectly cancelling on source-item disappearance. Window change,
focus loss, disposal, excessive delay or stale callbacks cancel the gesture.
MOVE return flags are logged as diagnostics, not treated as proof of handling.

Add fourth-point calibration for the player-inventory first-cell origin below
the chest (not hotbar). Reuse the known chest cell spacing for 27 inventory
cells. Old 3-point profiles must be recalibrated. Player-inventory targets come
from the stable 27-slot InventoryContainerModel and typed ItemStack counts;
occupied cells are skipped, and no available cell blocks the gesture. The
calibrated target and native slot index must match. Coordinates are still a
user-calibrated input path, not inferred semantic UI hit boxes.

A single gesture session reuses its maps/memory reader, avoiding repeated maps
scans between DOWN and MOVE/UP. Live pointer/type/layout checks remain bounded.
No journal fsync occurs while the synthetic finger is down; terminal logs
include duration, destination slot, coordinate, reason and dispatch flags.
The only automated action remains the explicit Refresh transfer test. There
is no buy/confirm dispatcher, packet API or successful-purchase assertion.

Tests cover inventory calibration geometry, valid/occupied/full inventory,
next-empty selection, window change rejection, source snapshots and typed
owner metadata. Java syntax parse is not an Android build or a live input test.
The next required device check is whether Refresh actually updates the auction
through this drag gesture. Auth, native Fast Exp, script API, rule matching and
journal behavior remain unchanged.

# Bedrock Crash Capture 0.38 — calibrated refresh input test

The user's screenshot and 0.36 confirmation report establish a 27-slot purchase
window: item preview=13, buy glass including=10, return glass including=16.
Preview name, seller and price are available. This does not establish an input
ABI, nor is a purchase enabled by those observations alone.

Add manual three-point chest-grid calibration for 54-slot auctions and 27-slot
confirmation windows. The overlay consumes touches rather than forwarding
them to the game. Points are centers of cells 0, 8, 9, in the Activity decor's
coordinate space. Geometry and viewport bounds are validated; profiles are
stored privately and rejected when viewport size changes. Recalibrate after
changing GUI scale/layout even if viewport dimensions remain the same.

The only new dispatched action is an explicit Refresh test for slot 49 of a
54-slot LevelContainerModel. Preparation performs the existing exact-build
probe and snapshots the window. Immediately before DOWN and before UP, a
bounded memory check requires player/client/manager ownership (live-confirmed
player+0x578), current model/vector size, typed slot userdata, and the exact
Refresh display name. A changed window results in cancellation. A round kulich
icon covering the target blocks the test. A rejected DOWN is cancelled instead
of sending UP. Disposing the menu cancels pending input; calibration pauses
Fast Exp leases and script ui_tick callbacks.

Touch events use this Activity's normal dispatchTouchEvent with a touchscreen
finger pointer, a DOWN then ~60ms UP, and recycled MotionEvents. No system input
permissions, other-app injection, memory writes or guessed C++ calls are used.
This is still an unverified device input path: a Java dispatch acceptance flag
is not proof of a server response. Incorrect calibration can hit a different
UI control; the test is for user-observed validation before enabling purchases.
There is no Buy/confirmation dispatch, generic JS touch API or automated trading.
The 27-slot profile can be prepared now but is not used to send any action.

Tests cover grid coordinates and viewport/shape/range validation; Refresh token
creation, metadata/type/owner/layout changes, and existing read-only container
checks. Java syntax parsing is not Android compilation. Actions/device tests
must confirm that the game receives the touch and actually refreshes. The next
step is a user-observed Refresh result plus the 0.38 journal. Native Fast Exp,
auth, resource fixes, JS API and rule matcher remain unchanged from 0.37.

# Bedrock Crash Capture 0.37 — read-only Auto Buy rule evaluation

The real 0.36 auction report successfully decoded all 52 nonempty slots of a
54-slot LevelContainerModel, including custom names, seller and formatted lot
prices. Thus the userdata+16 correction is confirmed for live display data.
Examples include Sphere of Wyvern at 120000 and Orion Talisman at 400000;
those exceed the user's original 58500 and 180000 effective rule limits.

Port the corrected user-script shopping defaults into AutoBuyDefaultRules and
add a pure AutoBuyMatcher. It strips formatting, normalizes case, requires one
readable price/seller field, validates integer/thousands price syntax and lot
count, honors blocked words/books, uses min(cap,market*count*ratio), and checks
required/custom enchant levels. Default market prices are used; market learning
and page-turning are not implemented. Missing market/type/quality data rejects
the candidate. Only the 45 item positions of a 54-slot LevelContainerModel are
evaluated; navigation/footer and inventory/confirmation models are excluded.

The read-only NBT decoder additionally attempts standard ench lists containing
CompoundTags with ShortTag id/lvl values. Type and bounds checks apply; invalid,
duplicate or changing lists discard enchant data. Exact RTTI identifies weapon
and enchanted-book item types via the existing Item weak-handle representation.
Armor item kind is not established and remains unsupported/rejected. Enchant
and item-kind reads need live validation; this is not full metadata coverage.

The existing Read Open Auction button now logs per-rule MATCH/SKIP verdicts
and a selection count in its result. It does not auto-scan, click, buy, refresh
or send packets. The full JS auction capability remains false. Before adding
purchase actions, establish whether the server opens confirmation and inspect
that screen's metadata and its input path. A diagnostic MATCH is not a
server-authorized transaction or confirmation of a purchased item.

Validation: real-report name/price examples, cap/ratio boundaries, formatted
prices, blocked names/books, required NBT/text enchants, missing/duplicate
metadata, missing market, footer exclusion; synthetic ench-list parsing plus
existing NBT and stable-container tests. No Android/device validation is claimed.
Auth, Fast Exp, launcher startup, journal screen and script API remain unchanged.

# Bedrock Crash Capture 0.36 — correct ItemStack userdata offset

The 0.35 device report confirms a LevelContainerModel with 54 slots, 52 nonempty,
and stable ItemStack/count data. The userdata matcher reports zero CompoundTags
because the collector used offset +24. Exact-library disassembly of the
ItemStackBase copy at 0x1076d6ec shows the +24 field copied separately, then
+16 passed to a deep-copy routine at 0x1076d794. The destructor at 0x1077ed80
also clears and virtually deletes the pointer at +16. Read userdata from +16,
still requiring the exact CompoundTag type before display decoding.

The new regression test follows the entire auction vector -> ItemStack+16 ->
CompoundTag display tree -> StringTag Name path. This covers the integration
that the earlier separate vector and standalone NBT tests did not exercise.
Existing bad-player/vptr/changed-content and NBT limits tests still pass.
The copied-library analysis is evidence for this game build only; live display
names/lore still need the user's auction snapshot for validation.

No purchases or clicks are enabled, and JS auction/packet capabilities remain
false. Auth, Fast Exp/native startup, script runtime, UI and journal behavior
are unchanged from 0.35. This fixes the observed missing-userdata collector
field, not first-attempt server entry or a complete Auto Buy implementation.

# Bedrock Crash Capture 0.35 — derived auction model and display NBT reader

The user's 0.34 report confirms the auction probe reached a verified player
and ChestContainerManagerModel at LocalPlayer+0x578. It did not accept a lot
model. The old reader admitted only the base ContainerModel vptr. RTTI in the
supplied exact game binary also identifies LevelContainerModel (0x13d34298),
InventoryContainerModel (0x13d341b0), and PlayerUIContainerModel (0x13d34468).
All three have the same size/index getters 0x10169ba4/0x10169bd0, confirming
vector+216 and 152-byte stride. Add these exact type checks and bounded model
vptr/vector rejection diagnostics. This is a plausible collector omission;
the report itself does not disclose the actual runtime model vptr.

For stable typed 27/54-slot vectors, additionally attempt to decode only
ItemStack userdata at +24 that identifies as CompoundTag. Exact-build RTTI
CompoundTag/ListTag/StringTag is 0x13ebe0b0/0x13ebe350/0x13ebe5f8. Static
serialization disassembly shows CompoundTag tree root+16, node key string+32,
inline variant tag+56 and discriminator+96; ListTag pointer vector+8/+16;
StringTag holds libc++ string+8 with low-bit long-string layout. The reader
looks up display.Name and display.Lore only, with typed checks, mapped-memory
reads, strict UTF-8 and length/node/depth-independent cycle limits. It rechecks
map/string/list headers and logs named lots without dumping arbitrary NBT.
All reading shares the auction read/time budget. Names/lore are diagnostic
snapshots, not an atomic server purchase/price guarantee.

Tests cover base and derived vectors, concurrent changes, tagged pointers,
synthetic display trees, inline/long UTF-8, lore vectors, bad types/lengths,
cycles and changed map roots. The real item-data/tree layout still needs the
user's live auction report. There are no clicks, purchases or packet sends;
script auction capabilities remain false. Native Fast Exp, launch button,
Microsoft flow, script runtime and dedicated journal behavior are unchanged.
This version does not claim to fix first-attempt server admission.

# Bedrock Crash Capture 0.34 — dedicated journal screen

The user reports that the launcher opens from the kulich Journal button but
its journal appears empty. Previously that intent displayed the entire launcher
control panel, with its text area below all controls, and synchronous report
collection on the UI thread. This can hide the text and block rendering;
it does not establish whether the underlying game recorded a server reason.

The same MainActivity now handles the Journal intent with a dedicated layout:
visible loading status, Save/Refresh controls and a selectable scrolling text
area filling remaining space. It bypasses the launcher controls. Collection
and export run on the existing single worker queue. Saving is unavailable until
the first collection finishes; rotation queues a new collection ahead of export.
Each refresh replaces the displayed report instead of appending duplicates.
A header, missing-log state and errors are explicit. launch-log.txt tail is
bounded at 512 KiB; own logcat and content logs keep their existing limits.
Success is shown after the output stream closes. Both main-panel journal
buttons route to this screen; Save Journal opens the document picker after load.

Only the journal UI/collection/export and version/documentation change. Auth,
resources, Fast Exp startup/native code, script API and auction snapshot remain
unchanged. No claim is made about fixing server connection or full Auto Buy.
Validation: Java syntax parse, XML/archive/version checks and comparison of
all other files with 0.33. Android build and screen/file-picker behavior still
require Actions/device verification. Routine reversible layout changes have
no implementation-mirroring UI tests in the absence of an Android runtime.

# Bedrock Crash Capture 0.33 — Fast Exp launch button and auction snapshot

Add Enable Fast Exp and Play at the top of the launcher. It uses the existing
launch preparation directly, without the separate Check Minecraft button,
and passes a startup request into the game. A UI-thread request controller
waits five seconds and retries the existing validated memory probe no more
than once per eight seconds while focused, until a live player is verified.
Only a ready bridge plus verified player and foreground Activity enables it.
A cancellation/disposal suppresses late results. Success consumes the request;
normal pause disables Fast Exp as before and does not auto-reenable it.
Manual Fast Exp actions cancel an outstanding startup request. Ordinary launch
does not request startup enabling. Native item-use guards are unchanged.

Auto Buy now has Read Open Auction, an explicitly diagnostic read-only step.
The supplied exact game binary's RTTI identifies ChestContainerManagerModel
vptr 0x137e8f20 and ContainerModel vptr 0x13d35930. Disassembly at
0x101656c4 follows the model map at manager+176 and the shared model pointer
at node+40; libc++ first-node link is a candidate at manager+192.
0x10169ba4/0x10169bd0 establish vector+216 and 152-byte ItemStack stride.
These are exact-build observations, not portable offsets.

The snapshot searches a freshly verified LocalPlayer for that manager, follows
bounded candidate map nodes and accepts only 27/54-slot vectors of matching
ItemStack vptrs, rereads object/contents/player/owner pointers, and logs slot
counts. All reads use /proc/self/mem with mapped writable-region checks,
read/time/node limits. No game methods, writes, clicks or purchase requests
are made. Names, lore, seller, price and confirmation still need adapters;
JS auction/inventory/packet capabilities remain false. The user must open the
actual auction, run this snapshot, and provide the report before implementing
purchases against an unverified live layout. Auto Buy is not yet functional.

Standalone tests cover tagged pointers, stable snapshot/counts, player/type/
content replacement rejection and unchanged memory, plus Fast Exp startup
world/focus/retry/cancel/consumed-request states and existing ECS probe tests.
Android builds and live container layout/startup behavior remain device checks.
Authentication, Application resources, script API and native sources remain
unchanged. This version does not claim to fix first-attempt server admission.

# Bedrock Crash Capture 0.32 — kulich script API v1

The user confirms Microsoft sign-in works in 0.31, but reports first-attempt
server connection failures. Their 0.31 journal shows WebKit returning its end
URL and Activity result, without the prior missing-Activity crash. It contains
no actionable server rejection reason or content logs. This version does not
claim to fix first-attempt server connection.

Add a real interpreted JavaScript module API via Rhino 1.7.15. Imported scripts
register utility modules with enable/disable handlers, validated number/boolean
settings in code, bounded journal output and a distinct ui_tick menu timer.
Fast Exp exposes its existing validated bridge (must already be prepared).
No raw native addresses, packet API, inventory or auction container interface
is exposed. Capabilities report those omissions and ProtoHax imports are
explicitly rejected. Auto Buy remains unconnected.

Scripts are imported using Android's document picker, stored as bounded text
under private content hashes, and loaded at the next game start, disabled by
default. Duplicate imports deduplicate. Removing imports moves copies to a
backup folder. The whole launcher screen now scrolls in landscape so import,
export and stop buttons remain reachable. Separate per-script scopes have no
Java globals, instruction deadlines and log-rate limits; this is not a separate
memory-isolated process for untrusted code. See KULICH-API.md and examples/.

Validation: compile and execute standalone API tests against the actual Rhino
1.7.15 dependency; lifecycle/example, range errors, capabilities/Java globals,
timeout shutdown, atomic registration, duplicate handling, bounded imports,
link rejection and backup moves. Java syntax parsing of Android source is not
an Android build. Actions must build the APK; script import/menu behavior needs
a phone. Native code, auth/resource fixes and Fast Exp behavior are preserved.

# Bedrock Crash Capture 0.31 — SDK WebKit Activity registration

The supplied 0.30 report provides a concrete fatal exception. The external
Microsoft browser returns through IntentHandler, and BrowserLaunchActivity
reports its operation completed successfully. That proves delivery of this
browser response, not completion of the entire account sign-in. The SDK next
starts ShowUrlType NonAuthFlow, which explicitly requests an in-process WebKit
strategy. Android throws ActivityNotFoundException for
com.microsoft.xal.browser.WebKitWebViewController, followed by a main-thread
fatal exception and process exit reason=4.

Register the installed SDK's WebKitWebViewController as exported=false, :game,
singleTask (matching the original game's public Activity metadata). It uses
an opaque framework Light.NoActionBar theme and handles the same configuration
changes as BrowserLaunchActivity. GameFactory instantiates it via the existing
game loader, including intent extras loader repair and the process-restart
guard. HostApplication's pre-created callback already covers the XAL browser
package and sets the extras/saved-state class loader before SDK onCreate.

There is no custom WebView client, TLS override, credential interception,
response rewriting or URL/token logging. Authentication remains in the
installed game's SDK. Native Fast Exp, one-step enable, Auto Buy preparation,
Application resources and log configuration are unchanged from 0.30.

Validation: Java syntax parsing; manifest coverage/process/export/mode checks
for all three XAL Activities seen in the game metadata; archive CRC/version
and unchanged native sources. Android compilation and full sign-in remain
GitHub Actions/device checks. This addresses the observed missing-Activity
crash, not a guarantee about every subsequent account/server flow.

# Bedrock Crash Capture 0.30 — one-step Fast Exp and Auto Buy preparation

The user confirmed game/server entry and Fast Exp work with 0.29. Preserve
that application resource fix, authentication setup and native item-use path.

Fast Exp's disconnected-state action is now Enable Fast Exp. It runs the
existing verified-library/client probe in a worker, then enables automatically
if the Activity still has focus. There is no separate manual probe step.
Failure leaves it disabled and explains how to retry in a world. A prepared
bridge retains the direct enable switch, 1–10-tick interval and existing
focus/menu pause behavior. Native guards and code are unchanged.

integrations/protohax contains a repaired user-supplied Auto Buy script and
extracted shopping rules, with tests and portability limitations documented.
It is not executed by the launcher: the @protohax/userscript runtime and auction
container/packet APIs are not implemented in kulich. Auto Buy remains explicitly
unconnected rather than presenting a nonfunctional enable switch.

Validation: Java syntax parse, Node module syntax and mock auction tests.
Android compilation and one-step button behavior require Actions/device tests.

# Bedrock Crash Capture 0.29 — application resources and content-log setup

The 0.28 report still lacks content logs. The user confirmed they only saved
the launcher report and could not find the game's Creator logging setting.
The report also contains numeric game resource lookup failures from SDK code
using applicationContext, whereas Activity resource attachment succeeds.
Neither this observation nor unrelated telemetry upload errors establish the
cause of the blank server screen.

GameRuntime now adds the same game ResourcesLoader to the Application Resources
in the hosted :game process before SDK initialization. Application-context
SDK lookups can see the game resources as well as Activity lookups. No Context
accessor overrides are introduced: the inherited JNI method owner compatibility
is preserved. The separate launcher process keeps its host resources. Public
resource-name availability markers are written to the launch journal, without
logging resource values, OAuth URLs, credentials or tokens.

Before starting the game (after the existing running-process guard), the host
sets only content_log_file:1 in its own Minecraft options.txt profiles. That
exact option name is present in the supplied game library. Existing unrelated
lines and line endings are preserved; an existing options.txt is copied once
to options.txt.kulich-before-content-log before replacement. The original
installed game's private data is never inspected or changed. On fresh installs,
a minimal options file is created under the launcher's data storage path.
Existing profiles in internal files and external app files are also recognized.
The replacement is atomic where supported. Link/directory/size guards apply.
A setup failure is recorded rather than blocking game launch. This configures
logging, not acceptance by the server or guaranteed creation of content logs.

Standalone tests cover preservation, backups, idempotence, fresh/external
profiles, symlink/size rejection and content-log collection. Java syntax parsing
is not Android type checking. GitHub Actions must build the APK; resource
availability, actual file logging, sign-in and server behavior require a phone.
Fast Exp native sources and XAL auth declarations are unchanged from 0.28.

# Bedrock Crash Capture 0.28 — content-log storage roots

The user clarified that the recorded blank server screen also occurred at
home with their normal connection. The mobile-data permission dialog does not
establish the cause. The report contains no fatal crash or server error.

The game log explicitly selects CurrentFileStoragePath as the application
data directory, which is above files/. 0.27 only searched files/ and external
app files. Its missing-content-log result could therefore be a collector gap.
0.28 includes the app data directory and prioritizes games/com.mojang/logs and
logs under each app-owned root before bounded traversal. Named-file and
symlink safeguards, byte/file limits, native bridge, auth and menu are unchanged.
It only reads existing content logs; it does not enable logging or edit game
options. If logging is disabled, enable file output in Minecraft Creator settings.

Standalone tests cover the data-directory case and log priority despite more
than 2048 cache files, along with previous export bounds and symlink tests.
Java syntax parsing is not an Android build. Device testing is still required.
This fixes a diagnostic collector omission, not a confirmed server-login cause.

# Bedrock Crash Capture 0.27 — server-screen diagnostics

The user reports that Nevertime works in the separately installed Minecraft,
but the hosted game displays a blank in-game screen after joining. The new
0.26 report contains no fatal exception or native crash: its only recorded
exit is the user-requested Android Settings force stop. It does not provide a
server disconnect reason or prove that the blank screen is an OAuth failure.
The unrelated telemetry database and Play services warnings are not treated
as the established cause.

This version adds a Journal button to the kulich menu header. It opens the
launcher diagnostics in a separate task, leaving the game Activity in its
own task. Android lifecycle pause still disables Fast Exp. No task-clearing
flags, process termination or sign-in restart are performed by this button.
The system document picker remains the destination for the Save Journal button.

Reports also collect up to three named Minecraft ContentLog text files from
this app's internal files and external app files, with a total 256 KiB byte
budget. Traversal is bounded and rejects symlinks. It never searches the
separately installed game's private data or reads arbitrary account files.
If Minecraft has not written content logs, the report says so; the user can
enable content-log file output in Minecraft Creator settings before joining.

This is a diagnostic and recovery change, not a confirmed fix for server login.
Fast Exp native code, game resources, and XAL authentication are unchanged.
Java parsing and standalone content-log tests can run locally. Android build,
menu navigation and Nevertime behavior require GitHub Actions/device testing.

# Bedrock Crash Capture 0.26 — XAL browser return handler

The user's 0.25 report shows BrowserLaunchActivity creating its SDK session,
selecting Chrome Custom Tabs and launching the browser. On return the SDK logs
onResume() with no intent data and cancels the operation. The process exits
normally. This does not establish a completed account sign-in or explain the
browser page's error message, which was not present in the journal.

The installed game's public Activity metadata names an exported singleTask
com.microsoft.xal.browser.IntentHandler. That component was missing in the
host. The exact literal `ms-xal-0000000048183522://auth` is present in the
supplied game library. 0.26 declares that SDK return Activity with precisely
this scheme and host, VIEW/DEFAULT/BROWSABLE, exported=true and :game process.
GameFactory loads it with the existing game loader. The pre-created extras
loader repair also applies to this XAL browser class. The original SDK handler
receives the URI and handles its state; no code, token or redirect data is
rewritten or logged by the host.

Both the original installed game and this launcher may handle the same custom
URI. If Android presents a chooser after Microsoft login, the user must select
Bedrock Crash Capture for this session. No default is forced or other handler
disabled. If the game process was killed while the browser was open, native
pending auth state cannot be fabricated; the existing factory failure path
asks the user to restart sign-in from the game.

Native Fast Exp code is byte-for-byte unchanged from confirmed working 0.23.
This patch addresses delivery of the browser response; successful sign-in,
subsequent account permissions and server acceptance remain device checks.
No guarantee of admission to arbitrary servers is made. Any error shown by the
Microsoft page needs its own text/code to diagnose beyond this journal.

Local validation: Java syntax parsing; XML handler/process/export/mode/filter
checks; exact callback literal found in supplied ELF; loader routing and native
source identity checks; ZIP CRC and existing workflow selection. Android build
and actual OAuth round-trip are not performed locally.

Build versionCode25 / versionName0.26 with Build latest launch test, try login
and save bedrock-crash-capture-0.26.txt. The useful next markers are the SDK
IntentHandler construction, BrowserLaunchActivity receiving return intent data,
and the game's sign-in outcome. Do not infer success from merely opening Chrome.

# Bedrock Crash Capture 0.25 — XAL Serializable extras loader

The 0.24 report confirms BrowserLaunchActivity is now instantiated through the
game loader. Its onCreate then fails reading BrowserLaunchParameters.FromArgs:
BadParcelableException / ClassNotFoundException for
BrowserLaunchActivity$ShowUrlType. Parcel attempts to resolve that SDK enum
through the host APK loader. The enum is supplied by the game's DEX.

0.25 sets the authentication intent extras loader in the factory, then repairs
it again using Application.ActivityLifecycleCallbacks.onActivityPreCreated.
The pre-created hook runs before the SDK's onCreate reads its parameters and
also assigns the game loader to saved state. This uses the public API available
on API29+ (the app's minimum is 30). No enum is redefined, converted or replaced.
No intent extras, URL, token or credentials are logged by the hook.

BrowserLaunchActivity's launchMode is set to singleTask, matching the original
installed-game metadata recorded in 0.24 (launchMode=2). Exported=false and the
:game process are retained. The existing unprepared-process guard remains.
The current failure is distinct from the earlier missing-component failure.

The native Fast Exp sources remain unchanged from confirmed working 0.23.
Full account sign-in/browser-return/server acceptance still require device
verification; this patch specifically addresses SDK parameter deserialization.
No OAuth client identity or return scheme is guessed or fabricated here.

Local validation: 26 Java files syntax-parsed, manifest process/launch-mode and
pre-created class-loader routing inspected, archive CRC/version/selection
verified. Android SDK compilation and runtime sign-in are not tested locally.
Build versionCode24 / versionName0.25 with Build latest launch test. Try login
and export bedrock-crash-capture-0.25.txt after success or failure.

# Bedrock Crash Capture 0.24 — XAL browser component

The user's 0.23 login report confirms ActivityNotFoundException for the explicit
component com.microsoft.xal.browser.BrowserLaunchActivity in the diagnostic
package. The native SDK subsequently calls JNI GetMethodID with that pending
exception, causing SIGABRT. This is a launcher component-registration failure;
it is not evidence that Fast Exp interferes with authentication.

0.24 declares that exact SDK Activity in the host manifest, unexported and in
the existing :game process. GameFactory instantiates it with the already
prepared game DexClassLoader, where the installed game's XAL SDK resides.
It does not call GameRuntime.prepare on the SDK's authentication intent or
replace the SDK Activity implementation. A restarted/unprepared game process
fails through the existing launch-failure Activity rather than attempting a
callback with stale native process state.

The manifest also permits browser VIEW/http/https and Custom Tabs service
queries needed on Android 11+. No OAuth scheme/client ID/redirect, token,
account identity or credential storage is fabricated. Browser-return handling,
account sign-in and server acceptance still require device verification. If
the next phase needs additional components or original redirect metadata, those
must be established from the real SDK/installed game and the next error.

Before game launch the journal inventories relevant installed-game Activity
names and public launch metadata. It does not log authentication intent extras,
OAuth URLs or credentials. Existing native Fast Exp sources are byte-for-byte
unchanged from the version the user confirmed works. Dump/text export remain.

VersionCode 23 / versionName 0.24; debug package remains
`dev.custom.bedrocklaunchtest.crashcapture`. Build with the existing **Build
latest launch test** archive workflow. On the phone try Microsoft sign-in and
export **bedrock-crash-capture-0.24.txt** after success or failure. The missing
initial Activity is addressed; full account/server compatibility is not yet
claimed. No guarantee of admission to every server is made.

Validation: Java syntax parsing and manifest/component/factory routing checks
performed locally. Android SDK/NDK compilation and sign-in runtime behavior
remain pending GitHub Actions/device tests. No login was performed here.

# Bedrock Crash Capture 0.23 — corrected client item-use call

This diagnostic build fixes the specific native argument mismatch established
by the user's 0.22 minidump. It retains the separate package and dump export
button introduced in 0.22. It has not yet been compiled with the Android SDK
or executed on the user's phone in this workspace.

## Dump evidence and the incorrect route

The 0.22 minidump contains SIGSEGV at libminecraftpe.so+0xfd898cc, fault
address 0x38. The instruction loads from a null ECS registry via x9. Its x0
is the exact tagged held ItemStack address also recorded in the user's text
log. The caller chain passes through +0x100a3770 and +0x1009cd00, then our
libkulichbridge. This is Actor interaction receiving an ItemStack in place
of an Actor. The slot-16 selection in 0.21–0.22 was wrong. It is removed.

The correct direct client item-use wrapper is 0x1009fdcc. The game's ordinary
input handler calls it at 0x9b6e6ec, with x0=GameMode, x1=ItemStack and w2=0.
The method builds the native item-use transaction (type 2) and on its client
path passes it to the player's virtual method at +1824. The module now calls
that same function with the validated live tagged ItemStack and false flag.
There is no Vec3 argument and no invocation of Actor interaction slot 16.

Before installation and each resolved action, the bridge checks the first
32 bytes of the exact entry function as well as the prior GameMode low-level
method profile. The existing complete game-file SHA-256 guard remains.
Unexpected code bytes reject actions; no alternate address is guessed.
The return register is not treated as proof that a projectile was spawned.
Calls/completed/inFlight remain diagnostic counters.

## Behavior and limits

Actions remain on the original LocalPlayer update thread, after its original
handler returns. Mode/player/client backlinks, selected slot, live XP item,
count, vector bounds and snapshots are checked again. Pointer tags are retained
for native arguments. The interval slider remains 1..10 local update ticks.
Three repeated callbacks are required before action. The UI lease, focus/menu
pause and onPause disabling remain. Fast Exp starts disabled.

The diagnostic dump explains the reported SIGSEGV, but the new wrapper's live
item behavior and actual XP projectiles still need device confirmation. Other
faults may remain. Auto Buy and Block Trap are not implemented.

## Separate install and export

The debug application ID remains
`dev.custom.bedrocklaunchtest.crashcapture`, label **Bedrock Crash Capture**.
The original launcher `dev.custom.bedrocklaunchtest` is a separate application.
This is an update of the diagnostic app, not access to the original app's data.
The uploaded 0.22 dump is already preserved outside the app for analysis.

The default applicationId literal is kept for the user's existing source ZIP
selector. The debug applicationIdSuffix is `.crashcapture`; a Gradle variant
assertion and the direct workflow's actual-APK check require the separate ID.
Only :app:assembleDebug is intended. VersionCode 22 / versionName 0.23 cause
**Build latest launch test** to select this source over 0.22.

The dump button uses ACTION_CREATE_DOCUMENT and gzip compression of only a
valid regular MDMP file in this app's private crash directory. It never deletes
or changes the source and needs no Termux/Shizuku or storage permission. Source
size, time, header and canonical parent are checked. The ordinary text journal
is also exportable. Native bridge debug symbols stay in the APK.

## Device verification

Build/install diagnostic 0.23 using the existing archive workflow. In an ordinary
single-player test world hold XP bottles, run Проверить подключение, enable
Fast Exp and close kulich for five seconds. Observe actual projectiles, reopen
kulich, disable and export bedrock-crash-capture-0.23.txt. If a new crash occurs,
use Сохранить дамп падения and export bedrock-crash-capture-0.23.dmp.gz.
The native status includes route=item-use to distinguish the corrected route.

## Validation performed here

- The exception context and frame-pointer chain were parsed from the real dump.
- The actual game binary confirms the fault instruction, canonical call target,
  false flag instruction and all 32 checked entry bytes.
- Native host tests pass for correct item-use arguments, mismatched code profile,
  independence from the Actor interaction slot, GameMode and SurvivalMode, tagged
  arguments, post-update replacement, item ownership, bounds and tick intervals.
- Native host C++ syntax checks and Java source syntax parsing pass.
- Existing binary dump-export tests pass, including source preservation.

These checks do not compile Android JNI/NDK code or execute Minecraft. Android
build and device execution remain pending. Toolchain: JDK17/Gradle8.7/AGP8.6.1,
SDK35, NDK27.0.12077973/CMake3.22.1, ARM64. Minimum30, target34, compile35.
