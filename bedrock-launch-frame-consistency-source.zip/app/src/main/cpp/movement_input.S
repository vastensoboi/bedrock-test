#if defined(__aarch64__)
.text
.p2align 2
.global kulich_auth_input_hook
.type kulich_auth_input_hook,%function
kulich_auth_input_hook:
    .cfi_startproc
    .cfi_same_value x29
    .cfi_same_value x30
    hint #34
    sub sp, sp, #336
    .cfi_def_cfa_offset 336
    stp x0, x1, [sp]
    stp x2, x3, [sp, #16]
    stp x4, x5, [sp, #32]
    stp x6, x7, [sp, #48]
    stp x8, x9, [sp, #64]
    stp x10, x11, [sp, #80]
    stp x12, x13, [sp, #96]
    stp x14, x15, [sp, #112]
    stp x16, x17, [sp, #128]
    stp x29, x30, [sp, #144]
    .cfi_offset x29, -192
    .cfi_offset x30, -184
    stp q0, q1, [sp, #160]
    stp q2, q3, [sp, #192]
    stp q4, q5, [sp, #224]
    stp q6, q7, [sp, #256]
    mrs x9, nzcv
    mrs x10, fpcr
    mrs x11, fpsr
    stp x9, x10, [sp, #288]
    str x11, [sp, #304]
    // Observe the original return site and stack before restoring x2/x3.
    ldr x2, [sp, #152]
    add x3, sp, #336
    bl kulich_auth_input_observe
    str x0, [sp, #320]
    ldp x9, x10, [sp, #288]
    ldr x11, [sp, #304]
    msr nzcv, x9
    msr fpcr, x10
    msr fpsr, x11
    ldp q0, q1, [sp, #160]
    ldp q2, q3, [sp, #192]
    ldp q4, q5, [sp, #224]
    ldp q6, q7, [sp, #256]
    ldp x0, x1, [sp]
    ldp x2, x3, [sp, #16]
    ldp x4, x5, [sp, #32]
    ldp x6, x7, [sp, #48]
    ldp x8, x9, [sp, #64]
    ldp x10, x11, [sp, #80]
    ldp x12, x13, [sp, #96]
    ldp x14, x15, [sp, #112]
    ldp x16, x17, [sp, #128]
    ldp x29, x30, [sp, #144]
    .cfi_same_value x29
    .cfi_same_value x30
    ldr x16, [sp, #320]
    add sp, sp, #336
    .cfi_def_cfa_offset 0
    // Original SP/LR and all ABI arguments, including x8, are restored.
    // Tail entry preserves every native return convention and exceptions.
    br x16
    .cfi_endproc
.size kulich_auth_input_hook, .-kulich_auth_input_hook
#endif
.section .note.GNU-stack,"",%progbits
