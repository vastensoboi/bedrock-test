# Pearl scan changes in 0.68

The 0.67 scan walked every `ActorOwnerComponent` packed entity ID under the
same 6 ms budget used to read the camera and trace terrain. Each unrelated
item, player or mob required component lookups and reads before being rejected
by its type. A deadline failure discarded the entire frame. This is a real
starvation path on a busy world; no phone journal was supplied, so it is not
confirmed as the only reason for the user's missing lines.

0.68 walks the active `ProjectileComponent` packed vector instead, then checks
the same actor owner, full entity generation, exact pearl vptr, state pointer
and finite physics fields. Ordinary non-projectile actors no longer contribute
scan work. Empty unallocated packed vectors are valid idle worlds.

Exact ARM64 evidence from the supplied 1.26.60.4 binary:

- `0xc04c97c..0xc04c98c` resolves component key `0x94488499` into `x20`.
- `0xc04c9ac` loads that pool's packed begin/end with `ldp ..., [x20,#32]`.
- `0xc04c9ac..0xc04c9d8` compares packed sizes and chooses the smallest
  intersected pool; `0xc04ca30` reads 32-bit IDs.
- `0xc04caf0..0xc04cb04` uses payload stride 760 for the projectile component.
- Factory `0x101b1908` allocates a 960-byte `ThrownEnderpearl`, calls constructor
  `0x101bc5e0` at `0x101b1944`; the constructor writes primary vptr
  `0x13d3adf8` at `0x101bc5fc`. The strict pearl type remains verified.

New native journal fields distinguish candidate count, exact pearl types,
state rejections, read failures and budget stops. Existing reason codes 0–4
retain their meanings; 5 means a read/time budget stopped a frame, 6 means
the projectile/state pool is not available yet, and 7 means a pearl type was
found but none of its state snapshots passed validation. Missing terrain
evidence still produces an unknown ETA rather than a fabricated landing.

Host tests cover own/other pearls, unchanged read cost when the unrelated
actor packed range grows, an empty projectile vector, malformed/stale vectors,
generation reuse, concurrent state changes and no game writes. Strict native
syntax checks and ASan/UBSan pass. Device visual validation remains necessary.
