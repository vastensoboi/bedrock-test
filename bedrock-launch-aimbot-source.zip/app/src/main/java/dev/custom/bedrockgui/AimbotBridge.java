package dev.custom.bedrockgui;

/** Game-thread target tracking; no touch injection or automatic attacks. */
public final class AimbotBridge {
    private static volatile boolean ready,enabled;private static volatile boolean head=true;private static volatile int radius=6;
    private AimbotBridge(){}
    private static native String install(long base,long client);
    private static native void enable(boolean value);
    private static native void configure(boolean head,int range);
    private static native void pulse(boolean value);
    private static native String status();
    public static void prepare(long base,long client){
        try{
            if(!FastExpBridge.isReady())return;
            String error=install(base,client);if(!error.isEmpty())throw new IllegalStateException(error);
            configure(head,radius);ready=true;GameRuntime.log("Aimbot: exact-build rotation bridge prepared");
        }catch(RuntimeException|LinkageError error){ready=false;GameRuntime.log("Aimbot bridge unavailable: "+error);}
    }
    public static boolean isReady(){return ready;}
    public static void setEnabled(boolean value){
        if(value&&!ready)throw new IllegalStateException("Aimbot ещё не подключён к миру");
        if(ready){enable(value);pulse(value);}enabled=value;GameRuntime.log("Aimbot: requested enabled="+value);
    }
    public static void settings(boolean value,int range){head=value;radius=Math.max(2,Math.min(12,range));if(ready)configure(head,radius);}
    public static void heartbeat(){if(ready)pulse(enabled);}
    public static String describe(){
        if(!ready)return "Подключение к игровому миру ещё не готово";
        String raw=status(),hint;
        if(!enabled)hint="Выключен";
        else if(raw.endsWith("reason=0")&&!raw.contains("target=4294967295 "))hint="Удерживаю цель";
        else if(raw.endsWith("reason=4"))hint="Ищу игрока в радиусе "+radius+" блоков";
        else if(raw.endsWith("reason=1"))hint="Ожидаю обновления модуля";
        else hint="Ожидаю подходящий игровой мир и данные игрока";
        return hint+"\n"+raw;
    }
}
