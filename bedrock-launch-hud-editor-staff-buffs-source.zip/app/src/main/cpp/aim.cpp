#include "aim_stability.h"
#include "friend_core.h"
#include "aim_distance.h"
#include "friend_pick_core.h"
#include "aim_health_evidence.h"
#include "hud_data_core.h"
#include "hud_roster_core.h"
#include "aim_profile.h"
#include <jni.h>
#include <mutex>
#include <chrono>
#include <atomic>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>
namespace {
using namespace kulich_aim;
std::mutex gate;int memory=-1;A base=0,client=0;bool ready=false,enabled=false,head=false,sharp=true;
std::atomic<int64_t> hudLease{0};int64_t hudFrameAt=-1,nextHudFrame=0;bool hudRosterGlobal=false,hudRosterKnown=false,hudEffectsKnown=false;std::string hudRosterData,hudEffectsData;
std::string healthEvidence;int64_t healthEvidenceAt=-1;A healthEvidenceActor=0;uint32_t healthEvidenceEntity=0xffffffffU;
std::atomic<int64_t> pickLease{0};int64_t pickAt=-1,nextPick=0;char pickName[385]{};
FriendPolicy friendPolicy;bool friendsValid=true;uint64_t friendSkips=0,unknownSkips=0;
AimStability stability;AxisStabilizer axis;ClickClock clicks;bool attackEnabled=true;int cpsMin=15,cpsMax=15;uint64_t attackCalls=0,attackAccepted=0;int64_t hudAt=-1;float hudHp=NAN,hudMaxHp=NAN;int attackState=1;AttemptMeter meter;uint64_t swingCalls=0;char hudName[385]{};int64_t hudReadAt=-1;A hudActor=0;uint32_t hudEntity=0;
std::atomic<int64_t> lease{0};double radius=3,attackRadius=3;Lock targetLock;
int turnSpeed=240,smoothMs=80,priority=0;TurnClock turnClock;AimDeadzone deadzone;AimRamp ramp;double maxTurn=0;bool settled=false;
uint64_t ticks=0,applied=0,cameraChanges=0;uint32_t cameraEntity=0xffffffffU;A cameraRegistry=0;float previousQuaternion[4]{};bool haveCamera=false;unsigned checked=0;int reason=0,binding=0;float lastDistance=0,lastHp=NAN;Angles lastLook{},lastView{},lastDesired{};int64_t nextScan=0,deadline=0;unsigned reads=0;
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(A at,void* out,size_t size){
 at=plain(at);if(memory<0||at<4096||size>65536||at>0x00ffffffffffffffULL-size||++reads>8192||(deadline&&now()>deadline))return false;
 ssize_t n;do{n=pread(memory,out,size,static_cast<off_t>(at));}while(n<0&&errno==EINTR);return n==ssize_t(size);
}
FriendPolicy::Decision friendDecision(A actor){
 if(!friendsValid)return FriendPolicy::Unknown;
 if(friendPolicy.empty())return FriendPolicy::Enemy;
 char raw[385]{},display[385]{};
 playerIdentity(readMemory,actor,raw,sizeof raw);
 if(friendPolicy.check(raw)==FriendPolicy::Friend)return FriendPolicy::Friend;
 targetDisplayName(readMemory,actor,display,sizeof display);
 return friendPolicy.check(raw,display);
}
bool allowedTarget(A actor){
 auto decision=friendDecision(actor);
 if(decision==FriendPolicy::Friend){friendSkips++;attackState=8;return false;}
 if(decision==FriendPolicy::Unknown){unknownSkips++;attackState=9;return false;}
 return true;
}

}
extern "C" void kulich_aim_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);if(!lock.owns_lock()||!ready||!enabled)return;
 ticks++;if(now()>lease.load()){reason=1;turnClock.reset();deadzone.reset();axis.reset();stability.reset();clicks.reset();meter.reset();ramp.reset();return;}
 double allowance=turnClock.allowance(now(),turnSpeed);reads=0;deadline=now()+5;
 A self=plain(taggedPlayer);if(pointer(readMemory,self)!=base+0x139f6ea0ULL||pointer(readMemory,self+3240)!=client){reason=2;targetLock.reset();return;}
 A weak[3]{};if(!readMemory(client+576,weak,sizeof weak)||!plain(weak[1])){reason=2;targetLock.reset();return;}
 A registry=plain(weak[0]);if(!registry||pointer(readMemory,self+8)!=registry||integer(readMemory,self+24)!=uint32_t(weak[2])){reason=2;targetLock.reset();return;}
 auto v=view(readMemory,registry);Actor local{},target{};
 if(!actor(readMemory,base,v,self,true,local,&binding)){reason=3;targetLock.reset();return;}
 bool retained=retain(readMemory,base,v,local,radius,targetLock,target);
 if(retained&&!allowedTarget(target.address)){retained=false;targetLock.reset();hudAt=-1;}
 if(retained){lastHp=health(readMemory,base,registry,target.entity);if(std::isfinite(lastHp)&&lastHp<=0){retained=false;targetLock.reset();}}
 // Retain one validated target; periodic nearest scans used to flip the
 // camera between nearby players even while the selected player was valid.
 if(!retained){
  stability.reset();axis.reset();deadzone.reset();
  if(now()<nextScan){reason=4;return;}nextScan=now()+300;
  if(!acquireFiltered(readMemory,base,v,local,radius,targetLock,target,checked,false,[](const Actor& candidate){return allowedTarget(candidate.address);})){reason=4;return;}
  lastHp=health(readMemory,base,registry,target.entity);
 }
 Angles desired{};
 // Revalidate identity/components immediately before calls on the game thread.
 Actor current{},currentTarget{};
 if(!actor(readMemory,base,v,self,true,current)||!actor(readMemory,base,v,target.address,false,currentTarget)||
    current.entity!=local.entity||current.rotation!=local.rotation||currentTarget.entity!=target.entity||
    distance2(current.box,currentTarget.box)>radius*radius||now()>lease.load()||!allowedTarget(currentTarget.address)) {reason=6;targetLock.reset();return;}
 // The active camera has its own input state; Actor::setRot is overwritten by
 // that state. Use the game's view-input callback and let its camera/player
 // systems perform the update. Preserve allocation tags on native arguments.
 A taggedClient=0;unsigned char alive=0;
 A owner=pointer(readMemory,client+424),lifetime=owner?pointer(readMemory,owner+8):0;
 if(!readMemory(self+3240,&taggedClient,8)||plain(taggedClient)!=client||!lifetime||
    !readMemory(lifetime,&alive,1)||!(alive&1)||
    pointer(readMemory,base+0x1388fe70ULL+165*8)!=base+CAMERA_OWNER_GET){reason=7;return;}
 CameraContext context=reinterpret_cast<CameraContext(*)(void*)>(base+ACTIVE_CAMERA_GET)(reinterpret_cast<void*>(taggedClient));
 CameraBinding camera{};if(!cameraBinding(readMemory,context,camera)){reason=7;return;}
 float quaternion[4]{};if(!readMemory(plain(camera.camera)+40,quaternion,sizeof quaternion)){reason=7;return;}
 if(haveCamera&&cameraEntity==context.entity&&cameraRegistry==plain(context.registry)){
  double change=0;for(int i=0;i<4;i++)change+=std::abs(quaternion[i]-previousQuaternion[i]);
  if(change>.00001)cameraChanges++;
 }
 std::memcpy(previousQuaternion,quaternion,sizeof quaternion);haveCamera=true;
 cameraEntity=context.entity;cameraRegistry=plain(context.registry);
 CameraBinding again{};
 if(!cameraBinding(readMemory,context,again)||again.camera!=camera.camera||again.direct!=camera.direct||
    now()>lease.load()){reason=7;return;}
 Angles view{};alignas(8) Angles value{},delta{};
 if(!cameraPose(again.look,view)||
    !stableAimAngles(point(current.box,true),currentTarget.box,view,desired)){reason=5;return;}
 Angles goal=stability.apply(currentTarget.address,currentTarget.entity,point(current.box,true),currentTarget.box,view,desired,radius);
 Angles stable=axis.apply(target.address,target.entity,head,view,goal);
 if(!(sharp?cameraSnap(stable,again.look,value,delta):cameraInput(stable,allowance*ramp.scale(target.address,target.entity,now()),allowance/turnSpeed,smoothMs/1000.0,again.look,value,delta))){reason=5;return;}
 lastView=view;lastLook=value;lastDesired=desired;
 settled=stability.holding()||angleGap(view,desired)<=.10;lastDistance=float(std::sqrt(distance2(local.box,target.box)));
 if(deadzone.hold(angleGap(view,stable))){settled=true;reason=0;return;}
 if((!sharp&&allowance==0)||angleGap(view,value)<.00001){reason=0;return;}
 reinterpret_cast<void(*)(const CameraContext*,void*,void*,const Angles*)>(base+CAMERA_INPUT)
  (&context,reinterpret_cast<void*>(camera.camera),reinterpret_cast<void*>(camera.direct),&delta);
 DirectLook accepted{};constexpr double rad=3.14159265358979323846/180.0;
 if(!readMemory(plain(camera.direct),&accepted,sizeof accepted)||!valid(accepted)||
    std::abs(accepted.pitch-(again.look.pitch+delta.pitch*rad))>.001||
    std::abs(accepted.pendingYaw-(again.look.pendingYaw-delta.yaw*rad))>.001){reason=8;return;}
 applied++;maxTurn=std::fmax(maxTurn,angleGap(view,value));reason=0;
}
extern "C" void kulich_aim_attack_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);if(!lock.owns_lock())return;
 if(!ready||!enabled||now()>lease.load()){attackState=1;return;}
 if(!targetLock.actor){attackState=2;return;}
 reads=0;deadline=now()+5;A self=plain(taggedPlayer);
 if(pointer(readMemory,self)!=base+0x139f6ea0ULL||pointer(readMemory,self+3240)!=client||pointer(readMemory,self+8)!=targetLock.registry){attackState=7;return;}
 auto v=view(readMemory,targetLock.registry);Actor local{},target{};Lock attackLock=targetLock;
 if(!actor(readMemory,base,v,self,true,local)||!retain(readMemory,base,v,local,radius,attackLock,target)){attackState=3;return;}
 if(!allowedTarget(target.address)){targetLock.reset();hudAt=-1;return;}
 float hp=health(readMemory,base,v.registry,target.entity);if(std::isfinite(hp)&&hp<=0){attackState=2;return;}
 bool refresh=hudReadAt<0||now()-hudReadAt>=200||hudActor!=target.address||hudEntity!=target.entity;hudAt=now();hudHp=hp;hudMaxHp=health(readMemory,base,v.registry,target.entity,true);
 if(refresh){hudReadAt=now();hudActor=target.address;hudEntity=target.entity;if(!targetName(readMemory,target.address,hudName,sizeof hudName))hudName[0]=0;}
 A taggedClient=0,mode=0,taggedTarget=0;
 if(!readMemory(self+3240,&taggedClient,8)||!readMemory(self+2568,&mode,8)||!mode){attackState=7;return;}
 A function=attackBinding(readMemory,base,mode,taggedPlayer);if(!function){attackState=7;return;}
 A lifetime=pointer(readMemory,pointer(readMemory,client+424)+8);unsigned char alive=0;
 if(!lifetime||!readMemory(lifetime,&alive,1)||!(alive&1)){attackState=7;return;}
 CameraContext context=reinterpret_cast<CameraContext(*)(void*)>(base+ACTIVE_CAMERA_GET)(reinterpret_cast<void*>(taggedClient));
 CameraBinding camera{};Vec hit{};
 if(!cameraBinding(readMemory,context,camera)){attackState=7;return;}
 // The rendered quaternion may be one frame behind our sharp input. Use the
 // effective view INCLUDING pending yaw, already validated by the aim path.
 attackState=attackDistanceState(point(local.box,true),camera.look,target.box,{radius,attackRadius},hit);if(attackState)return;
 A owner=component(readMemory,v.owners,target.entity,8);
 if(!owner||!readMemory(owner,&taggedTarget,8)||plain(taggedTarget)!=target.address||pointer(readMemory,self+2568)!=plain(mode)){attackState=7;return;}
 int count=clicks.take(now(),cpsMin,cpsMax);if(!count){attackState=5;return;}
 attackState=6;
 for(int i=0;i<count;i++){
  Actor fresh{};if(!actor(readMemory,base,v,target.address,false,fresh)||fresh.entity!=target.entity||pointer(readMemory,self+2568)!=plain(mode)||now()>lease.load()||!allowedTarget(fresh.address))break;
  int distanceState=attackDistanceState(point(local.box,true),camera.look,fresh.box,{radius,attackRadius},hit);
  if(distanceState){attackState=distanceState;break;}
  float at[3]{float(hit.x),float(hit.y),float(hit.z)};
  if(pointer(readMemory,base+0x139f6ea0ULL+880)==base+SWING){
   reinterpret_cast<bool(*)(void*,int,int)>(base+SWING)(reinterpret_cast<void*>(taggedPlayer),3,0);swingCalls++;
  }
  attackCalls++;meter.add(now());
  if(dispatchAttack(reinterpret_cast<bool(*)(void*,void*,const float*)>(function),reinterpret_cast<void*>(mode),reinterpret_cast<void*>(taggedTarget),at)){
   attackAccepted++;attackState=0;
  }
 }
}
extern "C" void kulich_hud_data_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);
 if(!lock.owns_lock()||!ready||now()>hudLease.load()||now()<nextHudFrame)return;
 nextHudFrame=now()+500;hudFrameAt=-1;hudRosterKnown=hudEffectsKnown=false;hudRosterData.clear();hudEffectsData.clear();reads=0;deadline=now()+5;
 A self=plain(taggedPlayer);
 if(pointer(readMemory,self)!=base+0x139f6ea0ULL||pointer(readMemory,self+3240)!=client)return;
 A weak[3]{};if(!readMemory(client+576,weak,sizeof weak)||!plain(weak[1]))return;
 A registry=plain(weak[0]);if(!registry||pointer(readMemory,self+8)!=registry||integer(readMemory,self+24)!=uint32_t(weak[2]))return;
 auto v=view(readMemory,registry);Actor local{};if(!actor(readMemory,base,v,self,true,local))return;
 hudEffectsKnown=kulich_hud::readBuffs(readMemory,registry,local.entity,hudEffectsData);
 // Give roster discovery its own bounded budget, independent from effects.
 reads=0;deadline=now()+5;std::vector<std::string> roster;
 hudRosterGlobal=kulich_hud::globalRoster(readMemory,base,client,self,roster);
 hudRosterKnown=hudRosterGlobal;
 if(!hudRosterKnown){reads=0;deadline=now()+5;hudRosterKnown=kulich_hud::nearbyRoster(readMemory,base,v,local,roster);}
 if(hudRosterKnown){hudRosterData=kulich_hud::encodeRoster(roster);if(hudRosterData.size()>65000){hudRosterKnown=false;hudRosterData.clear();}}
 hudFrameAt=now();
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_HudDataBridge_pulse(JNIEnv*,jclass,jboolean value){hudLease=value?now()+1200:0;}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_HudDataBridge_rosterSnapshot(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);
 if(!ready||now()>hudLease.load()||hudFrameAt<0||now()-hudFrameAt>3000||!hudRosterKnown)return env->NewStringUTF("");
 auto value=std::to_string(now()-hudFrameAt)+(hudRosterGlobal?"|G|":"|N|")+hudRosterData;return env->NewStringUTF(value.c_str());
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_HudDataBridge_effectsSnapshotNative(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);
 if(!ready||now()>hudLease.load()||hudFrameAt<0||now()-hudFrameAt>3000||!hudEffectsKnown)return env->NewStringUTF("");
 auto value=std::to_string(now()-hudFrameAt)+"|"+hudEffectsData;return env->NewStringUTF(value.c_str());
}
extern "C" void kulich_health_evidence_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);
 if(!lock.owns_lock()||!ready||!enabled||now()>lease.load()||!targetLock.actor)return;
 if(healthEvidenceActor==targetLock.actor&&healthEvidenceEntity==targetLock.entity&&healthEvidenceAt>=0&&now()-healthEvidenceAt<3000)return;
 reads=0;deadline=now()+5;A self=plain(taggedPlayer);
 if(pointer(readMemory,self)!=base+0x139f6ea0ULL||pointer(readMemory,self+3240)!=client||pointer(readMemory,self+8)!=targetLock.registry)return;
 View v=view(readMemory,targetLock.registry);Actor target{};
 if(!actor(readMemory,base,v,targetLock.actor,false,target)||target.entity!=targetLock.entity)return;
 float current=health(readMemory,base,v.registry,target.entity),maximum=health(readMemory,base,v.registry,target.entity,true);
 char prefix[180];snprintf(prefix,sizeof prefix,"target=%u clientAttribute=%.2f/%.2f (not server HP)\n",target.entity,current,maximum);
 healthEvidence=std::string(prefix)+metadataEvidence(readMemory,target.address);
 healthEvidenceActor=target.address;healthEvidenceEntity=target.entity;healthEvidenceAt=now();
}
extern "C" void kulich_friend_pick_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);
 if(!lock.owns_lock()||!ready||now()>pickLease.load()||now()<nextPick)return;
 nextPick=now()+50;pickAt=-1;pickName[0]=0;reads=0;deadline=now()+5;
 A self=plain(taggedPlayer);
 if(pointer(readMemory,self)!=base+0x139f6ea0ULL||pointer(readMemory,self+3240)!=client)return;
 A weak[3]{};if(!readMemory(client+576,weak,sizeof weak)||!plain(weak[1]))return;
 A registry=plain(weak[0]);
 if(!registry||pointer(readMemory,self+8)!=registry||integer(readMemory,self+24)!=uint32_t(weak[2]))return;
 View v=view(readMemory,registry);Actor local{},target{};
 if(!actor(readMemory,base,v,self,true,local))return;
 A taggedClient=0;if(!readMemory(self+3240,&taggedClient,8)||plain(taggedClient)!=client)return;
 A owner=pointer(readMemory,client+424),lifetime=owner?pointer(readMemory,owner+8):0;unsigned char alive=0;
 if(!lifetime||!readMemory(lifetime,&alive,1)||!(alive&1))return;
 CameraContext context=reinterpret_cast<CameraContext(*)(void*)>(base+ACTIVE_CAMERA_GET)(reinterpret_cast<void*>(taggedClient));
 CameraBinding camera{};
 if(!cameraBinding(readMemory,context,camera)||!pickFriendRay(readMemory,base,v,local,camera.look,target))return;
 if(!playerIdentity(readMemory,target.address,pickName,sizeof pickName)||friendKey(pickName).empty()){pickName[0]=0;return;}
 if(now()>deadline||now()>pickLease.load()){pickName[0]=0;return;}
 pickAt=now();
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_picking(JNIEnv*,jclass,jboolean value){
 pickLease=value?now()+1200:0;
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_AimbotBridge_pickSnapshot(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);
 if(!ready||now()>pickLease.load()||pickAt<0||now()-pickAt>150||!pickName[0])return env->NewStringUTF("");
 char value[850];int n=snprintf(value,sizeof value,"%lld|",static_cast<long long>(now()-pickAt));constexpr char hex[]="0123456789abcdef";
 for(const unsigned char* p=reinterpret_cast<const unsigned char*>(pickName);*p&&n+2<int(sizeof value);p++){value[n++]=hex[*p>>4];value[n++]=hex[*p&15];}
 value[n]=0;return env->NewStringUTF(value);
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_AimbotBridge_install(JNIEnv* env,jclass,jlong address,jlong owner){
 std::lock_guard<std::mutex> lock(gate);deadline=0;reads=0;
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0)return env->NewStringUTF("Cannot read game process");
 A candidate=A(address),candidateClient=plain(A(owner));
 if((base&&base!=candidate)||pointer(readMemory,candidateClient)!=candidate+0x1388fe70ULL)return env->NewStringUTF("Unsupported client binding");
 for(const auto& p:aimProfiles){uint32_t words[8]{};if(!readMemory(candidate+p.offset,words,sizeof words)||std::memcmp(words,p.words,sizeof words))return env->NewStringUTF("Aim code profile mismatch");}
 base=candidate;client=candidateClient;ready=true;targetLock.reset();turnClock.reset();deadzone.reset();axis.reset();stability.reset();clicks.reset();meter.reset();ramp.reset();nextScan=0;return env->NewStringUTF("");
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_enable(JNIEnv*,jclass,jboolean value){
 std::lock_guard<std::mutex> lock(gate);enabled=ready&&value;hudAt=-1;targetLock.reset();turnClock.reset();deadzone.reset();axis.reset();stability.reset();clicks.reset();meter.reset();ramp.reset();maxTurn=0;settled=false;nextScan=0;reason=0;cameraChanges=0;cameraEntity=0xffffffffU;cameraRegistry=0;haveCamera=false;if(!enabled)lease=0;
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_configure(JNIEnv*,jclass,jint aimTenths,jint attackTenths,jint low,jint high){
 std::lock_guard<std::mutex> lock(gate);auto distances=AimDistances::fromTenths(aimTenths,attackTenths);radius=distances.acquire;attackRadius=distances.attack;
 int minimum=low<1?1:low>40?40:low,maximum=high<1?1:high>40?40:high;
 if(minimum>maximum)std::swap(minimum,maximum);
 if(minimum!=cpsMin||maximum!=cpsMax){clicks.reset();meter.reset();}cpsMin=minimum;cpsMax=maximum;
}
extern "C" JNIEXPORT jint JNICALL Java_dev_custom_bedrockgui_AimbotBridge_friends(JNIEnv* env,jclass,jstring value){
 std::lock_guard<std::mutex> lock(gate);
 friendsValid=false;
 if(value){
  jint length=env->GetStringUTFLength(value);
  if(length>=0&&length<=2176){
   const char* chars=env->GetStringUTFChars(value,nullptr);
   if(chars){friendsValid=friendPolicy.replace(std::string(chars,static_cast<size_t>(length)));env->ReleaseStringUTFChars(value,chars);}
  }
 }
 // An add/remove affects an already retained target before its next attempt.
 targetLock.reset();stability.reset();axis.reset();deadzone.reset();hudAt=-1;nextScan=0;clicks.reset();meter.reset();
 return friendsValid?static_cast<jint>(friendPolicy.size()):-1;
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_pulse(JNIEnv*,jclass,jboolean active){lease=active?now()+1200:0;}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_AimbotBridge_status(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);char text[1024];
 snprintf(text,sizeof text,"Aimbot: enabled=%d point=%s aimRange=%.1f attackRange=%.1f speed=%d smoothMs=%d mode=%s priority=%s hp=%.2f autoAttack=%d cpsMin=%d cpsMax=%d attacks=%llu accepted=%llu attackState=%d actualCps=%u swings=%llu aimHold=%d contact=%d settled=%d maxTurn=%.3f target=%u distance=%.2f ticks=%llu applied=%llu checked=%u pitch=%.2f yaw=%.2f viewPitch=%.2f viewYaw=%.2f goalPitch=%.2f goalYaw=%.2f phase=camera-input-v13 camera=%u cameraChanges=%llu friends=%zu friendsValid=%d friendSkips=%llu unknownSkips=%llu bind=%d reason=%d",enabled,head?"head":"body",radius,attackRadius,turnSpeed,smoothMs,sharp?"sharp":"smooth",priority==1?"health":"nearest",lastHp,attackEnabled,cpsMin,cpsMax,static_cast<unsigned long long>(attackCalls),static_cast<unsigned long long>(attackAccepted),attackState,meter.rate(now()),static_cast<unsigned long long>(swingCalls),stability.holding(),stability.overlapping(),settled,maxTurn,targetLock.entity,lastDistance,static_cast<unsigned long long>(ticks),static_cast<unsigned long long>(applied),checked,lastLook.pitch,lastLook.yaw,lastView.pitch,lastView.yaw,lastDesired.pitch,lastDesired.yaw,cameraEntity,static_cast<unsigned long long>(cameraChanges),friendPolicy.size(),friendsValid,static_cast<unsigned long long>(friendSkips),static_cast<unsigned long long>(unknownSkips),binding,reason);
 std::string result(text);
 if(healthEvidenceAt>=0&&now()-healthEvidenceAt<15000)result+="\nHP evidence ageMs="+std::to_string(now()-healthEvidenceAt)+" "+healthEvidence;
 return env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_AimbotBridge_hudSnapshot(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);
 if(!enabled||hudAt<0||now()-hudAt>5000)return env->NewStringUTF("");
 char result[950]{};int n=snprintf(result,sizeof result,"%lld|%.2f|",static_cast<long long>(now()-hudAt),hudHp);
 constexpr char hex[]="0123456789abcdef";
 for(size_t i=0;i<sizeof hudName&&hudName[i]&&n+2<int(sizeof result);i++){
  unsigned char value=static_cast<unsigned char>(hudName[i]);result[n++]=hex[value>>4];result[n++]=hex[value&15];
 }
 snprintf(result+n,sizeof result-size_t(n),"|%.2f|%d|%u|%d|%d",hudMaxHp,attackState,meter.rate(now()),cpsMax,cpsMin);
 return env->NewStringUTF(result);
}
