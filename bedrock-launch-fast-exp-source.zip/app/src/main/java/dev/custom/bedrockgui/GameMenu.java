package dev.custom.bedrockgui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

/** Categorized in-window menu. Gameplay entries only enable when a real handler is registered. */
public final class GameMenu {
    public interface Toggle { void setEnabled(boolean enabled) throws Exception; }
    private static final String TARGET = "target", UTILITY = "utility";
    private static final int INK = Color.rgb(222, 235, 229), MUTED = Color.rgb(143, 166, 156);
    private static final int ACCENT = Color.rgb(125, 221, 172);
    private final Activity activity;
    private final SharedPreferences preferences;
    private final FrameLayout root;
    private final Button floating;
    private final View shade;
    private final LinearLayout panel, body, categories, moduleList, details;
    private final ScrollView moduleScroll, detailScroll;
    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final Drag iconDrag, panelDrag;
    private final Resize resize;
    private String category, selected;
    private boolean wide = true;
    private boolean resizing;
    private float widthRatio, heightRatio;

    private static final class Entry {
        final String id, category;
        String title, description;
        Toggle callback;
        boolean enabled;
        Entry(String id, String category, String title, String description) {
            this.id = id;this.category = category;this.title = title;this.description = description;
        }
    }

    public GameMenu(Activity activity) {
        this.activity = activity;
        preferences = activity.getSharedPreferences("game-menu-ui", 0);
        widthRatio = preferences.getFloat("panel.widthRatio", 0.86f);
        heightRatio = preferences.getFloat("panel.heightRatio", 0.86f);
        category = preferences.getString("category", UTILITY);
        if (!TARGET.equals(category) && !UTILITY.equals(category)) category = UTILITY;
        root = new FrameLayout(activity);

        shade = new View(activity);
        shade.setBackgroundColor(Color.argb(85, 0, 0, 0));shade.setClickable(true);
        shade.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        shade.setVisibility(View.GONE);
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        panel = new LinearLayout(activity);panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(background(Color.rgb(15, 24, 20), 18));panel.setElevation(dp(8));
        panel.setPadding(dp(12), dp(8), dp(12), dp(12));panel.setClickable(true);panel.setVisibility(View.GONE);
        LinearLayout header = new LinearLayout(activity);header.setGravity(Gravity.CENTER_VERTICAL);header.setClickable(true);
        LinearLayout brand = new LinearLayout(activity);brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = label("kulich", 23);title.setTypeface(Typeface.DEFAULT_BOLD);title.setTextColor(ACCENT);
        brand.addView(title);TextView hint = label("Перемещение — за заголовок", 11);hint.setTextColor(MUTED);brand.addView(hint);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        panel.addView(header, new LinearLayout.LayoutParams(-1, dp(54)));
        body = new LinearLayout(activity);panel.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout footer = new LinearLayout(activity);footer.setGravity(Gravity.CENTER_VERTICAL);
        TextView sizeHint = label("Размер окна", 12);sizeHint.setTextColor(MUTED);
        footer.addView(sizeHint, new LinearLayout.LayoutParams(0, -2, 1));
        TextView grip = label("◢", 27);grip.setGravity(Gravity.CENTER);grip.setTextColor(ACCENT);
        grip.setClickable(true);grip.setContentDescription("Изменить размер меню: потяни за угол");
        footer.addView(grip, new LinearLayout.LayoutParams(dp(48), -1));
        panel.addView(footer, new LinearLayout.LayoutParams(-1, dp(40)));
        categories = new LinearLayout(activity);
        moduleList = new LinearLayout(activity);moduleList.setOrientation(LinearLayout.VERTICAL);
        details = new LinearLayout(activity);details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(18), dp(12), dp(12), dp(12));
        moduleScroll = new ScrollView(activity);moduleScroll.setFillViewport(true);moduleScroll.addView(moduleList);
        detailScroll = new ScrollView(activity);detailScroll.setFillViewport(true);detailScroll.addView(details);
        root.addView(panel, new FrameLayout.LayoutParams(dp(740), dp(340)));
        panelDrag = new Drag(panel, "panel.", 0.5f, 0.5f, null);
        header.setOnTouchListener((v, event) -> resizing || panelDrag.touch(event));
        resize = new Resize();grip.setOnTouchListener((v, event) -> resize.touch(event));

        floating = button("kulich");floating.setTextSize(13);floating.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable circle = new GradientDrawable();circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.rgb(20, 76, 58));circle.setStroke(dp(2), ACCENT);floating.setBackground(circle);
        floating.setStateListAnimator(null);floating.setElevation(dp(16));
        floating.setContentDescription("kulich: нажми для меню или перетащи круглую иконку");
        root.addView(floating, new FrameLayout.LayoutParams(dp(68), dp(68)));
        floating.setOnClickListener(v -> toggle());
        iconDrag = new Drag(floating, "", 0.04f, 0.2f, () -> floating.performClick());
        floating.setOnTouchListener((v, event) -> iconDrag.touch(event));

        addCatalog("auto_buy", "Auto Buy", "Покупка выбранных предметов с учётом ограничения цены.");
        addCatalog("block_trap", "Block Trap", "Размещение блоков вокруг выбранной цели с учётом списка друзей.");
        addCatalog("fast_exp", "Fast Exp", "Ускоренное использование пузырьков опыта из руки.");
        root.postDelayed(fastHeartbeat,400);
        arrange(true);
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> fit());
        activity.getWindow().addContentView(root, new ViewGroup.LayoutParams(-1, -1));root.post(this::fit);
    }

    private void addCatalog(String id, String title, String description) {
        entries.put(id, new Entry(id, UTILITY, title, description));
    }
    /** Bind implemented gameplay behavior to a catalog ID, or add a new utility module. UI thread only. */
    public void addToggle(String id, String title, String description, Toggle callback) {
        addToggle(id, UTILITY, title, description, callback);
    }
    public void addToggle(String id, String category, String title, String description, Toggle callback) {
        if (id == null || id.isEmpty() || callback == null || (!TARGET.equals(category) && !UTILITY.equals(category)))
            throw new IllegalArgumentException("Module requires an ID, category and real callback");
        Entry entry = entries.get(id);
        if (entry != null && entry.callback != null) throw new IllegalArgumentException("Duplicate module ID: " + id);
        if (entry == null) { entry = new Entry(id, category, title, description);entries.put(id, entry); }
        else if (!entry.category.equals(category)) throw new IllegalArgumentException("Module category does not match catalog");
        entry.title = title;entry.description = description;entry.callback = callback;
        renderModules();renderDetails();
    }
    private void arrange(boolean wide) {
        this.wide = wide;body.removeAllViews();detach(categories);detach(moduleScroll);detach(detailScroll);
        categories.setOrientation(wide ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        body.setOrientation(wide ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        if (wide) {
            body.addView(categories, new LinearLayout.LayoutParams(dp(136), -1));
            body.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            body.addView(moduleScroll, new LinearLayout.LayoutParams(dp(180), -1));
            body.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            body.addView(detailScroll, new LinearLayout.LayoutParams(0, -1, 1));
        } else {
            body.addView(categories, new LinearLayout.LayoutParams(-1, dp(76)));
            LinearLayout content = new LinearLayout(activity);
            content.addView(moduleScroll, new LinearLayout.LayoutParams(0, -1, 0.43f));
            content.addView(separator(), new LinearLayout.LayoutParams(dp(1), -1));
            content.addView(detailScroll, new LinearLayout.LayoutParams(0, -1, 0.57f));
            body.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        }
        renderCategories();renderModules();renderDetails();
    }
    private void renderCategories() {
        categories.removeAllViews();
        categoryRow(TARGET, "01", "Таргет");categoryRow(UTILITY, "02", "Вспомогательные\nфункции");
    }
    private void categoryRow(String id, String number, String title) {
        LinearLayout row = new LinearLayout(activity);row.setOrientation(LinearLayout.VERTICAL);
        row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10), dp(8), dp(6), dp(8));
        boolean chosen = id.equals(category);
        row.setBackground(background(chosen ? Color.rgb(28, 57, 42) : Color.rgb(20, 30, 25), 10));
        TextView index = label(number, 11);index.setTextColor(chosen ? ACCENT : MUTED);row.addView(index);
        TextView name = label(title, 14);name.setTextColor(chosen ? INK : MUTED);row.addView(name);
        row.setOnClickListener(v -> {
            category = id;selected = null;preferences.edit().putString("category", id).apply();
            renderCategories();renderModules();renderDetails();
        });
        LinearLayout.LayoutParams bounds = wide ? new LinearLayout.LayoutParams(-1, dp(84)) :
                new LinearLayout.LayoutParams(0, -1, 1);
        bounds.setMargins(dp(3), dp(3), dp(3), dp(3));categories.addView(row, bounds);
    }
    private void renderModules() {
        moduleList.removeAllViews();
        boolean any = false;
        for (Entry entry : entries.values()) {
            if (!entry.category.equals(category)) continue;
            any = true;
            LinearLayout row = new LinearLayout(activity);row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(14), dp(8), dp(14));
            if (entry.id.equals(selected)) row.setBackground(background(Color.rgb(27, 53, 38), 10));
            TextView dot = label("●", 11);dot.setTextColor(entry.enabled ? ACCENT : MUTED);
            row.addView(dot, new LinearLayout.LayoutParams(dp(20), -2));
            LinearLayout text = new LinearLayout(activity);text.setOrientation(LinearLayout.VERTICAL);
            text.addView(label(entry.title, 16));
            TextView status = label(entry.callback == null ? "Не подключён" : entry.enabled ? "Включён" : "Выключен", 11);
            status.setTextColor(MUTED);text.addView(status);row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
            TextView arrow = label("›", 23);arrow.setTextColor(MUTED);row.addView(arrow);
            row.setOnClickListener(v -> { selected = entry.id;renderModules();renderDetails(); });
            moduleList.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        if (!any) {
            TextView empty = label("Пока нет модулей", 14);empty.setTextColor(MUTED);empty.setPadding(dp(12), dp(20), dp(8), 0);
            moduleList.addView(empty);
        }
    }
    private void renderDetails() {
        Entry fast=entries.get("fast_exp");
        if(fast!=null&&fast.callback==null&&FastExpBridge.isReady()){fast.callback=FastExpBridge::setEnabled;renderModules();}
        details.removeAllViews();Entry entry = entries.get(selected);
        if (entry == null || !entry.category.equals(category)) {
            details.setGravity(Gravity.CENTER);
            TextView icon = label("◇", 54);icon.setTextColor(Color.rgb(64, 86, 74));details.addView(icon);
            TextView hint = label("Выбери модуль", 18);hint.setTextColor(MUTED);details.addView(hint);return;
        }
        details.setGravity(Gravity.TOP);
        TextView title = label(entry.title, 23);title.setTypeface(Typeface.DEFAULT_BOLD);details.addView(title);
        TextView description = label(entry.description, 14);description.setTextColor(MUTED);
        description.setPadding(0, dp(14), 0, dp(20));details.addView(description);
        if (entry.callback != null) renderToggle(entry);
        if(entry.id.equals("fast_exp")&&entry.callback!=null){
            TextView note=label("Экспериментальный режим. Использует только пузырьки опыта. После включения закрой меню круглой иконкой kulich. При сворачивании выключается.",12);
            note.setTextColor(MUTED);details.addView(note);
            Button stats=button("Статус Fast Exp");details.addView(stats);
            TextView nativeState=label(FastExpBridge.describe(),12);nativeState.setTextColor(MUTED);details.addView(nativeState);
            stats.setOnClickListener(v->{String value=FastExpBridge.describe();nativeState.setText(value);GameRuntime.log(value);});
        }
        TextView state = label(entry.callback == null ? "Модуль ещё не подключён к игре" : "Готов к работе", 13);
        state.setTextColor(entry.callback == null ? Color.rgb(210, 181, 123) : ACCENT);state.setPadding(0, dp(12), 0, 0);details.addView(state);
        if (entry.id.equals("fast_exp") && entry.callback == null) {
            Button probe = button("Проверить подключение");
            details.addView(probe, new LinearLayout.LayoutParams(-1, dp(52)));
            TextView output = label("Проверку выполняй в одиночном мире. Результат можно сохранить в журнал.", 12);
            output.setTextColor(MUTED);output.setPadding(0, dp(10), 0, 0);details.addView(output);
            probe.setOnClickListener(v -> {
                if (!GameEngineProbe.begin()) {
                    Toast.makeText(activity, "Проверка уже выполняется", Toast.LENGTH_SHORT).show();return;
                }
                probe.setEnabled(false);output.setText("Проверяю подключение…");
                Thread worker = new Thread(() -> {
                    String result;
                    try { result = GameEngineProbe.run(); }
                    finally { GameEngineProbe.end(); }
                    activity.runOnUiThread(() -> {
                        if (activity.isFinishing() || activity.isDestroyed()) return;
                        probe.setEnabled(true);output.setText(result);
                        if(FastExpBridge.isReady()){renderModules();renderDetails();}
                    });
                }, "game-engine-probe");
                worker.setDaemon(true);worker.start();
            });
        }
    }
    private void renderToggle(Entry entry) {
        if(entry.id.equals("fast_exp"))entry.enabled=FastExpBridge.isEnabled();
        Switch control = new Switch(activity);control.setText("Включить");control.setTextSize(17);control.setTextColor(INK);
        control.setChecked(entry.enabled);details.addView(control, new LinearLayout.LayoutParams(-1, dp(48)));
        boolean[] reverting = {false};
        control.setOnCheckedChangeListener((button, enabled) -> {
            if (reverting[0] || entry.callback == null) return;
            try { entry.callback.setEnabled(enabled);entry.enabled = enabled;renderModules(); }
            catch (Exception | LinkageError error) {
                reverting[0] = true;control.setChecked(entry.enabled);reverting[0] = false;
                GameRuntime.log("Menu module failed: " + entry.id + " / " + error);
                Toast.makeText(activity, "Не удалось изменить модуль", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private long lastFastLog;
    private final Runnable fastHeartbeat=new Runnable(){public void run(){
        boolean closed=panel.getVisibility()!=View.VISIBLE&&activity.hasWindowFocus()&&!activity.isFinishing();
        FastExpBridge.heartbeat(closed);
        long now=android.os.SystemClock.uptimeMillis();
        if(FastExpBridge.isEnabled()&&now-lastFastLog>3000){lastFastLog=now;GameRuntime.log(FastExpBridge.describe());}
        root.postDelayed(this,400);
    }};
    private void toggle() { if (panel.getVisibility() == View.VISIBLE) close();else open(); }
    public void open() { FastExpBridge.heartbeat(false);shade.setVisibility(View.VISIBLE);panel.setVisibility(View.VISIBLE);floating.bringToFront(); }
    public void close() { panel.setVisibility(View.GONE);shade.setVisibility(View.GONE);floating.bringToFront(); }
    public void dispose() {
        root.removeCallbacks(fastHeartbeat);FastExpBridge.setEnabled(false);
        for (Entry entry : entries.values()) if (entry.enabled && entry.callback != null) {
            try { entry.callback.setEnabled(false);entry.enabled = false; }
            catch (Exception | LinkageError error) { GameRuntime.log("Menu module cleanup failed: " + entry.id + " / " + error); }
        }
        detach(root);
    }
    private void fit() {
        if (root.getWidth() == 0 || root.getHeight() == 0) return;
        FrameLayout.LayoutParams bounds = (FrameLayout.LayoutParams) panel.getLayoutParams();
        int width = menuWidth(root.getWidth() * widthRatio);
        int height = menuHeight(root.getHeight() * heightRatio);
        if (bounds.width != width || bounds.height != height) { bounds.width = width;bounds.height = height;panel.setLayoutParams(bounds); }
        boolean useWide = width >= dp(620);if (useWide != wide) arrange(useWide);
        iconDrag.apply();if (!resizing) panelDrag.apply();
    }
    private int menuWidth(float value) {
        int maximum = Math.max(1, root.getWidth() - dp(24));
        return Math.max(Math.min(dp(360), maximum), Math.min(Math.round(value), maximum));
    }
    private int menuHeight(float value) {
        int maximum = Math.max(1, root.getHeight() - dp(24));
        return Math.max(Math.min(dp(264), maximum), Math.min(Math.round(value), maximum));
    }
    private final class Resize {
        float rawX, rawY, anchorX, anchorY;int startWidth, startHeight, pointer = -1;
        boolean touch(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pointer = event.getPointerId(0);rawX = event.getRawX(0);rawY = event.getRawY(0);
                    anchorX = panel.getX();anchorY = panel.getY();startWidth = panel.getWidth();startHeight = panel.getHeight();
                    resizing = true;root.requestDisallowInterceptTouchEvent(true);return true;
                case MotionEvent.ACTION_MOVE: move(event);return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerId(event.getActionIndex()) == pointer) {
                        int next = event.getActionIndex() == 0 ? 1 : 0;pointer = event.getPointerId(next);
                        rawX = event.getRawX(next);rawY = event.getRawY(next);
                        startWidth = panel.getLayoutParams().width;startHeight = panel.getLayoutParams().height;
                    }
                    return true;
                case MotionEvent.ACTION_UP: move(event);finish();return true;
                case MotionEvent.ACTION_CANCEL: finish();return true;
                default: return true;
            }
        }
        void move(MotionEvent event) {
            int index = event.findPointerIndex(pointer);if (index < 0) return;
            int width = menuWidth(startWidth + event.getRawX(index) - rawX);
            int height = menuHeight(startHeight + event.getRawY(index) - rawY);
            // Limit growth to the space after the anchored top-left corner.
            width = Math.min(width, Math.max(1, (int) (root.getWidth() - anchorX)));
            height = Math.min(height, Math.max(1, (int) (root.getHeight() - anchorY)));
            widthRatio = width / (float) Math.max(1, root.getWidth());
            heightRatio = height / (float) Math.max(1, root.getHeight());
            FrameLayout.LayoutParams bounds = (FrameLayout.LayoutParams) panel.getLayoutParams();
            if (bounds.width != width || bounds.height != height) { bounds.width = width;bounds.height = height;panel.setLayoutParams(bounds); }
            panel.setX(anchorX);panel.setY(anchorY);
            panelDrag.x = anchorX / Math.max(1, root.getWidth() - width);
            panelDrag.y = anchorY / Math.max(1, root.getHeight() - height);
            boolean useWide = width >= dp(620);if (useWide != wide) arrange(useWide);
        }
        void finish() {
            pointer = -1;resizing = false;root.requestDisallowInterceptTouchEvent(false);
            preferences.edit().putFloat("panel.widthRatio", widthRatio).putFloat("panel.heightRatio", heightRatio).apply();
            panelDrag.save();
        }
    }
    private final class Drag {
        final View target;final String prefix;final Runnable tap;
        float x, y, rawX, rawY, startX, startY;int pointer = -1;boolean moved;
        Drag(View target, String prefix, float x, float y, Runnable tap) {
            this.target = target;this.prefix = prefix;this.tap = tap;
            this.x = preferences.getFloat(prefix + "x", x);this.y = preferences.getFloat(prefix + "y", y);
        }
        boolean touch(MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    pointer = event.getPointerId(0);rawX = event.getRawX(0);rawY = event.getRawY(0);
                    startX = target.getX();startY = target.getY();moved = false;root.requestDisallowInterceptTouchEvent(true);return true;
                case MotionEvent.ACTION_MOVE: move(event);return true;
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerId(event.getActionIndex()) == pointer) {
                        int next = event.getActionIndex() == 0 ? 1 : 0;pointer = event.getPointerId(next);
                        rawX = event.getRawX(next);rawY = event.getRawY(next);startX = target.getX();startY = target.getY();moved = true;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    move(event);if (moved) save();else if (tap != null) tap.run();finish();return true;
                case MotionEvent.ACTION_CANCEL: if (moved) save();finish();return true;
                default: return true;
            }
        }
        void move(MotionEvent event) {
            int index = event.findPointerIndex(pointer);if (index < 0) return;
            float dx = event.getRawX(index) - rawX, dy = event.getRawY(index) - rawY;
            if (Math.hypot(dx, dy) > ViewConfiguration.get(activity).getScaledTouchSlop()) moved = true;
            if (!moved) return;
            int spanX = Math.max(0, root.getWidth() - target.getWidth()), spanY = Math.max(0, root.getHeight() - target.getHeight());
            target.setX(Math.max(0, Math.min(startX + dx, spanX)));target.setY(Math.max(0, Math.min(startY + dy, spanY)));
            if (spanX > 0) x = target.getX() / spanX;if (spanY > 0) y = target.getY() / spanY;
        }
        void apply() { target.setX(x * Math.max(0, root.getWidth() - target.getWidth()));target.setY(y * Math.max(0, root.getHeight() - target.getHeight())); }
        void save() { preferences.edit().putFloat(prefix + "x", x).putFloat(prefix + "y", y).apply(); }
        void finish() { pointer = -1;root.requestDisallowInterceptTouchEvent(false); }
    }
    private static void detach(View view) { if (view.getParent() instanceof ViewGroup) ((ViewGroup) view.getParent()).removeView(view); }
    private int dp(int value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }
    private TextView label(String text, int size) { TextView view = new TextView(activity);view.setText(text);view.setTextSize(size);view.setTextColor(INK);view.setGravity(Gravity.CENTER_VERTICAL);return view; }
    private Button button(String text) { Button view = new Button(activity);view.setText(text);view.setTextColor(INK);view.setTextSize(18);view.setAllCaps(false);view.setMinWidth(0);view.setMinimumWidth(0);view.setPadding(dp(4), 0, dp(4), 0);view.setBackground(background(Color.rgb(29, 57, 43), 12));return view; }
    private View separator() { View view = new View(activity);view.setBackgroundColor(Color.rgb(37, 54, 45));return view; }
    private GradientDrawable background(int color, int radius) { GradientDrawable shape = new GradientDrawable();shape.setColor(color);shape.setCornerRadius(dp(radius));return shape; }
}
