#pragma once
#include <cmath>
#include <cstdint>
#include <cstring>
#include <type_traits>

// Exact 1.26.60.4 arm64 build. See docs/pearl-world-collision-abi.md.
// These helpers must run on the game's thread with a freshly validated Actor.
namespace kulich_world_collision {
using Address=uint64_t;
constexpr Address SOURCE_TABLE=0x13d6dcd0ULL, REGION_GET=0xfd827a0ULL;
constexpr Address CLIP=0x1037905cULL, PROJECTILE_FILTER=0x141db670ULL;
constexpr Address RELEASE_WEAK=0x135d3980ULL;
struct Vec3 { float x=0,y=0,z=0; };
// A trivial large return value preserves the native x8 indirect-result ABI.
struct alignas(8) NativeHit { unsigned char bytes[136]{}; };
static_assert(sizeof(Vec3)==12&&sizeof(NativeHit)==136,"Exact native layouts");
static_assert(std::is_trivially_copyable<NativeHit>::value&&std::is_trivially_destructible<NativeHit>::value,
              "Native hit must retain the large trivial aggregate return ABI");
enum class Result { Unavailable,Miss,Block };
struct Hit { Vec3 position{};int32_t block[3]{};uint8_t face=0;float fraction=0; };
struct WeakRelease {
 Address count=0,release=0;
 ~WeakRelease(){if(count&&release)reinterpret_cast<void(*)(void*)>(release)(reinterpret_cast<void*>(count));}
 WeakRelease(const WeakRelease&)=delete;WeakRelease& operator=(const WeakRelease&)=delete;
 WeakRelease(Address count,Address release):count(count),release(release){}
};
inline Address plain(Address p){return p&0x00ffffffffffffffULL;}
template<class Read> Address pointer(Read& read,Address at){Address p=0;return read(plain(at),&p,sizeof p)?plain(p):0;}
inline bool valid(Vec3 v){return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z)&&std::abs(v.x)<=32000000&&std::abs(v.y)<=32000000&&std::abs(v.z)<=32000000;}
inline Result decode(const NativeHit& native,Vec3 start,Vec3 end,Hit& hit){
 hit={};int32_t kind=-1;std::memcpy(&kind,native.bytes+24,4);
 if(kind==2||kind==3)return Result::Miss;
 if(kind!=0||!valid(start)||!valid(end))return Result::Unavailable;
 std::memcpy(&hit.position,native.bytes+44,12);std::memcpy(hit.block,native.bytes+32,12);hit.face=native.bytes[28];
 if(!valid(hit.position)||hit.face>5)return Result::Unavailable;
 double dx=double(end.x)-start.x,dy=double(end.y)-start.y,dz=double(end.z)-start.z;
 double length2=dx*dx+dy*dy+dz*dz;if(length2<1e-12||length2>256)return Result::Unavailable;
 double hx=double(hit.position.x)-start.x,hy=double(hit.position.y)-start.y,hz=double(hit.position.z)-start.z;
 double t=(hx*dx+hy*dy+hz*dz)/length2;
 if(t<-.001||t>1.001)return Result::Unavailable;
 double ex=hx-t*dx,ey=hy-t*dy,ez=hz-t*dz;
 // Reject corrupt/unrelated result coordinates, allowing float rounding.
 if(ex*ex+ey*ey+ez*ez>.01)return Result::Unavailable;
 hit.fraction=float(std::fmax(0.,std::fmin(1.,t)));return Result::Block;
}
template<class Read> bool profile(Read& read,Address base){
 const uint32_t clip[]{0x6db923e9U,0xa9017bfdU,0xa9026ffcU,0xa90367faU};
 const uint32_t region[]{0xa9be7bfdU,0xa9014ff4U,0x910003fdU,0xaa0003f3U};
 const uint32_t release[]{0xb0004ed0U,0xf943fe11U,0x911fe210U,0xd61f0220U};
 uint32_t data[4]{};
 return base&&read(base+CLIP,data,sizeof data)&&!std::memcmp(data,clip,sizeof data)&&
  read(base+REGION_GET,data,sizeof data)&&!std::memcmp(data,region,sizeof data)&&
  read(base+RELEASE_WEAK,data,sizeof data)&&!std::memcmp(data,release,sizeof data);
}
template<class Read> bool sourceBinding(Read& read,Address base,Address source){
 source=plain(source);Address table=pointer(read,source);
 return source>=4096&&table==base+SOURCE_TABLE&&pointer(read,table+51*8)==base+CLIP;
}
template<class Read> bool filterBinding(Read& read,Address base){
 Address implementation=pointer(read,base+PROJECTILE_FILTER+32);
 Address table=implementation?pointer(read,implementation):0;
 Address invoke=table?pointer(read,table+48):0;
 return table>=base+0x13600000ULL&&table<base+0x14700000ULL&&
  invoke>=base+0x6000000ULL&&invoke<base+0x136869b0ULL;
}
// The caller validates registry ownership/lifetime before entering. Actor::getRegion
// performs the engine's own dimension/thread guard and returns its BlockSource.
template<class Read> Address region(Read& read,Address base,Address actor){
 // Do not replace actor with checkedActor: native loads require the allocation
 // tag even though /proc/self/mem validation uses the untagged address.
 Address checkedActor=plain(actor);
 if(checkedActor<4096||!pointer(read,checkedActor+480)||!pointer(read,checkedActor+488)||!profile(read,base))return 0;
#if defined(__aarch64__)
 Address source=reinterpret_cast<Address(*)(void*)>(base+REGION_GET)(reinterpret_cast<void*>(actor));
 return sourceBinding(read,base,source)?source:0;
#else
 return 0;
#endif
}
// Flags and filter are copied from the actual ProjectileSystem segment trace.
// This traces terrain only; actor intersections belong to the caller's actor pass.
template<class Read> Result trace(Read& read,Address base,Address source,Address actor,Vec3 start,Vec3 end,uint8_t projectileFlag,Hit& hit){
 hit={};if(!valid(start)||!valid(end)||!sourceBinding(read,base,source)||!filterBinding(read,base))return Result::Unavailable;
 double dx=double(end.x)-start.x,dy=double(end.y)-start.y,dz=double(end.z)-start.z;
 if(dx*dx+dy*dy+dz*dz<1e-12||dx*dx+dy*dy+dz*dz>256)return Result::Unavailable;
#if defined(__aarch64__)
 using Clip=NativeHit(*)(void*,const Vec3*,const Vec3*,bool,uint32_t,int,bool,bool,void*,const void*,bool);
 NativeHit native=reinterpret_cast<Clip>(base+CLIP)(reinterpret_cast<void*>(source),&start,&end,
  (projectileFlag&1)!=0,1U&~uint32_t(projectileFlag),200,true,false,
  reinterpret_cast<void*>(actor),reinterpret_cast<const void*>(base+PROJECTILE_FILTER),false);
 Address weak=0;std::memcpy(&weak,native.bytes+64,sizeof weak);WeakRelease release(weak,base+RELEASE_WEAK);
 return decode(native,start,end,hit);
#else
 (void)actor;(void)projectileFlag;return Result::Unavailable;
#endif
}
}
