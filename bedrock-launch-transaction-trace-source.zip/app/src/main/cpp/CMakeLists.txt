cmake_minimum_required(VERSION 3.22.1)
project(kulichbridge LANGUAGES CXX)
add_library(kulichbridge SHARED fast_exp.cpp)
target_compile_features(kulichbridge PRIVATE cxx_std_17)
target_compile_options(kulichbridge PRIVATE -Wall -Wextra -Werror -mbranch-protection=standard)

add_library(kulichtransactions SHARED transaction_trace.cpp)
target_compile_features(kulichtransactions PRIVATE cxx_std_17)
target_compile_options(kulichtransactions PRIVATE -Wall -Wextra -Werror -mbranch-protection=standard)
