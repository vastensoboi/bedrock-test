# Observed incoming movement packets in 0.75

The 0.74 report establishes successful local Timer input writes, but it does
not identify the network event associated with the reported position rollback.
This optional observer records typed client-side receive-handler calls. It
does not drop, rewrite, delay or suppress a packet, change movement, pause a
module or establish an anticheat bypass.

## Exact supported ARM64 routes

These offsets apply only to the supplied Minecraft 1.26.60.4 library whose
identity is already verified by the engine probe.

`CorrectPlayerMovePredictionPacket` has vptr `0x13b143e0`; its virtual getId at
`0xc7703a4` returns 161. Its RTTI-identified
`PacketHandlerDispatcherInstance<CorrectPlayerMovePredictionPacket, false>`
has vptr `0x13b36eb0`. Virtual slot 2 is `0xcc5516c`. That dispatcher loads the
handler from argument x2, dereferences the packet reference in argument x3,
and dispatches handler virtual +1632, slot 204. The eventual callback ABI is
`void(handler, NetworkIdentifier&, CorrectPlayerMovePredictionPacket&)` in
x0/x1/x2.

Both primary handler tables inherit this callback at `0xa2eaf70`:

- `ClientNetworkHandler`, vptr `0x1394afc0`, entry `0x1394b620`;
- `LegacyClientNetworkHandler`, vptr `0x1394b878`, entry `0x1394bed8`.

An exhaustive RELATIVE-relocation scan found these two primary slot-204
entries, with offset-to-top zero and matching RTTI. The small Legacy secondary
table at `0x1394c0e0` does not have this slot and is not patched.

`MovePlayerPacket` has vptr `0x13b95ce0`; getId at `0xdc16c24` returns 19. Its
RTTI-identified dispatcher has vptr `0x13b32330`, slot-2 callback `0xcc51458`.
It performs the same argument conversion and dispatches handler virtual +376,
slot 47. The Legacy primary-table callback at that slot is `0xa300578`.
The base handler's slot is a RET stub and is not patched.

## Bound client and own entity

The shared handler constructor at `0xa2f71bc` stores a config's ClientInstance
pointer at handler +88 (`0xa2f72c4..0xa2f72c8`). The derived constructor later
installs the Legacy primary vptr (`0xa2f7614..0xa2f7620`) without changing that
inherited field. The correction callback itself reads handler +88 and invokes
its virtual +248 at `0xa2eafc8..0xa2eafd4`. For the verified ClientInstance
table `0x1388fe70`, that getter is `0x9b7f610`: it resolves the weak entity at
client +576 and returns the current actor through the entity registry.

The observer requires the exact base or Legacy handler type, handler +88 equal
to the currently bound ClientInstance, the exact packet type and the existing
weak local-player proof. This validates registry, full entity generation,
ActorOwner ownership, LocalPlayer type, removed flag, shape/rotation bindings
and player-to-client back-reference. A second capture must retain the same
identity. Reads strip allocation tags; the original raw callback arguments
retain their tags and are forwarded unchanged exactly once.

Legacy MovePlayer traffic also includes remote actors. Before reading the
full local actor graph, read only the bound weak entity's RuntimeID component
and reject a packet with a different runtime ID. Native getter
`0xfd898b8..0xfd8997c` proves key `0xfc0dbbb5`, stride 8 and a numeric uint64
payload. The Legacy receive callback reads the packet's corresponding uint64
at +48. The observer revalidates this value during the second capture and
records the packet's raw byte at +80 without assigning an enum meaning.
The frequent remote-actor path therefore avoids shape/rotation reads and the
second full binding pass.

## Recorder and installation

Only three already-verified callback entries are replaced. Their original
forwarding targets are published before any replacement. Eleven exact code
profiles cover the callbacks, typed dispatchers, packet IDs, constructor field,
local getter and runtime-ID getter. Installation also requires the original
entry values and read-only, non-executable libminecraftpe.so mappings.

Page permissions are restored after publication. On failure, observation is
disabled and original entries are restored when all required pages can be
made writable. A remaining forwarding wrapper still retains its original
target. An optional observer installation failure does not make Timer
installation fail.

The network callback uses a nonblocking mutex attempt for the recorder;
contention increments `busy` rather than waiting for the journal. There are
no unbounded scans. The ring retains at most 16 events. Per-phase cumulative
counts and the last Timer-on and Timer-off events survive ring overflow, so a
later stream of off-phase updates cannot erase the on-phase summary. Events
carry full entity generation, own runtime ID for packet 19, requested
multiplier and effective Timer phase sampled at observation. Ages use the
current boot-time clock, including Android deep sleep, with a steady-clock
fallback if that clock is unavailable. Counts belong to the current bound client and are
reset when preparation changes that client; entity IDs distinguish respawns
within the same client binding.

## Interpretation and limits

`received` means a typed receive handler was called for the verified client.
For packet 19 it additionally means the runtime ID matched the current local
entity. Ordinary MovePlayer updates are not automatically an anticheat
correction. Packet 161 can select a prediction context such as a player or
controlled entity; that payload is deliberately not interpreted here.

The observer does not establish that the original callback applied a packet,
that a displayed rollback was caused by that particular event, or which
server-side validation rule was involved. It contains no server reason code,
position rewrite, packet blocking or acceptance guarantee. Zero matched events
must be interpreted alongside `ready`, `calls`, `skipped` and `busy`, rather
than as proof that the server sent no relevant traffic.

`MovementCorrectionTest` checks both packet types, real weak-entity/component
layout, stale generation/runtime-ID/packet rejection, cheap remote-ID
filtering, raw tagged forwarding exactly once despite observation failures,
propagation of an original exception, ring bounds, phase retention and ages.
Strict host and ARM64-conditional C++ syntax and exact profile-byte checks
pass. Device capture and the server's actual behavior remain unverified.
