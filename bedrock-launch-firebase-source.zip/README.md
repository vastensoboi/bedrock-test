# Bedrock Launch Test 0.8 — experimental hosted launch

This is a separate test app, applicationId dev.custom.bedrocklaunchtest.
It does not overwrite the installed Minecraft or Bedrock Diagnostic app.

The test prepares installed Minecraft's base/split APKs and ARM64 libraries,
then attempts native startup and a game Activity inside this app's :game process.
This is NOT injection into an already running Minecraft process. No gameplay
modules, packet modifications, Xposed hooks or libVHax.so are included.

Implemented startup attempt:

1. Extract game native libraries using the previously tested extraction component.
2. Create a separate DexClassLoader through AppComponentFactory for the game Activity.
3. Initialize declared game Application/provider classes (static initialization
   only; full foreign Application/provider lifecycle is NOT emulated).
4. Preload known game native dependencies and libminecraftpe.so from that loader.
5. Load the small libmc.so forwarding shim.
6. Attach game resources with ResourcesLoader/ResourcesProvider public APIs.
7. Instantiate a host Activity subclass whose real MainActivity superclass is
   supplied by the installed game's DEX at runtime, and call its onCreate.
8. Write stage markers and Java failures to an app-private journal. After native
   crashes the host can show available historical process-exit reasons.

This version uses public class-loader/component/resource APIs and does not
modify private pathList/nativeLibraryDirectories fields.

## Crucial limitations

The user's device logs confirm native library loading, resource resolution,
game onCreate returning and Activity resume. The process then exits with
SIGABRT (signal 6). Version 0.5's own-UID log identifies a CheckJNI method/receiver
mismatch in pgs::JniHelperImpl::InitializeImpl. A working title screen and
gameplay have NOT been confirmed.
The copied Application/provider static initialization does not reproduce all
Android startup behavior. Game callbacks, resources, identity, storage, auth,
provider registration, dynamic features or native dependencies can still fail.
There is no claim of verified Minecraft 1.26.60.4 / Android 17 compatibility.
Returning from onCreate does not prove successful gameplay or menu rendering.
This app does not disable licensing checks or change the installed game.

The game runs with the host app's UID, package identity and private storage;
it does not inherit the original app's grants, private files or login state.
Application class loading and library preloading occur during factory startup;
a slow or blocked native initializer may time out or crash the :game process.
The first useful device result is a visible game title screen or an error log.
Login and joining a server are not needed for this initial test.

## Native shim origin

app/src/main/jniLibs/arm64-v8a/libmc.so is the exact 4.64 KiB binary supplied by
this session's user, not a newly built independent shim. Its ELF/functions were
statically inspected before packaging. It forwards native entry points to the
real libminecraftpe.so via dlopen/dlsym and was not executed in the development
workspace. This binary is used only to test the observed startup bridge.
A readable independent reconstruction was produced separately in mc-forwarder.c.
This prototype does not claim authorship of the supplied binary.

The game-api-stub module is a compile-only class declaration and MUST NOT be
packaged in the APK. The cloud workflow checks that the stub is absent from DEX.

## Checks performed here

- Parsed syntax of all Java sources.
- Compiled and ran extraction-component tests: split extraction, unchanged bytes,
  read-only files, path filtering, duplicates, invalid ELF and cleanup.
- Checked manifest component paths, compile-only dependency and shim identity.

Android SDK remains unavailable locally. Earlier builds were compiled through
GitHub Actions and tested by the user. The new 0.8 Android changes have not yet
been compiled or tested on-device. A workflow supplies the Android build and
APK packaging checks.

## Device test after a successful APK build

1. Install Bedrock Launch Test alongside the existing diagnostic app and game.
2. Open it and tap «Тест запуска Minecraft».
3. If the game opens, report whether the title screen actually appears.
4. If it fails/closes, return, tap «Показать журнал запуска», then «Сохранить журнал».
5. If the test process is still running, «Остановить тестовый процесс игры» stops
   only this app's own :game process. It does not kill the installed game process.

## Building

JDK 17, Android SDK Platform 35, Gradle 8.7. SDK path via ANDROID_HOME,
ANDROID_SDK_ROOT or local.properties sdk.dir.

    gradle :app:assembleDebug

Minimum Android version is 11 / API 30. Target SDK remains 34; compile SDK 35
supplies the public APIs used. Testing on Android 17 is still required.

Public Android API references:
- https://developer.android.com/reference/android/app/AppComponentFactory
- https://developer.android.com/reference/android/content/res/loader/ResourcesProvider

## Device observations and resource fix (0.4)

The user's S24 Ultra / Android 17 / Minecraft 1.26.60.4 log confirms successful
loading of the eight game native libraries and the mc shim. The initial hosted
Activity failed because the host framework theme was not AppCompat-compatible.
The original game Activity theme is now applied before super.onCreate.
The next device log confirms the theme was resolved as AppTheme.SplashScreen;
startup then failed with Resource ID #0x0 in initAccessibilityDisclosurePopup.

0.4 adds a Resources subclass that retries unresolved game/host-name lookups
against com.mojang.minecraftpe. It does not override Android package/UID identity,
replace successful lookups, redirect framework/other-package names, or skip the
accessibility dialog. Remapped and missing lookups are recorded (up to 32 keys).
The next device log confirms all three accessibility popup resource names now
resolve to game resource IDs, onCreate returns and the Activity resumes. The
process then exits with reason=2, status=6. This establishes progress past the
earlier Java resource exception, not successful game startup.

## Native crash diagnostics (0.5)

The startup behavior is unchanged from 0.4. Version 0.5 adds evidence collection
for the observed SIGABRT rather than guessing a native fix:

- Before launch, start logcat filtered to this application's own UID. Keep at
  most 2 MiB in app-private storage, stop after 60 seconds, and include the last
  128 KiB in the saved report. No READ_LOGS permission is requested. Android may
  deny access or omit system/debuggerd records; the log is not guaranteed to
  contain the native crash.
- For matching historical game-process exits after the last launch, request
  ApplicationExitInfo.getTraceInputStream(). Android may provide no trace.
- When available, parse selected Android tombstone protobuf fields (8 MiB limit)
  to show the abort message, signal, cause and up to 40 crashing-thread frames.
  ANR traces are not passed to this native protobuf parser.
- Display version 0.5 in the main screen and export bedrock-launch-0.5.txt.

The native report parser passed a pure-Java test with an abort message, Unicode,
signal, thread backtrace, unknown fields and truncated/invalid protobuf input.
Java source syntax parsing passed; this does not substitute for Android builds.

After installing the 0.5 APK, perform one launch attempt, wait for the failure,
return and use «Сохранить журнал». Root and a separate Minecraft APK upload
are not required for this diagnostic step.

References:
- https://developer.android.com/reference/android/app/ApplicationExitInfo#getTraceInputStream()
- https://android.googlesource.com/platform/system/core/+/refs/heads/master/debuggerd/proto/tombstone.proto

## Context loader JNI compatibility (0.6)

The provided bedrock-launch-0.5.txt contains the exact fatal message:

    JNI DETECTED ERROR IN APPLICATION: can't call java.lang.ClassLoader
    dev.custom.bedrockgui.HostedGameActivity.getClassLoader()
    on instance of android.app.Application

The aborting native stack includes pgs::JniHelperImpl::InitializeImpl,
pgs::JniHelper::Initialize and Pgs_initialize. Native code attempts to reuse a
method ID resolved on the game Activity with an Application receiver. An
Activity-declared override is invalid for that receiver.

0.6 removes HostedGameActivity's getClassLoader/getResources/getAssets overrides.
The existing attached base Context still supplies game resources and its loader.
The host Application now returns the shared game loader once prepared, so SDK
lookups through Application can resolve the same classes. The loader reference
is volatile for cross-thread visibility. No JNI check is disabled.

Before game onCreate, a guard records getClassLoader's declaring class, verifies
that the Application is an instance of that class, and verifies both contexts
return the prepared game loader. A mismatch stops with a Java journal entry
instead of deliberately proceeding into the already observed native abort.

The new Android code requires a fresh GitHub build and device test. This change
addresses the observed mismatch; further startup failures remain possible.

## Explicit Play Games initialization (0.7)

The provided bedrock-launch-0.6.txt confirms the loader compatibility guard:

    owner=android.content.ContextWrapper applicationCompatible=true
    activityLoader=true applicationLoader=true

Game onCreate returns and the Activity resumes. The next native abort has a
different cause: a pending IllegalStateException from PlayGames.getAchievementsClient
stating that PlayGamesSdk has not been initialized. Loading the provider class
in NativeStartup does not invoke PlayGamesInitProvider.onCreate and therefore
does not initialize the SDK.

0.7 calls the public static PlayGamesSdk.initialize(android.content.Context)
method reflectively from the game class loader, on the main thread before
super.onCreate. It receives the attached host Application. A successful return
is logged and the call is not repeated on Activity recreation in the same
process. Reflection/initialization failures are included in the existing Java
failure journal before native game startup, rather than swallowed.

This is targeted SDK initialization, not full emulation of foreign providers or
the original Application lifecycle. No second Play Games SDK is bundled, no
account sign-in is explicitly requested, and no game application ID, package
identity or signing certificate is spoofed. Google authentication and game
services under the host package are not verified. An SDK initialization return
does not establish that the game menu or login works.

The API signature and provider's normal initialization role were checked against
Google's reference:
https://developers.google.com/android/reference/com/google/android/gms/games/PlayGamesSdk

Java source syntax checks pass. The new Android build and device test remain
necessary; the runtime trace must establish whether this resolves the observed
SDK initialization exception and what the next startup stage does.

## Firebase initialization and Messaging components (0.8)

The user's bedrock-launch-0.7.txt confirms PlayGamesSdk.initialize returns,
game onCreate returns and the Activity resumes. The subsequent abort reports
a pending IllegalStateException: default FirebaseApp is not initialized in
dev.custom.bedrocklaunchtest:game. Its Java stack goes through
FirebaseMessaging.getInstance and NotificationListenerService.retrieveDeviceToken.

0.8 calls FirebaseApp.initializeApp(Context) from the installed game's SDK via
reflection before game onCreate. It passes the Activity's context with attached
game resources, so FirebaseOptions can read the game's actual string resources.
Using only the host Application for this call would omit those resource values.
No configuration values are invented or printed in the stage journal.

The host manifest declares Firebase's ComponentDiscoveryService metadata for
FirebaseMessagingRegistrar, FirebaseInstallationsRegistrar and TransportRegistrar,
matching the standard Firebase component discovery format and the supplied VHax
manifest. This service declaration is used for metadata lookup; the launcher
does not start it. The SDK classes still come from the installed game, not a
second bundled Firebase dependency.

The preflight checks for a non-null default FirebaseApp and calls the same
FirebaseMessaging.getInstance entry point that failed in 0.7. Each stage is
logged. A reflective Java error is preserved by the existing Activity journal.
The helper is skipped after successful initialization on Activity recreation.

This prepares the in-process SDK; it does not establish successful notification
token registration or implement complete incoming push handling under the host
package. The original game still controls its notification-token request.

References checked:
- https://github.com/firebase/firebase-android-sdk/blob/master/firebase-common/src/main/java/com/google/firebase/FirebaseApp.java
- https://github.com/firebase/firebase-android-sdk/blob/master/firebase-components/src/main/java/com/google/firebase/components/ComponentDiscovery.java
- https://firebase.google.com/docs/reference/android/com/google/firebase/FirebaseOptions

Java source syntax and Firebase manifest entries were checked locally.
Android compilation, SDK initialization and game rendering still require the
GitHub build and the user's device test. No working game menu is claimed.

The new root-level Build latest launch test workflow chooses the highest
versionCode among root bedrock-launch ZIPs for this applicationId. It accepts
download suffixes such as (1), ignores older app versions and rejects different
archives with the same highest versionCode. Future source updates with a higher
versionCode can reuse that workflow without adding another workflow file.
