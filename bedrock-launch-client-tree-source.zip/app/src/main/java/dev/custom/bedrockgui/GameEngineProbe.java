package dev.custom.bedrockgui;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Uses only this hosted process's maps/mem and validates the exact supplied game file first. */
public final class GameEngineProbe {
    private static final String EXPECTED_SHA="4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4";
    private static final AtomicBoolean running=new AtomicBoolean();
    private static String verifiedFile;
    private GameEngineProbe(){}
    public static boolean begin(){return running.compareAndSet(false,true);}
    public static void end(){running.set(false);}
    public static String run() {
        GameRuntime.log("Engine probe: begin; read-only, no game calls");
        try {
            if(GameRuntime.nativeDirectory==null)throw new IOException("Game library directory is unavailable");
            File library=new File(GameRuntime.nativeDirectory,"libminecraftpe.so");
            if(library.length()!=342231392L)throw new IOException("Unsupported Minecraft library size");
            if(!library.getAbsolutePath().equals(verifiedFile)){
                MessageDigest sha=MessageDigest.getInstance("SHA-256");
                try(InputStream input=new FileInputStream(library)){
                    byte[] buffer=new byte[128*1024];int count;
                    while((count=input.read(buffer))!=-1)sha.update(buffer,0,count);
                }
                StringBuilder value=new StringBuilder();for(byte b:sha.digest())value.append(String.format(Locale.ROOT,"%02x",b&255));
                if(!EXPECTED_SHA.equals(value.toString()))throw new IOException("Unsupported Minecraft library SHA-256");
                verifiedFile=library.getAbsolutePath();
            }
            GameRuntime.log("Engine probe: exact library SHA-256 verified");
            List<EngineMemoryProbe.Region> regions=new ArrayList<>();
            long base=-1;File canonical=library.getCanonicalFile();
            for(String line:Files.readAllLines(Paths.get("/proc/self/maps"))){
                EngineMemoryProbe.Region region=EngineMemoryProbe.Region.parse(line);regions.add(region);
                if(region.offset==0&&region.path.endsWith("/libminecraftpe.so")&&
                        new File(region.path).getCanonicalFile().equals(canonical))base=region.start;
            }
            if(base<0)throw new IOException("Loaded game library mapping not found");
            GameRuntime.log("Engine probe: load base 0x"+Long.toHexString(base));
            try(RandomAccessFile memory=new RandomAccessFile("/proc/self/mem","r")){
                EngineMemoryProbe.Reader reader=(address,destination,count)->{
                    memory.seek(address);memory.readFully(destination,0,count);return true;
                };
                EngineMemoryProbe probe=new EngineMemoryProbe(regions,reader,base,
                        line->GameRuntime.log("Engine probe: "+line));
                EngineMemoryProbe.Result result=probe.scan(base+0x1400a010L,base+0x14308e60L);
                if(result.reads==0||result.reads==result.readFailures)
                    throw new IOException("Reading this process's game memory was unavailable");
                return result.summary()+"\nРезультат записан в журнал. Fast Exp пока не включён.";
            }
        }catch(Exception error){
            GameRuntime.log("Engine probe failed: "+error);
            return "Проверка недоступна: "+error.getMessage()+". Результат записан в журнал.";
        }
    }
}
