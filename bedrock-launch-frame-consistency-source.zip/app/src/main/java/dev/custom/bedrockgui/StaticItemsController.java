package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

/** Prepares the renderer when a world exists; opening menus retains the toggle. */
public final class StaticItemsController {
    private final Activity activity;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean requested,preparing,disposed;
    private int generation;
    private String message="Выключен";
    public StaticItemsController(Activity activity){this.activity=activity;}
    public boolean isEnabled(){return requested;}
    public String status(){return !requested||!StaticItemsBridge.isReady()?message:StaticItemsBridge.describe();}
    public String displayStatus(){return status().split("\n",2)[0];}
    public void setEnabled(boolean value){
        if(disposed)return;
        generation++;requested=value;handler.removeCallbacksAndMessages(null);
        if(!value){StaticItemsBridge.setEnabled(false);message="Выключен";return;}
        if(StaticItemsBridge.isReady()){
            try{StaticItemsBridge.setEnabled(true);}
            catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить предметы. Причина в журнале";throw error;}
            return;
        }
        message="Подключаю предметы. Нужен загруженный мир";prepare(generation);
    }
    private void prepare(int epoch){
        if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
        if(preparing||!GameEngineProbe.begin()){handler.postDelayed(()->prepare(epoch),400);return;}
        preparing=true;
        Thread worker=new Thread(()->{
            try{GameEngineProbe.run();}
            catch(RuntimeException|LinkageError error){GameRuntime.log("Static items preparation failed: "+error);}
            finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{
                preparing=false;
                if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
                if(GameEngineProbe.playerFound()&&StaticItemsBridge.isReady()){
                    try{StaticItemsBridge.setEnabled(true);}
                    catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить предметы. Причина в журнале";GameRuntime.log("Static items enable failed: "+error);}
                }else if(GameEngineProbe.playerFound()){
                    requested=false;message="Предметы не подключились. Причина в журнале";
                }else{
                    message="Войди в мир: предметы подключатся автоматически";handler.postDelayed(()->prepare(epoch),8000);
                }
            });
        },"static-items-prepare");worker.setDaemon(true);worker.start();
    }
    public void dispose(){setEnabled(false);disposed=true;handler.removeCallbacksAndMessages(null);}
}
