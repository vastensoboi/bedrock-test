# Aimbot 0.61 — stable torso tracking and fixed/ranged CPS

Add one two-thumb CPS control (1–40), matching the supplied range-control
reference. Left thumb sets minimum, right sets maximum. Equal endpoints are a
fixed requested rate, shown as e.g. “20 · фикс.”. Coincident thumbs separate by
drag direction, including endpoints. Store aim.cps.min/max; migrate legacy
aim.cps as a fixed rate. Colours follow the active kulich theme. Keyboard and
accessibility actions can adjust either endpoint. Radius remains 1–5 blocks.

Native configure now receives radius/min/max. Fixed mode uses fractional
periods; range mode samples an integer rate between endpoints for each next
interval. At most two attempts run per local-player update, excessive backlog
is discarded, and displayed actual CPS counts actual attack dispatches in the
last second. A selected fixed rate is a requested attempt frequency while a
valid target is in the camera ray, not a guarantee of server hits or independent
sword animations. Above 20 CPS some attempts share a 20 Hz update.

Reduce aim-induced camera shake by retaining the validated current target
until it dies, leaves range, or fails identity checks. Remove periodic nearest
switching between nearby players. Keep sharp initial acquisition, but stop
recentering to the exact chest centre while the view ray remains inside a
small inner torso region. Wider retained bounds provide hysteresis. At
horizontal centre gaps under .35 blocks preserve yaw; resume normal tracking
past .45 blocks to avoid atan2 flips as bodies cross. An exactly coincident
eye/chest keeps the validated view rather than dropping the target. Hold state
resets on identity changes, enable/install, expiry, and loss/reacquisition.
Attack still requires the fresh full-box ray and all existing native guards.
No guessed camera-origin field or animation-state writes are introduced.
Journal phase=camera-input-v9 adds cpsMin/cpsMax, aimHold and contact. The HUD
shows actual CPS alongside the selected fixed/range setting; its eight-field
snapshot accepts earlier three/seven-field models as well.

Validation: fourteen gameplay suites, including fixed rates 1–40 at 20 Hz,
interval bounds and normalization, pauses/backlog, torso/eye jitter simulation,
sharp acquisition, moving target and entity reset, contact hysteresis, exact
overlap and HUD range parsing. Full Java typecheck against Android35/Rhino,
C++ syntax (-Wall -Wextra -Werror) and ASan/UBSan new model tests pass. These
checks do not establish on-phone rendering, touch, server behaviour or absence
of all camera shake. Normal movement/damage animation is not altered.

Upload bedrock-launch-aimbot-stable-cps-source.zip to the repository root;
run Build latest launch test and install BedrockLaunchTest-0.61. In Target ->
Aimbot, move both CPS circles to the same value for fixed frequency, or apart
for a range such as 6–17. Preserve Auto Buy and Fast Exp behaviour.

## Earlier releases

# Aimbot 0.60 — simplified sharp aim, reference-style HUD, swing and CPS 1–30

Match the 1.39-second supplied reference visually: compact dark rounded card
near screen centre-right, neutral pixel head icon, single-line rank/name, HP
number with red heart and green health bar. The avatar is a neutral icon, not
an extracted player skin. Add a small live attack-state / actual-configured CPS
line to explain pauses. No unconfirmed kill notification is generated: the user's
clarification concerned intermittent CPS and missing sword animation.

Remove the old mode/priority/head-body/speed/smoothing/auto-attack controls from
Aimbot. Keep enable plus shared distance 1–5 blocks and CPS 1–30. It sharply
aims at the nearest player's chest and attacks while enabled. Old preference
values are clamped to the new ranges. The distance is the client attempt limit;
server reach and damage rules still apply. At rates above the ~20 Hz callback,
up to two attempts share a tick. Do not claim 30 independent visual swings or
server hits per second.

Fix two concrete client causes of intermittent attempts: aim and attack now
run together AFTER original player movement, using the same fresh positions;
attack ray uses effective DirectLook including pending yaw instead of the
previous rendered quaternion. Close overlapping boxes are supported rather
than rejected just because ray entry is zero. Target identity, allocation tags,
GameMode slot 16, lease and code profiles remain checked; no range bypass or
packet spoofing. The clock retains phase while waiting for a target.

Call the native LocalPlayer swing API before each attack attempt, via pinned
slot 110 (+880), function 0xaf60d78, args source=3 and main hand=0. Source 3/main
hand 0 mirrors the stock contact path at 0x1009c854..0x1009c868. The base swing
implementation 0xfa887f0 updates animation time +1032 and hand/swing state
+1076/+1077 while keeping its own minimum-cycle guard. Do not repeatedly reset
animation fields. Journal logs attackState, actualCps, swings and corrected
camera-input-v8 phase alongside attack/accepted counts.

Target HUD updates for the currently tracked target, including before the first
accepted hit, so rejection/out-of-range/view-miss conditions remain visible.
States distinguish off, lost target, range, view miss, pacing, native rejection
and unavailable data. HP max is read from AttributeInstance +120 (getter
0x101a9ac8), current remains +124. Hide the bar when max is unavailable/invalid
rather than inventing a maximum. Native ASCII/hex snapshot extends to seven
fields; legacy three-field parsing stays supported. Metadata name cache is
keyed by actor+entity and refreshed every 200 ms; lost-target card expires after
five seconds, disabling hides it immediately. Rank is extracted only from an
explicit [Rank] Name server prefix.

Validation: twelve gameplay suites, including every rate 1–30, post-update
ordering/tag preservation, stale-render vs effective-view ray regression,
reach 1/3/5 and overlapping target, swing code profile, unknown/extended HUD
snapshot and health limits. Android API 35/Rhino Java, C++ syntax and
address/undefined sanitizers pass (leak checks disabled under debugger). Full
APK linking and on-phone appearance/animation/attack behaviour remain unverified.

Upload bedrock-launch-aimbot-simple-source.zip to repository root and run Build
latest launch test. Install BedrockLaunchTest-0.60; enable Target -> Aimbot,
choose distance and CPS. Check the card's live state if attacks stop and save
the 0.60 journal if runtime problems remain. Auto Buy and Fast Exp settings and
actions are retained; their existing update stage precedes aim/attack.

## Earlier releases (superseded controls and callback phase)

# Aimbot 0.59 — up to 40 CPS and first Target HUD

Expand CPS control and native clamping to 10–40. On the existing ~20 Hz game
callback, 21–40 CPS means up to two attempts per tick; this does not provide
25 ms timing or guarantee corresponding server damage. Fractional deadlines
preserve average rate, cap each callback at two, drop excessive backlog and
revalidate target identity/GameMode before each call. Keep the corrected slot
16 attack route from 0.58. Existing CPS preferences are retained, default 15.

Add a passive rectangular TargetHud card at bottom-right. Show it after a native
accepted attack, refresh on subsequent accepted attacks, expire five seconds
after the last event and hide immediately when Aimbot is disabled. The snapshot
contains server-supplied name tag and client-visible current HP. Only an explicit
[Rank] Nick prefix is separated into privilege and name. Missing rank/name/HP
are shown as unavailable; no server privileges or health are invented. The
snapshot is a last-hit event, not proof of server damage. Manual attacks and
KillAura are not wired into this first version. TargetHud.show(TargetHudData)
is separate from Aimbot for later reuse by KillAura or other modules.

Native string evidence: Actor +320 exposes synchronized metadata; name-tag key
4 is read at 0xfda03c0..0xfda03c8 via typed string getter 0xfa4de14. That getter
reads metadata owner -> vector, item[4], validates virtual type getter at +24
returns DataItem type 4, and returns item+16 as libc++ string. Implement bounded
read-only lookup with vector limits, exact mov w0,#4;ret validation and 384-byte
cap. JNI carries UTF-8 as ASCII hex to avoid NewStringUTF limitations. Java
removes Minecraft formatting, parses explicit rank prefix and validates age,
health and malformed data. No new engine writes or native game calls.

Validation: twelve gameplay suites, including every CPS rate 10–40 at 20 Hz,
two-per-tick bounds/backlog rejection, typed name metadata, target-HUD UTF-8,
colors, rank/unknown values/expiry; Android API 35/Rhino Java type checking,
native C++ syntax and address/undefined sanitizers (leak check disabled under
debugger). Full APK linking, panel appearance and native data on the phone
remain unverified. Build BedrockLaunchTest-0.59 using Build latest launch test
with bedrock-launch-aimbot-target-hud-source.zip at repository root.

## Earlier releases

# Aimbot 0.58 — correct auto-attack dispatch

The supplied 0.57 phone journal contains autoAttack=1, cps=20, targets within
1–3 blocks, attacks up to 1277 and accepted=0. Attempts reached the engine;
the clock, target binding and ray checks were passing. The previous release
incorrectly identified GameMode slot 15 as attack. It is entity interaction.

Bind virtual slot 16 (+128) instead: GameMode 0x1009cb98, SurvivalMode
0x100a11c8. Preserve native mode/target allocation tags and use the three-pointer
bool(GameMode*,Actor*,const float[3]*) ABI. The base wrapper copies x2 into x3,
sets w2=1 and enters shared implementation 0x1009cba4; the Survival wrapper
performs its native guard before the same shared implementation. The lambda
at 0x100a36f8 writes action 1 at transaction+88 (0x100a3760..0x100a3768).
The old slot 15 callback at 0x100a3190 explicitly writes action 0 at +88
(0x100a3208): interaction, explaining rejection by ordinary players.
Both attack code prefixes are re-pinned to the supplied exact-build library.

The new attackBinding helper verifies ownership, GameMode type and the actual
slot 16 entry. Regression tests reject the old interaction function, wrong
owner/type and corrupted virtual entry; dispatch tests require three arguments,
validate the impact pointer and verify allocation tags survive. Existing CPS
10–20, range/ray checks, Head/Body, priorities, Sharp/Smooth and stabilization
are retained. No changes to account login, Auto Buy or Fast Exp behaviour.

Validation: all eleven gameplay suites, native C++ syntax with warnings as
errors, Android API 35/Rhino Java checks, exact-library code prefixes and
address/undefined sanitizers (leak checking disabled under debugger). Full ARM64
linking and auto-attack behaviour on the phone remain unverified.

Upload bedrock-launch-aimbot-attack-fix-source.zip and run Build latest launch
test. Install BedrockLaunchTest-0.58, enable Aimbot and Auto attack, approach a
player within 1–2 blocks and test. Journal phase=camera-input-v6 distinguishes
the corrected dispatch. If hits still fail, compare attacks/accepted in 0.58;
a native true return is still not a server damage acknowledgement.

## Earlier releases (0.57 dispatch identification is superseded above)

# Aimbot 0.57 — 10–20 CPS and independent-axis stabilization

Aimbot now includes Auto attack (default on, separately switchable) and CPS
10–20, default 15, persisted as aim.attack and aim.cps. With Aimbot enabled,
attack only the selected, revalidated remote player when the actual camera
forward ray intersects that player's bounding box within three blocks. Native
attack dispatch is after original LocalPlayer update and the existing Fast Exp
stage, using freshly read GameMode and preserved native allocation tags.

Fractional monotonic deadlines achieve the requested average on a 20 Hz source
without rounding 15 CPS down to 10. Never issue more than one attack per callback
or catch-up bursts after lag. Off, expired lease, missing target, bad binding or
ray miss suppress attacks. The attack range check uses a copy of target lock,
so it never clears the aiming target when standing outside attack range.
CPS counts attempts, and accepted counts native return values, not server damage.
A bounding-box ray is not a terrain visibility test; this release adds no wall
raycast or server-specific logic. Runtime behaviour needs phone verification.

Reduce small corrective motion in BOTH Sharp and Smooth by independently
stabilizing pitch and yaw (0.12 degree entry / 0.24 degree exit). A moving yaw
no longer forces tiny pitch corrections every update. Reset stabilization for
new target identity or a Head/Body change. Existing global deadzone, target
hysteresis and smooth ramp remain. Complete removal of visible shake is not
verified; the previous uploaded MP4 contained only audio.

Exact-build evidence: GameMode slot 15 (+120) is 0x1009c5e4;
SurvivalMode slot 15 is 0x100a11f0, a guarded tail call to that base function.
Native client input 0x9b6e60c..0x9b6e628 loads slot +120 with x0=GameMode,
x1=target Actor, x2=hit position (HitResult+44), w3=0. Dispatch uses the same
bool(GameMode*,Actor*,const float[3]*,bool) ABI. Both code prefixes are pinned
with the existing exact-build SHA gate. Slot 14 is an eight-argument block
interaction routine and is deliberately not used. Header aim_combat.h contains
pure clock, ray and axis helpers. New native counters are logged with
phase=camera-input-v5, autoAttack, cps, attacks and accepted.

Validation: all eleven gameplay suites, including all integer rates 10–20 over
10 seconds on 20 Hz sampling, no duplicate/catch-up dispatch, independent-axis
noise rejection, target changes, ray hit/miss/backward/range/NaN rejection;
Android API 35/Rhino Java checking, C++ syntax with warnings as errors, and aim
address/undefined sanitizers (leak checks disabled under debugger). Full ARM64
APK linking and device verification remain outstanding.

Upload bedrock-launch-aimbot-cps-source.zip to repository root, run Build latest
launch test and install BedrockLaunchTest-0.57. In Target -> Aimbot choose CPS,
Sharp/Smooth, Head/Body and priority. Auto attack can be disabled while keeping
aiming enabled. Check rates and misses in the 0.57 journal if hits do not occur.

## Earlier releases

# Aimbot 0.56 — selectable sharp and smooth modes

Target -> Aimbot -> Aim mode offers Smooth / Sharp (Режим наведения:
Плавно / Резко), persisted under aim.sharp. Smooth stays the default and keeps
its speed, easing, start ramp and final deadzone. Sharp bypasses speed/easing/
ramp and sends the full shortest-angle correction at the next eligible game
update. It respects camera pitch limits, selection radius, Head/Body, priority,
identity revalidation, lifetime and lease. It does not attack automatically.

Sharp uses camera input state including pending yaw, so subsequent callbacks
cannot replay a turn that has not yet been consumed. Allow pending yaw up to
2*pi during wrap crossings; the camera system normalizes it when consumed.
Changing modes resets the clock/ramp/deadzone but retains a valid target.
Speed and smoothness controls are clearly described as Smooth-only settings.

The submitted MP4 contains a single AAC audio stream, 10.303 seconds, with no
video stream. No visual diagnosis of residual jitter was possible. Existing
anti-jitter measures remain; this release does not claim to eliminate all
screen shake. Full APK linking and on-phone behaviour remain unverified.

Validation: all eleven gameplay suites, including one-update sharp convergence,
positive/negative pitch, yaw wrapping, pending-input replay rejection, pitch
limits and return to Smooth. Native C++ syntax and Android API 35/Rhino Java
checks pass. Upload bedrock-launch-aimbot-modes-source.zip to repository root,
run Build latest launch test and install BedrockLaunchTest-0.56. Select Резко
in the module to test instant turning. Test Голова/Тело, toggle modes and disable.

## Earlier releases

# Aimbot 0.55 — faster turns, reduced jitter and target priorities

Target -> Aimbot now offers Nearest and Lowest HP. Rescan candidates every
300 ms. Keep the current target unless a candidate is about 8% closer (squared
distance threshold .85), or has more than 0.5 fewer HP. Rank equal HP by distance.
Unknown health is never zero: prefer known HP, otherwise fall back to nearest
and display the fallback. Exclude zero-health players when the attribute is
available. Health is client-visible data; servers may omit updates or send the
same/default health for remote players.

Tune existing installs once to 240 degrees/second and 80 ms response; subsequent
user changes persist. Faster coarse acquisition uses adaptive easing, with a
180 ms smooth start ramp for each new target. Final aim uses a hysteresis band:
stop within .12 degrees, resume outside .24 degrees. Keep native input feedback,
pending-yaw accounting, exact camera binding and Head/Body points. This reduces
small corrective oscillations and repeated target switching; phone behaviour
and perceived smoothness still need testing. No new frame hook is introduced.

Health reader evidence in the exact supplied library: AttributesComponent key
0xfd3b0613, payload stride 88 from 0xfdabaa4; parallel sorted uint32 ID vector
+0/+8 and AttributeInstance vector +24/+32, stride 136 from 0x10177014.
Health attribute global 0x141d8f48 is initialized with minecraft:health at
0x1018e97c..0x1018e9a0; its ID getter at 0x101a8bf0 reads +4. Thus the runtime
ID is read from base+0x141d8f4c. Health lookup and positive-value test appear
at 0x101be38c..0x101be3a8; current-value getter 0x101a9ad0 reads float +124.
Use bounded read-only lookups, entity sparse generations, finite/range checks,
matching vector lengths and unchanged header re-read. No new native calls.

Validation: all eleven gameplay suites, including nearest vs HP selection,
unknown/NaN/dead health, hysteresis and acquisition ramp; native C++ syntax,
Android 35/Rhino Java checks and address/undefined sanitizers (leak checking
disabled under debugger). Full APK linking and on-phone behaviour are unverified.

Upload bedrock-launch-aimbot-priority-source.zip to the repository root and run
Build latest launch test. Install BedrockLaunchTest-0.55. Test priorities near
two players with different distance/health; check Head and Body and adjust
Speed/Smoothness as desired. Journal phase=camera-input-v3 includes priority,
hp, current view and goal angles. Fast Exp and Auto Buy remain unchanged.

## Earlier releases

# Aimbot · 0.54: точка наведения и плавность

В видео 0.53 камера уходит в небо вместо удержания головы. В преобразовании
вертикального ввода был неверный знак; расчёт ошибки ещё использовал углы
Actor, отстающие от состояния камеры. Исправлены обе причины.

Теперь ошибка считается по DirectLook: мировой pitch = минус pitch камеры,
мировой yaw = 180° минус её yaw с учётом ожидающего поворота. Вертикальный ввод
имеет обратный знак относительно требуемого мирового pitch. Повторный тик до
обработки ввода не добавляет уже ожидающий поворот ещё раз.

Точка «Голова» — центр по X/Z и 90% высоты bounding box; «Тело» — центр по X/Z
и 60% высоты (грудь). Положение цели читается заново при обновлении; одна цель
удерживается по прежним правилам. Автоматических ударов нет.

Добавлена «Плавность»: 40–200 мс с шагом 20, по умолчанию 100 мс. Больше значение
— мягче доводка, но больше отставание от быстро движущейся цели. Экспоненциальная
доводка зависит от прошедшего времени, сохраняет общий предел скорости поворота
60–360°/с и прекращает коррекции менее 0.04° у неподвижной точки. Настройка
сохраняется как aim.smooth_ms. Нового кадрового хука нет: используется прежний
игровой callback и система камеры Minecraft.

Собери BedrockLaunchTest-0.54 через Build latest launch test. В игре открой
kulich → Таргет → Aimbot. Проверь «Голова» и «Тело» рядом с игроком на одном
уровне, затем выше/ниже себя; измени плавность и выключи модуль для проверки
возврата ручного управления. Плавность 100 мс уже установлена по умолчанию.
Результат на телефоне ещё не проверен.

В журнале версия различается по phase=camera-input-v2. Добавлены smoothMs,
viewPitch/viewYaw (состояние ввода камеры с ожидающим yaw) и goalPitch/goalYaw
(углы к выбранной точке). cameraChanges отдельно считает изменения quaternion.
Эти данные не показывают причины серверных флагов.

## Evidence correcting the previous model

In the supplied exact-build library, CameraDirectLookSystem at 0x11e6e530
builds quaternion (sin(p/2)*cos(y/2), cos(p/2)*sin(y/2),
-sin(p/2)*sin(y/2), cos(p/2)*cos(y/2)). The first trig calls at 0x1360e640
resolve to cosf via GOT 0x13fc9e58; calls at 0x13686950 resolve to sinf via
GOT 0x14005fe0. The 0.53 test model had misidentified this convention.

Camera forward helper 0x11e99170 rotates the constant (0,0,-1) at 0x140426d8.
UpdatePlayerFromCamera at 0x8a42760 calls that path and Vec3-to-angles
0x13521d9c, whose pitch is -atan2(forward.y, horizontal length). Together
these establish world pitch=-DirectLook.pitch and yaw=pi-DirectLook.yaw.
The native input callback 0x11e5dcb4 still increments native pitch by input.x
and subtracts input.y from pending yaw. No native profile/ABI is changed.

Validation: eleven gameplay suites; the new regression oracle builds native
quaternions and projects the forward vector rather than assuming Actor pitch
has the input sign. Tests cover up/down sign, head/torso convergence at multiple
heights, yaw wrap, delayed camera consumption, smoothing, stationary deadband,
limits, and 20/40/60 Hz model sampling. Android 35/Rhino Java typechecks, native
C++ syntax and address/undefined sanitizers pass (leak check disabled under
debugger). These checks do not replace a phone test or full Android APK build.

## Earlier implementation (superseded)

# Aimbot · 0.53: ввод активной камеры

Проверка на телефоне показала: в 0.51/0.52 изменение углов Actor не поворачивает
экран. Счётчик `applied` подтверждал вызовы, а не видимое наведение.

В 0.53 модуль больше не вызывает Actor::setRot/setYHeadRot. Он получает активную
камеру клиента и передаёт ограниченный поворот обработчику обзора Minecraft.
Игра сама обновляет камеру и направление игрока. Голова/тело, радиус, удержание
цели и настройка скорости 60–360°/с сохранены.

Собери BedrockLaunchTest-0.53 через Build latest launch test, открой
kulich → Таргет → Aimbot и проверь рядом с другим игроком в выбранном радиусе.
Проверь сначала «Голова», затем «Тело»; после выключения управление должно
оставаться ручным. На телефоне новый путь ещё не проверен.

Если экран неподвижен, сохрани журнал 0.53. `phase=camera-input` отличает новую
версию; `camera` показывает ID привязанной камеры; `applied` считает принятые
изменения ввода; `cameraChanges` считает изменения ориентации CameraComponent
между обновлениями. Они не заменяют наблюдение за экраном. `reason=7` означает,
что активная камера/её ввод не прошли проверку, `reason=8` — обработчик не
подтвердил ожидаемые значения ввода. Причины флагов Nevertime журнал клиента
не устанавливает.

## Camera path evidence for the supplied ARM64 library

The existing exact SHA-256 gate remains in place. Native code prefixes are
pinned alongside the older Actor profiles.

- ClientInstance virtual 165 points to 0x9b8bbf8. Client +424 owns the registry
  interface; its +8 lifetime pointer is checked alive before native dispatch.
  The original tagged client pointer comes from LocalPlayer +3240.
- 0x9c706c0 returns optional<StrictEntityContext> for the active camera using
  the native AArch64 x8 aggregate-result ABI. Layout: registry +0, registry+40
  at +8, entity ID +16, present byte +24; total 32 bytes. Context construction
  is visible at 0x134686b8; optional construction at 0x13469160.
- Require matching entity generation, ActiveCameraComponent (0x113040a1) and
  CurrentInputCameraComponent (0xf6c60b46) in the returned camera registry.
  CameraComponent (0x4f6047c7) stride 280; CameraDirectLookComponent
  (0xceb578f1) stride 20. These are FNV-1a of MinecraftCamera::qualified names.
- CameraDirectLook has yaw radians +0, pitch radians +4, pending yaw delta +8,
  minimum pitch +12 and maximum pitch +16. Its system at 0x11e6e530 consumes
  pending yaw, builds a unit quaternion at CameraComponent +40, then clears
  the pending yaw. Payload strides and offsets appear at 0x11e6e6e8..0x11e6e7b4.
- The input callback 0x11e5dcb4 takes context, camera, direct-look and a pointer
  to a two-float degree delta. It adds delta.x * pi/180 to pitch, subtracts
  delta.y * pi/180 from pending yaw, then normalizes/clamps pitch. The registry
  dispatcher at 0x11e5dd18 passes this callback and delta into 0x11e6df64.
- Native input dispatch runs on the existing game-update callback. Both native
  payload arguments retain the allocation tags from their storage pages.
  All read-only lookups still use untagged addresses. Revalidate components,
  finite pitch limits, unit quaternion and lease immediately before dispatch;
  read back input state afterwards. No direct rotation or packet writes.

Validation: eleven gameplay suites, including active camera identity/generation,
input-vs-render camera tags, MTE payload tags, invalid quaternion/limits and a
native-input/camera-consumption model; all app Java typechecks with Android 35
and Rhino; C++ syntax with warnings as errors; address/undefined sanitizers
(leak check disabled under the sandbox debugger). Full ARM64 APK linking and
visible camera behaviour require GitHub Actions and the phone.

## Earlier implementation (superseded)

# Aimbot · 0.52: плавный поворот

В журнале 0.51 цель найдена, привязка корректна, вызовы поворота выполняются.
Сообщений сервера, объясняющих «флаги», в журнале нет. Совместимость с Nevertime
по этому отчёту подтвердить нельзя.

В 0.52 поворот перенесён перед обновлением игрока и ограничен по скорости.
Настройка «Скорость поворота» — 60–360°/с, по умолчанию 180°/с. При обычном
обновлении раз в 50 мс это до 9° суммарного изменения pitch/yaw за обновление.
При задержке не накапливается большой разворот: учитывается максимум 100 мс.
Голова/тело, радиус и удержание одной цели сохранены. При захвате модуль сначала
плавно доворачивает камеру, затем следует за целью в пределах выбранной скорости.

Собери BedrockLaunchTest-0.52 через Build latest launch test. Проверь рядом
с другим игроком. Если снова возникают рывки или откаты, выключи модуль и сохрани
журнал 0.52. В нём добавлены maxTurn, speed и phase=before-update. Они помогают
проверить клиентские повороты, но не заменяют сообщение/журнал самого сервера.

## Предыдущая версия и схема данных

# Aimbot · 0.51

1. Собери исходники через Build latest launch test и установи BedrockLaunchTest-0.51.
2. Войди в мир, где рядом есть другой игрок. Открой kulich → Таргет → Aimbot.
3. Выбери «Голова» или «Тело», радиус (по умолчанию 6 блоков) и включи модуль.
4. Поверни камеру: при найденной цели модуль должен возвращать её к выбранной
   точке и следовать за движением игрока. Переключи голову/тело для проверки.
5. Выключи модуль — камера должна сразу снова управляться вручную. Если нет
   наведения или возник вылет, сохрани журнал kulich 0.51.

Меню можно держать открытым; модуль сохраняет состояние при другом окне.
Если Android/Minecraft останавливает саму игру, наведение ждёт её обновлений.
При выключении и закрытии игрового процесса наведение прекращается.

Первая версия выбирает ближайшего RemotePlayer по расстоянию и удерживает
именно его, даже если другой игрок подошёл ближе. При исчезновении/смене мира
или выходе из радиуса ищется новая цель. Мобы не выбираются. Фильтра друзей,
команд и проверки стены пока нет. Камера и голова поворачиваются явно; ударов
и отдельной подмены поворота в пакетах нет. Реальная работа на телефоне ещё
не подтверждена: локальные тесты не заменяют эту проверку.

## Exact-build layout evidence

The existing GameEngineProbe verifies SHA-256
4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4.

- RemotePlayer RTTI primary vptr is 0x139f76b0; constructors store it at
  0xaf694a8/0xaf694ac and 0xaf699d4/0xaf699d8. LocalPlayer remains 0x139f6ea0.
- Actor EntityContext is registry at +8, registry+40 at +16, 32-bit entity at +24.
  ActorOwnerComponent FNV-1a key 0x85b93800 is already established by player lookup.
  Actor removed flag +617 is checked by native resolver 0xfdb3c24..0xfdb3c38.
- Registry buckets/nodes and sparse generation scheme are the same as the
  existing player probe: map header +96/+104/+120/+128, 32-byte nodes;
  root entity sparse pages +216. Component sparse pages begin at storage+8,
  payload-page vector at +80/+88/+96; 128 payloads per page. Owner payload size 8.
- Component hashes are FNV-1a of their names. ActorRotationComponent = 0x75df36b7,
  AABBShapeComponent = 0xbac1b3cf, ActorHeadRotationComponent = 0xbabe7211.
  Rotation data is 16 bytes (current and previous Vec2), shape is 32 bytes
  (min/max Vec3, width/height), head is 8 bytes (current/previous yaw).
- Actor +552 is position, +560 shape and +568 rotation. Position getter
  0xfd8e62c loads current XYZ; shape getter 0xfd9b14c loads width at +24;
  yaw getter 0xfdaf960 reads rotation+4. Component addresses must match the
  local/remote cached shape and local cached rotation before gameplay use.
- Actor setRot 0xfd8f694 loads two floats from x1 and writes current rotation;
  setYHeadRot 0xfdafa3c resolves hash 0xbabe7211 and writes s0 to current yaw.
  Both signatures and the first eight instructions are pinned in aim_profile.h.
  Original MTE-tagged local this pointer is retained for native calls.

Native acquisition is bounded to 4096 owner entries and a five-millisecond/read
budget. Targets are revalidated immediately before native calls; stale entity
indices/pointers never authorize rotation. Journal records binding rejection,
scanned entries, target ID, angle values and applied-call count. An applied call
count proves native dispatch; actual camera behaviour still requires device
observation. There is no raw memory-write backend or arbitrary target setter API.
