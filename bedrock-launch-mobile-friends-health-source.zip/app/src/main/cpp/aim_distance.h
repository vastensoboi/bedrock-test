#pragma once
#include "aim_combat.h"
namespace kulich_aim {
struct AimDistances {
 double acquire=3,attack=3;
 static AimDistances fromTenths(int aim,int hit){
  aim=aim<10?10:aim>60?60:aim;hit=hit<10?10:hit>aim?aim:hit;
  return {aim/10.0,hit/10.0};
 }
};
// Distinguish a tracked target outside attack reach from a view-ray miss.
// Keep tracking in the wider radius; dispatch only inside the smaller one.
inline int attackDistanceState(Vec eye,const DirectLook& look,const Box& box,AimDistances ranges,Vec& hit){
 if(!std::isfinite(ranges.acquire)||!std::isfinite(ranges.attack)||ranges.attack<1||ranges.acquire>6||ranges.acquire<ranges.attack)return 3;
 if(!rayHitView(eye,look,box,ranges.acquire,hit))return 4;
 double x=hit.x-eye.x,y=hit.y-eye.y,z=hit.z-eye.z;
 return x*x+y*y+z*z>ranges.attack*ranges.attack+1e-6?3:0;
}
}
