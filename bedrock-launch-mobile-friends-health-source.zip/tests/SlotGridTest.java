import dev.custom.bedrockgui.SlotGrid;
public final class SlotGridTest {
    static void check(boolean value){if(!value)throw new AssertionError();}
    static void invalid(float x,float y,float rx,float ry,float nx,float ny){try{new SlotGrid(54,1280,591,x,y,rx,ry,nx,ny);throw new AssertionError();}catch(IllegalArgumentException expected){}}
    public static void main(String[] args){
        SlotGrid preset=SlotGrid.preconfigured(54,2340,1080);
        check(Math.abs(preset.point(49)[0]-1164.5728f)<0.05f&&Math.abs(preset.point(49)[1]-588.96606f)<0.05f);
        SlotGrid confirmation=SlotGrid.preconfigured(27,2340,1080);
        check(Math.abs(confirmation.y-preset.y-1.5f*preset.dy)<0.01f);
        SlotGrid scaled=SlotGrid.preconfigured(54,1170,540);
        check(Math.abs(scaled.point(49)[0]*2-preset.point(49)[0])<0.05f&&Math.abs(scaled.point(49)[1]*2-preset.point(49)[1])<0.05f);
        SlotGrid wide=SlotGrid.preconfigured(54,2560,1080);
        check(Math.abs(wide.x-preset.x-110)<0.01f&&Math.abs(wide.y-preset.y)<0.01f);
        SlotGrid screenshot=SlotGrid.preconfigured(27,1280,591);
        check(Math.abs(screenshot.point(13)[0]-640)<8&&Math.abs(screenshot.point(13)[1]-199)<8);
        try{SlotGrid.preconfigured(54,1080,2340);throw new AssertionError();}catch(IllegalArgumentException expected){}
        try{SlotGrid.preconfigured(12,2340,1080);throw new AssertionError();}catch(IllegalArgumentException expected){}
        SlotGrid g=new SlotGrid(27,1280,591,442.5f,150,836.9f,150,442.5f,199.4f);
        check(Math.abs(g.point(13)[0]-639.7f)<0.1f&&Math.abs(g.point(13)[1]-199.4f)<0.1f);
        check(g.fits(27,1280,591)&&!g.fits(54,1280,591)&&!g.fits(27,2340,1080));
        SlotGrid listing=new SlotGrid(54,1280,591,100,100,500,100,100,150);
        check(listing.point(49)[0]==300&&listing.point(49)[1]==350);
        SlotGrid noisy=new SlotGrid(54,1280,591,100,100,500,100,100,140);
        check(noisy.dx==noisy.dy&&Math.abs(noisy.point(49)[1]-350)<4); // old vertical extrapolation hit y=300
        SlotGrid noisyX=new SlotGrid(54,1280,591,100,100,500,100,114,140);
        check(Math.abs(noisyX.point(49)[0]-300)<4&&Math.abs(noisyX.point(49)[1]-350)<8);
        try{listing.point(54);throw new AssertionError();}catch(IllegalArgumentException expected){}
        invalid(100,100,50,100,100,150);invalid(100,100,500,100,100,105);invalid(100,100,500,160,100,150);
        invalid(100,100,500,100,200,150);invalid(Float.NaN,100,500,100,100,150);invalid(100,500,500,500,100,550);
        System.out.println("PASS: screenshot-scale confirmation geometry, refresh slot geometry, viewport/layout mismatch, range/shape/NaN/bounds guards");
    }
}
