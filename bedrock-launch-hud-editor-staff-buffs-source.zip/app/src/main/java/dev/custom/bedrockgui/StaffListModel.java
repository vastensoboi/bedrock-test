package dev.custom.bedrockgui;

import java.util.*;

/** Configured staff plus fresh observed roster evidence. Missing nearby actors are never called offline. */
public final class StaffListModel {
    public static final int MAX_NAMES=128;
    public static final long FRESH_MS=3000;
    private final LinkedHashMap<String,String> configured=new LinkedHashMap<>();
    private Set<String> observed=Collections.emptySet();
    private boolean globalKnown,available;
    private long observedAt=-1;

    public StaffListModel(){this("");}
    public StaffListModel(String encoded){setNames(encoded==null?"":encoded);}
    public static String normalize(String name){return name!=null&&name.matches("[A-Za-z0-9_]{1,16}")?name.toLowerCase(Locale.ROOT):"";}
    /** Atomically replace saved names; malformed input keeps the previous list. */
    public boolean setNames(String encoded){
        if(encoded==null||encoded.length()>4096)return false;
        LinkedHashMap<String,String> next=new LinkedHashMap<>();
        for(String line:encoded.split("\\r?\\n",-1)){
            String name=line.trim();if(name.isEmpty())continue;
            String key=normalize(name);if(key.isEmpty())return false;
            if(!next.containsKey(key)&&next.size()>=MAX_NAMES)return false;
            next.putIfAbsent(key,name);
        }
        configured.clear();configured.putAll(next);return true;
    }
    public String encoded(){return String.join("\n",configured.values());}
    public String[] configuredNames(){return configured.values().toArray(new String[0]);}
    /** observedAtMs is the monotonic capture time, not receipt time. Null means unavailable. */
    public void update(String[] names,boolean globalKnown,long observedAtMs){
        available=names!=null&&names.length<=4096&&observedAtMs>=0;
        this.globalKnown=available&&globalKnown;observedAt=observedAtMs;
        if(!available){observed=Collections.emptySet();return;}
        HashSet<String> next=new HashSet<>();
        for(String name:names){String key=normalize(name);if(!key.isEmpty())next.add(key);}
        observed=next;
    }
    public boolean fresh(long nowMs){return available&&nowMs>=observedAt&&nowMs-observedAt<=FRESH_MS;}
    public boolean globalKnown(long nowMs){return fresh(nowMs)&&globalKnown;}
    public List<String> lines(long nowMs){
        if(configured.isEmpty())return Collections.singletonList("Добавь ники сотрудников");
        if(!fresh(nowMs))return Collections.singletonList("Список игроков недоступен");
        ArrayList<String> result=new ArrayList<>();
        for(Map.Entry<String,String> entry:configured.entrySet())if(observed.contains(entry.getKey()))result.add(entry.getValue()+(globalKnown?" · в сети":" · рядом"));
        if(globalKnown){if(result.isEmpty())result.add("Сотрудников в сети нет");}
        else result.add("Полный список игроков недоступен");
        return Collections.unmodifiableList(result);
    }
}
