package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.widget.*;
import dalvik.system.DexClassLoader;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Diagnostic only: does not initialize game classes or load game native code. */
public final class MainActivity extends Activity {
    private static final String GAME = "com.mojang.minecraftpe";
    private static final int SAVE_REPORT = 41;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final StringBuffer report = new StringBuffer();
    private TextView log;
    private Button test;
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private static final class ProbeLoader extends DexClassLoader {
        ProbeLoader(String dexPath, String optimized, String libs, ClassLoader parent) {
            super(dexPath, optimized, libs, parent);
        }
        String library(String name) { return super.findLibrary(name); }
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout page = new LinearLayout(this); page.setOrientation(1);
        page.setPadding(dp(16), dp(16), dp(16), dp(12)); page.setBackgroundColor(Color.rgb(15,20,29));
        TextView title = new TextView(this); title.setText("Bedrock Diagnostic"); title.setTextSize(25); title.setTextColor(Color.WHITE); page.addView(title);
        TextView info = new TextView(this);
        info.setText("Проверка установленного Minecraft. Нужен свободный объём примерно в размере игровых библиотек. Игровые классы проверяются без запуска инициализации; инжекта и игровых функций здесь нет.");
        info.setTextColor(Color.LTGRAY); info.setPadding(0,dp(12),0,dp(12)); page.addView(info);
        test = new Button(this); test.setText("Проверить Minecraft");
        test.setOnClickListener(v -> { test.setEnabled(false); report.setLength(0); worker.execute(this::probe); }); page.addView(test);
        Button clear = new Button(this); clear.setText("Очистить подготовленные библиотеки");
        clear.setOnClickListener(v -> {
            if(!test.isEnabled()) { Toast.makeText(this,"Дождись окончания проверки",Toast.LENGTH_SHORT).show(); return; }
            test.setEnabled(false);
            worker.execute(() -> {
                try { GameArchiveCache.clear(new File(getCodeCacheDir(),"game-probe")); say("Кэш подготовленных библиотек очищен."); }
                catch(IOException error) { say("Ошибка очистки: " + error); }
                finally { runOnUiThread(() -> { if(!isFinishing()&&!isDestroyed())test.setEnabled(true); }); }
            });
        }); page.addView(clear);
        Button save = new Button(this); save.setText("Сохранить журнал");
        save.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain")
                    .addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"bedrock-diagnostic.txt");
            try { startActivityForResult(intent,SAVE_REPORT); }
            catch (ActivityNotFoundException error) { Toast.makeText(this,"Системный выбор файла недоступен",Toast.LENGTH_LONG).show(); }
        }); page.addView(save);
        ScrollView scroll = new ScrollView(this); log = new TextView(this);
        log.setTextColor(Color.rgb(180,230,220)); log.setTextIsSelectable(true); log.setTextSize(13); scroll.addView(log);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(page);
        File previous = new File(getFilesDir(),"last-report.txt");
        try { if (previous.isFile()) report.append(new String(java.nio.file.Files.readAllBytes(previous.toPath()),java.nio.charset.StandardCharsets.UTF_8)); }
        catch (IOException ignored) {}
        log.setText(report.toString());
    }
    private void say(String text) {
        report.append(text).append('\n');
        runOnUiThread(() -> { if(!isFinishing()&&!isDestroyed()) log.setText(report.toString()); });
    }
    private void probe() {
        try {
            say("Устройство: " + Build.MANUFACTURER + " " + Build.MODEL);
            say("Android: " + Build.VERSION.RELEASE + " / API " + Build.VERSION.SDK_INT);
            say("ABI: " + String.join(", ",Build.SUPPORTED_ABIS));
            say("PAGE_SIZE: " + android.system.Os.sysconf(android.system.OsConstants._SC_PAGESIZE));
            if(!Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a")) throw new IOException("Нужен ARM64");
            PackageInfo info = getPackageManager().getPackageInfo(GAME,0);
            ApplicationInfo app = info.applicationInfo;
            if(app==null) throw new IOException("ApplicationInfo не получен");
            say("Minecraft: " + info.versionName + " (code " + info.getLongVersionCode() + ")");
            List<File> apks = new ArrayList<>(); apks.add(new File(app.sourceDir));
            if(app.splitSourceDirs!=null) for(String split:app.splitSourceDirs) apks.add(new File(split));
            say("APK-файлов: " + apks.size());
            for(File apk:apks) say("  " + apk.getName() + ": " + apk.length() + " байт");
            File cache = new File(getCodeCacheDir(),"game-probe");
            GameArchiveCache.Result result = GameArchiveCache.prepare(apks,cache,this::say);
            say("Заголовки ELF64 ARM64 проверены; библиотек: " + result.libraries.size());
            say("Каталог библиотек: " + result.directory.getName());
            StringBuilder dex = new StringBuilder();
            for(File apk:apks) { if(dex.length()>0)dex.append(File.pathSeparator); dex.append(apk.getAbsolutePath()); }
            File optimized = new File(cache,"optimized");
            if(!optimized.isDirectory()&&!optimized.mkdirs()) throw new IOException("Недоступен каталог optimized");
            ProbeLoader loader = new ProbeLoader(dex.toString(),optimized.getAbsolutePath(),result.directory.getAbsolutePath(),getClassLoader());
            String nativePath = loader.library("minecraftpe");
            if(nativePath==null) throw new IOException("ClassLoader не разрешил libminecraftpe.so");
            say("Разрешение native path: OK");
            Class<?> activity = Class.forName("com.mojang.minecraftpe.MainActivity",false,loader);
            if(!Activity.class.isAssignableFrom(activity)) throw new IOException("Игровой класс не является Activity");
            say("Игровой MainActivity найден, тип Activity проверен: OK");
            say("PASS: файлы и классы подготовлены. Инициализация игры, загрузка .so и запуск игры НЕ проверены.");
        } catch(PackageManager.NameNotFoundException error) {
            say("FAIL: Minecraft с пакетом com.mojang.minecraftpe не найден в этом профиле Android.");
        } catch(Exception | LinkageError error) {
            say("FAIL: " + error);
            StringWriter trace = new StringWriter(); error.printStackTrace(new PrintWriter(trace)); say(trace.toString());
        } finally {
            try(FileOutputStream out = new FileOutputStream(new File(getFilesDir(),"last-report.txt"))) {
                out.write(report.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            } catch(IOException ignored) {}
            runOnUiThread(() -> { if(!isFinishing()&&!isDestroyed()) test.setEnabled(true); });
        }
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request!=SAVE_REPORT||result!=RESULT_OK||data==null||data.getData()==null)return;
        try(OutputStream out=getContentResolver().openOutputStream(data.getData())) {
            if(out==null)throw new IOException("Файл недоступен");
            out.write(report.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            Toast.makeText(this,"Журнал сохранён",Toast.LENGTH_SHORT).show();
        } catch(IOException error) { Toast.makeText(this,"Ошибка сохранения: "+error.getMessage(),Toast.LENGTH_LONG).show(); }
    }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
}
