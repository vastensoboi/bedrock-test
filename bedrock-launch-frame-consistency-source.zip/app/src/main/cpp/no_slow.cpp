#include "no_slow_core.h"
#include <jni.h>
#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cerrno>
namespace {
using namespace kulich_noslow;
using Bulk=void(*)(void*,void*);using Single=void(*)(void*,void*,void*);
std::atomic<A> gameBase{0},boundClient{0};std::atomic<bool> enabled{false};std::atomic<int64_t> lease{0};
std::atomic<uint64_t> bulkCalls{0},singleCalls{0},modified{0},rejected{0};std::mutex installGate;
Bulk originalBulk=nullptr;Single originalSingle=nullptr;int memory=-1;thread_local bool inside=false;
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(A address,void* out,size_t n){address=plain(address);if(memory<0||address<4096||n>65536||address>0x00ffffffffffffffULL-n)return false;ssize_t count;do{count=pread(memory,out,n,static_cast<off_t>(address));}while(count<0&&errno==EINTR);return count==ssize_t(n);}
bool writeFloat(A address,float value){if(!address||(plain(address)&3))return false;std::memcpy(reinterpret_cast<void*>(address),&value,4);return true;}
template<class Call> void around(void* system,void* entity,Call original){
 if(inside||!enabled.load(std::memory_order_acquire)||now()>lease.load()){original();return;}
 inside=true;auto read=readMemory;auto write=writeFloat;
 auto lookup=[&](Binding& value){return resolve(read,gameBase.load(),boundClient.load(),reinterpret_cast<A>(system),reinterpret_cast<A>(entity),value);};
 try{if(invoke(read,write,lookup,original,true))modified.fetch_add(1,std::memory_order_relaxed);else rejected.fetch_add(1,std::memory_order_relaxed);}
 catch(...){inside=false;throw;}
 inside=false;
}
void bulk(void* system,void* view){bulkCalls.fetch_add(1,std::memory_order_relaxed);around(system,nullptr,[&](){originalBulk(system,view);});}
void single(void* system,void* view,void* entity){singleCalls.fetch_add(1,std::memory_order_relaxed);around(system,entity,[&](){originalSingle(system,view,entity);});}
struct Profile {A offset;uint32_t words[8];};
constexpr Profile profiles[]={
 {BULK,{0xd10243ffU,0xa9037bfdU,0xa9046ffcU,0xa90567faU,0xa9065ff8U,0xa90757f6U,0xa9084ff4U,0x9100c3fdU}},
 {SINGLE,{0xd10103ffU,0xa9017bfdU,0xa90257f6U,0xa9034ff4U,0x910043fdU,0xd53bd056U,0xaa0203f5U,0xaa0003f3U}},
 {0xc127b10ULL,{0xbc6b7900U,0xf9402948U,0xd344fe0aU,0x52800c8bU,0xf86969c9U,0xf86a6908U,0x1e200800U,0x52800a0aU}},
 {0xc1275b0ULL,{0xbc687b20U,0x52800c88U,0x9ba83948U,0x92401b8aU,0x1e200800U,0x9bab614aU,0x2d448901U,0x1e200821U}},
 {0xc127decULL,{0x52992581U,0x72b0cfe1U,0x9100a300U,0x97fff4eaU,0x528310e1U,0xaa0003f5U,0x9100a300U,0x72a03161U}}
};
std::string install(A base,A client){
 std::lock_guard<std::mutex> lock(installGate);
 if(gameBase.load()){if(gameBase.load()!=base)return "Game base changed";boundClient.store(plain(client));return {};}
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0||pointer(readMemory,plain(client))!=base+0x1388fe70ULL)return "No Slow client binding unavailable";
 for(const auto& p:profiles){uint32_t code[8]{};if(!readMemory(base+p.offset,code,sizeof code)||std::memcmp(code,p.words,sizeof code))return "No Slow code profile mismatch";}
 A table=base+ADAPTER_TABLE,first=0,second=0;
 if(!readMemory(table+48,&first,8)||!readMemory(table+56,&second,8)||first!=base+BULK||second!=base+SINGLE)return "No Slow system callback mismatch";
 long pageSize=sysconf(_SC_PAGESIZE);if(pageSize<=0)return "Invalid page size";
 A page=(table+48)-(table+48)%A(pageSize);if(table+64>page+A(pageSize))return "Unexpected callback page";
 FILE* maps=fopen("/proc/self/maps","r");if(!maps)return "Cannot inspect callback mapping";
 char line[2048],perms[5]{};unsigned long long lo=0,hi=0;bool expected=false;
 while(fgets(line,sizeof line,maps))if(sscanf(line,"%llx-%llx %4s",&lo,&hi,perms)==3&&page>=lo&&page+A(pageSize)<=hi){expected=perms[0]=='r'&&perms[1]=='-'&&perms[2]=='-'&&std::string(line).find("/libminecraftpe.so")!=std::string::npos;break;}
 fclose(maps);if(!expected)return "Unexpected callback mapping permissions";
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ|PROT_WRITE))return "Cannot update movement callback table";
 originalBulk=reinterpret_cast<Bulk>(first);originalSingle=reinterpret_cast<Single>(second);boundClient.store(plain(client));gameBase.store(base);
 __atomic_store_n(reinterpret_cast<A*>(table+48),reinterpret_cast<A>(&bulk),__ATOMIC_RELEASE);
 __atomic_store_n(reinterpret_cast<A*>(table+56),reinterpret_cast<A>(&single),__ATOMIC_RELEASE);
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ)){
  __atomic_store_n(reinterpret_cast<A*>(table+48),first,__ATOMIC_RELEASE);__atomic_store_n(reinterpret_cast<A*>(table+56),second,__ATOMIC_RELEASE);gameBase.store(0);return "Cannot restore callback page protection";
 }
 return {};
}
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_NoSlowBridge_install(JNIEnv* env,jclass,jlong base,jlong client){auto error=install(A(base),A(client));return env->NewStringUTF(error.c_str());}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_NoSlowBridge_enable(JNIEnv*,jclass,jboolean value){enabled.store(value);lease.store(0);}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_NoSlowBridge_pulse(JNIEnv*,jclass,jboolean value){lease.store(value?now()+1200:0);}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_NoSlowBridge_status(JNIEnv* env,jclass){char result[400];snprintf(result,sizeof result,"No Slow: enabled=%d bulk=%llu single=%llu modified=%llu rejected=%llu route=item-use-input-factor",enabled.load(),static_cast<unsigned long long>(bulkCalls.load()),static_cast<unsigned long long>(singleCalls.load()),static_cast<unsigned long long>(modified.load()),static_cast<unsigned long long>(rejected.load()));return env->NewStringUTF(result);}
