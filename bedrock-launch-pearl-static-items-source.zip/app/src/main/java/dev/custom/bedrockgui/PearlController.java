package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

/** Prepare the read-only pearl feed without enabling Aimbot; retain the toggle across menus. */
public final class PearlController {
    private final Activity activity;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean requested,preparing,disposed;
    private int generation;
    private String message="Выключен";
    public PearlController(Activity activity){this.activity=activity;}
    public boolean isEnabled(){return requested;}
    public String status(){return !requested||!PearlBridge.isReady()?message:PearlBridge.describe();}
    public String displayStatus(){return status().split("\n",2)[0];}
    public void setEnabled(boolean value){
        if(disposed)return;
        generation++;requested=value;handler.removeCallbacksAndMessages(null);
        if(!value){PearlBridge.setEnabled(false);message="Выключен";return;}
        if(PearlBridge.isReady()){
            try{PearlBridge.setEnabled(true);}
            catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить прогноз жемчуга. Причина в журнале";throw error;}
            return;
        }
        message="Подключаю прогноз жемчуга. Нужен загруженный мир";prepare(generation);
    }
    private void prepare(int epoch){
        if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
        if(preparing||!GameEngineProbe.begin()){handler.postDelayed(()->prepare(epoch),400);return;}
        preparing=true;
        Thread worker=new Thread(()->{
            try{GameEngineProbe.run();}
            catch(RuntimeException|LinkageError error){GameRuntime.log("прогноз жемчуга preparation failed: "+error);}
            finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{
                preparing=false;
                if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
                if(GameEngineProbe.playerFound()&&PearlBridge.isReady()){
                    try{PearlBridge.setEnabled(true);}
                    catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить прогноз жемчуга. Причина в журнале";GameRuntime.log("прогноз жемчуга enable failed: "+error);}
                }else if(GameEngineProbe.playerFound()){
                    requested=false;message="прогноз жемчуга не подключился. Причина в журнале";
                }else{
                    message="Войди в мир: прогноз жемчуга подключится автоматически";handler.postDelayed(()->prepare(epoch),8000);
                }
            });
        },"pearl-prediction-prepare");worker.setDaemon(true);worker.start();
    }
    public void dispose(){setEnabled(false);disposed=true;handler.removeCallbacksAndMessages(null);}
}
