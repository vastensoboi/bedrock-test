#include "../app/src/main/cpp/own_input_gate.h"
#include <atomic>
#include <cassert>
#include <iostream>
#include <thread>
#include <vector>

using kulich_own_step::InputGate;

void inspectionInvalidation(){
 InputGate gate;
 assert(gate.epoch()!=0&&!gate.tryBeginReplay(0));
 const uint64_t inspected=gate.epoch();
 auto ordinary=gate.beginInput();
 assert(ordinary.entered&&!ordinary.replay&&ordinary.token>inspected);
 assert(!gate.tryBeginReplay(inspected)&&!gate.tryBeginReplay(ordinary.token));
 gate.endInput();
 assert(!gate.tryBeginReplay(inspected));
 assert(gate.tryBeginReplay(ordinary.token));gate.endReplay();
}

void readerCompletionOrder(){
 InputGate gate;
 auto first=gate.beginInput(),second=gate.beginInput();
 assert(first.entered&&second.entered&&!first.replay&&!second.replay);
 assert(first.token<second.token&&second.token==gate.epoch());
 gate.endInput(); // Complete the newer reader first.
 assert(!gate.tryBeginReplay(gate.epoch()));
 gate.endInput();
 assert(!gate.tryBeginReplay(first.token));
 assert(gate.tryBeginReplay(second.token));gate.endReplay();
 // The next reader changes the epoch even after all previous readers ended.
 auto third=gate.beginInput();assert(third.entered&&third.token>second.token);gate.endInput();
 assert(!gate.tryBeginReplay(second.token));
 assert(gate.tryBeginReplay(third.token));gate.endReplay();
}

void replayRejectsInputWithoutLosingEpoch(){
 InputGate gate;
 const auto prior=gate.epoch();assert(gate.tryBeginReplay(prior));
 auto denied=gate.beginInput();
 assert(!denied.entered&&denied.replay&&denied.token==0);
 assert(gate.epoch()>prior&&!gate.tryBeginReplay(gate.epoch()));
 auto second=gate.beginInput();assert(!second.entered&&second.replay&&second.token==0);
 gate.endReplay();
 assert(!gate.tryBeginReplay(prior));
 assert(gate.tryBeginReplay(gate.epoch()));gate.endReplay();
 auto ordinary=gate.beginInput();assert(ordinary.entered&&!ordinary.replay);gate.endInput();
 assert(gate.tryBeginReplay(ordinary.token));gate.endReplay();
}

void staleInspectedEpoch(){
 InputGate gate;
 auto first=gate.beginInput();gate.endInput();
 const auto inspected=first.token;
 auto late=gate.beginInput();gate.endInput();
 assert(!gate.tryBeginReplay(inspected));
 assert(gate.tryBeginReplay(late.token));gate.endReplay();
 // A rejected stale writer must not leave the gate permanently exclusive.
 auto resumed=gate.beginInput();assert(resumed.entered&&!resumed.replay);gate.endInput();
}

void threadedMutualExclusion(){
 InputGate gate;
 std::atomic<bool> start{false},writerReady{false};
 std::atomic<unsigned> firstAttempts{0};
 std::atomic<unsigned> activeReaders{0},activeWriters{0};
 std::atomic<uint64_t> entered{0},denied{0},replayed{0};
 std::vector<std::thread> threads;
 for(unsigned index=0;index<4;++index)threads.emplace_back([&]{
  while(!start.load(std::memory_order_acquire)||!writerReady.load(std::memory_order_acquire))std::this_thread::yield();
  for(unsigned i=0;i<30000;++i){
   auto admission=gate.beginInput();
   if(admission.entered){
    assert(!admission.replay&&admission.token!=0);
    activeReaders.fetch_add(1);assert(activeWriters.load()==0);
    entered.fetch_add(1);activeReaders.fetch_sub(1);gate.endInput();
   }else{
    assert(admission.replay&&admission.token==0);denied.fetch_add(1);
   }
   if(i==0)firstAttempts.fetch_add(1,std::memory_order_release);
  }
 });
 threads.emplace_back([&]{
  while(!start.load(std::memory_order_acquire))std::this_thread::yield();
  // Force real concurrent rejected readers before opportunistic stress; a
  // writer that merely loses every later admission cannot vacuously pass.
  assert(gate.tryBeginReplay(gate.epoch()));
  assert(activeWriters.fetch_add(1)==0);replayed.fetch_add(1);
  writerReady.store(true,std::memory_order_release);
  while(firstAttempts.load(std::memory_order_acquire)!=4)std::this_thread::yield();
  assert(activeReaders.load()==0&&activeWriters.fetch_sub(1)==1);gate.endReplay();
  for(unsigned i=0;i<120000;++i){
   if(gate.tryBeginReplay(gate.epoch())){
    assert(activeWriters.fetch_add(1)==0);assert(activeReaders.load()==0);
    replayed.fetch_add(1);assert(activeWriters.fetch_sub(1)==1);gate.endReplay();
   }
  }
 });
 start.store(true,std::memory_order_release);
 for(auto& thread:threads)thread.join();
 assert(entered.load()+denied.load()==120000);
 assert(gate.epoch()==120001&&activeReaders.load()==0&&activeWriters.load()==0);
 // This also detects a transient rejected-reader count lost by a writer's
 // release: no callback remains, so the final admission must succeed.
 assert(gate.tryBeginReplay(gate.epoch()));gate.endReplay();
 auto final=gate.beginInput();assert(final.entered&&!final.replay);gate.endInput();
 assert(gate.tryBeginReplay(final.token));gate.endReplay();
 assert(replayed.load()>0&&denied.load()>=4);
}

int main(){
 inspectionInvalidation();readerCompletionOrder();replayRejectsInputWithoutLosingEpoch();
 staleInspectedEpoch();threadedMutualExclusion();
 std::cout<<"PASS: bounded no-wait input/replay admission, reader overlap, stale epochs, rejected-reader preservation and concurrent mutual exclusion\n";
}
