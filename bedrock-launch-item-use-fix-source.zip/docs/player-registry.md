# Exact-build player lookup, version 0.16

Library: 342231392 bytes, SHA-256
`4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4`.
The public probe wrapper rejects other library contents before scanning memory.
All addresses below are relative to that library's load base.

## Evidence recovered from ARM64 instructions

* ClientInstance vtable slot 31 at `0x9b7f610` uses the entity reference at
  client+576, constructs a temporary context through `0xe82f8c0` → `0x1346904c`,
  and passes the context to `0xaf67fb0` with flag 1.
* The context constructor validates the entity's generation with sparse pages
  at registry+216/+224 and dense count at registry+280. The context receives
  registry and registry+40. This test implementation reads these structures;
  it does not perform the constructor's reference-count modifications.
* `0xaf67fb0` looks up key `0xacb47b38`, validates the component's sparse entry,
  then tail-calls `0xfdb3b58`.
* `0xfdb3b58` looks up key `0x85b93800`. The sparse value chooses a dense page
  through pool+80; a page contains 128 pointer-sized entries. The payload getter
  `0xbd987e0` returns the pointer stored in that entry.
* For both component lookups the map has bucket pointers at registry+96/+104
  and 32-byte node pointers at registry+120/+128. Node offsets are chain index 0,
  key 8 and pool pointer 16. Sparse pages contain 2048 32-bit entries. Entity IDs
  use 18 index bits and upper generation bits; the native generation comparison
  rejects XOR values greater than `0x3fffe`.
* The LocalPlayer constructor at `0xaf5b4ac` installs vptr `0x139f6ea0` and
  stores its client argument at player+3240 (`0xaf5b60c`). Its caller allocates
  4304 bytes. The probe checks both vptr and client back-reference before
  recording a verified binding.

## Read limits and concurrent state

The existing limits remain: four seconds, 20000 read attempts, mapped readable
ranges, 64 recognized objects and a root range no larger than 4 MiB. Component
hash maps allow at most 4096 buckets/nodes and 64 links in a collision chain.
Each individual read is checked against the process maps and uses the existing
read-only file reader. Broken links, stale generations, invalid types and
entity changes produce rejection rather than a native dereference or call.

After resolving a candidate, the probe compares the client reference again and
rechecks registry and actor sparse indices. This is a diagnostic snapshot, not
an object lock or an ownership guarantee for later actions. Gameplay access
still requires an appropriately synchronized game-thread bridge.

## Validation and remaining work

The pure Java tests exercise an ECS-only player, nonzero sparse/dense page
indices, hash collisions/cycles, reused entity generations, a missing marker,
an incorrect client back-reference, a malformed vector and concurrent entity
replacement. Java sources have also been syntax-parsed. Android type checking,
APK assembly and device validation must still run in GitHub Actions/on-device.

The user's 0.15 log confirmed the MinecraftGame → client-tree → ClientInstance
path. The new 0.16 entity path is derived from this exact binary and has not yet
been confirmed in live device memory. No selected-slot/item layout or use/place
function ABI has been established. This release cannot enable Fast Exp,
Block Trap or Auto Buy and does not load the supplied VHax native library.
