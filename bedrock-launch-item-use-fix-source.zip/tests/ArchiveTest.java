import dev.custom.bedrockgui.GameArchiveCache;
import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.util.*;
import java.util.zip.*;

public final class ArchiveTest {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    private static byte[] header(){
        byte[] b=new byte[64];b[0]=0x7f;b[1]='E';b[2]='L';b[3]='F';b[4]=2;b[5]=1;b[6]=1;b[16]=3;b[18]=(byte)183;b[52]=64;return b;
    }
    private static File zip(Path path,Map<String,byte[]> entries)throws IOException{
        try(ZipOutputStream stream=new ZipOutputStream(Files.newOutputStream(path))){
            for(Map.Entry<String,byte[]> entry:entries.entrySet()){
                stream.putNextEntry(new ZipEntry(entry.getKey()));stream.write(entry.getValue());stream.closeEntry();
            }
        }return path.toFile();
    }
    public static void main(String[] args)throws Exception{
        Path dir=Files.createTempDirectory("game-archive-test-");File cache=dir.resolve("cache").toFile();
        try{
            File base=zip(dir.resolve("base.apk"),Map.of("classes.dex",new byte[]{1,2,3}));
            byte[] minecraft=header();
            File split=zip(dir.resolve("arm64.apk"),Map.of(
                "lib/arm64-v8a/libminecraftpe.so",minecraft,
                "lib/arm64-v8a/libsupport.so",header(),
                "lib/arm64-v8a/../../outside.so",header(),
                "lib/x86/libwrong.so",header()));
            GameArchiveCache.Result result=GameArchiveCache.prepare(List.of(base,split),cache,text->{});
            check(result.libraries.size()==2,"only whitelisted ARM64 files extracted");
            File extracted=new File(result.directory,"libminecraftpe.so");
            check(Arrays.equals(Files.readAllBytes(extracted.toPath()),minecraft),"library bytes preserved");
            check(!Files.getPosixFilePermissions(extracted.toPath()).contains(PosixFilePermission.OWNER_WRITE),"library made read-only");
            check(!dir.resolve("outside.so").toFile().exists(),"zip traversal blocked");
            GameArchiveCache.Result again=GameArchiveCache.prepare(List.of(base,split),cache,text->{});
            check(again.directory.equals(result.directory),"repeat preparation stable");
            File duplicate=zip(dir.resolve("duplicate.apk"),Map.of("lib/arm64-v8a/libminecraftpe.so",header()));
            boolean failed=false;try{GameArchiveCache.prepare(List.of(split,duplicate),cache,text->{});}catch(IOException e){failed=true;}
            check(failed,"duplicate library rejected");
            byte[] wrong=header();wrong[18]=62;
            File bad=zip(dir.resolve("bad.apk"),Map.of("lib/arm64-v8a/libminecraftpe.so",wrong));
            failed=false;try{GameArchiveCache.prepare(List.of(bad),cache,text->{});}catch(IOException e){failed=true;}
            check(failed,"wrong ELF architecture rejected");
            failed=false;try{GameArchiveCache.prepare(List.of(base),cache,text->{});}catch(IOException e){failed=true;}
            check(failed,"missing game library rejected");
            for(File f:Objects.requireNonNull(cache.listFiles()))check(!f.getName().startsWith("stage-"),"failed staging removed");
            GameArchiveCache.clear(cache);check(!cache.exists(),"private extraction cache removable");
            System.out.println("PASS: split APK extraction, exact bytes, read-only files, traversal filtering, duplicate rejection, ELF architecture, missing game library, cleanup.");
        }finally{
            GameArchiveCache.clear(dir.toFile());
        }
    }
}
