package dev.custom.bedrockgui;

import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.function.Consumer;

/** Read-only candidate container snapshot. It never calls game methods or clicks slots. */
public final class AuctionMemoryProbe {
    public static final class TapToken {
        final long player,client,manager,node,model,vector,vptr,tag;final int slots;final EmptyTarget destination;
        TapToken(long player,long client,long manager,long node,long model,long vector,long vptr,long tag,int slots){
            this.player=player;this.client=client;this.manager=manager;this.node=node;this.model=model;this.vector=vector;this.vptr=vptr;this.tag=tag;this.slots=slots;this.destination=null;
        }
        private TapToken(TapToken p,EmptyTarget d){player=p.player;client=p.client;manager=p.manager;node=p.node;model=p.model;vector=p.vector;vptr=p.vptr;tag=p.tag;slots=p.slots;destination=d;}
        public int destinationSlot(){return destination==null?-1:destination.slot;}
    }
    private static final class EmptyTarget {
        final long model,node,vector;final int slot;
        EmptyTarget(long model,long node,long vector,int slot){this.model=model;this.node=node;this.vector=vector;this.slot=slot;}
    }
    private EmptyTarget inventoryTarget;
    private TapToken refreshToken;private int windowSlots;
    public int windowSlots(){return windowSlots;}
    public TapToken token(int slots){return slots==54&&refreshToken!=null&&inventoryTarget!=null?new TapToken(refreshToken,inventoryTarget):null;}
    private static String plain(String name){return name.replaceAll("§.","").trim().toLowerCase(Locale.ROOT);}
    public boolean validateTap(TapToken token)throws IOException {
        reads=0;deadline=System.nanoTime()+100000000L;
        if(token==null||token.slots!=54||token.destination==null||!inventoryValid(token,true)||pointer(token.player)!=base+0x139f6ea0L||
                pointer(token.player+3240)!=token.client||pointer(token.player+0x578)!=token.manager||
                pointer(token.manager)!=base+0x137e8f20L||pointer(token.node+40)!=token.model)return false;
        byte[] model=read(token.model,240);int slot=49;
        if(model==null||q(model,0)!=token.vptr||q(model,216)!=token.vector||q(model,224)-token.vector!=token.slots*152L)return false;
        byte[] stack=read(token.vector+slot*152L,152);
        if(stack==null||q(stack,0)!=base+0x13d95ff8L||q(stack,16)!=token.tag)return false;
        NbtDisplayReader.Display display=new NbtDisplayReader(this::read,base).read(token.tag);
        return display!=null&&plain(display.name).equals("обновить")&&Arrays.equals(model,read(token.model,240))&&
                pointer(token.player+0x578)==token.manager&&pointer(token.node+40)==token.model;
    }
    private boolean inventoryValid(TapToken token,boolean empty)throws IOException {
        EmptyTarget d=token.destination;if(d==null||pointer(d.node+40)!=d.model)return false;
        byte[] model=read(d.model,240);
        if(model==null||q(model,0)!=base+0x13d341b0L||q(model,216)!=d.vector||q(model,224)-d.vector!=27*152L)return false;
        byte[] slot=read(d.vector+d.slot*152L,152);
        return slot!=null&&q(slot,0)==base+0x13d95ff8L&&(!empty||(slot[34]&255)==0);
    }
    public boolean validateDragWindow(TapToken token)throws IOException {
        reads=0;deadline=System.nanoTime()+100000000L;
        if(token==null||token.slots!=54||pointer(token.player)!=base+0x139f6ea0L||pointer(token.player+3240)!=token.client||
                pointer(token.player+0x578)!=token.manager||pointer(token.manager)!=base+0x137e8f20L||pointer(token.node+40)!=token.model)return false;
        byte[] model=read(token.model,240);
        return model!=null&&q(model,0)==token.vptr&&q(model,216)==token.vector&&q(model,224)-token.vector==54*152L&&inventoryValid(token,false);
    }
    private final List<EngineMemoryProbe.Region> regions;
    private final EngineMemoryProbe.Reader reader;private final long base;private final Consumer<String> log;
    private int reads;private long deadline;
    public AuctionMemoryProbe(List<EngineMemoryProbe.Region> regions,EngineMemoryProbe.Reader reader,long base,Consumer<String> log){
        this.regions=regions;this.reader=reader;this.base=base;this.log=log;
    }
    private static long ptr(long p){return EngineMemoryProbe.untag(p);}
    private byte[] read(long address,int size)throws IOException {
        address=ptr(address);
        if(address==0||size<0||reads>=8000||System.nanoTime()>deadline)return null;
        boolean mapped=false;
        for(EngineMemoryProbe.Region r:regions)if(r.readable&&r.writable&&address>=r.start&&address<r.end&&size<=r.end-address){mapped=true;break;}
        if(!mapped)return null;
        reads++;byte[] data=new byte[size];
        try{return reader.read(address,data,size)?data:null;}catch(IOException error){return null;}
    }
    private static long q(byte[] data,int offset){return ptr(ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).getLong(offset));}
    private long pointer(long address)throws IOException {byte[] bytes=read(address,8);return bytes==null?0:q(bytes,0);}
    public String scan(long player,long client)throws IOException {
        refreshToken=null;inventoryTarget=null;windowSlots=0;
        reads=0;deadline=System.nanoTime()+2000000000L;player=ptr(player);client=ptr(client);
        byte[] actor=read(player,4304);
        if(actor==null||q(actor,0)!=base+0x139f6ea0L||q(actor,3240)!=client||client==0)
            return "Игрок изменился. Открой аукцион и повтори чтение.";
        Set<Long> managers=new LinkedHashSet<>();
        for(int offset=0;offset+8<=actor.length;offset+=8){
            long candidate=q(actor,offset);
            if(candidate!=0&&pointer(candidate)==base+0x137e8f20L){
                managers.add(candidate);log.accept("Auto Buy: ChestContainerManagerModel at player+0x"+Integer.toHexString(offset));
            }
        }
        if(managers.isEmpty())return "Открытый сундуковый контейнер пока не найден. Покупки не выполнялись.";
        List<String> candidates=new ArrayList<>();Set<Long> seen=new HashSet<>();
        for(long manager:managers){
            byte[] state=read(manager,216);if(state==null||q(state,0)!=base+0x137e8f20L)continue;
            // Exact build: model map at +176; libc++ first-node link at +16.
            long node=q(state,192);
            log.accept("Auto Buy: model map first="+Long.toHexString(node)+" size="+q(state,200));
            for(int n=0;node!=0&&n<32&&seen.add(node);n++){
                byte[] entry=read(node,56);if(entry==null)break;
                long model=q(entry,40);
                byte[] object=read(model,240);
                long modelVptr=object==null?0:q(object,0);
                log.accept("Auto Buy: map model vptr offset=0x"+Long.toHexString(modelVptr-base));
                // These derived vtables retain exactly the same vector size/index getters.
                if(object!=null&&(modelVptr==base+0x13d35930L||modelVptr==base+0x13d34298L||
                        modelVptr==base+0x13d341b0L||modelVptr==base+0x13d34468L)){
                    // Disassembly 0x10169ba4/0x10169bd0: vector at +216,
                    // indexing uses 152-byte ItemStack objects. Do not infer names/prices.
                    long begin=q(object,216),end=q(object,224),capacity=q(object,232);
                    long bytes=end-begin;
                    if(begin!=0&&end>=begin&&capacity>=end&&capacity-begin<=152L*4096&&bytes%152==0&&(bytes/152==27||bytes/152==54)){
                        int slots=(int)(bytes/152);byte[] stacks=read(begin,(int)bytes);boolean valid=stacks!=null;
                        StringBuilder amounts=new StringBuilder();int nonEmpty=0;
                        if(valid)for(int i=0;i<slots;i++){
                            if(q(stacks,i*152)!=base+0x13d95ff8L){valid=false;break;}
                            int count=stacks[i*152+34]&255;
                            if(count>0){nonEmpty++;if(amounts.length()>0)amounts.append(", ");amounts.append(i).append(':').append(count);}
                        }
                        byte[] current=read(model,240),currentStacks=read(begin,(int)bytes);
                        if(valid&&current!=null&&currentStacks!=null&&Arrays.equals(object,current)&&Arrays.equals(stacks,currentStacks)&&
                                pointer(player)==base+0x139f6ea0L&&pointer(player+3240)==client&&pointer(manager)==base+0x137e8f20L&&pointer(node+40)==model&&pointer(manager+192)==q(state,192)){
                            String value="Container candidate: slots="+slots+" nonEmpty="+nonEmpty+" slotCounts={"+amounts+"}";
                            log.accept("Auto Buy: "+value);candidates.add(value);
                            if(modelVptr==base+0x13d34298L)windowSlots=slots;
                            if(modelVptr==base+0x13d341b0L&&slots==27&&inventoryTarget==null){
                                for(int i=0;i<27;i++)if((stacks[i*152+34]&255)==0){inventoryTarget=new EmptyTarget(model,node,begin,i);log.accept("Auto Buy input: empty player inventory slot="+i);break;}
                            }
                            NbtDisplayReader nbt=new NbtDisplayReader(this::read,base);int decoded=0,typed=0,matches=0,listed=0;
                            List<AutoBuyMatcher.Rule> rules=AutoBuyDefaultRules.rules();
                            for(int i=0;i<slots;i++)if((stacks[i*152+34]&255)>0){
                                // Exact ItemStackBase copy/destructor use userdata at +16.
                                // +24 is a different copied field; require CompoundTag before decoding.
                                long tag=q(stacks,i*152+16);
                                byte[] type=read(tag,8);
                                if(type==null||q(type,0)!=base+0x13ebe0b0L)continue;
                                typed++;
                                NbtDisplayReader.Display display=nbt.read(tag);
                                if(display!=null){
                                    decoded++;int count=stacks[i*152+34]&255;
                                    log.accept("Auto Buy lot: slot="+i+" count="+count+" "+display.log());
                                    if(modelVptr==base+0x13d34298L&&slots==54&&i==49&&plain(display.name).equals("обновить")){
                                        TapToken token=new TapToken(player,client,manager,node,model,begin,modelVptr,tag,slots);
                                        refreshToken=token;
                                    }
                                    if(modelVptr==base+0x13d34298L&&slots==54&&i<45){
                                        long handle=q(stacks,i*152+8),item=pointer(handle),itemType=pointer(item);
                                        String kind=itemType==base+0x13d89030L?"sword":itemType==base+0x13d9de58L?"book":"";
                                        AutoBuyMatcher.Verdict verdict=AutoBuyMatcher.evaluate(display.name,display.lore,count,kind,display.ench,rules);
                                        if(verdict.candidate){listed++;if(verdict.accepted)matches++;log.accept("Auto Buy decision: slot="+i+" "+verdict.log());}
                                    }
                                }
                            }
                            log.accept("Auto Buy: CompoundTag userdata="+typed+" display entries decoded="+decoded);
                            if(modelVptr==base+0x13d34298L&&slots==54){
                                String selection="Подбор: лотов из списка="+listed+", подходят="+matches+". Покупки выключены.";
                                candidates.add(selection);log.accept("Auto Buy: "+selection);
                            }
                        }else log.accept("Auto Buy: changed/invalid container snapshot rejected");
                    }else log.accept("Auto Buy: vector rejected begin="+Long.toHexString(begin)+" bytes="+bytes+" capacityBytes="+(capacity-begin));
                }
                node=q(entry,0);
            }
            if(reads>=8000||System.nanoTime()>deadline){log.accept("Auto Buy: read/time budget reached; diagnostic output may be partial");break;}
            if(pointer(manager+192)!=q(state,192))return "Окно контейнера изменилось. Повтори чтение. Покупки не выполнялись.";
        }
        return candidates.isEmpty()?"Менеджер контейнера найден, но лоты пока не прочитаны. Покупки не выполнялись.":
                String.join("\n",candidates)+"\nСнимок и доступные названия/описания записаны в журнал. Покупка ещё не подключена.";
    }
}
