package dev.custom.bedrockgui;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import java.util.function.Consumer;

/** One official native Place request at a time; completion means a matching reply, not purchase success. */
public final class NativeContainerInput {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean busy,loaded,uncertain,purchase,retryable,refresh;private String status="Нативный перенос готовится при включении";private int generation;private long until,lastLog;
    static native int submit(long base,long[] fields);
    private static native int progress();
    private static native void cancel();
    private static native void cancelQueued();
    private static native int reason();
    private static native String details();
    public boolean busy(){return busy||SystemClock.uptimeMillis()<until;}
    public boolean uncertain(){return uncertain;}
    public boolean retryable(){return retryable;}
    public String status(){return status;}
    public void reset(){uncertain=false;}
    public void automatic(AuctionMemoryProbe.ActionToken token,Consumer<Boolean> done){
        retryable=false;
        if(busy()||token==null){retryable=true;done.accept(false);return;}
        purchase=token.slots==27&&token.slot==10;refresh=token.slots==54&&token.slot==49;
        try{
            int result=GameEngineProbe.submitNative(token);loaded=true;
            if(result!=1){retryable=result==-1||result==-7;status="Действие пока недоступно ("+result+")";GameRuntime.log("Native container enqueue rejected: "+result);done.accept(false);return;}
        }catch(java.io.IOException|RuntimeException|LinkageError error){GameRuntime.log("Native container unavailable: "+error);done.accept(false);return;}
        busy=true;status="Жду игровой тик";int epoch=++generation;long deadline=SystemClock.uptimeMillis()+3500;
        handler.post(new Runnable(){public void run(){
            if(!busy||epoch!=generation)return;
            int state=progress();if(state==2)status="Запрос отправлен, ожидаю ответ сервера";
            if(state==3){
                busy=false;uncertain=false;status="Получен ответ сервера";if(purchase)until=SystemClock.uptimeMillis()+600;
                if(!refresh||SystemClock.uptimeMillis()-lastLog>=3000){lastLog=SystemClock.uptimeMillis();GameRuntime.log(details()+"; matching server reply observed; effect must be checked in container");}done.accept(true);return;
            }
            if(state==4||state==5||SystemClock.uptimeMillis()>=deadline){
                busy=false;uncertain=purchase&&(state==1||state==2||state==5||(state==4&&reason()==6));retryable=!purchase&&state==4&&reason()<=3;status="Действие не завершено";GameRuntime.log(details()+"; action completion unavailable");cancel();done.accept(false);return;
            }
            handler.postDelayed(this,25);
        }});
    }
    public void cancelPending(){
        // Stop an unexecuted command. A request already sent is not undone or replayed.
        if(loaded&&busy)cancelQueued();
    }
    public void close(){cancelPending();generation++;handler.removeCallbacksAndMessages(null);busy=false;}
}
