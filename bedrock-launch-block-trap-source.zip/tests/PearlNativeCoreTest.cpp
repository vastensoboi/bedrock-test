#include "../app/src/main/cpp/pearl_native_core.h"
#include <cassert>
#include <iostream>

using namespace kulich_pearl;
struct Memory {
 static constexpr A root=0x200000,base=0x10000000,tag=0xb400000000000000ULL;
 std::vector<unsigned char> bytes=std::vector<unsigned char>(0x400000);
 A next=root+0x10000,changingState=0,changingBounds=0;unsigned reads=0,stateReads=0,boundsReads=0;
 A alloc(size_t n){A p=next;next=(next+n+7)&~A(7);assert(next-root<bytes.size());return p;}
 template<class T>void put(A p,T value){assert(p>=root&&p-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+p-root,&value,sizeof value);}
 bool operator()(A p,void* out,size_t n){
  ++reads;if(p<root||p-root>bytes.size()||n>bytes.size()-(p-root))return false;
  std::memcpy(out,bytes.data()+p-root,n);
  if(p==changingState&&n==sizeof(State)&&++stateReads%2==0)static_cast<unsigned char*>(out)[0]^=1;
  if(p==changingBounds&&n==24&&++boundsReads%2==0)static_cast<unsigned char*>(out)[8]^=4;
  return true;
 }
};
struct Storage {A pool=0,sparse=0,payload=0,packed=0;unsigned stride=0;};
Storage storage(Memory& m,unsigned stride){
 Storage s{};s.pool=m.alloc(104);s.stride=stride;s.sparse=m.alloc(8192);
 std::memset(m.bytes.data()+s.sparse-Memory::root,255,8192);
 A pages=m.alloc(8);m.put(pages,s.sparse|Memory::tag);
 m.put(s.pool+8,pages|Memory::tag);m.put(s.pool+16,(pages+8)|Memory::tag);
 A payloadPages=m.alloc(8);s.payload=m.alloc(128*stride);m.put(payloadPages,s.payload|Memory::tag);
 m.put(s.pool+80,payloadPages|Memory::tag);m.put(s.pool+88,(payloadPages+8)|Memory::tag);m.put(s.pool+96,(payloadPages+8)|Memory::tag);
 s.packed=m.alloc(128*4);m.put(s.pool+32,s.packed|Memory::tag);m.put(s.pool+40,s.packed|Memory::tag);m.put(s.pool+48,(s.packed+512)|Memory::tag);
 return s;
}
A bind(Memory& m,const Storage& s,uint32_t entity,unsigned index){
 m.put(s.sparse+(entity&2047)*4,(entity&0xfffc0000U)|index);
 return s.payload+index*s.stride;
}
struct Fixture {
 Memory m;A registry=Memory::root+0x1000,local=Memory::root+0x3000,entitySparse=0;
 Storage owners=storage(m,8),states=storage(m,36),projectiles=storage(m,760),uids=storage(m,8),water=storage(m,1);
 std::array<A,12> actors{},state{},projectile{};std::vector<uint32_t> active;
 static constexpr uint32_t localEntity=0x40001;
 Fixture(){
  A buckets=m.alloc(64),nodes=m.alloc(5*32);
  for(unsigned i=0;i<8;i++)m.put<int64_t>(buckets+i*8,-1);
  std::array<uint32_t,5> keys{kulich_aim::OWNER,STATE,PROJECTILE,UNIQUE_ID,WAS_IN_WATER};
  std::array<A,5> pools{owners.pool,states.pool,projectiles.pool,uids.pool,water.pool};
  for(unsigned i=0;i<5;i++){
   int64_t previous=-1;m(buckets+(keys[i]&7)*8,&previous,8);
   m.put(nodes+i*32,previous);m.put(nodes+i*32+8,keys[i]);m.put(nodes+i*32+16,pools[i]|Memory::tag);
   m.put<int64_t>(buckets+(keys[i]&7)*8,i);
  }
  m.put(registry+96,buckets|Memory::tag);m.put(registry+104,(buckets+64)|Memory::tag);
  m.put(registry+120,nodes|Memory::tag);m.put(registry+128,(nodes+5*32)|Memory::tag);
  A pages=m.alloc(8);entitySparse=m.alloc(8192);std::memset(m.bytes.data()+entitySparse-Memory::root,255,8192);
  m.put(pages,entitySparse|Memory::tag);m.put(registry+216,pages|Memory::tag);m.put(registry+224,(pages+8)|Memory::tag);
  header(local,localEntity,0x139f6ea0ULL,0);m.put(bind(m,uids,localEntity,0),int64_t(123));active.push_back(localEntity);publish();
 }
 void header(A actor,uint32_t entity,A type,unsigned index){
  m.put(actor,Memory::base+type);m.put(actor+8,registry|Memory::tag);m.put(actor+16,(registry+40)|Memory::tag);m.put(actor+24,entity);
  m.put(bind(m,owners,entity,index),actor|Memory::tag);m.put(entitySparse+(entity&2047)*4,(entity&0xfffc0000U)|(entity&2047));
 }
 uint32_t id(unsigned i){return 0x40002U+i;}
 void add(unsigned i,int64_t owner=123){
  assert(i<actors.size());actors[i]=m.alloc(1024);header(actors[i],id(i),PEARL_VTABLE,i+1);
  state[i]=bind(m,states,id(i),i);projectile[i]=bind(m,projectiles,id(i),i);
  m.put(actors[i]+552,state[i]|Memory::tag);
  m.put(state[i],State{{float(i),64,0},{float(i)-1,63,0},{1,1,.25f}});
  m.put(projectile[i]+8,owner);m.put(projectile[i]+280,.03f);m.put(projectile[i]+436,.99f);m.put(projectile[i]+440,.8f);
  active.push_back(id(i));publish();
 }
 void publish(){
  for(size_t i=0;i<active.size();i++)m.put(owners.packed+i*4,active[i]);
  m.put(owners.pool+40,(owners.packed+active.size()*4)|Memory::tag);
  size_t count=0;
  for(uint32_t entity:active)if(entity!=localEntity)m.put(projectiles.packed+count++*4,entity);
  m.put(projectiles.pool+40,(projectiles.packed+count*4)|Memory::tag);
 }
};
int main(){
 // A short flight can start and end between the journal's 3-second samples.
 // Empty frames must retain evidence that it was found and published.
 FlightEvidence evidence;
 evidence.observed({2,1,0,false},1,100);evidence.published(1,100);
 evidence.observed({},0,150);
 assert(evidence.totalCandidates==2&&evidence.totalTypes==1&&evidence.totalValid==1);
 assert(evidence.flightFrames==1&&evidence.publishedFrames==1&&evidence.peakCandidates==2&&evidence.peakPearls==1);
 assert(evidence.lastFlightPearls==1&&FlightEvidence::age(3150,evidence.lastValidAt)==3050);
 evidence.observed({1,1,1,false},0,4000);evidence.failed(7,4000);evidence.observed({},0,4050);
 assert(evidence.lastFlightReason==7&&evidence.lastValidAt==100&&evidence.lastTypedAt==4000);
 evidence.observed({1,1,0,false},1,4100);evidence.published(1,4100);
 assert(evidence.lastFlightReason==0&&evidence.publishedFrames==2&&evidence.lastPublishedAt==4100);
 assert(FlightEvidence::age(20,-1)==-1&&FlightEvidence::age(20,21)==-1);
 Fixture f;f.add(0);f.add(1,456);f.add(2,-1);
 auto v=view(f.m,f.registry);assert(v.states==f.states.pool&&v.projectiles==f.projectiles.pool);
 std::vector<Snapshot> values;unsigned checked=0;auto before=f.m.bytes;
 ScanStats scan{};f.m.reads=0;
 assert(collect(f.m,Memory::base,f.registry,f.local,values,checked,&scan)&&values.size()==3&&checked==3&&before==f.m.bytes);
 assert(scan.candidates==3&&scan.pearlTypes==3&&scan.stateFailures==0&&!scan.missingPool);
 unsigned projectileReads=f.m.reads;
 // A busy world's unrelated ActorOwner IDs must not consume the flight scan
 // budget. Their packed range is not traversed; owner/generation checks for
 // every actual projectile still use the sparse owner mapping.
 f.m.put(f.owners.pool+40,(f.owners.packed+MAX_ACTORS*4)|Memory::tag);
 f.m.put(f.owners.pool+48,(f.owners.packed+MAX_ACTORS*4)|Memory::tag);f.m.reads=0;
 assert(collect(f.m,Memory::base,f.registry,f.local,values,checked)&&values.size()==3&&checked==3&&f.m.reads==projectileReads);
 f.m.put(f.owners.pool+48,(f.owners.packed+512)|Memory::tag);f.publish();
 assert(values[0].owner==0&&values[1].owner==1&&values[2].owner==-1&&values[0].id==f.id(0));
 assert(values[0].position.y==64&&values[0].velocity.y==1&&std::abs(values[0].gravity-.03f)<1e-6);
 // Water uses the actual flag-component membership and actual liquid inertia.
 bind(f.m,f.water,f.id(0),0);assert(collect(f.m,Memory::base,f.registry,f.local,values,checked));
 assert(values[0].inWater&&values[0].drag==.8f);
 f.m.put<unsigned char>(f.projectile[0]+1,1);Snapshot value{};
 assert(pearl(f.m,Memory::base,v,f.actors[0],true,123,value)&&value.gravity==0);
 f.m.put<unsigned char>(f.projectile[0]+1,0);
 Vector p{1,2,3},motion{1,2,3};step(p,motion,.03f,.99f);
 assert(p.x==2&&p.y==4&&p.z==6&&std::abs(motion.y-1.95f)<1e-6); // gravity AFTER drag
 // A missing local UID never falsely labels an opponent's pearl as ours.
 f.m.put(f.uids.sparse+(Fixture::localEntity&2047)*4,uint32_t(0xffffffffU));
 assert(collect(f.m,Memory::base,f.registry,f.local,values,checked)&&values[0].owner==-1);
 bind(f.m,f.uids,Fixture::localEntity,0);
 // Fail closed on wrong actor type, registry, generation, owner or StateVector.
 A actor=f.actors[0],state=f.state[0];uint32_t entity=f.id(0);
 f.m.put(actor,Memory::base+0x139f76b0ULL);assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.put(actor,Memory::base+PEARL_VTABLE);
 f.m.put(actor+8,f.registry+8);assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.put(actor+8,f.registry);
 f.m.put(actor+24,entity+0x40000U);assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.put(actor+24,entity);
 f.m.put(f.entitySparse+(entity&2047)*4,uint32_t(0xffffffffU));assert(!pearl(f.m,Memory::base,v,actor,true,123,value));
 f.m.put(f.entitySparse+(entity&2047)*4,(entity&0xfffc0000U)|(entity&2047));
 f.m.put(bind(f.m,f.owners,entity,1),f.local);assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.put(bind(f.m,f.owners,entity,1),actor);
 f.m.put<unsigned char>(actor+617,1);assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.put<unsigned char>(actor+617,0);
 f.m.put(actor+552,state+4);assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.put(actor+552,state);
 State saved{};f.m(state,&saved,sizeof saved);State bad=saved;bad.velocity.y=NAN;f.m.put(state,bad);
 assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.put(state,saved);
 f.m.put(f.projectile[0]+280,NAN);assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.put(f.projectile[0]+280,.03f);
 f.m.put(f.projectile[0]+440,1.2f);assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.put(f.projectile[0]+440,.8f);
 // Concurrent tick/recycling never combines a new velocity with an old pose.
 f.m.changingState=state;assert(!pearl(f.m,Memory::base,v,actor,true,123,value));f.m.changingState=0;
 f.m.changingBounds=f.projectiles.pool+32;assert(!collect(f.m,Memory::base,f.registry,f.local,values,checked)&&values.empty());f.m.changingBounds=0;
 f.m.put(f.projectiles.pool+40,f.projectiles.packed+(MAX_ACTORS+1)*4);assert(!collect(f.m,Memory::base,f.registry,f.local,values,checked));f.publish();
 // Other-player pearls are included; stale payloads absent from active IDs are not.
 for(unsigned i=3;i<11;i++)f.add(i,456);
 before=f.m.bytes;assert(collect(f.m,Memory::base,f.registry,f.local,values,checked)&&values.size()==MAX_PEARLS&&checked==8&&before==f.m.bytes);
 for(auto& s:values)assert(s.id>=f.id(0)&&s.id<f.id(8));
 f.active={Fixture::localEntity,f.id(10),f.id(10)};f.publish();
 assert(collect(f.m,Memory::base,f.registry,f.local,values,checked)&&values.size()==1&&values[0].id==f.id(10)&&values[0].owner==1);
 // An unallocated/empty projectile vector is a valid idle world.
 f.m.put<A>(f.projectiles.pool+32,0);f.m.put<A>(f.projectiles.pool+40,0);f.m.put<A>(f.projectiles.pool+48,0);
 assert(collect(f.m,Memory::base,f.registry,f.local,values,checked)&&values.empty()&&checked==0);
 std::cout<<"PASS: exact pearl identity/state/physics, own and opponent owner IDs, liquid inertia, active-only bounded scan, stale generation and concurrent-read guards, no game writes\n";
}
