#pragma once
#include <cstdint>
namespace kulich_aim {
struct AimProfile {uint64_t offset;uint32_t words[8];};
constexpr uint64_t SET_ROT=0xfd8f694ULL;
constexpr uint64_t SET_HEAD=0xfdafa3cULL;
constexpr uint64_t POSITION_GET=0xfd8e62cULL;
constexpr uint64_t SHAPE_GET=0xfd9b14cULL;
constexpr uint64_t ROTATION_GET=0xfdaf960ULL;
constexpr AimProfile aimProfiles[]={
{SET_ROT,{0xf9411c08U,0xfd400020U,0xfd000100U,0xd65f03c0U,0xf9411c08U,0xbd000100U,0xd65f03c0U,0xf9411c08U}},
{SET_HEAD,{0xf9400809U,0x528e422aU,0x72b757caU,0xa943a12bU,0xcb0b0108U,0xd343fd08U,0x51000508U,0x8a0a010cU}},
{POSITION_GET,{0xf9411408U,0x2d400500U,0xbd400902U,0xd65f03c0U,0xf9411808U,0x1e2c1000U,0x2d430901U,0x1e222030U}},
{SHAPE_GET,{0xf9411808U,0xbd401900U,0xd65f03c0U,0x3949a408U,0x7100011fU,0x1a9f17e0U,0xd65f03c0U,0xf9400809U}},
{ROTATION_GET,{0xf9411c08U,0xbd400500U,0xd65f03c0U,0xf9411c28U,0xbd400500U,0xd65f03c0U,0xf9400809U,0x528e422aU}},
};
}
