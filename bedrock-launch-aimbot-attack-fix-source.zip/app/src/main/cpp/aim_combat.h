#pragma once
#include "aim_camera.h"
#include "aim_profile.h"
namespace kulich_aim {
// Slot 15 is INTERACT (transaction action 0); slot 16 is ATTACK (action 1).
// Both accept hit coordinates, but only the latter emits an attack request.
template<class Read> A attackBinding(Read& read,A base,A mode,A self){
 A table=pointer(read,plain(mode)),function=0;
 if(pointer(read,plain(mode)+8)!=plain(self))return 0;
 if(table==base+0x13d227d0ULL)function=base+ATTACK;
 else if(table==base+0x13d22900ULL)function=base+ATTACK_SURVIVAL;
 else return 0;
 return pointer(read,table+128)==function?function:0;
}
template<class Attack> bool dispatchAttack(Attack attack,void* mode,void* target,const float* position){
 return attack(mode,target,position);
}
class ClickClock {
 double next=-1;int setting=0;
public:
 void reset(){next=-1;setting=0;}
 bool due(int64_t now,int cps){
  cps=cps<10?10:cps>20?20:cps;
  if(next<0||setting!=cps||now<next-1000){setting=cps;next=double(now);}
  if(now+.00001<next)return false;
  double period=1000.0/cps;
  if(now-next>200)next=now;
  do{next+=period;}while(next<=now+.00001);
  return true;
 }
};
class AxisStabilizer {
 A actor=0;uint32_t entity=0;bool head=false,p=false,y=false;
public:
 void reset(){actor=0;p=y=false;}
 Angles apply(A address,uint32_t id,bool pointHead,Angles current,Angles desired){
  if(actor!=address||entity!=id||head!=pointHead){actor=address;entity=id;head=pointHead;p=y=false;}
  double dp=desired.pitch-current.pitch,dy=std::remainder(double(desired.yaw)-current.yaw,360.0);
  p=std::abs(dp)<=(p?.24:.12);y=std::abs(dy)<=(y?.24:.12);
  if(p)desired.pitch=current.pitch;
  if(y)desired.yaw=current.yaw;
  return desired;
 }
};
inline bool rayHit(Vec origin,const float q[4],const Box& box,double reach,Vec& hit){
 if(!valid(box)||!std::isfinite(reach)||reach<=0||reach>3.01)return false;
 double x=q[0],y=q[1],z=q[2],w=q[3],norm=x*x+y*y+z*z+w*w;
 if(!std::isfinite(norm)||norm<.90||norm>1.10)return false;
 Vec direction{-2*(x*z+y*w),2*(x*w-y*z),-1+2*(x*x+y*y)};
 double o[3]{origin.x,origin.y,origin.z},d[3]{direction.x,direction.y,direction.z},near=0,far=reach;
 for(int i=0;i<3;i++){
  if(!std::isfinite(o[i])||!std::isfinite(d[i]))return false;
  if(std::abs(d[i])<1e-8){if(o[i]<box.lo[i]||o[i]>box.hi[i])return false;continue;}
  double a=(box.lo[i]-o[i])/d[i],b=(box.hi[i]-o[i])/d[i];if(a>b)std::swap(a,b);
  near=std::fmax(near,a);far=std::fmin(far,b);if(near>far)return false;
 }
 if(near<=.001)return false;
 hit={origin.x+direction.x*near,origin.y+direction.y*near,origin.z+direction.z*near};return true;
}
}
