#pragma once
#include "aim_core.h"
#include <algorithm>

// Exact supported ARM64 image only. LocalPlayer virtual 144 is af5f724;
// its direct call af5f918 -> fa85d14 advances the local swing animation.
// That routine increments cycle+1032, obtains duration through fa8364c,
// normalizes phase+1028 and clears active+1077/cycle at the natural end.
// Advancing this cycle neither emits attacks nor changes a shared clock.
namespace kulich_swing {
using namespace kulich_aim;
constexpr A LOCAL_TABLE=0x139f6ea0ULL,UPDATE=0xaf5f724ULL,DURATION=0xfa8364cULL;
constexpr unsigned SLOT=144;
struct Profile {A offset;uint32_t words[8];};
constexpr Profile profiles[]={
 {UPDATE,{0xd10243ffU,0xa9067bfdU,0xf9003bf5U,0xa9084ff4U,0x910183fdU,0xd53bd055U,0xaa0003f3U,0xf94016a8U}},
 {0xfa85d14ULL,{0xa9be7bfdU,0xf9000bf3U,0x910003fdU,0x3950d408U,0xaa0003f3U,0x360002c8U,0xb9440a68U,0x3950d261U}},
 {DURATION,{0xa9bd7bfdU,0xf9000bf5U,0xa9024ff4U,0x910003fdU,0x2a0103f4U,0x52800061U,0xaa0003f3U,0x940ca8c4U}},
 {0xaf5f918ULL,{0x952c98ffU,0xaa1303e0U,0x954a5a0eU,0x91002260U,0x95497ce2U,0x36000440U,0xaa1303e0U,0x954a0d64U}}
};
template<class Read>bool profile(Read& read,A base){
 for(const auto& p:profiles){uint32_t code[8]{};if(!read(base+p.offset,code,sizeof code)||std::memcmp(code,p.words,sizeof code))return false;}
 return true;
}
struct Binding {A actor=0,registry=0,cycleAddress=0;uint32_t entity=0xffffffffU;int32_t cycle=0,duration=0;uint8_t hand=0;bool active=false;};
struct NativeDuration {
 A base;
 int32_t operator()(A actor,uint8_t hand)const{
#if defined(__aarch64__)
  return reinterpret_cast<int32_t(*)(void*,int)>(base+DURATION)(reinterpret_cast<void*>(actor),hand);
#else
  (void)actor;(void)hand;return 0;
#endif
 }
};
template<class Read,class Duration>
bool resolve(Read& read,A base,A client,A taggedSelf,Binding& out,Duration duration){
 out={};client=plain(client);A self=plain(taggedSelf),weak[3]{};
 if(pointer(read,client)!=base+0x1388fe70ULL||pointer(read,self)!=base+LOCAL_TABLE||pointer(read,self+3240)!=client||
    !read(client+576,weak,sizeof weak)||plain(weak[0])<4096||!plain(weak[1]))return false;
 A registry=plain(weak[0]);uint32_t entity=uint32_t(weak[2]);
 if((entity&0x3ffffU)==0x3ffffU||sparse(read,registry+216,entity)<0)return false;
 A owner=component(read,pool(read,registry,OWNER),entity,8),header[4]{};
 if(!owner||pointer(read,owner)!=self||!read(self,header,sizeof header)||
    plain(header[1])!=registry||plain(header[2])!=registry+40||uint32_t(header[3])!=entity)return false;
 uint8_t active=0,hand=0,removed=1;int32_t cycle=0;
 if(!read(self+617,&removed,1)||removed||!read(self+1077,&active,1)||active>1||
    !read(self+1076,&hand,1)||(active&&hand>1)||!read(self+1032,&cycle,4)||cycle< -1||cycle>255)return false;
 int32_t total=active?duration(taggedSelf,hand):0;
 if(active&&(total<1||total>256||cycle>=total))return false;
 A currentWeak[3]{},currentHeader[4]{};int32_t currentCycle=0;uint8_t currentHand=255,currentActive=0;
 if(!read(client+576,currentWeak,sizeof currentWeak)||std::memcmp(weak,currentWeak,sizeof weak)||
    !read(self,currentHeader,sizeof currentHeader)||std::memcmp(header,currentHeader,sizeof header)||
    pointer(read,owner)!=self||sparse(read,registry+216,entity)<0||
    !read(self+1032,&currentCycle,4)||currentCycle!=cycle||
    !read(self+1076,&currentHand,1)||currentHand!=hand||!read(self+1077,&currentActive,1)||currentActive!=active||
    !read(self+617,&removed,1)||removed)return false;
 out={taggedSelf,registry,taggedSelf+1032,entity,cycle,total,hand,bool(active)};return true;
}
template<class Read>bool resolve(Read& read,A base,A client,A taggedSelf,Binding& out){
 return resolve(read,base,client,taggedSelf,out,NativeDuration{base});
}
class Clock {
 A actor=0,registry=0;uint32_t entity=0xffffffffU;
 int setting=100,fraction=0;
public:
 void reset(){actor=registry=0;entity=0xffffffffU;setting=100;fraction=0;}
 int extra(const Binding& b,int value){
  value=std::max(100,std::min(200,value));
  if(value==100||b.cycle< -1||(b.active&&(b.duration<1||b.duration>256||b.cycle>=b.duration))){reset();return 0;}
  if(actor!=b.actor||registry!=b.registry||entity!=b.entity||setting!=value){
   reset();actor=b.actor;registry=b.registry;entity=b.entity;setting=value;
  }
  // Clock cadence follows local callbacks even while not swinging. Otherwise
  // a 6-tick swing at x1.10 could reset before its first fractional bonus.
  fraction+=value-100;
  int count=fraction/100;fraction%=100;
  if(!b.active)return 0;
  return std::max(0,std::min(count,b.duration-1-b.cycle));
 }
};
// This is committed local animation progress, not a temporary input modifier.
// The native update must own interpolation and completion; never restore over
// its phase/output or synthesize a swing/attack when inactive.
template<class Lookup,class Write,class Original>
bool invoke(Clock& clock,Lookup lookup,Write write,Original original,int factor,bool enabled){
 Binding binding{};bool changed=false;
 if(enabled&&factor>100&&lookup(binding)){
  int extra=clock.extra(binding,factor);
  if(extra){changed=write(binding.cycleAddress,binding.cycle+extra);if(!changed)clock.reset();}
 }else clock.reset();
 try{original();}catch(...){clock.reset();throw;}
 return changed;
}
}
