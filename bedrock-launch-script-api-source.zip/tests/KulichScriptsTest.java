import dev.custom.bedrockgui.*;
import java.nio.file.*;
import java.io.*;
import java.util.*;

public final class KulichScriptsTest {
    private static void require(boolean value){if(!value)throw new AssertionError();}
    private static final class Host implements KulichScripts.Host {
        Map<String,KulichScripts.Toggle> toggles=new LinkedHashMap<>();List<String> logs=new ArrayList<>(),failed=new ArrayList<>();
        public void register(String id,String name,String description,KulichScripts.Toggle cb){require(!name.isEmpty());toggles.put(id,cb);}
        public void log(String value){logs.add(value);}
        public Object fast(String operation,Object value){return operation.equals("ready")?false:"test status";}
        public void failed(String id){failed.add(id);}
    }
    public static void main(String[] args)throws Exception {
        Path root=Path.of(args[0]);String bootstrap=Files.readString(root.resolve("app/src/main/assets/kulich-api.js"));
        Host host=new Host();KulichScripts scripts=new KulichScripts(host);
        scripts.load(bootstrap,Files.readString(root.resolve("examples/api-demo.js")),"demo.js");
        require(host.toggles.size()==1);int before=host.logs.size();scripts.tick();require(host.logs.size()==before);
        host.toggles.get("script_api_demo").set(true);
        for(int i=0;i<5;i++)scripts.tick();require(host.logs.stream().anyMatch(s->s.contains("API работает")));
        host.toggles.get("script_api_demo").set(false);before=host.logs.size();scripts.tick();require(host.logs.size()==before);
        scripts.load(bootstrap,"defineModule({id:'options'}, {n:{type:'number',def:3,min:1,max:10}}, function(c){c.onEnable(function(){c.options.n.value=11;});});","options.js");
        try{host.toggles.get("script_options").set(true);throw new AssertionError();}catch(IllegalStateException expected){}
        scripts.load(bootstrap,"defineModule({id:'isolation'}, {},function(c){if(typeof Packages!=='undefined'||typeof java!=='undefined')throw Error('Java visible');if(c.capabilities.auction||c.capabilities.packets)throw Error('Unsupported capability');});","isolation.js");
        require(host.toggles.containsKey("script_isolation"));
        scripts.load(bootstrap,"defineModule({id:'loop'}, {},function(c){c.on('ui_tick',function(){while(true){};});});","loop.js");
        host.toggles.get("script_loop").set(true);scripts.tick();require(host.failed.contains("script_loop"));
        int count=host.toggles.size();scripts.load(bootstrap,"defineModule({id:'partial'}, {},function(c){});throw Error('bad file');","bad.js");require(host.toggles.size()==count);
        scripts.load(bootstrap,"defineModule({id:'api_demo'}, {},function(c){});","duplicate.js");require(host.toggles.size()==count);
        scripts.close();
        Path temp=Files.createTempDirectory("kulich-import");
        try {
            String source=Files.readString(root.resolve("examples/api-demo.js"));
            String a=ScriptFiles.store(temp.toFile(),new ByteArrayInputStream(source.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            String b=ScriptFiles.store(temp.toFile(),new ByteArrayInputStream(source.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
            require(a.equals(b)&&ScriptFiles.list(temp.toFile()).length==1);
            try{ScriptFiles.store(temp.toFile(),new ByteArrayInputStream("import x from '@protohax/userscript'".getBytes()));throw new AssertionError();}catch(IOException expected){}
            try{ScriptFiles.store(temp.toFile(),new ByteArrayInputStream(new byte[ScriptFiles.MAX_BYTES+1]));throw new AssertionError();}catch(IOException expected){}
            Path outside=temp.resolveSibling("outside-kulich-script");Files.writeString(outside,"secret");
            Path link=temp.resolve("script-"+"f".repeat(64)+".js");Files.createSymbolicLink(link,outside);
            require(ScriptFiles.list(temp.toFile()).length==1);Files.delete(link);Files.delete(outside);
            Path backup=temp.resolve("archived");
            require(ScriptFiles.archive(temp.toFile(),backup.toFile())==1);
            require(ScriptFiles.list(temp.toFile()).length==0&&ScriptFiles.list(backup.toFile()).length==1);
        }finally{try(var paths=Files.walk(temp)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
        System.out.println("PASS: real Rhino module lifecycle/demo, settings bounds, no Java globals, truthful capabilities, timeout stop, atomic registration, duplicate rejection, bounded/deduplicated imports, symlink rejection");
    }
}
