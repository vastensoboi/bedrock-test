# Own-player airborne steps, 0.80

## What 0.79 shows

The supplied phone journal reports 743 completed extra steps, 743 observed
extra native inputs and 743 locally verified inputs. All 25 backend snapshots
show no fault, no snapshot/input mismatch, no rejected callsite and no worker
submission. Local guards are passing; server acceptance is not established.

The retained correction reports contain 104 unique packet161 comparisons,
80 for extra inputs and 24 for ordinary inputs. All are coherent locally.
Thirteen extra inputs have server position matching their exact pre-step
position within 0.00001 blocks, with delta matching within 0.00000011. Their
submitted packet instead exactly matches the post-replay state. Other rows
show accumulated disagreement. This is evidence about native step timing or
semantics; it does not identify a private server rule or prove a fix.

Air acceleration was explicitly excluded in 0.79. One 3.228-second journal
interval contains 64 ordinary inputs, zero extra steps and 64 ineligible
frames, with `not-grounded`. The fallback air-speed multiplier is also bypassed
when the own-frame backend is installed, so jumping has no acceleration path.

## New air path

The same append, native replay and native producer can now operate on an
explicitly classified normal-air actor after the jump button is released.
The ordinary native tick initiates the jump. Extra steps continue its existing
vertical motion; they never manufacture a jump request or change the impulse,
velocity, gravity constant, world clock or another actor's cadence.

Air requires known OnGround absence, normal AirTravel presence and GroundTravel
absence. WaterTravel, gliding, flying and pending native jump requests exclude
extra work. Registry lookup failure or unreadable sparse storage is unknown,
never proof of absence. The sole-own replay/history, no-passenger, current
ordinary submission, clean history, empty movement markers and no-active-use
requirements remain. The captured travel/request state and binding are checked
again before append; append must preserve them as well as actor pose.

Released input is checked directly as well as through MobIsJumping: native
JumpInputSystem reads primary32 bit5 at MoveInput+0 and auxiliary16 bits4/5 at
MoveInput+96. All three terms must be zero, preventing a newly updated button
from slipping through a still-absent Jumping component. Their native read and
call-site instructions have four additional exact profiles. No semantic names
are assigned to the auxiliary flags and no input bit is cleared or rewritten.

Append validation also accepts acknowledged old-record pruning. It verifies a
single new final tick and the same owner/history, not a nondecreasing record
count. The immediately revalidated binding is the baseline, so legitimate
trimming cannot be mistaken for a failed append after its offset is committed.

Holding jump still excludes extra work on both ground and air. Known absence
of request components alone does not establish that saved native MoveInput
contains no initial-press semantics. A replay can recreate requests, including
when crossing landing. Full held-button acceleration remains unverified; this
build supports the released-button airborne subset.

## Reporting and validation

`extraGroundSteps` and `extraAirSteps` count completed native steps by their
starting motion. `verifiedAirInputs` counts coherent observed extra packets
from air steps. The retained correction trace includes `stepMode=ground|air`;
missing phase information remains explicitly unavailable. `jump-held`,
`pending-jump-request`, `unsupported-travel` and `locomotion-unavailable`
distinguish rejected candidates. A successful append that unexpectedly changes
motion faults as `snapshot-changed-locomotion`, retaining its committed offset.

The added host model covers takeoff, released air, landing, held-button and
pending-request rejection, conflicting selectors, tagged native lookup and
unreadable-versus-absent components. The complete runner now has 50 suites.
Strict host/ARM64-conditional compilation, Android/Rhino Java type checking,
sanitizers and 37 offline native profiles/12 table bindings supplement those tests. They
do not execute Minecraft or an APK and cannot confirm airborne physics or
remote-server acceptance.

For the phone check, use a loaded world, enable Timer, press and release jump
and export the journal after landing. The new air counters distinguish a
rejected phase from a completed extra airborne step. Server rollbacks remain
unresolved; a ground or air counter increasing is not an acknowledgement.
