package dev.custom.bedrockgui;
import java.util.*;
/** Defaults migrated from the user-provided script; no learned market estimates yet. */
public final class AutoBuyDefaultRules {
 public static final String[] BLOCKED=new String[]{"цербер","сфинкс","кронос","илиад","артемид"};
 private AutoBuyDefaultRules(){}
 public static List<AutoBuyMatcher.Rule> rules(){return Arrays.asList(
new AutoBuyMatcher.Rule("сфера полубога","сфера полубога","",7000000L,0.43,3000000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("сфера виверны","сфера виверны","",130000L,0.45,60000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("талисман ориона","талисман ориона","",600000L,0.5,180000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("талисман фантома","талисман фантома","",2500000L,0.45,1100000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("талисман властелина","талисман властелина","",16000000L,0.45,7200000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("талисман карателя","талисман карателя","",0L,0.5,300000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("амулет дуэли","амулет дуэли","",4100000L,0.45,1800000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("НЕРУШИМКА","НЕРУШИМКА","",1800000L,0.5,1100000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("меч властелина","меч властелина","sword",780000L,0.5,390000L,new String[]{"острота"},new int[]{7},new String[]{"вампиризм","иссушение","крит","противоядие","опытный","отравление"},2),
new AutoBuyMatcher.Rule("шлем властелина","шлем властелина","armor",580000L,0.45,290000L,new String[]{"защита","броненосец","поглощение"},new int[]{5,1,1},new String[]{},0),
new AutoBuyMatcher.Rule("нагрудник властелина","нагрудник властелина","armor",580000L,0.45,290000L,new String[]{"защита","броненосец","поглощение"},new int[]{5,1,1},new String[]{},0),
new AutoBuyMatcher.Rule("поножи властелина","поножи властелина","armor",580000L,0.45,290000L,new String[]{"защита","броненосец","поглощение"},new int[]{5,1,1},new String[]{},0),
new AutoBuyMatcher.Rule("ботинки властелина","ботинки властелина","armor",580000L,0.45,290000L,new String[]{"защита","броненосец","поглощение"},new int[]{5,1,1},new String[]{},0),
new AutoBuyMatcher.Rule("","нерушимая броня","armor",2000000L,0.5,1000000L,new String[]{"защита","нерушимость","броненосец","поглощение"},new int[]{5,1,1,1},new String[]{},0),
new AutoBuyMatcher.Rule("battlepass","battlepass","",7000000L,0.43,3000000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("сила iii","сила iii","",1000000L,0.45,450000L,new String[]{},new int[]{},new String[]{},0),
new AutoBuyMatcher.Rule("черепашка","черепашка","",500000L,0.45,225000L,new String[]{},new int[]{},new String[]{},0)
);}
}