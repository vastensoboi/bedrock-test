package dev.custom.bedrockgui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Read only named content logs in this app's storage; never inspect account files. */
public final class GameContentLogs {
    private static final int LIMIT = 256 * 1024;
    private GameContentLogs() {}

    public static File[] roots(File data, File files, File[] external) {
        List<File> bases = new ArrayList<>();
        if(data!=null)bases.add(data);
        if(files!=null)bases.add(files);
        if(external!=null)for(File root:external)if(root!=null)bases.add(root);
        List<File> ordered = new ArrayList<>();
        // Check expected log directories before a bounded traversal can be
        // consumed by worlds, caches or installed resource packs.
        for(File base:bases){
            ordered.add(new File(base,"games/com.mojang/logs"));
            ordered.add(new File(base,"logs"));
        }
        ordered.addAll(bases);
        return ordered.toArray(new File[0]);
    }

    public static String read(File[] roots) {
        List<File> logs = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        int[] budget = {2048};
        for (File root : roots) {
            if (root == null) continue;
            try { scan(root.getCanonicalFile(), root.getCanonicalFile(), 0, budget, visited, logs); }
            catch (IOException | SecurityException ignored) {}
        }
        logs.sort(Comparator.comparingLong(File::lastModified).reversed());
        StringBuilder output = new StringBuilder();
        int remaining = LIMIT, count = 0;
        for (File file : logs) {
            if (remaining <= 0 || count == 3) break;
            try (RandomAccessFile input = new RandomAccessFile(file, "r")) {
                long length = input.length();
                int size = (int)Math.min(Math.min(length, 96 * 1024), remaining);
                input.seek(length - size);
                byte[] bytes = new byte[size];input.readFully(bytes);
                output.append("\n--- ").append(file.getName()).append("; modified=")
                        .append(file.lastModified()).append("; tailBytes=").append(size).append(" ---\n")
                        .append(new String(bytes, StandardCharsets.UTF_8));
                remaining -= size;count++;
            } catch (IOException | SecurityException ignored) {}
        }
        return count == 0 ? "Журналы контента не найдены в доступных каталогах приложения. " +
                "В настройках Minecraft в разделе «Создатель» можно включить запись журнала контента в файл перед повторным подключением." : output.toString();
    }

    private static void scan(File file, File root, int depth, int[] budget,
                             Set<String> visited, List<File> logs) throws IOException {
        if (depth > 7 || budget[0]-- <= 0) return;
        File canonical = file.getCanonicalFile();
        // Reject symlinks, including ones pointing to private account data elsewhere.
        if (!file.getAbsoluteFile().equals(canonical) ||
                !canonical.toPath().startsWith(root.toPath()) || !visited.add(canonical.getPath())) return;
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) {
                if (budget[0] <= 0) break;
                scan(child, root, depth + 1, budget, visited, logs);
            }
        } else if (file.isFile()) {
            String name = file.getName().toLowerCase(Locale.ROOT);
            if ((name.startsWith("contentlog") || name.startsWith("content_log")) &&
                    (name.endsWith(".txt") || name.endsWith(".log"))) logs.add(file);
        }
    }
}
