package dev.custom.bedrockgui;

/** Exact-build game-thread placement bridge; uses only the selected held block. */
public final class BlockTrapBridge {
    private static volatile boolean ready,enabled;
    private static volatile String problem="";
    private static int rangeTenths=40,intervalTicks=3;
    private BlockTrapBridge(){}
    private static native String install(long base,long client);
    private static native void enable(boolean value);
    private static native void pulse(boolean active);
    private static native void settings(int rangeTenths,int intervalTicks);
    private static native String status();
    public static synchronized void prepare(long base,long client){
        if(!FastExpBridge.isReady())return;
        try{
            String error=install(base,client);
            if(error==null||!error.isEmpty())throw new IllegalStateException(error==null?"No native install result":error);
            settings(rangeTenths,intervalTicks);ready=true;problem="";pulse(enabled);
            GameRuntime.log("Block Trap: selected-block placement bridge prepared");
        }catch(RuntimeException|LinkageError error){
            if(ready)try{enable(false);pulse(false);}catch(RuntimeException|LinkageError ignored){}
            ready=false;enabled=false;problem=error.toString();GameRuntime.log("Block Trap unavailable: "+error);
        }
    }
    public static boolean isReady(){return ready;}
    public static boolean isEnabled(){return enabled;}
    public static boolean hasProblem(){return !problem.isEmpty();}
    public static synchronized void configure(int range,int interval){
        rangeTenths=Math.max(20,Math.min(50,range));intervalTicks=Math.max(2,Math.min(10,interval));
        if(ready)settings(rangeTenths,intervalTicks);
    }
    public static synchronized void setEnabled(boolean value){
        if(value&&!ready)throw new IllegalStateException("Нужен загруженный мир");
        if(ready){settings(rangeTenths,intervalTicks);enable(value);pulse(value);}
        enabled=value;GameRuntime.log("Block Trap: enabled="+value);
    }
    public static void heartbeat(){if(ready)pulse(enabled);}
    public static String describe(){
        if(!ready)return "Block Trap ещё не подключён к миру"+(problem.isEmpty()?"":"\n"+problem);
        try{String report=status();return (enabled?liveState(report):"Выключен")+"\n"+report;}
        catch(RuntimeException|LinkageError error){
            ready=false;enabled=false;problem=error.toString();GameRuntime.log("Block Trap status unavailable: "+error);
            return "Статус Block Trap недоступен; причина в журнале\n"+problem;
        }
    }
    private static String liveState(String report){
        int reason=-1;
        if(report!=null)for(String field:report.split("[\\s;]+"))if(field.startsWith("reason=")){
            try{reason=Integer.parseInt(field.substring(7));}catch(NumberFormatException ignored){}
        }
        switch(reason){
            case 0:return "Игра приняла попытку размещения";
            case 1:return "Ожидаю обновление интерфейса";
            case 2:return "Войди в мир для Block Trap";
            case 3:return "Возьми обсидиан или обычный твёрдый блок";
            case 4:return "Не удалось проверить игроков";
            case 5:return "Не удалось получить блоки мира";
            case 6:return "Рядом нет подходящей цели";
            case 7:return "Игра отклонила размещение";
            case 8:return "Ожидаю появления блока";
            case 9:return "Цель или блок изменились; проверяю заново";
            case 10:return "Проверка мира заняла слишком долго; повторяю";
            case 11:return "Проверка видимости опоры недоступна";
            case 12:return "Нет свободной клетки с подходящей видимой опорой";
            default:return "Block Trap включён · выбери блок в руке";
        }
    }
}
