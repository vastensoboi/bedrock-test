package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

/** Prepare on a worker; changing windows never changes the requested toggle. */
public final class AimbotController {
    private final Activity activity;private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean requested,preparing,disposed;private int generation;
    private String message="Выключен";
    public AimbotController(Activity activity){this.activity=activity;}
    public boolean isEnabled(){return requested;}
    public String status(){return !requested||!AimbotBridge.isReady()?message:AimbotBridge.describe();}
    public String displayStatus(){return status().split("\n",2)[0];}
    public void setEnabled(boolean value){
        if(disposed)return;generation++;requested=value;handler.removeCallbacksAndMessages(null);
        if(!value){AimbotBridge.setEnabled(false);message="Выключен";return;}
        if(AimbotBridge.isReady()){AimbotBridge.setEnabled(true);return;}
        message="Подключаю наведение. Нужен загруженный мир";prepare(generation);
    }
    private void prepare(int epoch){
        if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
        if(preparing||!GameEngineProbe.begin()){handler.postDelayed(()->prepare(epoch),400);return;}
        preparing=true;
        Thread worker=new Thread(()->{
            try{GameEngineProbe.run();}
            catch(RuntimeException|LinkageError error){GameRuntime.log("Aimbot preparation failed: "+error);}
            finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{
                preparing=false;if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
                if(GameEngineProbe.playerFound()&&AimbotBridge.isReady()){
                    try{AimbotBridge.setEnabled(true);}
                    catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить наведение. Причина в журнале";GameRuntime.log("Aimbot enable failed: "+error);}
                }
                else if(GameEngineProbe.playerFound()){requested=false;message="Наведение не подключилось. Причина в журнале";}
                else{message="Войди в мир: подключение повторится автоматически";handler.postDelayed(()->prepare(epoch),8000);}
            });
        },"aimbot-prepare");worker.setDaemon(true);worker.start();
    }
    public void dispose(){setEnabled(false);disposed=true;handler.removeCallbacksAndMessages(null);}
}
