#pragma once
#include <array>
#include <cstdint>
#include <cstring>
namespace kulich_transaction {
using A=uint64_t;
inline A plain(A a){return a&0x00ffffffffffffffULL;}
// Java-validated immutable token, checked again on the game thread.
using Fields=std::array<A,22>;
struct Transfer {A manager=0,source=0,destination=0;int netId=0,count=0,slot=0,target=0,destinationType=29;bool take=false;};
template<class Read> Transfer validate(Read read,A base,const Fields& f){
 Transfer out;auto ptr=[&](A at){A v=0;return read(plain(at),&v,8)?plain(v):0;};
 auto byte=[&](A at){uint8_t v=0;return read(plain(at),&v,1)?int(v):-1;};
 auto integer=[&](A at){int32_t v=-1;return read(plain(at),&v,4)?v:-1;};
 auto member=[&](A wanted,A model){A node=ptr(f[2]+192);for(int i=0;node&&i<32;i++){if(node==wanted)return ptr(node+40)==model;node=ptr(node);}return false;};
 int slots=int(f[6]),slot=int(f[7]),dest=int(f[14]);
 if(!((slots==54&&(slot<45||slot==49))||(slots==27&&(slot==10||slot==16)))||slot<0||dest<0||dest>=27||f[9]==0||f[9]>255)return out;
 if(ptr(f[0])!=base+0x139f6ea0ULL||ptr(f[0]+3240)!=f[1]||ptr(f[0]+0x578)!=f[2]||ptr(f[1])!=base+0x1388fe70ULL||ptr(f[2])!=base+0x137e8f20ULL)return out;
 if(!member(f[3],f[4])||!member(f[11],f[12]))return out;
 if(ptr(f[4])!=base+0x13d34298ULL||ptr(f[4]+216)!=f[5]||ptr(f[4]+224)!=f[5]+slots*152ULL)return out;
 if(ptr(f[12])!=base+0x13d341b0ULL||ptr(f[12]+216)!=f[13]||ptr(f[12]+224)!=f[13]+27*152ULL)return out;
 A source=f[5]+slot*152ULL,destination=f[13]+dest*152ULL;
 auto matches=[&](A stack,A tag,A count,A item){return ptr(stack)==base+0x13d95ff8ULL&&ptr(stack+16)==tag&&byte(stack+34)==int(count)&&ptr(ptr(stack+8))==item;};
 if(!matches(source,f[8],f[9],f[10])||ptr(destination)!=base+0x13d95ff8ULL||byte(destination+34)!=0)return out;
 if(f[15]&&(!matches(f[5]+13*152ULL,f[15],f[16],f[17])||ptr(f[5]+16*152ULL+16)!=f[18]))return out;
 int sourceType=integer(source+144),sourceId=integer(source+128),targetType=integer(destination+144),targetId=integer(destination+128);
 if(sourceType!=0||sourceId<=0||!(targetType==-1||(targetType==0&&targetId==0)))return out;
 bool take=!(slots==54&&slot==49);
 if(take){
  // Exact-build cursor model: base manager creates PlayerUIContainerModel(enum 59),
  // size 1, whose UI backing index is 0. Never take onto an occupied cursor.
  if(!member(f[19],f[20])||ptr(f[20])!=base+0x13d34468ULL||byte(f[20]+40)!=59||
     ptr(f[20]+216)!=f[21]||ptr(f[20]+224)!=f[21]+152||ptr(f[21])!=base+0x13d95ff8ULL||byte(f[21]+34)!=0)return out;
  int cursorType=integer(f[21]+144),cursorId=integer(f[21]+128);
  if(!(cursorType==-1||(cursorType==0&&cursorId==0)))return out;
  destination=f[21];
 }
 A taggedManager=0;if(!read(f[0]+2592,&taggedManager,8))return out;
 A manager=plain(taggedManager);
 if(ptr(manager)!=base+0x13d21c98ULL||ptr(manager+16)!=f[0]||byte(manager+8)!=1||ptr(manager+96)!=0)return out;
 out.manager=taggedManager;out.source=source;out.destination=destination;out.netId=sourceId;out.count=int(f[9]);out.slot=slot;out.take=take;out.target=take?0:dest+9;out.destinationType=take?59:29;return out;
}
inline std::array<unsigned char,40> descriptor(int type,int slot,int id,int variant){
 std::array<unsigned char,40> out{};out[0]=uint8_t(type);out[12]=uint8_t(slot);std::memcpy(out.data()+16,&id,4);std::memcpy(out.data()+32,&variant,4);return out;
}
}
