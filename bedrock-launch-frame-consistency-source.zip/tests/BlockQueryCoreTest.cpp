#include "../app/src/main/cpp/block_query_core.h"
#include <cassert>
#include <map>
#include <vector>
#include <iostream>
using namespace kulich_block_query;
struct Memory {
 std::map<A,std::vector<unsigned char>> data;A change=0;unsigned reads=0;
 template<class T>void put(A at,T value){auto& bytes=data[plain(at)];bytes.resize(sizeof value);std::memcpy(bytes.data(),&value,sizeof value);}
 bool operator()(A at,void* out,size_t n){
  auto it=data.find(plain(at));if(it==data.end()||it->second.size()<n)return false;
  std::memcpy(out,it->second.data(),n);if(plain(at)==change&&++reads>1)static_cast<unsigned char*>(out)[0]^=8;return true;
 }
};
int main(){
 constexpr A base=0x10000000ULL,sourceAddress=0x20000000ULL,block=0x20001000ULL,type=0x20002000ULL,tag=0xab00000000000000ULL;
 Memory read;read.put(sourceAddress,base+kulich_world_collision::SOURCE_TABLE);read.put(base+kulich_world_collision::SOURCE_TABLE+51*8,base+kulich_world_collision::CLIP);
 read.put(base+kulich_world_collision::SOURCE_TABLE+16,base+GET_BLOCK);read.put<int16_t>(sourceAddress+64,320);read.put<int16_t>(sourceAddress+66,-64);
 assert(source(read,base,sourceAddress|tag,{0,-64,0})&&source(read,base,sourceAddress|tag,{0,319,0}));
 assert(!source(read,base,sourceAddress,{0,-65,0})&&!source(read,base,sourceAddress,{0,320,0})&&!source(read,base,sourceAddress,{32000001,0,0}));
 read.put(block,base+BLOCK_TABLE);read.put(block+104,type|tag);read.put(type,base+AIR_TABLE);
 Cell cell;auto before=read.data;
 assert(inspect(read,base,block|tag,cell)==Result::Air&&cell.block==(block|tag)&&cell.type==(type|tag)&&before==read.data);
 read.put(type,base+0x13e10000ULL);assert(inspect(read,base,block,cell)==Result::Block);
 assert(!inertSupport(read,base,cell));
 for(A table:INERT_TABLES){read.put(type,base+table);assert(inspect(read,base,block,cell)==Result::Block&&inertSupport(read,base,cell));}
 read.put(type,base+0x13ddd258ULL);assert(inspect(read,base,block,cell)==Result::Block&&!inertSupport(read,base,cell)); // chest
 read.put(type,base+0x13e56128ULL);assert(inspect(read,base,block,cell)==Result::Block&&!inertSupport(read,base,cell)); // slab
 // ItemStack's virtual56 wrapper returns a BlockType, not a Block state.
 // Never reinterpret that object as the source-query result. The actual
 // renderer state getter follows BlockType+512 to a distinct Block object.
 read.put(type,base+0x13db7a28ULL);read.put(type+512,block|tag);
 assert(inspect(read,base,type|tag,cell)==Result::Unavailable);
 A renderedState=rawPointer(read,type+512);
 assert(renderedState==(block|tag)&&inspect(read,base,renderedState,cell)==Result::Block&&inertSupport(read,base,cell));
 read.put(type,A(0));assert(inspect(read,base,block,cell)==Result::Unavailable);read.put(type,base+AIR_TABLE);
 read.put(block,base+BLOCK_TABLE+8);assert(inspect(read,base,block,cell)==Result::Unavailable);read.put(block,base+BLOCK_TABLE);
 read.change=block+104;assert(inspect(read,base,block,cell)==Result::Unavailable);read.change=0;
 read.put(base+kulich_world_collision::SOURCE_TABLE+16,base+GET_BLOCK+4);assert(!source(read,base,sourceAddress,{0,0,0}));
 std::cout<<"PASS: exact BlockSource query bindings, world Y bounds, typed AirBlock classification, distinct held BlockType versus Block state, conservative inert-support list, tagged pointers and stable read-only state\n";
}
