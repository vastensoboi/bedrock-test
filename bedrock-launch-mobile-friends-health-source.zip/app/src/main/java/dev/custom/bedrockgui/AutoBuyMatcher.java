package dev.custom.bedrockgui;

import java.math.BigDecimal;
import java.util.*;
import java.util.regex.*;

/** Pure read-only rule evaluation; never sends a click or purchase request. */
public final class AutoBuyMatcher {
    public static final class Rule {
        public final String name,label,kind;public final long market,cap;public final double ratio;
        private final String normalizedName;
        public final String[] need,any;public final int[] levels;public final int anyMin;
        public Rule(String name,String label,String kind,long market,double ratio,long cap,String[] need,int[] levels,String[] any,int anyMin){
            this.name=name;this.label=label;this.kind=kind;this.market=market;this.ratio=ratio;this.cap=cap;
            this.normalizedName=lower(name);
            this.need=need;this.levels=levels;this.any=any;this.anyMin=anyMin;
        }
        public long priceLimit(int count){
            if(market<=0||count<1||count>255)return 0;
            return BigDecimal.valueOf(market).multiply(BigDecimal.valueOf(count)).multiply(BigDecimal.valueOf(ratio)).min(BigDecimal.valueOf(cap)).longValue();
        }
    }
    public static final class Verdict {
        public boolean candidate,accepted;public String reason="не из списка",seller="",rule="";public long price,limit;
        public String log(){return (accepted?"MATCH":"SKIP")+" rule="+rule+" price="+price+" limit="+limit+" reason="+reason;}
    }
    private static final Pattern PRICE=Pattern.compile("^\\s*Цена:\\s*([0-9][0-9 ,.\\u00a0\\u202f]*)\\$\\s*$");
    private static final Pattern SELLER=Pattern.compile("^\\s*Игрок:\\s*([A-Za-z0-9_]{3,20})\\s*$");
    private static final Pattern FORMAT=Pattern.compile("§.");
    private static String clean(String value){return value.indexOf('§')<0?value.trim():FORMAT.matcher(value).replaceAll("").trim();}
    private static String lower(String value){return clean(value).toLowerCase(Locale.ROOT);}
    private static long money(String value){
        String s=value.trim().replace('\u00a0',' ').replace('\u202f',' ');String[] groups=s.split("[ ,.]");
        if(groups.length>1){if(groups[0].length()<1||groups[0].length()>3)return 0;for(int i=1;i<groups.length;i++)if(groups[i].length()!=3)return 0;
            Set<Character> separators=new HashSet<>();for(char c:s.toCharArray())if(c==' '||c==','||c=='.')separators.add(c);if(separators.size()!=1)return 0;}
        try{long n=Long.parseLong(s.replaceAll("[ ,.]",""));return n>0&&n<=9007199254740991L?n:0;}catch(NumberFormatException error){return 0;}
    }
    private static int level(String text,String name,Map<Integer,Integer> ench){
        int id=name.equals("защита")?0:name.equals("острота")?9:name.equals("неразрушимость")?17:name.equals("починка")?26:-1;
        int result=id<0?0:ench.getOrDefault(id,0);
        Pattern p=Pattern.compile("(?<![а-яёa-z])"+Pattern.quote(name)+"(?![а-яёa-z])(?:[\\s:]+([ivxlc]+|[0-9]{1,3})(?![а-яёa-z0-9]))?");
        Matcher m=p.matcher(text);
        while(m.find()){
            String v=m.group(1);int n=1;
            if(v!=null){try{n=Integer.parseInt(v);}catch(NumberFormatException ignored){n=0;String chars="ivxlc";int[] values={1,5,10,50,100};for(int i=0;i<v.length();i++){int a=values[chars.indexOf(v.charAt(i))];int b=i+1<v.length()?values[chars.indexOf(v.charAt(i+1))]:0;n+=a<b?-a:a;}}}
            result=Math.max(result,n);
        }
        return result;
    }
    public static Verdict evaluate(String name,List<String> lore,int count,String kind,Map<Integer,Integer> ench,List<Rule> rules){
        Verdict out=new Verdict();String normalized=lower(name);
        Rule matched=null;
        for(Rule rule:rules)if((!rule.name.isEmpty()&&normalized.contains(rule.normalizedName))||rule.name.isEmpty()&&rule.kind.equals(kind)){
            matched=rule;break;
        }
        if(matched==null)return out;out.candidate=true;out.rule=matched.label;
        String text=lower(name+" "+String.join(" ",lore));
        for(String blocked:AutoBuyDefaultRules.BLOCKED)if(text.contains(blocked)){out.reason="слово из стоп-листа";return out;}
        if(kind.equals("book")||normalized.contains("книг")){out.reason="книга";return out;}
        if(count<1||count>255){out.reason="некорректное количество";return out;}
        int prices=0,sellers=0;
        for(String line:lore){String cleaned=clean(line);Matcher pm=PRICE.matcher(cleaned);if(pm.matches()){prices++;out.price=money(pm.group(1));}
            Matcher sm=SELLER.matcher(cleaned);if(sm.matches()){sellers++;out.seller=sm.group(1);}}
        if(prices!=1||out.price==0||sellers!=1){out.reason="цена или продавец отсутствуют/неоднозначны";return out;}
        if(matched.market<=0){out.reason="нет рыночной цены";return out;}
        out.limit=matched.priceLimit(count);
        if(out.price>out.limit){out.reason="выше лимита";return out;}
        if(!matched.kind.isEmpty()&&!matched.kind.equals(kind)){out.reason="тип предмета не подтверждён";return out;}
        for(int i=0;i<matched.need.length;i++)if(level(text,matched.need[i],ench)<matched.levels[i]){out.reason="не хватает зачарования: "+matched.need[i]+" "+matched.levels[i];return out;}
        int customs=0;for(String e:matched.any)if(level(text,e,ench)>=1)customs++;
        if(customs<matched.anyMin){out.reason="не хватает дополнительных зачарований";return out;}
        out.accepted=true;out.reason="подходит по текущим данным; покупка не отправлялась";return out;
    }
}
