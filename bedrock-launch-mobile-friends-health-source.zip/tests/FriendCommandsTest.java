package dev.custom.bedrockgui;
public final class FriendCommandsTest {
    private static void check(boolean value){if(!value)throw new AssertionError();}
    public static void main(String[] args){
        FriendCommands f=new FriendCommands();
        check(FriendCommands.isCommand(" .ADD Alice ")&&FriendCommands.isCommand(".remove"));
        check(!FriendCommands.isCommand("hello .add Alice")&&!FriendCommands.isCommand(".address Alice")&&!FriendCommands.isCommand(null));
        check(f.execute(".add Alice").changed&&f.contains("aLiCe")&&!f.contains("Ali"));
        check(!f.execute(".ADD ALICE").changed&&f.names().length==1&&f.names()[0].equals("Alice"));
        check(f.execute(".add Alice_2").changed&&f.execute(".add Alicex").changed);
        check(f.execute(".REMOVE aLIcE").changed&&!f.contains("Alice")&&f.contains("Alice_2")&&f.contains("Alicex"));
        check(!f.execute(".remove Alice").changed);
        for(String invalid:new String[]{".add",".add A B",".add [VIP]A",".add ../x",".add Имя",".add A-B",".add abcdefghijklmnopq",".add A\n.remove B",".remove A extra",".list"})check(!f.execute(invalid).changed);
        check(f.execute(".add _123456789abcdef").changed); // 16 ASCII chars
        String saved=f.serialized();FriendCommands loaded=new FriendCommands(saved);check(loaded.serialized().equals(saved)&&loaded.contains("ALICEX"));
        loaded=new FriendCommands("Alice\r\nALICE\n../x\nBob\nИмя\n");check(loaded.names().length==2&&loaded.contains("alice")&&loaded.contains("bob"));
        f=new FriendCommands();for(int i=0;i<FriendCommands.MAX_FRIENDS;i++)check(f.execute(".add Nick"+i).changed);
        check(!f.execute(".add Extra").changed&&f.names().length==FriendCommands.MAX_FRIENDS);
        check(f.execute(".remove Nick10").changed&&f.execute(".add Extra").changed);
        check(new FriendCommands(f.serialized()).names().length==FriendCommands.MAX_FRIENDS);
        System.out.println("PASS: local friend commands, exact case-insensitive identity, restore/dedup, invalid input and capacity");
    }
}
