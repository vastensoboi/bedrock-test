#pragma once
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <limits>
#include <ostream>
#include <sstream>

// Owned diagnostic values only: retaining a trace never retains a reference to
// mutable actor, packet, or native history memory.
namespace kulich_frame {
enum class Origin {Unknown,Ordinary,Extra,Unexpected};
struct Pose {
 std::array<float,3> position{},delta{};
};
struct Key {
 uint64_t client=0,registry=0,actor=0,history=0;
 uint32_t entity=0;
};
struct Input {
 uint64_t world=0,rawTick=0,outputTick=0,replayTick=0,historyLast=0;
 bool historyKnown=false;
 Pose actor{},packet{};
};
struct Step {
 uint64_t tick=0;
 bool beforeKnown=false,appendKnown=false,replayKnown=false;
 Pose before{},afterAppend{},afterReplay{};
 bool motionKnown=false,airborne=false;
};
struct Trace {
 Origin origin=Origin::Unknown;
 bool known=false;
 Key owner{};
 Input input{};
 Step step{};
};

inline bool same(const Key& a,const Key& b){
 return a.client==b.client&&a.registry==b.registry&&a.actor==b.actor&&
  a.history==b.history&&a.entity==b.entity;
}
inline bool same(const Pose& a,const Pose& b){
 return !std::memcmp(a.position.data(),b.position.data(),sizeof(float)*a.position.size())&&
  !std::memcmp(a.delta.data(),b.delta.data(),sizeof(float)*a.delta.size());
}
inline bool finite(const Pose& pose){
 for(float value:pose.position)if(!std::isfinite(value))return false;
 for(float value:pose.delta)if(!std::isfinite(value))return false;
 return true;
}
inline bool coherent(const Trace& trace){
 // rawTick is retained as evidence. Without an offset in this value model, no
 // relationship between rawTick and outputTick can be inferred here.
 return trace.known&&trace.input.historyKnown&&finite(trace.input.actor)&&finite(trace.input.packet)&&
  trace.input.outputTick==trace.input.replayTick&&trace.input.outputTick==trace.input.historyLast&&
  same(trace.input.actor,trace.input.packet);
}
inline bool snapshotStable(const Step& step){
 return step.beforeKnown&&step.appendKnown&&finite(step.before)&&finite(step.afterAppend)&&
  same(step.before,step.afterAppend);
}
inline bool compatible(const Trace& trace,const Key& owner,uint64_t tick,const Pose& packet){
 // Preserve incoherent clocks and actor snapshots as evidence, provided this
 // trace still describes the finite packet observed for the same owner/tick.
 return trace.known&&same(trace.owner,owner)&&trace.input.outputTick==tick&&
  finite(trace.input.packet)&&finite(packet)&&same(trace.input.packet,packet);
}

namespace detail {
inline const char* source(Origin origin){
 switch(origin){
  case Origin::Ordinary:return "ordinary";
  case Origin::Extra:return "extra";
  case Origin::Unexpected:return "unexpected";
  default:return "unknown";
 }
}
inline void describePose(std::ostream& out,const Pose& pose,bool known){
 if(!known){out<<"unavailable";return;}
 out<<"{pos=("<<pose.position[0]<<','<<pose.position[1]<<','<<pose.position[2]
    <<") delta=("<<pose.delta[0]<<','<<pose.delta[1]<<','<<pose.delta[2]<<")}";
}
inline void describeClock(std::ostream& out,uint64_t tick,bool known){
 if(known)out<<tick;else out<<"unavailable";
}
}

inline void describe(std::ostream& out,const Trace& trace){
 // Formatting a diagnostic must not alter the caller's numeric formatting.
 std::ostringstream text;
 text<<std::setprecision(std::numeric_limits<float>::max_digits10)
     <<"source="<<detail::source(trace.origin)<<" known="<<(trace.known?"yes":"no")
     <<" coherent="<<(coherent(trace)?"yes":"no")
     <<" owner={client="<<trace.owner.client<<" registry="<<trace.owner.registry
     <<" actor="<<trace.owner.actor<<" history="<<trace.owner.history<<" entity="<<trace.owner.entity<<'}';
 text<<" world=";detail::describeClock(text,trace.input.world,trace.known);
 text<<" raw=";detail::describeClock(text,trace.input.rawTick,trace.known);
 text<<" output=";detail::describeClock(text,trace.input.outputTick,trace.known);
 text<<" replay=";detail::describeClock(text,trace.input.replayTick,trace.known&&trace.input.historyKnown);
 text<<" historyLast=";detail::describeClock(text,trace.input.historyLast,trace.known&&trace.input.historyKnown);
 text<<" actor=";detail::describePose(text,trace.input.actor,trace.known);
 text<<" packet=";detail::describePose(text,trace.input.packet,trace.known);
 text<<" stepTick=";detail::describeClock(text,trace.step.tick,
  trace.step.beforeKnown||trace.step.appendKnown||trace.step.replayKnown);
 text<<" stepBefore=";detail::describePose(text,trace.step.before,trace.step.beforeKnown);
 text<<" stepAppend=";detail::describePose(text,trace.step.afterAppend,trace.step.appendKnown);
 text<<" stepReplay=";detail::describePose(text,trace.step.afterReplay,trace.step.replayKnown);
 text<<" stepMode="<<(trace.step.motionKnown?(trace.step.airborne?"air":"ground"):"unavailable");
 out<<text.str();
}
}
