package dev.custom.bedrockgui;

import android.content.Context;
import android.content.SharedPreferences;

/** Shared by the local command console and any game-chat command adapter. */
public final class FriendStore {
    private static SharedPreferences preferences;
    private static FriendCommands model=new FriendCommands();
    private FriendStore(){}
    public static synchronized void initialize(Context context){
        if(preferences==null){
            Context app=context.getApplicationContext();
            preferences=(app==null?context:app).getSharedPreferences("kulich-friends",Context.MODE_PRIVATE);
            model=new FriendCommands(preferences.getString("names",""));
        }
        AimbotBridge.setFriends(model.serialized());
    }
    public static boolean isCommand(String text){return FriendCommands.isCommand(text);}
    public static synchronized String execute(String text){
        if(preferences==null)return "Список друзей ещё не готов";
        FriendCommands next=new FriendCommands(model.serialized());
        FriendCommands.Result result=next.execute(text);
        if(!result.changed){AimbotBridge.setFriends(model.serialized());return result.message;}
        // Publish only a successfully saved change. A failed write must not
        // silently remove protection or report a friend as persistently saved.
        if(!preferences.edit().putString("names",next.serialized()).commit())return "Не удалось сохранить список друзей";
        model=next;AimbotBridge.setFriends(model.serialized());
        return result.message;
    }
    /** Toggle only a verified raw nickname from the current crosshair selection. */
    public static synchronized String toggle(String nickname){
        if(FriendCommands.normalize(nickname).isEmpty())return "Ник игрока не подтверждён";
        return execute((model.contains(nickname)?".remove ":".add ")+nickname);
    }
    public static synchronized boolean contains(String nickname){return model.contains(nickname);}
    public static synchronized String[] names(){return model.names();}
    public static synchronized String serialized(){return model.serialized();}
    public static synchronized String summary(){
        String[] names=model.names();return names.length==0?"Друзей пока нет":"Друзья ("+names.length+"):\n"+String.join("\n",names);
    }
}
