import dev.custom.bedrockgui.SlotGrid;
public final class SlotGridTest {
    static void check(boolean value){if(!value)throw new AssertionError();}
    static void invalid(float x,float y,float rx,float ry,float nx,float ny){try{new SlotGrid(54,1280,591,x,y,rx,ry,nx,ny);throw new AssertionError();}catch(IllegalArgumentException expected){}}
    public static void main(String[] args){
        SlotGrid g=new SlotGrid(27,1280,591,442.5f,150,836.9f,150,442.5f,199.4f);
        check(Math.abs(g.point(13)[0]-639.7f)<0.1f&&Math.abs(g.point(13)[1]-199.4f)<0.1f);
        check(g.fits(27,1280,591)&&!g.fits(54,1280,591)&&!g.fits(27,2340,1080));
        SlotGrid listing=new SlotGrid(54,1280,591,100,100,500,100,100,150);
        check(listing.point(49)[0]==300&&listing.point(49)[1]==350);
        try{listing.point(54);throw new AssertionError();}catch(IllegalArgumentException expected){}
        invalid(100,100,50,100,100,150);invalid(100,100,500,100,100,105);invalid(100,100,500,160,100,150);
        invalid(100,100,500,100,200,150);invalid(Float.NaN,100,500,100,100,150);invalid(100,500,500,500,100,550);
        System.out.println("PASS: screenshot-scale confirmation geometry, refresh slot geometry, viewport/layout mismatch, range/shape/NaN/bounds guards");
    }
}
