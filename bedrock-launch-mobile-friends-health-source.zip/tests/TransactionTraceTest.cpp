#include "../app/src/main/cpp/transaction_trace_core.h"
#include <cassert>
#include <vector>
#include <iostream>
int main(){
 using namespace kulich_trace;
 std::vector<unsigned char> mem(0x5000);
 auto put=[&](size_t at,uint64_t v){std::memcpy(mem.data()+at,&v,8);};
 auto read=[&](Address at,void* out,size_t n){if(at>mem.size()||n>mem.size()-at)return false;std::memcpy(out,mem.data()+at,n);return true;};
 put(0x1000+48,0x2000);put(0x1000+56,0x2048);put(0x1000+64,0x2048);
 put(0x2000+16,0x3000);put(0x2000+24,0x3068);put(0x2000+32,0x3068);mem[0x3000]=1;
 int32_t req=-3,id=13;std::memcpy(mem.data()+0x2008,&req,4);
 mem[0x3008]=1;mem[0x3010]=7;mem[0x301c]=49;std::memcpy(mem.data()+0x3020,&id,4);mem[0x3038]=29;mem[0x3044]=9;mem[0x3060]=1;
 auto before=mem;auto s=capture(read,0x1000,147);
 assert(s.valid&&s.rows==1&&s.hasAction&&s.action[0]==1&&mem==before);
 assert(describe(s).find("firstAction=01")!=std::string::npos);
 assert(describe(s).find("requestId=-3")!=std::string::npos&&describe(s).find("action=place count=1 sourceType=7 sourceSlot=49 sourceNetId=13 targetType=29 targetSlot=9 targetNetId=0")!=std::string::npos);
 put(0x1000+56,0x2049);assert(!capture(read,0x1000,147).valid);mem=before;
 put(0x1000+64,0x2000);assert(!capture(read,0x1000,147).valid);mem=before;
 auto moving=[&](Address at,void* out,size_t n){bool ok=read(at,out,n);if(at==0x3000)mem[0x2000]++;return ok;};
 assert(!capture(moving,0x1000,147).valid);mem=before;
 auto headerMoving=[&](Address at,void* out,size_t n){bool ok=read(at,out,n);if(at==0x3000)mem[0x1000+56]++;return ok;};
 assert(!capture(headerMoving,0x1000,147).valid);mem=before;
 put(0x1000+56,0x2030);put(0x1000+64,0x2030);auto response=capture(read,0x1000,148);
 assert(response.valid&&response.rows==1&&!response.hasAction);
 int repliesSeen=0;mem[0x2000]=5;std::memcpy(mem.data()+0x2010,&req,4);
 replies(read,0x1000,[&](int request,int status){assert(request==-3&&status==5);repliesSeen++;});assert(repliesSeen==1);
 auto unstableReply=[&](Address at,void* out,size_t n){bool ok=read(at,out,n);if(at==0x2000)mem[0x1000+56]++;return ok;};
 replies(unstableReply,0x1000,[&](int,int){assert(false);});
 assert(!capture(read,0x1000,1).valid);
 assert(!vector(0x1000,0x1001,0x1001,72,128));
 std::cout<<"PASS: bounded native request/response capture, stable vectors, no memory writes, unknown packet and changed data rejection\n";
}
