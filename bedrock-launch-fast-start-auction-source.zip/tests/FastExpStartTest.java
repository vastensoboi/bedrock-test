import dev.custom.bedrockgui.FastExpStart;
public final class FastExpStartTest {
    static void check(boolean v){if(!v)throw new AssertionError();}
    public static void main(String[] args){
        FastExpStart s=new FastExpStart(true,100);
        check(!s.due(5099,true)&&!s.due(5100,false)&&s.due(5100,true));s.begin();check(!s.due(20000,true));
        check(!s.result(6000,false,true));check(!s.due(13999,true)&&s.due(14000,true));s.begin();
        check(!s.result(15000,true,false));check(s.due(23000,true));s.begin();check(s.result(24000,true,true));
        check(!s.due(999999,true));
        s=new FastExpStart(true,0);s.begin();s.cancel();check(!s.result(10000,true,true));
        check(!new FastExpStart(false,0).due(999999,true));
        System.out.println("PASS: startup delay, focus/world guards, retry interval, in-flight suppression, cancellation and no re-enable after success");
    }
}
