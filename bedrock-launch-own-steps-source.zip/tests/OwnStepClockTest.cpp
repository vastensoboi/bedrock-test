#include "../app/src/main/cpp/own_step_clock.h"
#include <cassert>
#include <iostream>
using namespace kulich_own_step;
int main(){
 Session session{1,2,3,4};Clock c;uint64_t tick=0;
 assert(!c.bind({},1)&&!c.bind(session,0)&&!c.mapped(1,tick));
 for(uint64_t world=1;world<=200;++world){
  assert(c.bind(session,world)&&c.mapped(world,tick));
  assert(tick==world+(world-1)/10);
  assert(c.submitted(world,tick));
  bool extra=c.plan(world,true,110,true);
  assert(extra==(world%10==0));
  assert(!c.plan(world,true,200,true));
  if(extra){uint64_t next=0;assert(c.next(world,next));assert(!c.commit(world,next+1));assert(c.commit(world,next));assert(!c.commit(world,next+1));}
  else{uint64_t next=0;assert(c.next(world,next));assert(!c.commit(world,next));}
 }
 assert(c.commits==20&&c.offset()==20);
 c.pause();assert(c.offset()==20);
 for(uint64_t world=201;world<=220;++world){
  assert(c.bind(session,world)&&c.mapped(world,tick)&&tick==world+20);
  assert(c.submitted(world,tick)&&!c.plan(world,false,200,true));
 }
 // Missing ordinary sends and missing history support produce no extra work.
 assert(c.bind(session,221)&&!c.plan(221,true,200,true));
 assert(c.mapped(221,tick)&&c.submitted(221,tick)&&!c.plan(221,true,200,false));
 assert(c.offset()==20&&c.fraction()==0);
 // Actor/history/vehicle changes do not belong in the clock identity: the
 // same session retains its numbering even while extra simulation is paused.
 assert(c.bind(session,222)&&c.mapped(222,tick)&&tick==242);
 assert(c.submitted(222,tick)&&c.plan(222,true,200,true));
 assert(c.next(222,tick)&&tick==243&&c.commit(222,tick));
 assert(c.offset()==21);
 // A genuine world rollback or a new session uses the new native baseline.
 assert(c.bind(session,10)&&c.offset()==0&&c.mapped(10,tick)&&tick==10&&c.sentTick()==0);
 assert(c.bind({1,2,4,5},11)&&c.offset()==0);
 // Settings and long gaps discard fractional credit, never catch up.
 for(uint64_t world=12;world<=20;++world){
  assert(c.bind({1,2,4,5},world)&&c.mapped(world,tick)&&c.submitted(world,tick));
  assert(!c.plan(world,true,110,true));
 }
 assert(c.fraction()==90);
 assert(c.bind({1,2,4,5},40)&&c.mapped(40,tick)&&c.submitted(40,tick));
 assert(!c.plan(40,true,110,true)&&c.fraction()==10);
 assert(c.bind({1,2,4,5},41)&&c.mapped(41,tick)&&c.submitted(41,tick));
 assert(!c.plan(41,true,150,true)&&c.fraction()==50);
 assert(c.bind({1,2,4,5},42)&&c.mapped(42,tick)&&c.submitted(42,tick));
 assert(c.plan(42,true,150,true)&&c.next(42,tick)&&c.commit(42,tick));
 // The last representable tick cannot be advanced or wrapped.
 assert(c.bind({1,2,4,5},UINT64_MAX));
 assert(!c.mapped(UINT64_MAX,tick)&&!c.next(UINT64_MAX,tick));
 assert(c.bind({9,8,7,6},UINT64_MAX)&&c.mapped(UINT64_MAX,tick));
 assert(!c.next(UINT64_MAX,tick));
 Clock paused;assert(paused.bind(session,1)&&paused.submitted(1,1));
 assert(!paused.plan(1,true,150,true)&&paused.fraction()==50);paused.pause();
 assert(paused.fraction()==0&&paused.offset()==0);
 assert(paused.bind(session,2)&&paused.submitted(2,2)&&!paused.plan(2,true,150,true));
 assert(paused.bind(session,3)); // No ordinary input on this frame.
 assert(!paused.plan(3,true,150,true));
 assert(paused.bind(session,4)&&paused.submitted(4,4)&&!paused.plan(4,true,150,true));
 assert(paused.fraction()==50);
 assert(paused.bind(session,5)&&paused.submitted(5,5)&&!paused.plan(5,true,99,true));
 assert(paused.fraction()==0);
 assert(paused.bind(session,6)&&paused.submitted(6,6)&&paused.plan(6,true,300,true));
 assert(paused.next(6,tick));paused.pause();assert(!paused.commit(6,tick));
 Clock edge;assert(edge.bind(session,UINT64_MAX-1)&&edge.submitted(UINT64_MAX-1,UINT64_MAX-1));
 assert(edge.plan(UINT64_MAX-1,true,200,true)&&edge.next(UINT64_MAX-1,tick)&&tick==UINT64_MAX);
 assert(edge.commit(UINT64_MAX-1,tick)&&!edge.next(UINT64_MAX-1,tick));
 assert(edge.bind({1,2,3,5},UINT64_MAX)&&edge.offset()==0&&edge.sentTick()==0);
 std::cout<<"PASS: OwnStepClockTest\n";
}
