# Movement correction payload and replay-window evidence in 0.76

The 0.75 report contains 107 matched packet-161 observations. It establishes
that the bound client received prediction corrections; it does not retain
their corrected state or input ticks. Version 0.76 records those typed fields
and observes the native player's available history window at receipt.
The same three verified callback entries remain in use. There are no new
packet hooks, movement writes, packet edits or claims of server acceptance.

## Exact packet layout

These offsets are for the supplied Minecraft 1.26.60.4 ARM64 library, rather
than offsets inferred from the wire format:

| Packet offset | Native value | Observation |
| --- | --- | --- |
| +48 | Three floats | Corrected position at the referenced input tick |
| +60 | Three floats | Corrected velocity at that input tick |
| +72 | Two floats | Corrected rotation, Vehicle context only |
| +80 / +84 | Optional float / presence byte | Vehicle angular velocity |
| +88 | uint64 input tick | Zero is retained as a valid value |
| +96 | Boolean byte | Ground state |
| +97 | Context byte | Player = 0, Vehicle = 1 |

The normal serializer branch at `0xc77044c` reads the context byte at +97.
The following field visits at `0xc770474`, `0xc7704e0`, `0xc770534`,
`0xc77056c`, `0xc770594`, `0xc7705a4` and `0xc7705c4` establish the field
groups and the optional storage. The tick accessor at `0xdac573c` is a plain
64-bit load. The decoder's commit at `0xc771cd0..0xc771ce4` writes the +72,
+80 and +96 groups back into the packet object.

The consumer copies this data into a typed queued correction. Its apply
routine at `0xa458130` resolves StateVectorComponent key `0x1b5d5238`.
`0xa4581e0..0xa4581fc` copies the queued position to StateVector +0 and
velocity to StateVector +24. At `0xa458200..0xa458210`, the context-1 test
gates the vehicle rotation and angular-velocity application. Player capture
therefore ignores unused vehicle storage, including its padding or arbitrary
floating values. An absent optional vehicle float is also never read.

The [Mojang packet reference for 1.26.60](https://mojang.github.io/bedrock-protocol-docs/1.26.60/packets/correct-player-move-prediction-packet/)
independently identifies the corrected state, Player/Vehicle contexts and
input-tick semantics. The memory layout above comes from the exact native
code. A corrected position refers to a past input tick; subtracting it from
the current position at receipt would not measure prediction error.

## Stable optional observation

Two captures must agree on the meaningful payload fields and the verified
client/registry/actor/entity binding. Coordinate and velocity values must be
finite and bounded by world-scale limits; those limits are not normal-speed
thresholds. The boolean and context bytes must be defined values. Vehicle
rotation and present angular velocity must be finite. Padding and absent or
inapplicable vehicle storage do not participate in comparison.

Malformed, unavailable or changing payload data does not erase a verified
receive event. It is retained with `payload=unavailable`, and a separate
`payloadUnavailable` counter is incremented. Valid payload data is retained
in the bounded event ring and the last Timer-on/off summaries, including
after a later stream of events overflows the ring. The original handler still
receives its original raw arguments exactly once.

## Native history observation

For stable Player payloads, the observer reads the current entity's
ReplayStateComponent, key `0x9fc78512`, stride 32. Its +8 pointer reaches the
history object; that object's +48 and +56 fields are the history count and
first/base input tick. This is observed through the separately guarded
`movement_history_core.h` reader. The binding and meaningful payload fields
are revalidated afterwards; a packet change during the history read clears
only the history observation. A missing or changing history never invalidates
the already captured payload or receive event.

The native eligibility helper `0xa430288` uses a lower tick boundary: zero
returns no rewind state, and an available history object is eligible when its
first tick is at most the received input tick. This helper does not enforce
the history upper boundary. The diagnostic therefore separates the exact
`nativeLowerGate` result from classification as inside, older than or newer
than the observed window. A future tick may pass that lower gate; that alone
does not establish a server or client defect.

For Vehicle context, the own Player history is explicitly not applicable.
For tick zero, the native lower gate is blocked; the packet is still valid.
This does not infer an error or anticheat reason. No snapshot position lookup
or native history function is called, and no history contents are changed.
The observer cannot establish that the eventual queued correction was applied
with the same window as observed at receipt.

## Validation and remaining limits

The observer now checks 23 exact instruction profiles, including 12 payload
anchors, as well as the six history-reader profiles before installing its
existing callbacks. The original callback entries, read-only mappings,
allocation tags, optional-failure behavior and remote MovePlayer fast filter
are preserved.

`MovementCorrectionTest` exercises field decoding, valid zero ticks, vehicle
optionals, ignored Player vehicle storage, nonfinite and out-of-range values,
truncated reads, changed fields between snapshots, padding changes, binding
changes after history observation, a matching history window, packet changes
during history reads, unavailable history, and payload retention after ring overflow.
The core test and ASan/UBSan pass, as do strict host and ARM64-conditional
native syntax checks. `MovementHistoryTest` separately verifies the history
reader. These checks do not replace a phone test or establish an anticheat
bypass.

## Follow-up device report

The supplied `bedrock-crash-capture-0.76.txt` has a complete on/off comparison.
Timer x1.05 was active for 5.494 seconds, then disabled for 21.042 seconds
before the final journal snapshot. There are 21 unique packet-161 events,
all in the active interval. No new matched receive events occur in the off
interval even though native callbacks and the recorder continue running.
Four earlier own MovePlayer events precede this test.

All 21 payloads are valid Player context, on ground, and inside the observed
60-tick history window. Twenty corrections refer to a tick two frames behind
the window's latest tick, and one is three frames behind. Input ticks advance
from 1018 to 1099: nineteen gaps of four and one gap of five. There are no
zero, stale or out-of-window reference ticks in this sample. The received
positions and velocities remain finite and consistent between snapshots.
The report contains no new native, profile or fatal errors.

This result does not support the proposed stale-correction/history-window
explanation. It is consistent with the server correcting the result of the
locally changed per-step speed while normal prediction history remains
available. It does not identify a private anticheat rule, its configuration,
a client defect or a verified bypass. No movement change is justified solely
by these observations.

## Additional clock-component research

`ClientPredictionSyncTimerComponent` (`0x6b53a2f0`) is a global uint32
countdown. RTTI for the system at vptr `0x13ac53e0` describes it explicitly as
`OptionalGlobal`. The callback at `0xc09a270` observes movement corrections;
`0xc09a39c..0xc09a3a8` sets the countdown to 200 when it is zero. The system
at `0xc038efc` consumes the countdown with saturating subtraction and controls
the movement-prediction synchronization packet. This is not an evidenced
per-player time multiplier.

`VariableTickEligibleComponent` is an entity marker used by ActorTicked
add/remove systems. Those systems are not restricted to LocalPlayer, and the
marker does not establish a path for generating extra local simulation steps.
`CurrentTickComponent` is a context uint64 tick value. Writing its number
would not itself generate valid movement/input steps. These fields were
inspected without changes; none provides a demonstrated acceleration or
server-acceptance mechanism.

## Further input and replay trace (2026-11-23)

These are follow-up analysis notes, not a new launcher release. The offline
checks and their output are in `outputs/minecraft-analysis/check-timer-input-path.py`
and `timer-input-path-evidence.json` in the workspace; no new APK or gameplay
change accompanies these findings.

`SendPlayerInputPacketSystem` has vptr `0x138994e0`, single callback
`0x9c18008`, and calls producer `0xaf64398` at `0x9c180cc`. Its constructor
`0x9c0e960` is registered at `0x96a4a08` in the shared registration routine.
The producer copies context `CurrentTickComponent` into packet offset 168;
the setter `0xdac5734` is only `str x1,[x0]; ret`. For the on-foot path,
packet position at +56 comes directly from StateVector+0 and velocity at
+72 from StateVector+24. The sender at Actor+1984 submits through virtual
byte+24/slot3, with no new simulation or history step supplied by that call.
`LoopbackPacketSender` vptr `0x13b3ac00`, slot3 `0xcc8934c`, is a verified
native submission observation candidate, not a network acknowledgement.

The replay advance leaf `0xc20393c` takes an existing Level tick and stores
it in ReplayState+24. History append `0xfabe5a4` checks that its implicit
last tick equals the supplied tick; repeating the same tick trims/resets the
window instead of creating an independent new step. Replay facade `0xccf7030`
walks existing recorded frames, creating a temporary entity in the same
registry with rewind markers. Its simulation callback uses that special
context. A supported entry for a complete new own-player forward step was
not established in these examined branches.

The current ground callbacks assign fresh native results at `0xc1afad4`
and `0xc1b0b64`; the investigation did not establish double scaling there.
`ThrottledTickPolicy` belongs to ServerPlayerMovementComponent+32, stride88,
not an independent client-local clock. In the native reference server,
packet322 is checked by `ValidateClientPredictionSystem` / `0xcdd0518`
against server attributes via `0x11f060f0`; this is not a demonstrated
trusted client speed setter. Nevertime's private implementation remains
unknown, so these native server findings are not claims about its code.

The supplied VHax reference was also inspected without execution. Its Timer
BaseTickEvent callback `0x18ccf84` reads Timer+532 and writes that float
through the shared chain `*[0x1b21510] -> +384 -> +208/+216`. Cleanup
`0x18cd1a8..0x18cd1dc` restores both targets to 20.0. The callback contains
no independent own-player input/history step. The exact simulation/render
roles of the two clocks and Minecraft-version compatibility are unverified;
no reference offsets or clock writes were ported into the launcher.

The read-only verifier passes against the exact Minecraft and VHax SHA-256
values. This verifies recorded native anchors, not runtime acceleration or
remote server acceptance. The existing 0.76 source ZIP remains unchanged.
