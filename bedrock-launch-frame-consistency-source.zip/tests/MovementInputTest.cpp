#include "../app/src/main/cpp/movement_correction_core.h"
#include <cassert>
#include <iostream>
#include <vector>
using namespace kulich_input;
struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;
 std::vector<unsigned char> bytes=std::vector<unsigned char>(0x60000);A next=root+0x10000;
 template<class T>void put(A at,T value){at=plain(at);assert(at>=root&&at-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+at-root,&value,sizeof value);}
 A alloc(size_t size){A at=next;next=(next+size+7)&~A(7);assert(next-root<bytes.size());return at;}
 bool operator()(A at,void* out,size_t size){
  assert(at==plain(at));if(at<root||at-root>bytes.size()||size>bytes.size()-(at-root))return false;
  std::memcpy(out,bytes.data()+at-root,size);return true;
 }
};
A storage(Memory& m,uint32_t entity,unsigned stride,bool present=true){
 A pool=m.alloc(104),vector=m.alloc(8),sparsePage=m.alloc(8192),pages=m.alloc(8),payload=m.alloc(128*stride);
 std::fill(m.bytes.begin()+sparsePage-Memory::root,m.bytes.begin()+sparsePage-Memory::root+8192,255);
 m.put(pool+8,vector);m.put(pool+16,vector+8);m.put(vector,sparsePage);
 if(present)m.put(sparsePage+(entity&2047)*4,entity&0xfffc0000U);
 m.put(pool+80,pages);m.put(pool+88,pages+8);m.put(pool+96,pages+8);m.put(pages,payload|Memory::tag);return pool;
}
kulich_frame::Trace traceFor(const Sample& sample,kulich_frame::Origin origin=kulich_frame::Origin::Ordinary){
 kulich_frame::Trace trace{};trace.known=true;trace.origin=origin;trace.owner=frameKey(sample.owner.key);
 trace.input.world=100;trace.input.rawTick=101;trace.input.outputTick=sample.value.tick;
 trace.input.replayTick=trace.input.historyLast=sample.value.tick;trace.input.historyKnown=true;
 trace.input.actor=trace.input.packet=framePose(sample.value);
 trace.step.tick=sample.value.tick+1;trace.step.beforeKnown=trace.step.appendKnown=trace.step.replayKnown=true;
 trace.step.before=trace.step.afterAppend=trace.input.actor;
 trace.step.afterReplay=trace.input.actor;trace.step.afterReplay.position[0]+=1;
 return trace;
}
std::string traceText(const kulich_frame::Trace& trace){
 std::ostringstream out;kulich_frame::describe(out,trace);return out.str();
}
void traceIntegration(const Sample& valid){
 const auto ordinary=traceFor(valid),extra=traceFor(valid,kulich_frame::Origin::Extra);
 const auto position=valid.value.position,delta=valid.value.delta;
 auto compare=[&](const Book& book){return book.compare(valid.owner.key,valid.value.tick,150,0,position,delta);};
 // Missing provenance preserves the original same-input-tick comparison.
 assert(!valid.trace.known);
 Book missing;missing.add(100,false,100,valid);auto result=compare(missing);
 assert(result.state==Match::Exact&&!result.trace.known);
 std::ostringstream text;describe(text,result);
 assert(text.str().find("submittedFrame{source=unknown known=no coherent=no")!=std::string::npos);

 // Incoherent clocks and actor poses are the evidence this trace must retain.
 for(unsigned mismatch=0;mismatch<5;++mismatch){
  auto trace=ordinary;
  switch(mismatch){
   case 0:++trace.input.replayTick;break;
   case 1:++trace.input.historyLast;break;
   case 2:trace.input.actor.position[1]+=2;break;
   case 3:trace.input.actor.delta[1]+=.5f;break;
   default:trace.input.historyKnown=false;break;
  }
  Sample submitted=valid;assert(attachTrace(submitted,trace));
  Book book;book.add(100,true,105,submitted);result=compare(book);
  assert(result.state==Match::Exact&&result.trace.known&&!kulich_frame::coherent(result.trace));
  assert(traceText(result.trace)==traceText(trace));
  std::ostringstream description;describe(description,result);
  assert(description.str().find("submittedFrame{source=ordinary known=yes coherent=no")!=std::string::npos);
  assert(description.str().find("world=100 raw=101 output=")!=std::string::npos);
  assert(description.str().find("stepBefore={pos=")!=std::string::npos);
  assert(description.str().find("stepAppend={pos=")!=std::string::npos);
  assert(description.str().find("stepReplay={pos=")!=std::string::npos);
 }
 // The exact captured owner and packet are still required. Check direct field
 // assignment too, so callers cannot bypass validation when entering the ring.
 auto rejected=[&](const kulich_frame::Trace& trace){
  Sample submitted=valid;submitted.trace=ordinary;
  assert(!attachTrace(submitted,trace)&&!submitted.trace.known&&same(submitted.value,valid.value));
  submitted.trace=trace;Book book;book.add(100,false,100,submitted);auto comparison=compare(book);
  assert(comparison.state==Match::Exact&&!comparison.trace.known);
 };
 for(unsigned field=0;field<5;++field){
  auto stale=ordinary;
  switch(field){
   case 0:++stale.owner.client;break;case 1:++stale.owner.registry;break;
   case 2:++stale.owner.actor;break;case 3:stale.owner.history^=uint64_t(1)<<56;break;
   default:stale.owner.entity^=0x40000U;break;
  }
  rejected(stale);
 }
 auto stale=ordinary;++stale.input.outputTick;rejected(stale);
 stale=ordinary;stale.input.packet.position[0]+=1;rejected(stale);
 stale=ordinary;stale.input.packet.delta[2]+=.25f;rejected(stale);
 stale=ordinary;stale.input.packet.position[1]=NAN;rejected(stale);
 stale=ordinary;stale.known=false;rejected(stale);

 Sample submitted=valid;auto source=ordinary;assert(attachTrace(submitted,source));
 const std::string original=traceText(source);
 source.input.rawTick=999;source.step.afterAppend.position[2]=999;
 assert(traceText(submitted.trace)==original);
 Book retained;retained.add(100,true,105,submitted);
 const Frame savedFrame=retained.frames[0];const Comparison savedComparison=compare(retained);
 submitted.trace.input.actor.position[0]=999;submitted.trace.step.afterReplay.delta[0]=999;
 assert(traceText(retained.frames[0].sample.trace)==original);
 kulich_correction::Payload payload{};payload.available=true;payload.inputTick=valid.value.tick;payload.submitted=savedComparison;
 kulich_correction::Book received;received.add(200,true,105,kulich_correction::Kind::Prediction,255,valid.owner.key.entity,0,payload);
 for(unsigned i=0;i<150;++i){
  Sample next=valid;next.value.tick=valid.value.tick+i+1;
  assert(attachTrace(next,traceFor(next,kulich_frame::Origin::Extra)));
  retained.add(201+i,false,100,next);
  received.add(201+i,false,100);
 }
 assert(compare(retained).state==Match::NoRecord);
 assert(traceText(savedFrame.sample.trace)==original&&traceText(savedComparison.trace)==original);
 assert(traceText(received.lastOn.payload.submitted.trace)==original);
 assert(kulich_correction::describe(received,400).find("submittedFrame{source=ordinary known=yes coherent=yes")!=std::string::npos);

 Sample first=valid;assert(attachTrace(first,ordinary));
 Sample second=valid;assert(attachTrace(second,extra));
 Book origins;origins.add(100,true,105,first);origins.add(110,true,105,second);
 assert(compare(origins).state==Match::Ambiguous&&origins.conflicts==1);
 origins.add(120,true,105,first);assert(origins.conflicts==1);
 // Unknown traces and same-origin diagnostics cannot manufacture conflicts.
 Sample unknown=second;unknown.trace.known=false;
 Book compatible;compatible.add(100,true,105,first);compatible.add(110,true,105,unknown);
 auto changed=ordinary;++changed.input.replayTick;assert(attachTrace(second,changed));
 compatible.add(120,true,105,second);
 assert(compare(compatible).state==Match::Exact&&compatible.conflicts==0);
 assert(traceText(compare(compatible).trace)==original);
 second.trace=extra;++second.trace.owner.actor;compatible.add(130,true,105,second);
 assert(compare(compatible).state==Match::Exact&&compatible.conflicts==0);
 // Even if the first duplicate had no trace, subsequent known origins must
 // still conflict without replacing that first packet's immutable trace.
 Book initiallyUnknown;initiallyUnknown.add(100,true,105,unknown);
 initiallyUnknown.add(110,true,105,first);assert(compare(initiallyUnknown).state==Match::Exact);
 assert(!compare(initiallyUnknown).trace.known&&initiallyUnknown.conflicts==0);
 assert(attachTrace(second,extra));initiallyUnknown.add(120,true,105,second);
 assert(compare(initiallyUnknown).state==Match::Ambiguous&&initiallyUnknown.conflicts==1);
}
int main(){
 Memory m;constexpr A base=0x10000000,client=Memory::root+0x1000,registry=Memory::root+0x3000;
 constexpr A actorAddress=Memory::root+0x5000,sender=Memory::root+0x7000,packet=Memory::root+0x8000,history=Memory::root+0x9000;
 constexpr uint32_t id=0x40001;
 uint32_t keys[]{OWNER,SHAPE,ROTATION,REPLAY,PASSENGER};unsigned strides[]{8,32,16,32,16};A pools[5]{};
 for(unsigned i=0;i<5;++i)pools[i]=storage(m,id,strides[i],i!=4);
 A buckets=m.alloc(128),nodes=m.alloc(5*32);for(unsigned i=0;i<16;++i)m.put<int64_t>(buckets+i*8,-1);
 for(unsigned i=0;i<5;++i){int64_t previous=-1;m(buckets+(keys[i]&15)*8,&previous,8);m.put(nodes+i*32,previous);m.put(nodes+i*32+8,keys[i]);m.put(nodes+i*32+16,pools[i]);m.put<int64_t>(buckets+(keys[i]&15)*8,i);}
 m.put(registry+96,buckets);m.put(registry+104,buckets+128);m.put(registry+120,nodes);m.put(registry+128,nodes+5*32);
 A entityPages=m.alloc(8),entitySparse=m.alloc(8192);
 m.put(registry+216,entityPages);m.put(registry+224,entityPages+8);m.put(entityPages,entitySparse);m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|1);
 m.put(client,base+0x1388fe70ULL);m.put(client+576,std::array<A,3>{registry|Memory::tag,(Memory::root+0xa000)|Memory::tag,id});
 m.put(actorAddress,base+0x139f6ea0ULL);m.put(actorAddress+8,registry);m.put(actorAddress+16,registry+40);m.put(actorAddress+24,id);m.put(actorAddress+3240,client);
 m.put(actorAddress+1984,sender|Memory::tag);m.put(sender,base+SENDER);
 m.put(component(m,pools[0],id,8),actorAddress|Memory::tag);
 A shape=component(m,pools[1],id,32),rotation=component(m,pools[2],id,16),replay=component(m,pools[3],id,32);
 m.put(actorAddress+560,shape);m.put(actorAddress+568,rotation);
 m.put(shape,Box{{-.3f,0,-.3f},{.3f,1.8f,.3f},.6f,1.8f});m.put(rotation,Angles{});m.put(replay+8,history|Memory::tag);
 m.put(packet,base+PACKET);m.put(packet+56,std::array<float,3>{-9.25f,99,16.125f});m.put(packet+72,std::array<float,3>{.1f,-.2f,.3f});m.put(packet+168,uint64_t(77));
 Sample sample{};auto before=m.bytes;
 auto snapshot=[&](){return capture(m,base,client|Memory::tag,sender|Memory::tag,packet|Memory::tag,sample);};
 assert(snapshot()&&sample.value.tick==77&&sample.owner.key.actor==actorAddress&&sample.owner.key.history==(history|Memory::tag)&&sample.owner.key.entity==id&&sample.owner.footKnown&&sample.owner.onFoot);
 assert(m.bytes==before); // Capture never writes any native memory.
 auto valid=sample;
 assert(!capture(m,base,client,sender+8,packet,sample));
 m.put(packet,base+kulich_correction::CORRECT_PACKET);unsigned actorReads=0;
 auto cheap=[&](A at,void* out,size_t bytes){if(at==actorAddress)++actorReads;return m(at,out,bytes);};
 assert(!capture(cheap,base,client,sender,packet,sample)&&actorReads==0);m.put(packet,base+PACKET);
 m.put(sender,base+SENDER+8);assert(!snapshot());m.put(sender,base+SENDER);
 m.put(actorAddress+3240,client+8);assert(!snapshot());m.put(actorAddress+3240,client);
 m.put(entitySparse+(id&2047)*4,uint32_t(0x80001));assert(!snapshot());m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|1);
 m.put(replay+8,A(0));assert(!snapshot());m.put(replay+8,history|Memory::tag);
 m.put(packet+56,NAN);assert(!snapshot());m.put(packet+56,-9.25f);
 m.put(packet+72,std::numeric_limits<float>::infinity());assert(!snapshot());m.put(packet+72,.1f);
 m.put(packet+168,uint64_t(0));assert(snapshot()&&sample.value.tick==0);m.put(packet+168,uint64_t(77));
 auto unavailable=[&](A at,void* out,size_t bytes){return at==packet+168?false:m(at,out,bytes);};
 assert(!capture(unavailable,base,client,sender,packet,sample));
 unsigned reads=0;auto changing=[&](A at,void* out,size_t bytes){if(at==packet+56&&++reads==2)m.put(packet+56,-10.f);return m(at,out,bytes);};
 assert(!capture(changing,base,client,sender,packet,sample));m.put(packet+56,-9.25f);
 reads=0;auto newHistory=[&](A at,void* out,size_t bytes){if(at==replay+8&&++reads==2)m.put(replay+8,history+8);return m(at,out,bytes);};
 assert(!capture(newHistory,base,client,sender,packet,sample));m.put(replay+8,history|Memory::tag);
 A passengerVector=pointer(m,pools[4]+8),passengerPage=pointer(m,passengerVector);
 auto failedPassenger=[&](A at,void* out,size_t bytes){return at==passengerPage+(id&2047)*4?false:m(at,out,bytes);};
 assert(!capture(failedPassenger,base,client,sender,packet,sample));
 m.put(passengerPage+(id&2047)*4,id&0xfffc0000U);assert(snapshot()&&sample.owner.footKnown&&!sample.owner.onFoot);
 m.put(passengerPage+(id&2047)*4,uint32_t(0xffffffffU));
 m.put(nodes+4*32+8,uint32_t(0x12345678));assert(snapshot()&&!sample.owner.footKnown&&!sample.owner.onFoot);
 m.put(nodes+4*32+8,PASSENGER);assert(snapshot());valid=sample;
 traceIntegration(valid);

 Book book;std::array<float,3> serverPos{-8.25f,97,20.125f},serverDelta{.6f,-.7f,.3f};
 assert(book.compare(valid.owner.key,77,100,0,serverPos,serverDelta).state==Match::NoRecord);
 book.add(100,true,105,valid);auto result=book.compare(valid.owner.key,77,150,0,serverPos,serverDelta);
 assert(result.state==Match::Exact&&result.sent.tick==77&&result.ageMs==50&&result.positionError[0]==1&&result.positionError[1]==-2&&result.positionError[2]==4);
 assert(std::abs(result.deltaError[0]-.5)<1e-6&&result.deltaError[2]==0&&result.submissions==1&&result.onSubmissions==1);
 std::ostringstream text;describe(text,result);assert(text.str().find("serverMinusSubmittedPos=(1,-2,4)")!=std::string::npos);
 assert(book.compare(valid.owner.key,0,150,0,serverPos,serverDelta).state==Match::ZeroTick);
 assert(book.compare(valid.owner.key,77,150,1,serverPos,serverDelta).state==Match::Vehicle);
 assert(book.compare(valid.owner.key,78,150,0,serverPos,serverDelta).state==Match::NoRecord);
 Key other=valid.owner.key;other.entity+=0x40000;assert(book.compare(other,77,150,0,serverPos,serverDelta).state==Match::DifferentBinding);
 other=valid.owner.key;other.history+=8;assert(book.compare(other,77,150,0,serverPos,serverDelta).state==Match::DifferentBinding);
 other=valid.owner.key;other.history^=0x100000000000000ULL;assert(book.compare(other,77,150,0,serverPos,serverDelta).state==Match::DifferentBinding);
 assert(book.compare(valid.owner.key,77,99,0,serverPos,serverDelta).state==Match::Expired);
 assert(book.compare(valid.owner.key,77,10101,0,serverPos,serverDelta).state==Match::Expired);
 book.add(110,false,100,valid);result=book.compare(valid.owner.key,77,150,0,serverPos,serverDelta);
 assert(result.state==Match::Exact&&result.submissions==2&&result.onSubmissions==1&&result.mixedFactor&&book.size==1&&book.duplicates==1);
 auto conflict=valid;conflict.value.position[1]+=1;book.add(120,true,105,conflict);book.add(130,true,105,valid);
 assert(book.compare(valid.owner.key,77,150,0,serverPos,serverDelta).state==Match::Ambiguous&&book.conflicts==1);
 Book disabled;disabled.add(100,false,200,valid);
 assert(disabled.compare(valid.owner.key,77,150,0,serverPos,serverDelta).hundredths==100);
 Book unknown;auto notKnown=valid;notKnown.owner.footKnown=false;unknown.add(100,false,100,notKnown);
 assert(unknown.compare(valid.owner.key,77,150,0,serverPos,serverDelta).state==Match::SourceUnknown);
 notKnown.owner.footKnown=true;notKnown.owner.onFoot=false;unknown={};unknown.add(100,false,100,notKnown);
 assert(unknown.compare(valid.owner.key,77,150,0,serverPos,serverDelta).state==Match::Riding);
 Book rolling;
 for(uint64_t i=0;i<150;++i){auto frame=valid;frame.value.tick=i+1;rolling.add(100+int64_t(i)*50,true,105,frame);}
 assert(rolling.size==128&&rolling.submissions==150&&rolling.duplicates==0&&rolling.on.unique==150);
 assert(rolling.compare(valid.owner.key,22,7600,0,serverPos,serverDelta).state==Match::NoRecord);
 assert(rolling.compare(valid.owner.key,23,7600,0,serverPos,serverDelta).state==Match::Exact);
 assert(describe(rolling).find("lastOnRunObservedFramesPerSecond=20")!=std::string::npos);
 auto next=valid;next.value.tick=151;rolling.add(7600,false,100,next);next.value.tick=152;rolling.add(7650,false,100,next);
 assert(rolling.on.unique==150&&rolling.off.unique==2&&rolling.off.first==7600);
 next.value.tick=153;rolling.add(7700,true,105,next);assert(rolling.on.unique==1&&rolling.off.unique==2);
 next.value.tick=1;rolling.add(7750,true,105,next);assert(rolling.size==1&&rolling.resets==2);
 next.owner.key.entity+=0x40000;next.value.tick=2;rolling.add(7800,false,100,next);
 assert(rolling.size==1&&rolling.resets==3&&rolling.compare(valid.owner.key,1,7850,0,serverPos,serverDelta).state==Match::DifferentBinding);
 // The existing event ring keeps the comparison after the input ring expires.
 kulich_correction::Payload payload{};payload.available=true;payload.inputTick=77;payload.submitted=result;
 kulich_correction::Book received;received.add(200,true,105,kulich_correction::Kind::Prediction,255,id,0,payload);
 for(unsigned i=0;i<40;++i)received.add(300+i,false,100);
 assert(received.lastOn.payload.submitted.state==Match::Exact&&received.lastOn.payload.submitted.submissions==2);
 assert(kulich_correction::describe(received,400).find("submittedComparison=same-input-tick")!=std::string::npos);
 std::cout<<"PASS: immutable native input/trace snapshots, incoherent trace retention, stale trace rejection, origin conflicts, exact sender/local actor/history binding, tagged reads, packet/generation races, passenger exclusion, past-tick comparison, ambiguous duplicate rejection, age limits, bounded ring, clock reset and separate on/off cadence\n";
}
