package dev.custom.bedrockgui;
public final class HudBoundsTest {
    private static void check(boolean value){if(!value)throw new AssertionError();}
    private static void inside(HudBounds.Rect r,int width,int height){check(r.left>=0&&r.top>=0&&r.width>0&&r.height>0&&r.left+r.width<=width&&r.top+r.height<=height);}
    public static void main(String[] args){
        HudBounds b=new HudBounds(1,1,200,100);HudBounds.Rect r=b.project(1000,600,2);inside(r,1000,600);check(r.left==600&&r.top==400&&r.width==400&&r.height==200);
        r=b.project(600,1000,2);inside(r,600,1000);check(r.left==200&&r.top==800); // right/bottom anchoring survives rotation
        b=b.moved(-500,9999,1000,600,2);r=b.project(1000,600,2);check(r.left==0&&r.top==400);
        b=new HudBounds(.5f,.5f,200,100);r=b.project(1000,600,2);int left=r.left,top=r.top;
        b=b.resized(r,9999,9999,1000,600,2);r=b.project(1000,600,2);inside(r,1000,600);check(r.left==left&&r.top==top&&r.left+r.width==1000&&r.top+r.height==600);
        b=b.resized(r,-100,-100,1000,600,2);r=b.project(1000,600,2);check(r.width==160&&r.height==80&&r.left==left&&r.top==top);
        // A widget larger than a tiny viewport still fits, below the preferred minimum.
        b=new HudBounds(1,1,800,400);r=b.project(40,20,3);inside(r,40,20);check(r.width==40&&r.height==20);
        HudBounds full=b.moved(999,-999,40,20,3);r=full.project(1000,600,1);inside(r,1000,600);check(full.xFraction==1&&full.yFraction==1);
        for(float invalid:new float[]{Float.NaN,Float.POSITIVE_INFINITY,Float.NEGATIVE_INFINITY,-10000}){
            b=new HudBounds(invalid,invalid,invalid,invalid);inside(b.project(500,300,invalid),500,300);
        }
        // Size and normalized coordinates constitute a stable persisted round trip.
        b=new HudBounds(.27f,.81f,231,84);HudBounds restored=new HudBounds(b.xFraction,b.yFraction,b.widthDp,b.heightDp);
        HudBounds.Rect a=b.project(1280,720,1.5f),c=restored.project(1280,720,1.5f);check(a.left==c.left&&a.top==c.top&&a.width==c.width&&a.height==c.height);
        System.out.println("PASS: HUD normalized anchoring, drag/resize bounds, rotation, small viewports and malformed saved geometry");
    }
}
