package dev.custom.bedrockgui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

/** Bounded recorder with one writer across launcher and game processes. */
final class OwnLogRecorder {
    interface Starter { Process start() throws IOException; }
    private final long durationMillis;
    private final int segmentBytes;
    private final Starter starter;
    private final LongSupplier elapsedMillis;
    private Session current;
    private String problem="";

    private static final class Session {
        final Process process;
        final CaptureLease lease;
        final RollingLog log;
        final File status;
        final long deadline;
        Session(Process process,CaptureLease lease,RollingLog log,File status,long deadline){
            this.process=process;this.lease=lease;this.log=log;this.status=status;this.deadline=deadline;
        }
    }
    OwnLogRecorder(long durationMillis,int segmentBytes,Starter starter,LongSupplier elapsedMillis){
        if(durationMillis<1||segmentBytes<4096)throw new IllegalArgumentException("Invalid capture bounds");
        this.durationMillis=durationMillis;this.segmentBytes=segmentBytes;
        this.starter=starter;this.elapsedMillis=elapsedMillis;
    }
    synchronized String problem(){return problem;}
    synchronized void stop(){if(current!=null)finish(current,"Запись остановлена при завершении игры");}

    /** A fresh launch resets logs; resume recovery preserves both recent segments. */
    synchronized boolean start(File directory,boolean reset){
        if(current!=null){
            if(!reset&&current.process.isAlive()&&elapsedMillis.getAsLong()<current.deadline)return true;
            finish(current,reset?"Новая сессия записи":"Предыдущая сессия записи истекла");
        }
        CaptureLease lease;
        try{lease=CaptureLease.acquire(directory);}
        catch(IOException|RuntimeException error){problem="Не удалось открыть запись logcat: "+error;return false;}
        if(lease==null)return false; // Another process owns the bounded writer.
        File status=new File(directory,"own-logcat-status.txt");
        RollingLog log=new RollingLog(directory,segmentBytes);
        Process process=null;
        try {
            if(reset)log.reset();
            process=starter.start();
            Session session=new Session(process,lease,log,status,elapsedMillis.getAsLong()+durationMillis);
            current=session;
            String marker=(reset?"Запись начата: ":"Запись возобновлена: ")+System.currentTimeMillis()+
                    "; лимит сессии "+durationMillis/60000+" мин.; хранится до "+(2L*segmentBytes)+" байт.";
            byte[] bytes=("\n--- "+marker+" ---\n").getBytes(StandardCharsets.UTF_8);
            log.append(bytes,bytes.length);
            writeStatus(status,marker);
            problem="";
            Thread reader=new Thread(()->read(session),"own-logcat-reader");
            reader.setDaemon(true);reader.start();
            Thread timeout=new Thread(()->expire(session),"own-logcat-timeout");
            timeout.setDaemon(true);timeout.start();
            return true;
        } catch(IOException|RuntimeException error) {
            problem="Logcat недоступен: "+error;
            if(current!=null&&current.process==process)finish(current,problem);
            else{
                if(process!=null)process.destroy();
                writeStatus(status,problem);
                try{lease.close();}catch(IOException ignored){}
            }
            return false;
        }
    }
    private void read(Session session){
        String end="Поток logcat завершён";
        try(InputStream input=session.process.getInputStream()){
            byte[] bytes=new byte[4096];int count;
            while((count=input.read(bytes))!=-1){
                synchronized(this){
                    if(current!=session)return;
                    session.log.append(bytes,count);
                }
            }
        }catch(IOException error){end="Поток logcat остановлен: "+error;}
        finally{finish(session,end);}
    }
    private void expire(Session session){
        try{
            if(!session.process.waitFor(durationMillis,TimeUnit.MILLISECONDS))
                finish(session,"Лимит времени записи истёк; при возврате в игру запись возобновится");
        }catch(InterruptedException error){
            Thread.currentThread().interrupt();finish(session,"Ожидание записи прервано");
        }
    }
    private synchronized void finish(Session session,String message){
        // An old timeout/reader must neither overwrite new status nor release its lease.
        if(current!=session)return;
        current=null;
        writeStatus(session.status,message+"; время: "+System.currentTimeMillis());
        try{session.process.destroy();}
        finally{try{session.lease.close();}catch(IOException ignored){}}
    }
    static void writeStatus(File file,String value){
        try{Files.write(file.toPath(),value.getBytes(StandardCharsets.UTF_8));}
        catch(IOException ignored){}
    }
}
