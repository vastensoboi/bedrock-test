#include "pearl_native_core.h"
#include "pearl_camera_core.h"
#include "world_collision_core.h"
#include <jni.h>
#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <sstream>
#include <locale>
#include <iomanip>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>

namespace {
using kulich_aim::A;
using kulich_aim::plain;
namespace terrain=kulich_world_collision;
std::mutex gate;
int memory=-1;
A gameBase=0,boundClient=0;
bool ready=false,enabled=false;
std::atomic<int64_t> lease{0};
int64_t deadline=0,nextFrame=0,capturedAt=-1;
unsigned reads=0,checked=0,visible=0,landings=0,rayCount=0,rotation=0;
uint64_t frames=0,rejected=0,readFailures=0,budgetStops=0;
bool budgetExceeded=false;
kulich_pearl::ScanStats scan;
int reason=0;
std::string cachedFrame;
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(A at,void* out,size_t size){
 at=plain(at);
 if(memory<0||at<4096||size>65536||at>0x00ffffffffffffffULL-size){++readFailures;return false;}
 if(++reads>16384||(deadline&&now()>deadline)){
  if(!budgetExceeded)++budgetStops;
  budgetExceeded=true;return false;
 }
 ssize_t n;do{n=pread(memory,out,size,static_cast<off_t>(at));}while(n<0&&errno==EINTR);
 if(n!=ssize_t(size))++readFailures;
 return n==ssize_t(size);
}
struct Profile {A offset;uint32_t words[8];};
constexpr Profile profiles[]={
 {0xc04c9acULL,{0xa9422a8bU,0xa90453f3U,0xa9422269U,0xf9002be0U,0xb90073f8U,0xa942300dU,0xcb0b014bU,0xcb09010aU}},
 {0xc04cae8ULL,{0x9100e3eaU,0x92401a89U,0x52805f0bU,0xa900f3eaU,0x92401b4aU,0x910083e0U,0x910013e2U,0x9bab6d34U}},
 {0x9c708ecULL,{0xd10283ffU,0xa9067bfdU,0xf9003bf7U,0xa90857f6U,0xa9094ff4U,0x910183fdU,0xd53bd056U,0xaa0803f3U}},
 {0xb7cf990ULL,{0x2d4886c8U,0x2d49aac9U,0x1e201820U,0x95f81299U,0x52800028U,0x1e200902U,0x1e220305U,0x1e220101U}},
 {0x11e64ed0ULL,{0xbd400100U,0xbd003800U,0xbd400500U,0xbd003c00U,0xbd400900U,0xbd004000U,0x2d401101U,0x2d430d02U}},
 {0xfd80e28ULL,{0xf9411408U,0x91006100U,0xd65f03c0U,0xa9bd7bfdU,0xf9000bf5U,0xa9024ff4U,0x910003fdU,0xaa0003f3U}},
 {0xc3edcb4ULL,{0xf9000401U,0xd65f03c0U,0xd10143ffU,0xa9017bfdU,0xa9025ff8U,0xa90357f6U,0xa9044ff4U,0x910043fdU}},
 {0xc3ef6c4ULL,{0xd101c3ffU,0x6d0223e9U,0xa9037bfdU,0xa9045ff8U,0xa90557f6U,0xa9064ff4U,0x9100c3fdU,0xd53bd058U}},
 {0xc3ef884ULL,{0x1e210804U,0x1e210840U,0x1e210861U,0x2d0002a4U,0xbd000aa1U,0x39400668U,0x37000088U,0xbd411a61U}},
 {0xc3ef8a0ULL,{0xbd411a61U,0x1e213800U,0xbd0006a0U,0xf9401708U,0xf9400fe9U,0xeb09011fU,0x54000101U,0xa9464ff4U}},
 {0xc3eb7d0ULL,{0xfc414360U,0xfd008c00U,0x39404368U,0x3906c808U,0x910063e0U,0x94e7afb7U,0x9104e275U,0x910063e1U}},
 {0xc3eb8dcULL,{0xfc5e0280U,0xfd0002c0U,0x39453a89U,0x3907e669U,0xb9400108U,0xb801b2c8U,0x39453e88U,0x39097668U}},
 {0xc04d668ULL,{0xf94002c8U,0x5280002bU,0x2a0003f7U,0x2a1f03e7U,0xd0040c6aU,0x9119c14aU,0xf940cd09U,0x9108a3e8U}}
};
std::string install(A base,A client){
 std::lock_guard<std::mutex> lock(gate);
 reads=0;deadline=0;client=plain(client);
 if(gameBase&&gameBase!=base)return "Game library base changed";
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0||kulich_aim::pointer(readMemory,client)!=base+0x1388fe70ULL)return "Pearl client binding unavailable";
 for(const auto& p:profiles){uint32_t code[8]{};if(!readMemory(base+p.offset,code,sizeof code)||std::memcmp(code,p.words,sizeof code))return "Pearl code profile mismatch";}
 if(!terrain::profile(readMemory,base))return "Pearl terrain profile mismatch";
 gameBase=base;boundClient=client;ready=true;capturedAt=-1;cachedFrame.clear();nextFrame=0;
 return {};
}
bool localBinding(A self,A& registry,A& taggedClient){
 if(kulich_aim::pointer(readMemory,self)!=gameBase+0x139f6ea0ULL||
    !readMemory(self+3240,&taggedClient,8)||plain(taggedClient)!=boundClient)return false;
 A weak[3]{};if(!readMemory(boundClient+576,weak,sizeof weak)||!plain(weak[0])||!plain(weak[1]))return false;
 registry=plain(weak[0]);
 // weak[1] is the weak-reference control block, not EntityContext storage.
 if(kulich_aim::pointer(readMemory,self+8)!=registry||
    kulich_aim::integer(readMemory,self+24)!=uint32_t(weak[2]))return false;
 auto v=kulich_pearl::view(readMemory,registry);std::array<A,4> header{};uint32_t entity=0;
 if(!kulich_pearl::identity(readMemory,gameBase,v,self,0x139f6ea0ULL,header,entity)||entity!=uint32_t(weak[2]))return false;
 A owner=kulich_aim::pointer(readMemory,boundClient+424),lifetime=owner?kulich_aim::pointer(readMemory,owner+8):0;
 unsigned char alive=0;return lifetime&&readMemory(lifetime,&alive,1)&&(alive&1);
}
// No cached native Actor is ever called: reacquire its current tagged owner
// pointer and generation immediately before entering the engine's ray query.
A taggedPearl(A registry,const kulich_pearl::Snapshot& pearl){
 auto v=kulich_pearl::view(readMemory,registry);std::array<A,4> header{};uint32_t entity=0;
 if(!kulich_pearl::identity(readMemory,gameBase,v,pearl.actor,kulich_pearl::PEARL_VTABLE,header,entity)||entity!=pearl.id||
    kulich_aim::component(readMemory,v.projectiles,entity,760)!=pearl.projectile)return 0;
 A owner=kulich_aim::component(readMemory,v.owners,entity,8),tagged=0;
 return owner&&readMemory(owner,&tagged,8)&&plain(tagged)==pearl.actor?tagged:0;
}
double impact(A registry,const kulich_pearl::Snapshot& pearl){
 A tagged=taggedPearl(registry,pearl);if(!tagged||now()>deadline||rayCount>=160)return -1;
 A source=terrain::region(readMemory,gameBase,tagged);uint8_t flag=0;
 if(!source||!readMemory(pearl.projectile+467,&flag,1))return -1;
 auto position=pearl.position,velocity=pearl.velocity;
 for(unsigned tick=0;tick<160&&rayCount<160&&now()<=deadline;tick++){
  auto end=position;end.x+=velocity.x;end.y+=velocity.y;end.z+=velocity.z;
  if(!kulich_pearl::finite(end,32000000))return -1;
  terrain::Hit hit{};++rayCount;
  auto result=terrain::trace(readMemory,gameBase,source,tagged,
   {position.x,position.y,position.z},{end.x,end.y,end.z},flag,hit);
  if(result==terrain::Result::Unavailable)return -1;
  if(result==terrain::Result::Block)return tick+double(hit.fraction);
  kulich_pearl::step(position,velocity,pearl.gravity,pearl.drag);
 }
 return -1;
}
}

extern "C" void kulich_pearl_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);
 if(!lock.owns_lock()||!ready||!enabled)return;
 int64_t at=now();if(at>lease.load()){cachedFrame.clear();capturedAt=-1;reason=1;return;}
 if(at<nextFrame)return;
 nextFrame=at+50;reads=0;deadline=at+6;checked=visible=landings=rayCount=0;budgetExceeded=false;scan={};
 A registry=0,taggedClient=0;
 auto fail=[&](int value){reason=budgetExceeded?5:value;++rejected;cachedFrame.clear();capturedAt=-1;deadline=0;};
 if(!localBinding(plain(taggedPlayer),registry,taggedClient)){fail(2);return;}
 std::vector<kulich_pearl::Snapshot> pearls;
 if(!kulich_pearl::collect(readMemory,gameBase,registry,plain(taggedPlayer),pearls,checked,&scan)){fail(scan.missingPool?6:3);return;}
 visible=unsigned(pearls.size());
 if(pearls.empty()){cachedFrame.clear();capturedAt=-1;reason=scan.pearlTypes&&scan.stateFailures?7:0;deadline=0;++frames;return;}
 auto context=reinterpret_cast<kulich_aim::CameraContext(*)(void*)>(gameBase+kulich_pearl_camera::RENDER_CAMERA_GETTER)(reinterpret_cast<void*>(taggedClient));
 kulich_pearl_camera::Camera camera{};
 bool renderCamera=kulich_pearl_camera::readCamera(readMemory,context,camera);
 if(!renderCamera){
  // An uninitialized render camera cannot provide a world-aligned curve.
  // Publish an explicitly labelled top-down plan using the verified local
  // actor, rather than inventing a FOV or hiding otherwise valid pearls.
  auto actors=kulich_aim::view(readMemory,registry);kulich_aim::Actor local{};
  if(!kulich_aim::actor(readMemory,gameBase,actors,plain(taggedPlayer),true,local)||
     std::abs(local.look.pitch)>90.01||std::abs(local.look.yaw)>1e8){fail(4);return;}
  camera.origin=kulich_aim::point(local.box,true);camera.pose=local.look;
 }
 std::vector<double> impacts(pearls.size(),-1);
 // Rotate the first ray-tested pearl so several simultaneous throws cannot
 // starve each other. The shared count/time limits bound game-thread work.
 for(size_t n=0;n<pearls.size()&&now()<=deadline&&rayCount<160;n++){
  size_t i=(rotation+n)%pearls.size();impacts[i]=impact(registry,pearls[i]);if(impacts[i]>=0)++landings;
 }
 ++rotation;
 std::ostringstream text;text.imbue(std::locale::classic());text<<std::setprecision(9);
 text<<camera.origin.x<<','<<camera.origin.y<<','<<camera.origin.z<<','<<camera.pose.pitch<<','<<camera.pose.yaw<<','<<camera.verticalFov;
 if(renderCamera){
  text<<','<<camera.aspect;
  for(double value:camera.view)text<<','<<value;
  text<<','<<camera.nearPlane;
 }
 text<<'|';
 for(size_t i=0;i<pearls.size();i++){
  if(i)text<<';';
  const auto& p=pearls[i];
  text<<p.id<<','<<p.owner<<','<<p.position.x<<','<<p.position.y<<','<<p.position.z<<','
      <<p.velocity.x<<','<<p.velocity.y<<','<<p.velocity.z<<','<<p.gravity<<','<<p.drag<<','<<impacts[i];
 }
 cachedFrame=text.str();capturedAt=at;reason=0;deadline=0;++frames;
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_PearlBridge_install(JNIEnv* env,jclass,jlong base,jlong client){auto error=install(A(base),A(client));return env->NewStringUTF(error.c_str());}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_PearlBridge_enable(JNIEnv*,jclass,jboolean value){std::lock_guard<std::mutex> lock(gate);enabled=bool(value);lease.store(0);capturedAt=-1;cachedFrame.clear();nextFrame=0;}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_PearlBridge_pulse(JNIEnv*,jclass,jboolean value){lease.store(value?now()+1200:0);}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_PearlBridge_snapshot(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);int64_t at=now();std::string frame;
 if(enabled&&at<=lease.load()&&capturedAt>=0&&at>=capturedAt&&at-capturedAt<=500&&!cachedFrame.empty())frame=std::to_string(at-capturedAt)+'|'+cachedFrame;
 return env->NewStringUTF(frame.c_str());
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_PearlBridge_status(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);char text[600];
 snprintf(text,sizeof text,"Pearl Prediction: enabled=%d frames=%llu pearls=%u terrainETA=%u rays=%u checked=%u candidates=%u pearlTypes=%u stateFailures=%u reads=%u readFailures=%llu budgetStops=%llu rejected=%llu reason=%d route=projectile-pool/render-camera/terrain-clip",enabled,static_cast<unsigned long long>(frames),visible,landings,rayCount,checked,scan.candidates,scan.pearlTypes,scan.stateFailures,reads,static_cast<unsigned long long>(readFailures),static_cast<unsigned long long>(budgetStops),static_cast<unsigned long long>(rejected),reason);
 return env->NewStringUTF(text);
}
