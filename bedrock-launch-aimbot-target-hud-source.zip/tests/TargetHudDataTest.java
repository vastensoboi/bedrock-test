package dev.custom.bedrockgui;
import java.nio.charset.StandardCharsets;
public final class TargetHudDataTest {
    private static String snapshot(String name,String hp,long age){StringBuilder hex=new StringBuilder();for(byte b:name.getBytes(StandardCharsets.UTF_8))hex.append(String.format("%02x",b&255));return age+"|"+hp+"|"+hex;}
    private static void check(boolean value){if(!value)throw new AssertionError();}
    public static void main(String[] args){
        TargetHudData t=TargetHudData.parse(snapshot("§a[Властелин] Steve_1\n20 ♥","18.5",200));
        check(t!=null&&t.name.equals("Steve_1")&&t.rank.equals("Властелин")&&t.hp==18.5f);
        t=TargetHudData.parse(snapshot("Alex","nan",0));check(t.name.equals("Alex")&&t.rank.equals("Не указана")&&Float.isNaN(t.hp));
        t=TargetHudData.parse(snapshot("","20",10));check(t.name.equals("Имя недоступно"));
        check(TargetHudData.parse(snapshot("Alex","20",5001))==null);
        check(TargetHudData.parse("0|20|zz")==null&&TargetHudData.parse("0|20|a")==null);
        check(TargetHudData.parse(snapshot("Alex","Infinity",0))==null&&TargetHudData.parse(snapshot("Alex","-1",0))==null);
        check(TargetHudData.parse("")==null&&TargetHudData.parse(null)==null);
        System.out.println("PASS: target HUD UTF-8/colors/rank, unknown HP/name, expiry and malformed input");
    }
}
