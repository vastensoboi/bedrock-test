#include "aim_core.h"
#include "aim_profile.h"
#include <jni.h>
#include <mutex>
#include <chrono>
#include <atomic>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>
namespace {
using namespace kulich_aim;
std::mutex gate;int memory=-1;A base=0,client=0;bool ready=false,enabled=false,head=true;
std::atomic<int64_t> lease{0};double radius=6;Lock targetLock;
uint64_t ticks=0,applied=0;unsigned checked=0;int reason=0,binding=0;float lastDistance=0;Angles lastLook{};int64_t nextScan=0,deadline=0;unsigned reads=0;
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(A at,void* out,size_t size){
 at=plain(at);if(memory<0||at<4096||size>65536||at>0x00ffffffffffffffULL-size||++reads>8192||(deadline&&now()>deadline))return false;
 ssize_t n;do{n=pread(memory,out,size,static_cast<off_t>(at));}while(n<0&&errno==EINTR);return n==ssize_t(size);
}
}
extern "C" void kulich_aim_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);if(!lock.owns_lock()||!ready||!enabled)return;
 ticks++;if(now()>lease.load()){reason=1;return;}reads=0;deadline=now()+5;
 A self=plain(taggedPlayer);if(pointer(readMemory,self)!=base+0x139f6ea0ULL||pointer(readMemory,self+3240)!=client){reason=2;targetLock.reset();return;}
 A weak[3]{};if(!readMemory(client+576,weak,sizeof weak)||!plain(weak[1])){reason=2;targetLock.reset();return;}
 A registry=plain(weak[0]);if(!registry||pointer(readMemory,self+8)!=registry||integer(readMemory,self+24)!=uint32_t(weak[2])){reason=2;targetLock.reset();return;}
 auto v=view(readMemory,registry);Actor local{},target{};
 if(!actor(readMemory,base,v,self,true,local,&binding)){reason=3;targetLock.reset();return;}
 if(!retain(readMemory,base,v,local,radius,targetLock,target)){
  if(now()<nextScan){reason=4;return;}nextScan=now()+200;
  if(!acquire(readMemory,base,v,local,radius,targetLock,target,checked)){reason=4;return;}
 }
 Angles desired{};if(!angles(point(local.box,true),point(target.box,head),local.look.yaw,desired)){reason=5;targetLock.reset();return;}
 // Revalidate identity/components immediately before calls on the game thread.
 Actor current{},currentTarget{};
 A headAddress=component(readMemory,v.heads,local.entity,8);float headData[2]{};
 if(!actor(readMemory,base,v,self,true,current)||!actor(readMemory,base,v,target.address,false,currentTarget)||
    current.entity!=local.entity||current.rotation!=local.rotation||currentTarget.entity!=target.entity||
    distance2(current.box,currentTarget.box)>radius*radius||!headAddress||!readMemory(headAddress,headData,sizeof headData)||
    !std::isfinite(headData[0])||!std::isfinite(headData[1])||now()>lease.load()||
    !angles(point(current.box,true),point(currentTarget.box,head),current.look.yaw,desired)) {reason=6;targetLock.reset();return;}
 // Actor APIs preserve the game's own component access and tagged this pointer.
 alignas(8) Angles value=desired;
 reinterpret_cast<void(*)(void*,const Angles*)>(base+SET_ROT)(reinterpret_cast<void*>(taggedPlayer),&value);
 reinterpret_cast<void(*)(void*,float)>(base+SET_HEAD)(reinterpret_cast<void*>(taggedPlayer),value.yaw);
 applied++;lastLook=value;lastDistance=float(std::sqrt(distance2(local.box,target.box)));reason=0;
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_AimbotBridge_install(JNIEnv* env,jclass,jlong address,jlong owner){
 std::lock_guard<std::mutex> lock(gate);deadline=0;reads=0;
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0)return env->NewStringUTF("Cannot read game process");
 A candidate=A(address),candidateClient=plain(A(owner));
 if((base&&base!=candidate)||pointer(readMemory,candidateClient)!=candidate+0x1388fe70ULL)return env->NewStringUTF("Unsupported client binding");
 for(const auto& p:aimProfiles){uint32_t words[8]{};if(!readMemory(candidate+p.offset,words,sizeof words)||std::memcmp(words,p.words,sizeof words))return env->NewStringUTF("Aim code profile mismatch");}
 base=candidate;client=candidateClient;ready=true;targetLock.reset();nextScan=0;return env->NewStringUTF("");
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_enable(JNIEnv*,jclass,jboolean value){
 std::lock_guard<std::mutex> lock(gate);enabled=ready&&value;targetLock.reset();nextScan=0;reason=0;if(!enabled)lease=0;
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_configure(JNIEnv*,jclass,jboolean aimHead,jint range){
 std::lock_guard<std::mutex> lock(gate);head=aimHead;radius=range<2?2:range>12?12:range;
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_pulse(JNIEnv*,jclass,jboolean active){lease=active?now()+1200:0;}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_AimbotBridge_status(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);char text[384];
 snprintf(text,sizeof text,"Aimbot: enabled=%d point=%s range=%.0f target=%u distance=%.2f ticks=%llu applied=%llu checked=%u pitch=%.2f yaw=%.2f bind=%d reason=%d",enabled,head?"head":"body",radius,targetLock.entity,lastDistance,static_cast<unsigned long long>(ticks),static_cast<unsigned long long>(applied),checked,lastLook.pitch,lastLook.yaw,binding,reason);
 return env->NewStringUTF(text);
}
