# Timer journal findings and capture correction

The supplied `bedrock-crash-capture-0.72.txt` contains 3,614 lines. Its game
journal covers an initial session and a later return to the same process.
The timestamps below use the phone's displayed local time (UTC+5), matching
the logcat and content-log entries, rather than the UTC epoch representation.

## What the report establishes

- Timer installed successfully with `route=own-player-attributes/use-duration/swing`.
  The first session used x2.00 and x1.15; the later test used x1.05.
- The later x1.05 samples have `ground=453`, `air=106`, followed by
  `ground=458`, `air=110`. These are cumulative successful native writes,
  not measured movement, server acknowledgements or anticheat decisions.
- At 22:51:46.261 the Activity resumed after more than two hours paused.
  At 22:51:46.282 the UID logcat reader recorded `IOException: Stream closed`.
  Its exported tail stops at that return, before the later test.
- Timer x1.05 was enabled at 22:52:13.268, disabled at 22:52:15.263,
  enabled again at 22:52:21.288 and disabled at 22:52:23.910.
  The second exported sample was taken only 57 ms after enabling. No final
  sample covered the remainder of that short interval, because the periodic
  status interval exceeded the active test window.
- The content log contains fresh errors at 22:52:01: 458 warnings about a full
  VoxelShape registry and an invalid `minecraft:empty` handle, plus 134 missing
  `minecraft:unit_cube` errors in the exported tail. These precede the x1.05
  test by about 12 seconds. Similar errors already occur in supplied reports
  as early as 0.34, before Timer existed. They are not evidence that the 0.72
  speed-attribute correction introduced this registry problem.

## What the report does not establish

The report contains no current server correction record or anticheat check
identifier for the x1.05 test. The UID logcat had already stopped. The shape
errors may warrant a separate content/collision investigation, but their
presence alone does not establish the cause of a position rollback. The
successful Timer write counters do not establish server acceptance either.

The 0.72 native audit found no repeated multiplication: Ground and Water use
scoped player input overrides; Air receives freshly generated native output.
Their originals execute once, and No Slow changes a distinct item-use input.
The server can still reject intentionally faster client movement.

## Changes in 0.73

Repair the bounded UID logcat recorder's recovery after returning to the
game. Keep a single writer across launcher and game processes, retain recent
log segments on recovery, and protect the new session from stale reader or
timeout cleanup. Short tests also log a final native Timer sample when the
module is disabled, and multiplier changes are written explicitly.

This is a diagnostic capture correction. It does not change movement,
collision shapes, server validation or the Timer multiplier, and does not
establish an anticheat bypass. Android lifecycle and server behavior still
require a phone test.
