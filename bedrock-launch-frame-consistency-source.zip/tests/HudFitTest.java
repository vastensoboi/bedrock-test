package dev.custom.bedrockgui;
public final class HudFitTest {
    private static void check(boolean value){if(!value)throw new AssertionError();}
    private static void near(float actual,float expected){check(Math.abs(actual-expected)<.0001f);}
    private static void inside(int width,int height,int childWidth,int childHeight,int header){
        HudFit.Result f=HudFit.fit(width,height,childWidth,childHeight,header);
        check(Float.isFinite(f.scale)&&f.scale>0&&f.left>=0&&f.top>=Math.max(0,Math.min(Math.max(1,height)-1,header)));
        check(f.left+Math.max(1,childWidth)*f.scale<=Math.max(1,width)+.001f);
        check(f.top+Math.max(1,childHeight)*f.scale<=Math.max(1,height)+.001f);
    }
    public static void main(String[] args){
        // Shrinking the viewport scales the whole card, not only its border.
        HudFit.Result f=HudFit.fit(110,63,220,126,0);near(f.scale,.5f);near(f.left,0);near(f.top,0);
        // Every added staff row contributes to natural height before fitting.
        f=HudFit.fit(220,126,220,252,0);near(f.scale,.5f);near(f.left,55);near(f.top,0);
        // An editor caption has its own space, never covering the first row.
        f=HudFit.fit(220,147,220,126,21);near(f.scale,1);near(f.top,21);
        // Preserve the content's aspect ratio for unusually thin/tall resizing.
        f=HudFit.fit(440,126,220,126,0);near(f.scale,1);near(f.left,110);
        f=HudFit.fit(440,252,220,126,0);near(f.scale,2);near(f.top,0);
        for(int w:new int[]{0,1,40,80,220,1280})for(int h:new int[]{0,1,20,40,126,720})
            for(int naturalHeight:new int[]{0,1,126,252,4096})for(int header:new int[]{0,21,1000})inside(w,h,220,naturalHeight,header);
        System.out.println("PASS: HUD content scales uniformly, all rows fit, editor caption stays separate, small and malformed viewports remain bounded");
    }
}
