package dev.custom.bedrockgui;

import java.io.*;
import java.nio.file.*;

/** Two bounded files retaining recent log bytes, shared safely with readers. */
public final class RollingLog {
    private static final Object LOCK = new Object();
    private final File current, previous;
    private final int segmentLimit;

    public RollingLog(File directory, int segmentLimit) {
        if (segmentLimit < 1) throw new IllegalArgumentException("Invalid segment size");
        this.current = new File(directory, "own-logcat.txt");
        this.previous = new File(directory, "own-logcat.previous.txt");
        this.segmentLimit = segmentLimit;
    }
    public void reset() throws IOException {
        synchronized (LOCK) {
            Files.deleteIfExists(previous.toPath());
            Files.write(current.toPath(), new byte[0]);
        }
    }
    public void append(byte[] data, int count) throws IOException {
        if (count < 0 || count > data.length || count > segmentLimit)
            throw new IllegalArgumentException("Invalid log chunk size");
        synchronized (LOCK) {
            if (current.length() + count > segmentLimit)
                Files.move(current.toPath(), previous.toPath(), StandardCopyOption.REPLACE_EXISTING);
            try (FileOutputStream out = new FileOutputStream(current, true)) {
                out.write(data, 0, count);
            }
        }
    }
    public byte[] tail(int maxBytes) throws IOException {
        if (maxBytes < 0) throw new IllegalArgumentException("Invalid tail size");
        synchronized (LOCK) {
            int recent = (int) Math.min(current.length(), maxBytes);
            int older = (int) Math.min(previous.length(), maxBytes - recent);
            ByteArrayOutputStream result = new ByteArrayOutputStream(older + recent);
            readTail(previous, older, result);
            readTail(current, recent, result);
            return result.toByteArray();
        }
    }
    private static void readTail(File file, int count, OutputStream out) throws IOException {
        if (count == 0) return;
        try (RandomAccessFile input = new RandomAccessFile(file, "r")) {
            input.seek(input.length() - count);
            byte[] data = new byte[count];
            input.readFully(data);out.write(data);
        }
    }
}
