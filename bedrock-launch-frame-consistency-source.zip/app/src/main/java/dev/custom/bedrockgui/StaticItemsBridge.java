package dev.custom.bedrockgui;

/** Exact-build dropped-item presentation; never freezes world item actors. */
public final class StaticItemsBridge {
    private static volatile boolean ready,enabled;
    private StaticItemsBridge(){}
    private static native String install(long base,long client);
    private static native void enable(boolean value);
    private static native void pulse(boolean active);
    private static native String status();
    public static synchronized void prepare(long base,long client){
        if(!FastExpBridge.isReady())return;
        try{
            String error=install(base,client);
            if(error==null||!error.isEmpty())throw new IllegalStateException(error==null?"No native install result":error);
            ready=true;pulse(enabled);GameRuntime.log("Static items: scoped item-render bridge prepared");
        }catch(RuntimeException|LinkageError error){
            if(ready){try{enable(false);pulse(false);}catch(RuntimeException|LinkageError ignored){}}
            ready=false;enabled=false;GameRuntime.log("Static items unavailable: "+error);
        }
    }
    public static boolean isReady(){return ready;}
    public static boolean isEnabled(){return enabled;}
    public static synchronized void setEnabled(boolean value){
        if(value&&!ready)throw new IllegalStateException("Нужен загруженный мир");
        if(ready){enable(value);pulse(value);}
        enabled=value;GameRuntime.log("Static items: enabled="+value);
    }
    public static void heartbeat(){if(ready)pulse(enabled);}
    public static String describe(){
        if(!ready)return "Предметы ещё не подключены к миру";
        return (enabled?"Предметы плашмя, без вращения":"Выключен")+"\n"+status();
    }
}
