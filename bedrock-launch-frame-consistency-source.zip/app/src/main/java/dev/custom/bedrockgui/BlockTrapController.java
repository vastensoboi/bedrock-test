package dev.custom.bedrockgui;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

/** Wait for a verified loaded world; menus and focus changes retain the toggle. */
public final class BlockTrapController {
    private final Activity activity;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean requested,preparing,disposed;
    private int generation;
    private String message="Выключен";
    public BlockTrapController(Activity activity){this.activity=activity;}
    public boolean isEnabled(){return requested;}
    public String status(){return requested&&(BlockTrapBridge.isReady()||BlockTrapBridge.hasProblem())?BlockTrapBridge.describe():message;}
    public String displayStatus(){return status().split("\n",2)[0];}
    public void setEnabled(boolean value){
        if(disposed)return;
        generation++;requested=value;handler.removeCallbacksAndMessages(null);
        if(!value){BlockTrapBridge.setEnabled(false);message="Выключен";return;}
        if(BlockTrapBridge.isReady()){
            try{BlockTrapBridge.setEnabled(true);}
            catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить Block Trap. Причина в журнале";throw error;}
            return;
        }
        message="Подключаю Block Trap. Нужен загруженный мир";prepare(generation);
    }
    private void prepare(int epoch){
        if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
        if(preparing||!GameEngineProbe.begin()){handler.postDelayed(()->prepare(epoch),400);return;}
        preparing=true;
        Thread worker=new Thread(()->{
            try{GameEngineProbe.run();}
            catch(RuntimeException|LinkageError error){GameRuntime.log("Block Trap preparation failed: "+error);}
            finally{GameEngineProbe.end();}
            activity.runOnUiThread(()->{
                preparing=false;
                if(disposed||!requested||epoch!=generation||activity.isFinishing()||activity.isDestroyed())return;
                if(GameEngineProbe.playerFound()&&BlockTrapBridge.isReady()){
                    try{BlockTrapBridge.setEnabled(true);}
                    catch(RuntimeException|LinkageError error){requested=false;message="Не удалось включить Block Trap. Причина в журнале";GameRuntime.log("Block Trap enable failed: "+error);}
                }else if(GameEngineProbe.playerFound()){
                    requested=false;message="Block Trap не подключился\n"+BlockTrapBridge.describe();
                }else{
                    message="Войди в мир: Block Trap подключится автоматически";handler.postDelayed(()->prepare(epoch),8000);
                }
            });
        },"block-trap-prepare");worker.setDaemon(true);worker.start();
    }
    public void dispose(){setEnabled(false);disposed=true;handler.removeCallbacksAndMessages(null);}
}
