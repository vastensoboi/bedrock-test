package dev.custom.bedrockgui;

/** Game-thread target tracking; no touch injection or automatic attacks. */
public final class AimbotBridge {
    private static volatile boolean ready,enabled;private static volatile boolean head=true;private static volatile int radius=6,speed=180;
    private AimbotBridge(){}
    private static native String install(long base,long client);
    private static native void enable(boolean value);
    private static native void configure(boolean head,int range,int speed);
    private static native void pulse(boolean value);
    private static native String status();
    public static void prepare(long base,long client){
        try{
            if(!FastExpBridge.isReady())return;
            String error=install(base,client);if(!error.isEmpty())throw new IllegalStateException(error);
            configure(head,radius,speed);ready=true;GameRuntime.log("Aimbot: exact-build camera input bridge prepared");
        }catch(RuntimeException|LinkageError error){ready=false;GameRuntime.log("Aimbot bridge unavailable: "+error);}
    }
    public static boolean isReady(){return ready;}
    public static void setEnabled(boolean value){
        if(value&&!ready)throw new IllegalStateException("Aimbot ещё не подключён к миру");
        if(ready){enable(value);pulse(value);}enabled=value;GameRuntime.log("Aimbot: requested enabled="+value);
    }
    public static void settings(boolean value,int range){head=value;radius=Math.max(2,Math.min(12,range));if(ready)configure(head,radius,speed);}
    public static void setSpeed(int value){speed=Math.max(60,Math.min(360,value));if(ready)configure(head,radius,speed);}
    public static void heartbeat(){if(ready)pulse(enabled);}
    public static String describe(){
        if(!ready)return "Подключение к игровому миру ещё не готово";
        String raw=status(),hint;
        if(!enabled)hint="Выключен";
        else if(raw.endsWith("reason=0")&&!raw.contains("target=4294967295 "))hint=raw.contains("settled=1 ")?"Удерживаю цель":"Плавно навожусь на цель";
        else if(raw.endsWith("reason=4"))hint="Ищу игрока в радиусе "+radius+" блоков";
        else if(raw.endsWith("reason=7"))hint="Активная камера пока не готова к наведению";
        else if(raw.endsWith("reason=8"))hint="Камера не подтвердила приём поворота";
        else if(raw.endsWith("reason=1"))hint="Ожидаю обновления модуля";
        else hint="Ожидаю подходящий игровой мир и данные игрока";
        return hint+"\n"+raw;
    }
}
