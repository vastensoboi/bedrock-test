#pragma once
#include "aim_combat.h"
#include <string>
namespace kulich_aim {
// Evidence only: numeric metadata IDs are not assumed to be health. Read the
// same validated metadata vector/string representation as the native getters.
template<class Read> std::string metadataEvidence(Read& read,A actor){
 A data=pointer(read,plain(actor)+320),begin=pointer(read,data),end=pointer(read,data+8);
 if(!data||!begin||end<begin||(end-begin)%8||(end-begin)/8>1024)return "metadata unavailable";
 constexpr size_t limit=2048;unsigned strings=0,primitives=0;std::string out;
 unsigned count=unsigned((end-begin)/8);if(count>128)count=128;
 constexpr char hex[]="0123456789abcdef";
 // Prefer the known display and score text before the generic scan, so
 // unusually long unrelated metadata cannot consume the whole evidence budget.
 std::array<unsigned,130> order{};unsigned used=0;
 if(count>4)order[used++]=4;
 if(count>84)order[used++]=84;
 for(unsigned key=0;key<count;key++)if(key!=4&&key!=84)order[used++]=key;
 for(unsigned index=0;index<used;index++){
  unsigned key=order[index];
  A item=pointer(read,begin+A(key)*8);if(!item)continue;
  A table=pointer(read,item),getter=pointer(read,table+24);uint32_t code[2]{};
  if(!getter||!read(getter,code,sizeof code)||code[1]!=0xd65f03c0U||
     (code[0]&0xffe0001fU)!=0x52800000U)continue;
  unsigned type=(code[0]>>5)&0xffffU;if(type>8)continue;
  std::string entry="id="+std::to_string(key)+" type="+std::to_string(type)+" ";
  if(type==4){
   if(strings>=16)continue;
   char value[385]{};if(!playerString(read,item+16,value,sizeof value)||!value[0])continue;
   strings++;entry+="utf8hex=";
   for(const unsigned char* p=reinterpret_cast<const unsigned char*>(value);*p;p++){entry.push_back(hex[*p>>4]);entry.push_back(hex[*p&15]);}
  }else{
   if(primitives>=16)continue;
   unsigned char raw[8]{};if(!read(item+8,raw,sizeof raw))continue;
   primitives++;entry+="raw8=";
   for(unsigned char c:raw){entry.push_back(hex[c>>4]);entry.push_back(hex[c&15]);}
  }
  if(out.size()+entry.size()+1>limit){if(out.size()+13<=limit)out+="[truncated]\n";break;}
  out+=entry;out+='\n';
 }
 A again=pointer(read,plain(actor)+320),againBegin=pointer(read,data),againEnd=pointer(read,data+8);
 if(again!=data||againBegin!=begin||againEnd!=end)return "metadata changed during snapshot";
 return out.empty()?"metadata contains no readable values":out;
}
}
