# Input admission and observation sessions, 0.81

## Control evidence

The follow-up 0.80 journal opens the same local-world database twice. All 20
retained correction snapshots keep calls=323, received=199, prediction=160 and
ownMove=39 unchanged. Their last-packet ages grow from roughly 400 to 442 seconds.
These are prior Nevertime observations, not new observed local-world rollback
events.

Sixteen backend snapshots show `unexpected-replay-input`. The first local
binding stalls after 20 extra steps; after reopening the world a second binding
completes 69 more, then stalls too. In five intervals `workerInputs` increases
while planned, appended and completed extra counts stay unchanged. In the old
code, any failed `stateGate.try_lock()` called the unexpected-replay path. Lock
contention outside replay therefore latched a permanent fault with a misleading
name. This is a concrete launcher defect; it does not identify a server rule.

The control also first records a duplicate/conflicting tick. Without producer
actor provenance its two underlying native packets cannot be reconstructed,
so the conflict's exact cause is not claimed.

## Nonblocking admission

Each ordinary own input observer enters a counted reader section and advances
an activity epoch. Readers never wait for the driver. If the existing state
mutex is busy, a reader retains only validated clock mapping and an owned
trace; it does not update Clock submission state or the driver baseline, and
does not latch a replay fault.

Optional replay requires no active readers and the epoch of the last coherent
ordinary baseline. The one-shot writer admission happens after readonly
preflight and before native mutation. It spans append, replay, submission and
all marker/metadata cleanup. An input observed during preflight invalidates
that reservation. Input during an admitted replay window remains a genuine
unsupported overlap and faults further optional work. The exclusive release
preserves transient counts from rejected readers; it never stores zero over a
reader. No callback spins or blocks to obtain admission.

The benign fallback permits a newer native world tick only within the same
complete published session and retained offset. The session, overflow bound
and publication are revalidated. Its active reader excludes extra offset
commits. The replay-window fallback remains stricter. Existing accumulated
offsets survive disable; no backward tick reset or fabricated position is used.

Admission covers the own input observer, not the entire original native sender
and its subsequent cleanup. Complete engine synchronization remains unproved.
This change does not claim that the server accepts faster realtime movement.

## Native producer identity

At the exact producer callsite, af64398 keeps its Actor pointer in callee-saved
x19, defined at af643e0 and used through the sender call at af64da4. The shim
passes that value in observer x4 after saving original x4/x5. Native arguments,
SP/LR, vector/FP state and unwind rules are restored before tail dispatch.

Both tick mapping and input capture require this full allocation-tagged actor
to equal the verified ActorOwner pointer. Missing, foreign, untagged aliases
of a tagged actor and changed allocation tags cannot enter the own-input ring
or rewrite its tick. Actual actor generation and history are still revalidated.
The input ring retires old frames when actor allocation tags change even if
the normalized numeric address is reused.

Two native anchors and a fingerprint of the 2576-byte producer body through
the send bind this x19 interpretation to the supplied game build. Offline
verification includes its SHA256 and native instructions; this is not native
execution.

## Observation scope

A verified client/registry/actor/history/entity/tag binding starts a correction
observation session. Rebinding retires retained rows, payloads and last-event
ages while preserving cumulative counters and event sequence. Client changes
retire stale observations before the next verified binding. The new fields
`observationSession`, `observationBound`, `sessionReceived`,
`sessionPredictionPackets` and `sessionOwnMovePlayerPackets` distinguish a new
local world receiving no observed packets from an old server's cumulative
totals. Neither observers nor this reporting layer discard native corrections.

The backend separately reports `ordinaryContentions`, `replayAdmissionsSkipped`,
`foreignProducerInputs`, `unknownProducerInputs` and `replayWindowInputs`.
The legacy `workerInputs` counter aliases replay-window overlap; it does not
identify a thread or prove that CCF itself was running at that instant.

## Validation

The full host runner now has 51 suites. New tests exercise reader/exclusive
admission, stale epochs, rejected-reader release races and coordinated
concurrent stress; existing suites cover tagged producer rejection, actor
retag retirement and correction-session isolation while preserving cumulative
counts. Strict host/ARM64-conditional compilation, host object generation,
Android35/Rhino Java17 checking and ASan/UBSan supplement those tests.

LLVM19 assembles the revised shim; dataflow checks verify x4 delivery and
native argument restoration, two negative register-delivery mutations, tail
dispatch and static DWARF rules. Offline profile checks cover 37 own-step
anchors, 12 table bindings, 14 input anchors and the complete producer-body
fingerprint. None builds or executes an Android APK or demonstrates Nevertime
acceptance. Phone testing of the false-stop fix and remaining server rollbacks
is still required.
