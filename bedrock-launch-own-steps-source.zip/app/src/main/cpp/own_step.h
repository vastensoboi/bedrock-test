#pragma once
#include <cstdint>
#include <string>
namespace kulich_own_step {
std::string install(uint64_t base,uint64_t client);
bool ready();
void settingsChanged();
void input(void* sender,void* packet)noexcept;
std::string report();
}
