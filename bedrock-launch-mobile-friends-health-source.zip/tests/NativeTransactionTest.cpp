#include "../app/src/main/cpp/transaction_action_core.h"
#include <cassert>
#include <vector>
#include <iostream>
using namespace kulich_transaction;
int main(){
 constexpr A base=0x10000000,root=0x200000,client=root+0x2000,manager=root+0x4000,node=root+0x5000,model=root+0x6000,slots=root+0x8000,invNode=root+0xd000,invModel=root+0xe000,invSlots=root+0x10000,net=root+0x14000,item=root+0x16000,handle=root+0x15000;
 std::vector<unsigned char> memory(0x20000);
 auto q=[&](A at,A v){std::memcpy(memory.data()+at-root,&v,8);};
 auto n=[&](A at,int32_t v){std::memcpy(memory.data()+at-root,&v,4);};
 auto b=[&](A at,int v){memory[at-root]=uint8_t(v);};
 auto read=[&](A at,void* out,size_t size){if(at<root||at-root>memory.size()||size>memory.size()-(at-root))return false;std::memcpy(out,memory.data()+at-root,size);return true;};
 q(root,base+0x139f6ea0);q(root+3240,client);q(root+0x578,manager);q(root+2592,0xb400000000000000ULL|net);q(client,base+0x1388fe70);q(manager,base+0x137e8f20);q(manager+192,node);
 q(node+40,model);q(node,invNode);q(invNode+40,invModel);
 q(model,base+0x13d34298);q(model+216,slots);q(model+224,slots+54*152);
 q(invModel,base+0x13d341b0);q(invModel+216,invSlots);q(invModel+224,invSlots+27*152);
 A cursorNode=root+0x1a000,cursorModel=root+0x1b000,cursorStack=root+0x1c000;
 q(invNode,cursorNode);q(cursorNode+40,cursorModel);q(cursorModel,base+0x13d34468);b(cursorModel+40,59);
 q(cursorModel+216,cursorStack);q(cursorModel+224,cursorStack+152);q(cursorStack,base+0x13d95ff8);n(cursorStack+144,-1);
 A source=slots+49*152;
 q(source,base+0x13d95ff8);q(source+8,handle);q(handle,item);q(source+16,root+0x18000);b(source+34,1);n(source+128,13);n(source+144,0);
 q(invSlots,base+0x13d95ff8);n(invSlots+144,-1);
 q(net,base+0x13d21c98);q(net+16,root);b(net+8,1);
 Fields f{root,client,manager,node,model,slots,54,49,root+0x18000,1,item,invNode,invModel,invSlots,0,0,0,0,0};
 auto before=memory;auto transfer=validate(read,base,f);
 assert(transfer.manager==(0xb400000000000000ULL|net)&&transfer.netId==13&&transfer.target==9&&transfer.slot==49&&memory==before);
 auto src=descriptor(7,49,13,0),dst=descriptor(29,9,0,0);int32_t id=0,kind=0;std::memcpy(&id,src.data()+16,4);std::memcpy(&kind,dst.data()+32,4);
 assert(src[0]==7&&src[12]==49&&id==13&&dst[0]==29&&dst[12]==9&&kind==0);
 // Refresh retains proven Place-to-inventory; lot/confirm clicks use Take-to-cursor.
 Fields listing=f;listing[7]=5;listing[19]=cursorNode;listing[20]=cursorModel;listing[21]=cursorStack;
 std::memcpy(memory.data()+slots+5*152-root,memory.data()+source-root,152);
 auto take=validate(read,base,listing);assert(take.take&&take.destinationType==59&&take.target==0&&take.destination==cursorStack);
 b(cursorStack+34,1);assert(!validate(read,base,listing).manager);b(cursorStack+34,0);
 b(cursorModel+40,60);assert(!validate(read,base,listing).manager);b(cursorModel+40,59);
 n(cursorStack+128,123);n(cursorStack+144,0);assert(!validate(read,base,listing).manager);n(cursorStack+128,0);n(cursorStack+144,-1);
 q(invNode,0);assert(!validate(read,base,listing).manager);memory=before;
 n(source+128,14);assert(validate(read,base,f).netId==14);memory=before;
 n(source+128,0);assert(!validate(read,base,f).manager);memory=before;
 n(source+144,1);assert(!validate(read,base,f).manager);memory=before;
 b(invSlots+34,1);assert(!validate(read,base,f).manager);memory=before;
 q(manager+192,invNode);assert(!validate(read,base,f).manager);memory=before;
 q(net+96,root+0x19000);assert(!validate(read,base,f).manager);memory=before;
 q(net+16,client);assert(!validate(read,base,f).manager);memory=before;
 f[7]=48;assert(!validate(read,base,f).manager);f[7]=49;
 q(model+224,slots+27*152);assert(!validate(read,base,f).manager);memory=before;
 q(source+16,root+0x18008);assert(!validate(read,base,f).manager);memory=before;
 // Confirmation native guard additionally binds preview and red control tags.
 f[6]=27;f[7]=10;f[15]=root+0x18100;f[16]=1;f[17]=item;f[18]=root+0x18200;
 f[19]=cursorNode;f[20]=cursorModel;f[21]=cursorStack;
 q(model+224,slots+27*152);A buy=slots+10*152;std::memcpy(memory.data()+buy-root,memory.data()+source-root,152);
 q(slots+13*152,base+0x13d95ff8);q(slots+13*152+8,handle);q(slots+13*152+16,f[15]);b(slots+13*152+34,1);q(slots+16*152+16,f[18]);
 assert(plain(validate(read,base,f).manager)==net);q(slots+13*152+16,root+0x18108);assert(!validate(read,base,f).manager);
 std::cout<<"PASS: game-thread binding, live net ID, Place refresh/Take cursor routes, occupied/wrong/unowned cursor rejection, changed owner/window/preview/scope rejection\n";
}
