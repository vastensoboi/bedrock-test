package dev.custom.bedrockgui;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
/** Compact reference-style target card; avatar is a neutral icon, not a player skin. */
public final class TargetHud {
    private final LinearLayout card;private final TextView name,hp,state;private final ProgressBar health;private final float density;
    public TargetHud(Context context){
        density=context.getResources().getDisplayMetrics().density;
        card=new LinearLayout(context);card.setOrientation(LinearLayout.HORIZONTAL);card.setPadding(dp(8),dp(7),dp(10),dp(7));card.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xdf171419);bg.setCornerRadius(dp(8));card.setBackground(bg);
        card.setClickable(false);card.setFocusable(false);card.setVisibility(View.GONE);
        card.addView(new Avatar(context),new LinearLayout.LayoutParams(dp(40),dp(40)));
        LinearLayout content=new LinearLayout(context);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(9),0,0,0);card.addView(content,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout top=new LinearLayout(context);top.setGravity(Gravity.CENTER_VERTICAL);
        name=line(context,13,Color.WHITE);name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        hp=line(context,13,0xffa3ec55);hp.setTypeface(Typeface.DEFAULT,Typeface.BOLD);top.addView(hp);
        TextView heart=line(context,13,0xffff5266);heart.setText(" ♥");top.addView(heart);content.addView(top);
        health=new ProgressBar(context,null,android.R.attr.progressBarStyleHorizontal);health.setMax(1000);health.setProgressTintList(ColorStateList.valueOf(0xff88e82e));health.setProgressBackgroundTintList(ColorStateList.valueOf(0xff333039));LinearLayout.LayoutParams bar=new LinearLayout.LayoutParams(-1,dp(5));bar.topMargin=dp(5);content.addView(health,bar);
        state=line(context,10,0xffbcb4c2);state.setSingleLine(true);content.addView(state);
        card.setTranslationX(dp(80));card.setTranslationY(dp(38));
    }
    private int dp(int v){return Math.round(v*density);}
    private TextView line(Context c,int size,int color){TextView t=new TextView(c);t.setTextSize(size);t.setTextColor(color);return t;}
    public View view(){return card;}
    public FrameLayout.LayoutParams bounds(){return new FrameLayout.LayoutParams(dp(236),-2,Gravity.CENTER);}
    public void updateSnapshot(String snapshot){show(TargetHudData.parse(snapshot));}
    public void show(TargetHudData t){
        if(t==null){card.setVisibility(View.GONE);return;}
        name.setText("⚡ "+(t.rank.equals("Не указана")?"":t.rank+" ")+t.name);hp.setText(Float.isNaN(t.hp)?"?":String.format(java.util.Locale.ROOT," %.0f",t.hp));
        if(Float.isFinite(t.maxHp)&&Float.isFinite(t.hp)){health.setVisibility(View.VISIBLE);health.setProgress(Math.max(0,Math.min(1000,Math.round(t.hp/t.maxHp*1000))));}else health.setVisibility(View.INVISIBLE);
        String message;
        switch(t.state){case 0:message="Бью";break;case 1:message="Выключен";break;case 2:message="Цель потеряна";break;case 3:message="Вне дистанции";break;case 4:message="Цель вне прицела";break;case 5:message=t.actualCps>0?"Бью":"Готов к удару";break;case 6:message="Игра отклонила удар";break;default:message="Нет игровых данных";}
        String configured=t.configuredMinCps==t.configuredCps?Integer.toString(t.configuredCps):t.configuredMinCps+"–"+t.configuredCps;
        state.setText(message+" · "+t.actualCps+"/"+configured+" CPS");state.setTextColor(t.state==6?0xffff7a80:0xffbcb4c2);card.setVisibility(View.VISIBLE);
    }
    private final class Avatar extends View {
        final Paint paint=new Paint();Avatar(Context c){super(c);}
        protected void onDraw(Canvas canvas){super.onDraw(canvas);float u=getWidth()/8f;paint.setColor(0xffe1e1dd);canvas.drawRect(u,u,7*u,7*u,paint);paint.setColor(0xffb6b7b4);canvas.drawRect(u,5*u,7*u,7*u,paint);canvas.drawRect(0,3*u,2*u,6*u,paint);canvas.drawRect(6*u,3*u,8*u,6*u,paint);paint.setColor(0xff868885);canvas.drawRect(2*u,4*u,3*u,5*u,paint);canvas.drawRect(5*u,4*u,6*u,5*u,paint);}
    }
}
