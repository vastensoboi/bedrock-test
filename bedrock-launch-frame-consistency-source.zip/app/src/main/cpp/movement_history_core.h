#pragma once
#include "aim_core.h"
#include <string>

namespace kulich_rewind {
using kulich_aim::A;
using kulich_aim::plain;
constexpr uint32_t REPLAY_STATE=0x9fc78512U;
enum class State {Unavailable,NotPlayer,ZeroTick,NoHistory,Empty,Older,Inside,Future};
struct Window {
 State state=State::Unavailable;
 bool gateKnown=false,eligible=false;
 uint64_t first=0,count=0,last=0;
};
// This mirrors the a430288 eligibility gate, not a snapshot lookup. That
// gate checks the lower tick boundary only; a future tick may pass it.
template<class Read>Window sample(Read& read,A registry,uint32_t entity,uint64_t inputTick,uint8_t context){
 using namespace kulich_aim;
 Window result{};
 if(context!=0){result.state=State::NotPlayer;return result;}
 if(inputTick==0){result.state=State::ZeroTick;result.gateKnown=true;return result;}
 A replay=component(read,pool(read,registry,REPLAY_STATE),entity,32),history=0,again=0;
 if(!replay||(replay&7)||!read(replay+8,&history,8))return {};
 if(history==0){
  if(!read(replay+8,&again,8)||again!=history||component(read,pool(read,registry,REPLAY_STATE),entity,32)!=replay)return {};
  result.state=State::NoHistory;result.gateKnown=true;return result;
 }
 if(plain(history)<4096||(plain(history)&7))return {};
 std::array<uint64_t,2> bounds{},second{};
 if(!read(plain(history)+48,bounds.data(),sizeof bounds)||
    !read(plain(history)+48,second.data(),sizeof second)||bounds!=second||
    !read(replay+8,&again,8)||again!=history||
    component(read,pool(read,registry,REPLAY_STATE),entity,32)!=replay)return {};
 uint64_t count=bounds[0],first=bounds[1];
 if(count&&first>std::numeric_limits<uint64_t>::max()-(count-1))return {};
 result.gateKnown=true;result.eligible=first<=inputTick;
 result.first=first;result.count=count;result.last=count?first+count-1:0;
 if(!count)result.state=State::Empty;
 else if(inputTick<first)result.state=State::Older;
 else if(inputTick-first<count)result.state=State::Inside;
 else result.state=State::Future;
 return result;
}
inline const char* stateName(State state){
 switch(state){
  case State::NotPlayer:return "not-player-context";
  case State::ZeroTick:return "zero-tick-direct-path";
  case State::NoHistory:return "no-history";
  case State::Empty:return "empty";
  case State::Older:return "older-than-window";
  case State::Inside:return "inside";
  case State::Future:return "newer-than-window";
  default:return "unavailable";
 }
}
inline std::string describe(const Window& value){
 std::string text=std::string("replayWindow=")+stateName(value.state)+" nativeLowerGate="+
  (!value.gateKnown?"unknown":value.eligible?"eligible":"blocked");
 if(value.state==State::Empty||value.state==State::Older||value.state==State::Inside||value.state==State::Future)
  text+=" historyFirstTick="+std::to_string(value.first)+" historyCount="+std::to_string(value.count)+" historyLastTick="+(value.count?std::to_string(value.last):"unavailable");
 return text;
}
struct Profile {A offset;uint32_t words[8];size_t count;};
constexpr Profile profiles[]={
 {0xa430288ULL,{0xb40007c1U,0xa9be7bfdU,0xa9014ff4U,0x910003fdU,0xf9400409U,0x5290a24aU,0x72b3f8eaU,0xa943a12bU},8},
 {0xa430344ULL,{0x92401949U,0xaa0103f4U,0x8b091513U,0xaa1303e0U,0x946511c5U,0xb40000c0U,0x955a3c87U,0xaa0003e8U},8},
 {0xa430358ULL,{0xb40000c0U,0x955a3c87U,0xaa0003e8U,0xaa1303e0U,0xeb14011fU,0x54000049U},6},
 {0xbd74a68ULL,{0xf9400400U,0xd65f03c0U},2},
 {0xfabf4ccULL,{0xa9432009U,0xcb080028U,0xeb09011fU,0x54000242U,0xf9401409U,0xd284926aU,0xf2b2492aU,0x8b080128U},8},
 {0xfabf578ULL,{0xf9401c00U,0xd65f03c0U},2}
};
template<class Read>bool profileValid(Read& read,A base){
 for(const auto& p:profiles){uint32_t words[8]{};size_t bytes=p.count*4;
  if(!read(base+p.offset,words,bytes)||std::memcmp(words,p.words,bytes))return false;
 }
 return true;
}
}
