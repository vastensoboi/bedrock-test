import { defineModule } from "@kulich/api";

defineModule(
  {id: "api_demo", name: "API Demo", description: "Пример модуля kulich API. Пишет сообщения в журнал."},
  {every: {type: "number", def: 5, min: 1, max: 100}},
  function(ctx) {
    var ticks = 0;
    ctx.onEnable(function() { ticks = 0; ctx.log("Модуль включён"); });
    ctx.onDisable(function() { ctx.log("Модуль выключен"); });
    // Это обновление интерфейса примерно раз в 400 мс, НЕ игровой тик.
    ctx.on("ui_tick", function() {
      ticks++;
      if (ticks % ctx.options.every.value === 0) ctx.log("API работает; обновлений: " + ticks);
    });
  }
);
