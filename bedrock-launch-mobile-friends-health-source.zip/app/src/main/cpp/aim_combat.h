#pragma once
#include "aim_camera.h"
#include "aim_profile.h"
namespace kulich_aim {
// Slot 15 is INTERACT (transaction action 0); slot 16 is ATTACK (action 1).
// Both accept hit coordinates, but only the latter emits an attack request.
template<class Read> A attackBinding(Read& read,A base,A mode,A self){
 A table=pointer(read,plain(mode)),function=0;
 if(pointer(read,plain(mode)+8)!=plain(self))return 0;
 if(table==base+0x13d227d0ULL)function=base+ATTACK;
 else if(table==base+0x13d22900ULL)function=base+ATTACK_SURVIVAL;
 else return 0;
 return pointer(read,table+128)==function?function:0;
}
template<class Attack> bool dispatchAttack(Attack attack,void* mode,void* target,const float* position){
 return attack(mode,target,position);
}
template<class Update,class Aim,class Attack> void afterPlayerUpdate(A player,Update update,Aim aim,Attack attack){
 update(player);aim(player);attack(player);
}
class ClickClock {
 double next=-1;int minimum=0,maximum=0;int64_t previous=-1;uint32_t random=0x6d2b79f5U;
 static int clamp(int value){return value<1?1:value>40?40:value;}
 uint32_t draw(){random^=random<<13;random^=random>>17;random^=random<<5;return random;}
 double period(){
  unsigned width=unsigned(maximum-minimum+1);
  if(width==1)return 1000.0/minimum;
  // Rejection avoids modulo bias; every integer rate in the selected range
  // is equally likely. This affects cadence only, never measured hit counts.
  uint32_t limit=0xffffffffU-(0xffffffffU%width),value;
  do{value=draw();}while(value>limit);
  return 1000.0/(minimum+int((value-1)%width));
 }
public:
 void reset(){next=-1;minimum=maximum=0;previous=-1;random=0x6d2b79f5U;}
 int take(int64_t now,int low,int high){
  low=clamp(low);high=clamp(high);if(low>high)std::swap(low,high);
  if(next<0||minimum!=low||maximum!=high||(previous>=0&&now<previous)){
   minimum=low;maximum=high;next=double(now);
  }
  previous=now;
  if(now+.00001<next)return 0;
  // A paused game or lost target must not accumulate an attack burst.
  if(now-next>100)next=double(now);
  int count=0;double lastPeriod=0;
  while(next<=now+.00001&&count<2){lastPeriod=period();next+=lastPeriod;count++;}
  if(next<=now+.00001)next=now+lastPeriod;
  return count;
 }
 int take(int64_t now,int cps){return take(now,cps,cps);}
 bool due(int64_t now,int cps){return take(now,cps)>0;}
 bool due(int64_t now,int low,int high){return take(now,low,high)>0;}

};
// Exact-build libc++ string storage: short size in byte0>>1, long size+8,
// tagged data pointer+16. Empty is valid for optional prefix/suffix fields.
template<class Read> bool playerString(Read& read,A address,char* out,size_t capacity){
 if(!out||capacity<1)return false;
 out[0]=0;address=plain(address);unsigned char header[24]{},again[24]{};
 if(address<4096||!read(address,header,sizeof header))return false;
 A length=0,at=address+1;
 if(header[0]&1){
  A allocated=0,raw=0;std::memcpy(&allocated,header,8);std::memcpy(&length,header+8,8);std::memcpy(&raw,header+16,8);at=plain(raw);
  if(length>384||length>=capacity||(allocated&~A(1))<length+1||at<4096)return false;
 }else{length=header[0]>>1;if(length>22||length>=capacity)return false;}
 if(length&&!read(at,out,size_t(length))){out[0]=0;return false;}
 // The enclosing player is checked by the caller; reject a concurrently
 // replaced string header rather than joining stale/freed buffer data.
 if(!read(address,again,sizeof again)||std::memcmp(header,again,sizeof header)||
    std::memchr(out,0,size_t(length))){out[0]=0;return false;}
 out[length]=0;return true;
}
// Actor metadata key4 is the server-supplied nametag, including explicit
// multiline HP. Native fa4de14 directly indexes vector[key], then type-checks.
template<class Read> bool metadataText(Read& read,A actor,unsigned key,char* out,size_t capacity){
 if(!out||capacity<2||key>1023)return false;
 out[0]=0;actor=plain(actor);
 A data=pointer(read,actor+320),begin=pointer(read,data),end=pointer(read,data+8);
 if(!data||!begin||end<begin||(end-begin)%8||(end-begin)/8<=key||(end-begin)/8>1024)return false;
 A item=pointer(read,begin+A(key)*8),table=pointer(read,item),getter=pointer(read,table+24);uint32_t code[2]{};
 if(!item||!getter||!read(getter,code,8)||code[0]!=0x52800080U||code[1]!=0xd65f03c0U)return false;
 return playerString(read,item+16,out,capacity)&&out[0];
}
template<class Read> bool metadataName(Read& read,A actor,char* out,size_t capacity){return metadataText(read,actor,4,out,capacity);}
// Player::getName at101f05ec returns this+b28. This separate raw player name
// is the identity for friend matching, independent of display ranks and HP.
template<class Read> bool playerIdentity(Read& read,A actor,char* out,size_t capacity){
 return playerString(read,plain(actor)+0xb28,out,capacity)&&out[0];
}
template<class Read> bool targetDisplayName(Read& read,A actor,char* out,size_t capacity){
 if(!out||capacity<2)return false;
 out[0]=0;actor=plain(actor);
 bool tagged=metadataName(read,actor,out,capacity);
 char name[385]{},prefix[385]{},suffix[385]{};unsigned char before=0,after=0;
 if(!playerIdentity(read,actor,name,sizeof name))return tagged;
 // A bare metadata name can still have separate native prefix/suffix fields.
 // Preserve customized/multiline metadata; decorate only exact raw equality.
 if(tagged&&std::strcmp(out,name))return true;
 // Native formatted-name builder101f0704 appends optional+b40 (flag+b58),
 // raw+b28, then optional+b60 (flag+b78); no synthetic ranks/separators.
 bool formatted=read(actor+0xb58,&before,1)&&read(actor+0xb78,&after,1)&&before<=1&&after<=1;
 if(formatted&&before)formatted=playerString(read,actor+0xb40,prefix,sizeof prefix);
 if(formatted&&after)formatted=playerString(read,actor+0xb60,suffix,sizeof suffix);
 size_t n=std::strlen(name),p=formatted?std::strlen(prefix):0,s=formatted?std::strlen(suffix):0;
 if(p+n+s>384||p+n+s>=capacity){p=s=0;if(n>=capacity)return false;}
 std::memcpy(out,prefix,p);std::memcpy(out+p,name,n);std::memcpy(out+p+n,suffix,s);out[p+n+s]=0;return true;
}
// Native fda528c is the matching typed-string getter for metadata84 (score
// line). Keep its exact server text for HUD health parsing, never for identity.
template<class Read> bool targetName(Read& read,A actor,char* out,size_t capacity){
 if(!targetDisplayName(read,actor,out,capacity))return false;
 char score[385]{};
 if(metadataText(read,actor,84,score,sizeof score)&&!std::strstr(out,score)){
  size_t nameSize=std::strlen(out),scoreSize=std::strlen(score);
  if(nameSize+1+scoreSize<capacity&&nameSize+1+scoreSize<=384){out[nameSize]='\n';std::memcpy(out+nameSize+1,score,scoreSize+1);}
 }
 return true;
}
class AxisStabilizer {
 A actor=0;uint32_t entity=0;bool head=false,p=false,y=false;
public:
 void reset(){actor=0;p=y=false;}
 Angles apply(A address,uint32_t id,bool pointHead,Angles current,Angles desired){
  if(actor!=address||entity!=id||head!=pointHead){actor=address;entity=id;head=pointHead;p=y=false;}
  double dp=desired.pitch-current.pitch,dy=std::remainder(double(desired.yaw)-current.yaw,360.0);
  p=std::abs(dp)<=(p?.24:.12);y=std::abs(dy)<=(y?.24:.12);
  if(p)desired.pitch=current.pitch;
  if(y)desired.yaw=current.yaw;
  return desired;
 }
};
inline bool rayHitVector(Vec origin,Vec direction,const Box& box,double reach,Vec& hit){
 if(!valid(box)||!std::isfinite(reach)||reach<=0||reach>6.000001)return false;
 double o[3]{origin.x,origin.y,origin.z},d[3]{direction.x,direction.y,direction.z},near=0,far=reach;
 for(int i=0;i<3;i++){
  if(!std::isfinite(o[i])||!std::isfinite(d[i]))return false;
  if(std::abs(d[i])<1e-8){if(o[i]<box.lo[i]||o[i]>box.hi[i])return false;continue;}
  double a=(box.lo[i]-o[i])/d[i],b=(box.hi[i]-o[i])/d[i];if(a>b)std::swap(a,b);
  near=std::fmax(near,a);far=std::fmin(far,b);if(near>far)return false;
 }
 if(near<=0){if(far<=.001)return false;near=std::fmin(.01,far*.5);}
 hit={origin.x+direction.x*near,origin.y+direction.y*near,origin.z+direction.z*near};return true;
}
inline bool rayHit(Vec origin,const float q[4],const Box& box,double reach,Vec& hit){
 double x=q[0],y=q[1],z=q[2],w=q[3],n=x*x+y*y+z*z+w*w;
 if(!std::isfinite(n)||n<.90||n>1.10)return false;
 return rayHitVector(origin,{-2*(x*z+y*w),2*(x*w-y*z),-1+2*(x*x+y*y)},box,reach,hit);
}
inline bool rayHitView(Vec origin,const DirectLook& look,const Box& box,double reach,Vec& hit){
 Angles pose{};if(!cameraPose(look,pose))return false;
 double p=pose.pitch*CAMERA_RAD,y=pose.yaw*CAMERA_RAD;
 return rayHitVector(origin,{-std::sin(y)*std::cos(p),-std::sin(p),std::cos(y)*std::cos(p)},box,reach,hit);
}
class AttemptMeter {
 std::array<int64_t,64> stamps{};unsigned cursor=0;
public:
 AttemptMeter(){reset();}
 void reset(){stamps.fill(-1);cursor=0;}
 void add(int64_t now){stamps[cursor++%stamps.size()]=now;}
 unsigned rate(int64_t now)const{unsigned count=0;for(auto t:stamps)if(t>=0&&now>=t&&now-t<1000)count++;return count;}
};

}
