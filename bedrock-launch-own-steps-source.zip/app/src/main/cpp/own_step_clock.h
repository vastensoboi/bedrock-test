#pragma once
#include <cstdint>
#include <limits>

// Numbering and fractional scheduling only. This class never changes a packet,
// a history buffer or any game clock. A caller must commit only after a fresh
// native history record has actually been appended.
namespace kulich_own_step {
struct Session {
 uint64_t client=0,registry=0,level=0,clockSource=0;
 bool valid()const{return client&&registry&&level&&clockSource;}
 bool operator==(const Session& b)const{return client==b.client&&registry==b.registry&&level==b.level&&clockSource==b.clockSource;}
};
class Clock {
 Session session_{};bool bound_=false,sent_=false,planned_=false,pending_=false;
 uint64_t world_=0,offset_=0,sentWorld_=0,sentTick_=0,plannedWorld_=0;
 unsigned fraction_=0;int setting_=100;
public:
 uint64_t resets=0,commits=0;
 bool bind(Session session,uint64_t world){
  if(!session.valid()||!world)return false;
  if(!bound_||!(session_==session)||world<world_){
   session_=session;bound_=true;offset_=0;sent_=planned_=pending_=false;sentTick_=sentWorld_=plannedWorld_=0;
   fraction_=0;setting_=100;++resets;
  }
  if(world!=world_)pending_=false;
  world_=world;return true;
 }
 bool matches(Session session)const{return bound_&&session_==session;}
 bool mapped(uint64_t world,uint64_t& result)const{
  if(!bound_||!world||world>std::numeric_limits<uint64_t>::max()-offset_)return false;
  result=world+offset_;return true;
 }
 bool submitted(uint64_t world,uint64_t tick){
  uint64_t expected=0;
  if(world!=world_||!mapped(world,expected)||tick!=expected)return false;
  sent_=true;sentWorld_=world;sentTick_=tick;return true;
 }
 // A duplicate cleanup, a missing ordinary submission or an ineligible frame
 // must not accumulate a burst of deferred simulation steps.
 bool plan(uint64_t world,bool active,int hundredths,bool eligible){
  if(!bound_||world!=world_||!sent_||sentWorld_!=world)return false;
  if(planned_&&plannedWorld_==world)return false;
  bool consecutive=!planned_||(plannedWorld_!=std::numeric_limits<uint64_t>::max()&&world==plannedWorld_+1);
  planned_=true;plannedWorld_=world;pending_=false;
  if(!active||hundredths<=100||!eligible){fraction_=0;setting_=100;return false;}
  if(hundredths>200)hundredths=200;
  if(!consecutive||setting_!=hundredths)fraction_=0;
  setting_=hundredths;fraction_+=unsigned(hundredths-100);
  if(fraction_<100)return false;
  fraction_-=100;pending_=true;return true;
 }
 bool next(uint64_t world,uint64_t& tick)const{
  uint64_t current=0;
  if(world!=world_||!mapped(world,current)||current==std::numeric_limits<uint64_t>::max())return false;
  tick=current+1;return true;
 }
 bool commit(uint64_t world,uint64_t recordedTick){
  uint64_t expected=0;
  if(!pending_||!next(world,expected)||recordedTick!=expected)return false;
  pending_=false;++offset_;++commits;return true;
 }
 // Disabling discards scheduling credit, while retaining the accumulated tick
 // offset. Dropping that offset would send backwards ticks after Timer stops.
 void pause(){fraction_=0;setting_=100;pending_=false;}
 uint64_t offset()const{return offset_;}
 uint64_t world()const{return world_;}
 uint64_t sentTick()const{return sentTick_;}
 unsigned fraction()const{return fraction_;}
};
}
