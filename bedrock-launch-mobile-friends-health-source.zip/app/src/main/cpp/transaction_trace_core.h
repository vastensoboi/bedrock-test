#pragma once
#include <array>
#include <cstdint>
#include <cstring>
#include <sstream>
namespace kulich_trace {
using Address=uint64_t;
constexpr Address untag(Address v){return v&0x00ffffffffffffffULL;}
struct Sample {int id=0;bool valid=false;uint32_t rows=0;std::array<unsigned char,72> row{};std::array<unsigned char,104> action{};bool hasAction=false;};
inline Address word(const unsigned char* p){Address v=0;std::memcpy(&v,p,8);return untag(v);}
inline bool vector(Address b,Address e,Address c,unsigned stride,unsigned limit){return b>=4096&&e>=b&&c>=e&&(e-b)%stride==0&&(c-b)%stride==0&&c-b<=uint64_t(stride)*limit;}
template<class Read> Sample capture(Read read,Address packet,int id){
 Sample s;s.id=id;std::array<unsigned char,72> h{},again{};
 if((id!=147&&id!=148)||!read(packet,h.data(),h.size()))return s;
 Address b=word(h.data()+48),e=word(h.data()+56),c=word(h.data()+64);unsigned stride=id==147?72:48;
 if(!vector(b,e,c,stride,128))return s;
 s.rows=static_cast<uint32_t>((e-b)/stride);
 if(s.rows&&!read(b,s.row.data(),stride))return s;
 if(id==147&&s.rows){
  Address ab=word(s.row.data()+16),ae=word(s.row.data()+24),ac=word(s.row.data()+32);
  if(vector(ab,ae,ac,104,128)&&ae>ab){
   std::array<unsigned char,72> current{};
   if(!read(ab,s.action.data(),s.action.size())||!read(b,current.data(),current.size())||current!=s.row)return s;
   std::array<unsigned char,104> currentAction{};
   if(!read(ab,currentAction.data(),currentAction.size())||currentAction!=s.action)return s;
   s.hasAction=true;
  }
 }
 if(!read(packet,again.data(),again.size())||h!=again)return s;
 s.valid=true;return s;
}
template<class Read,class Reply> void replies(Read read,Address packet,Reply reply){
 std::array<unsigned char,72> header{},again{};
 if(!read(packet,header.data(),header.size()))return;
 Address b=word(header.data()+48),e=word(header.data()+56),c=word(header.data()+64);
 if(!vector(b,e,c,48,128))return;
 for(Address row=b;row<e;row+=48){
  std::array<unsigned char,48> data{},check{};if(!read(row,data.data(),data.size()))return;
  int32_t id=0;std::memcpy(&id,data.data()+16,4);int status=data[0];
  if(!read(row,check.data(),check.size())||data!=check||!read(packet,again.data(),again.size())||header!=again)return;
  if(id<0)reply(id,status);
 }
}
inline std::string describe(const Sample& s){
 std::ostringstream o;o<<"packet="<<s.id<<" stable="<<s.valid<<" rows="<<s.rows;
 auto hex=[&](const unsigned char* p,size_t n){static constexpr char digits[]="0123456789abcdef";for(size_t i=0;i<n;i++)o<<digits[p[i]>>4]<<digits[p[i]&15];};
 if(s.valid&&s.rows){
  int32_t id=0;std::memcpy(&id,s.row.data()+(s.id==147?8:16),4);o<<" requestId="<<id;
  if(s.id==148)o<<" responseStatus="<<int(s.row[0]);
  o<<" firstRow=";hex(s.row.data(),s.id==147?72:48);}
 if(s.valid&&s.hasAction){
  int32_t type=-1,sourceId=0,targetId=0;std::memcpy(&type,s.action.data()+96,4);
  std::memcpy(&sourceId,s.action.data()+32,4);std::memcpy(&targetId,s.action.data()+72,4);
  if(type==0||type==1)o<<" action="<<(type==0?"take":"place")<<" count="<<int(s.action[8])<<" sourceType="<<int(s.action[16])<<" sourceSlot="<<int(s.action[28])<<" sourceNetId="<<sourceId<<" targetType="<<int(s.action[56])<<" targetSlot="<<int(s.action[68])<<" targetNetId="<<targetId;
  o<<" firstAction=";hex(s.action.data(),s.action.size());}
 return o.str();
}
}
