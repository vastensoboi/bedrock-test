#include "aim_combat.h"
#include "aim_profile.h"
#include <jni.h>
#include <mutex>
#include <chrono>
#include <atomic>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>
namespace {
using namespace kulich_aim;
std::mutex gate;int memory=-1;A base=0,client=0;bool ready=false,enabled=false,head=false,sharp=true;
AxisStabilizer axis;ClickClock clicks;bool attackEnabled=true;int cps=15;uint64_t attackCalls=0,attackAccepted=0;int64_t hudAt=-1;float hudHp=NAN,hudMaxHp=NAN;int attackState=1;AttemptMeter meter;uint64_t swingCalls=0;char hudName[385]{};int64_t hudReadAt=-1;A hudActor=0;uint32_t hudEntity=0;
std::atomic<int64_t> lease{0};double radius=3;Lock targetLock;
int turnSpeed=240,smoothMs=80,priority=0;TurnClock turnClock;AimDeadzone deadzone;AimRamp ramp;double maxTurn=0;bool settled=false;
uint64_t ticks=0,applied=0,cameraChanges=0;uint32_t cameraEntity=0xffffffffU;A cameraRegistry=0;float previousQuaternion[4]{};bool haveCamera=false;unsigned checked=0;int reason=0,binding=0;float lastDistance=0,lastHp=NAN;Angles lastLook{},lastView{},lastDesired{};int64_t nextScan=0,deadline=0;unsigned reads=0;
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(A at,void* out,size_t size){
 at=plain(at);if(memory<0||at<4096||size>65536||at>0x00ffffffffffffffULL-size||++reads>8192||(deadline&&now()>deadline))return false;
 ssize_t n;do{n=pread(memory,out,size,static_cast<off_t>(at));}while(n<0&&errno==EINTR);return n==ssize_t(size);
}
}
extern "C" void kulich_aim_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);if(!lock.owns_lock()||!ready||!enabled)return;
 ticks++;if(now()>lease.load()){reason=1;turnClock.reset();deadzone.reset();axis.reset();clicks.reset();meter.reset();ramp.reset();return;}
 double allowance=turnClock.allowance(now(),turnSpeed);reads=0;deadline=now()+5;
 A self=plain(taggedPlayer);if(pointer(readMemory,self)!=base+0x139f6ea0ULL||pointer(readMemory,self+3240)!=client){reason=2;targetLock.reset();return;}
 A weak[3]{};if(!readMemory(client+576,weak,sizeof weak)||!plain(weak[1])){reason=2;targetLock.reset();return;}
 A registry=plain(weak[0]);if(!registry||pointer(readMemory,self+8)!=registry||integer(readMemory,self+24)!=uint32_t(weak[2])){reason=2;targetLock.reset();return;}
 auto v=view(readMemory,registry);Actor local{},target{};
 if(!actor(readMemory,base,v,self,true,local,&binding)){reason=3;targetLock.reset();return;}
 bool retained=retain(readMemory,base,v,local,radius,targetLock,target);
 if(retained){lastHp=health(readMemory,base,registry,target.entity);if(std::isfinite(lastHp)&&lastHp<=0){retained=false;targetLock.reset();}}
 if(!retained||now()>=nextScan){
  if(!retained&&now()<nextScan){reason=4;return;}nextScan=now()+300;
  Lock candidateLock;Actor candidate{};
  if(acquire(readMemory,base,v,local,radius,candidateLock,candidate,checked,priority==1)){
   float hp=health(readMemory,base,registry,candidate.entity);
   if(!retained||prefer(priority==1,hp,distance2(local.box,candidate.box),lastHp,distance2(local.box,target.box),true)){
    target=candidate;targetLock=candidateLock;lastHp=hp;retained=true;
   }
  }
  if(!retained){reason=4;return;}
 }
 Angles desired{};if(!angles(point(local.box,true),aimPoint(target.box,head),local.look.yaw,desired)){reason=5;targetLock.reset();return;}
 // Revalidate identity/components immediately before calls on the game thread.
 Actor current{},currentTarget{};
 if(!actor(readMemory,base,v,self,true,current)||!actor(readMemory,base,v,target.address,false,currentTarget)||
    current.entity!=local.entity||current.rotation!=local.rotation||currentTarget.entity!=target.entity||
    distance2(current.box,currentTarget.box)>radius*radius||now()>lease.load()||
    !angles(point(current.box,true),aimPoint(currentTarget.box,head),current.look.yaw,desired)) {reason=6;targetLock.reset();return;}
 // The active camera has its own input state; Actor::setRot is overwritten by
 // that state. Use the game's view-input callback and let its camera/player
 // systems perform the update. Preserve allocation tags on native arguments.
 A taggedClient=0;unsigned char alive=0;
 A owner=pointer(readMemory,client+424),lifetime=owner?pointer(readMemory,owner+8):0;
 if(!readMemory(self+3240,&taggedClient,8)||plain(taggedClient)!=client||!lifetime||
    !readMemory(lifetime,&alive,1)||!(alive&1)||
    pointer(readMemory,base+0x1388fe70ULL+165*8)!=base+CAMERA_OWNER_GET){reason=7;return;}
 CameraContext context=reinterpret_cast<CameraContext(*)(void*)>(base+ACTIVE_CAMERA_GET)(reinterpret_cast<void*>(taggedClient));
 CameraBinding camera{};if(!cameraBinding(readMemory,context,camera)){reason=7;return;}
 float quaternion[4]{};if(!readMemory(plain(camera.camera)+40,quaternion,sizeof quaternion)){reason=7;return;}
 if(haveCamera&&cameraEntity==context.entity&&cameraRegistry==plain(context.registry)){
  double change=0;for(int i=0;i<4;i++)change+=std::abs(quaternion[i]-previousQuaternion[i]);
  if(change>.00001)cameraChanges++;
 }
 std::memcpy(previousQuaternion,quaternion,sizeof quaternion);haveCamera=true;
 cameraEntity=context.entity;cameraRegistry=plain(context.registry);
 CameraBinding again{};
 if(!cameraBinding(readMemory,context,again)||again.camera!=camera.camera||again.direct!=camera.direct||
    now()>lease.load()){reason=7;return;}
 Angles view{};alignas(8) Angles value{},delta{};
 if(!cameraPose(again.look,view)||
    !angles(point(current.box,true),aimPoint(currentTarget.box,head),view.yaw,desired)){reason=5;return;}
 Angles stable=axis.apply(target.address,target.entity,head,view,desired);
 if(!(sharp?cameraSnap(stable,again.look,value,delta):cameraInput(stable,allowance*ramp.scale(target.address,target.entity,now()),allowance/turnSpeed,smoothMs/1000.0,again.look,value,delta))){reason=5;return;}
 lastView=view;lastLook=value;lastDesired=desired;
 settled=angleGap(view,desired)<=.10;lastDistance=float(std::sqrt(distance2(local.box,target.box)));
 if(deadzone.hold(angleGap(view,desired))){settled=true;reason=0;return;}
 if((!sharp&&allowance==0)||angleGap(view,value)<.00001){reason=0;return;}
 reinterpret_cast<void(*)(const CameraContext*,void*,void*,const Angles*)>(base+CAMERA_INPUT)
  (&context,reinterpret_cast<void*>(camera.camera),reinterpret_cast<void*>(camera.direct),&delta);
 DirectLook accepted{};constexpr double rad=3.14159265358979323846/180.0;
 if(!readMemory(plain(camera.direct),&accepted,sizeof accepted)||!valid(accepted)||
    std::abs(accepted.pitch-(again.look.pitch+delta.pitch*rad))>.001||
    std::abs(accepted.pendingYaw-(again.look.pendingYaw-delta.yaw*rad))>.001){reason=8;return;}
 applied++;maxTurn=std::fmax(maxTurn,angleGap(view,value));reason=0;
}
extern "C" void kulich_aim_attack_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);if(!lock.owns_lock())return;
 if(!ready||!enabled||now()>lease.load()){attackState=1;return;}
 if(!targetLock.actor){attackState=2;return;}
 reads=0;deadline=now()+5;A self=plain(taggedPlayer);
 if(pointer(readMemory,self)!=base+0x139f6ea0ULL||pointer(readMemory,self+3240)!=client||pointer(readMemory,self+8)!=targetLock.registry){attackState=7;return;}
 auto v=view(readMemory,targetLock.registry);Actor local{},target{};Lock attackLock=targetLock;
 if(!actor(readMemory,base,v,self,true,local)||!retain(readMemory,base,v,local,radius,attackLock,target)){attackState=3;return;}
 float hp=health(readMemory,base,v.registry,target.entity);if(std::isfinite(hp)&&hp<=0){attackState=2;return;}
 bool refresh=hudReadAt<0||now()-hudReadAt>=200||hudActor!=target.address||hudEntity!=target.entity;hudAt=now();hudHp=hp;hudMaxHp=health(readMemory,base,v.registry,target.entity,true);
 if(refresh){hudReadAt=now();hudActor=target.address;hudEntity=target.entity;if(!targetName(readMemory,target.address,hudName,sizeof hudName))hudName[0]=0;}
 A taggedClient=0,mode=0,taggedTarget=0;
 if(!readMemory(self+3240,&taggedClient,8)||!readMemory(self+2568,&mode,8)||!mode){attackState=7;return;}
 A function=attackBinding(readMemory,base,mode,taggedPlayer);if(!function){attackState=7;return;}
 A lifetime=pointer(readMemory,pointer(readMemory,client+424)+8);unsigned char alive=0;
 if(!lifetime||!readMemory(lifetime,&alive,1)||!(alive&1)){attackState=7;return;}
 CameraContext context=reinterpret_cast<CameraContext(*)(void*)>(base+ACTIVE_CAMERA_GET)(reinterpret_cast<void*>(taggedClient));
 CameraBinding camera{};Vec hit{};
 if(!cameraBinding(readMemory,context,camera)){attackState=7;return;}
 // The rendered quaternion may be one frame behind our sharp input. Use the
 // effective view INCLUDING pending yaw, already validated by the aim path.
 if(!rayHitView(point(local.box,true),camera.look,target.box,radius,hit)){attackState=4;return;}
 A owner=component(readMemory,v.owners,target.entity,8);
 if(!owner||!readMemory(owner,&taggedTarget,8)||plain(taggedTarget)!=target.address||pointer(readMemory,self+2568)!=plain(mode)){attackState=7;return;}
 int count=clicks.take(now(),cps);if(!count){attackState=5;return;}
 float at[3]{float(hit.x),float(hit.y),float(hit.z)};attackState=6;
 for(int i=0;i<count;i++){
  Actor fresh{};if(!actor(readMemory,base,v,target.address,false,fresh)||fresh.entity!=target.entity||pointer(readMemory,self+2568)!=plain(mode)||now()>lease.load())break;
  if(pointer(readMemory,base+0x139f6ea0ULL+880)==base+SWING){
   reinterpret_cast<bool(*)(void*,int,int)>(base+SWING)(reinterpret_cast<void*>(taggedPlayer),3,0);swingCalls++;
  }
  attackCalls++;meter.add(now());
  if(dispatchAttack(reinterpret_cast<bool(*)(void*,void*,const float*)>(function),reinterpret_cast<void*>(mode),reinterpret_cast<void*>(taggedTarget),at)){
   attackAccepted++;attackState=0;
  }
 }
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_AimbotBridge_install(JNIEnv* env,jclass,jlong address,jlong owner){
 std::lock_guard<std::mutex> lock(gate);deadline=0;reads=0;
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0)return env->NewStringUTF("Cannot read game process");
 A candidate=A(address),candidateClient=plain(A(owner));
 if((base&&base!=candidate)||pointer(readMemory,candidateClient)!=candidate+0x1388fe70ULL)return env->NewStringUTF("Unsupported client binding");
 for(const auto& p:aimProfiles){uint32_t words[8]{};if(!readMemory(candidate+p.offset,words,sizeof words)||std::memcmp(words,p.words,sizeof words))return env->NewStringUTF("Aim code profile mismatch");}
 base=candidate;client=candidateClient;ready=true;targetLock.reset();turnClock.reset();deadzone.reset();axis.reset();clicks.reset();meter.reset();ramp.reset();nextScan=0;return env->NewStringUTF("");
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_enable(JNIEnv*,jclass,jboolean value){
 std::lock_guard<std::mutex> lock(gate);enabled=ready&&value;hudAt=-1;targetLock.reset();turnClock.reset();deadzone.reset();axis.reset();clicks.reset();meter.reset();ramp.reset();maxTurn=0;settled=false;nextScan=0;reason=0;cameraChanges=0;cameraEntity=0xffffffffU;cameraRegistry=0;haveCamera=false;if(!enabled)lease=0;
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_configure(JNIEnv*,jclass,jint range,jint rate){
 std::lock_guard<std::mutex> lock(gate);radius=range<1?1:range>5?5:range;
 int next=rate<1?1:rate>30?30:rate;if(next!=cps){clicks.reset();meter.reset();}cps=next;
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_AimbotBridge_pulse(JNIEnv*,jclass,jboolean active){lease=active?now()+1200:0;}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_AimbotBridge_status(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);char text[1024];
 snprintf(text,sizeof text,"Aimbot: enabled=%d point=%s range=%.0f speed=%d smoothMs=%d mode=%s priority=%s hp=%.2f autoAttack=%d cps=%d attacks=%llu accepted=%llu attackState=%d actualCps=%u swings=%llu settled=%d maxTurn=%.3f target=%u distance=%.2f ticks=%llu applied=%llu checked=%u pitch=%.2f yaw=%.2f viewPitch=%.2f viewYaw=%.2f goalPitch=%.2f goalYaw=%.2f phase=camera-input-v8 camera=%u cameraChanges=%llu bind=%d reason=%d",enabled,head?"head":"body",radius,turnSpeed,smoothMs,sharp?"sharp":"smooth",priority==1?"health":"nearest",lastHp,attackEnabled,cps,static_cast<unsigned long long>(attackCalls),static_cast<unsigned long long>(attackAccepted),attackState,meter.rate(now()),static_cast<unsigned long long>(swingCalls),settled,maxTurn,targetLock.entity,lastDistance,static_cast<unsigned long long>(ticks),static_cast<unsigned long long>(applied),checked,lastLook.pitch,lastLook.yaw,lastView.pitch,lastView.yaw,lastDesired.pitch,lastDesired.yaw,cameraEntity,static_cast<unsigned long long>(cameraChanges),binding,reason);
 return env->NewStringUTF(text);
}

extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_AimbotBridge_hudSnapshot(JNIEnv* env,jclass){
 std::lock_guard<std::mutex> lock(gate);
 if(!enabled||hudAt<0||now()-hudAt>5000)return env->NewStringUTF("");
 char result[950]{};int n=snprintf(result,sizeof result,"%lld|%.2f|",static_cast<long long>(now()-hudAt),hudHp);
 constexpr char hex[]="0123456789abcdef";
 for(size_t i=0;i<sizeof hudName&&hudName[i]&&n+2<int(sizeof result);i++){
  unsigned char value=static_cast<unsigned char>(hudName[i]);result[n++]=hex[value>>4];result[n++]=hex[value&15];
 }
 snprintf(result+n,sizeof result-size_t(n),"|%.2f|%d|%u|%d",hudMaxHp,attackState,meter.rate(now()),cps);
 return env->NewStringUTF(result);
}
