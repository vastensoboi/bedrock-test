#include "../app/src/main/cpp/hud_data_core.h"
#include <cassert>
#include <iostream>
#include <vector>
using namespace kulich_hud;
struct Memory {
 static constexpr A base=0x10000;std::vector<unsigned char> bytes=std::vector<unsigned char>(65536);bool mutate=false;unsigned headers=0;
 template<class T> void put(A p,T v){assert(p>=base&&p-base+sizeof v<=bytes.size());std::memcpy(bytes.data()+p-base,&v,sizeof v);}
 bool operator()(A p,void* out,size_t size){p=plain(p);if(p<base||p-base+size>bytes.size())return false;std::memcpy(out,bytes.data()+p-base,size);if(mutate&&p==base&&size==24&&++headers==2)static_cast<unsigned char*>(out)[8]^=8;return true;}
 void header(A begin,A end,A cap){put(base,std::array<A,3>{begin,end,cap});}
 void effect(A at,int id,int ticks,int amp){std::array<int32_t,9> f{};f[0]=id;f[1]=ticks;f[8]=amp;put(at,f);}
};
int main(){
 Memory m;std::string out;A data=Memory::base+256;
 assert(readEffectVector(m,Memory::base,out)&&out.empty()); // known empty component
 m.header(data,data+4*160,data+5*160);m.effect(data,1,1800,1);m.effect(data+160,12,-1,0);m.effect(data+320,0,0,0);m.effect(data+480,5,0,4);
 auto original=m.bytes;assert(readEffectVector(m,Memory::base,out)&&out=="1,1,1800;12,0,-1"&&m.bytes==original);
 constexpr A tag=0xb400000000000000ULL;m.header(data|tag,(data+4*160)|tag,(data+5*160)|tag);
 assert(readEffectVector(m,Memory::base|tag,out)&&out=="1,1,1800;12,0,-1");
 m.mutate=true;m.headers=0;assert(!readEffectVector(m,Memory::base,out)&&out.empty());m.mutate=false;
 m.header(data,data+161,data+320);assert(!readEffectVector(m,Memory::base,out));
 m.header(data,data+129*160,data+129*160);assert(!readEffectVector(m,Memory::base,out));
 m.header(data,data+2*160,data+2*160);m.effect(data+160,1,100,0);assert(!readEffectVector(m,Memory::base,out));
 m.header(data,data+160,data+160);
 for(auto value:std::vector<std::array<int,3>>{{39,100,0},{1,-2,0},{1,100,-1},{1,100,256}}){m.effect(data,value[0],value[1],value[2]);assert(!readEffectVector(m,Memory::base,out));}
 m.effect(data,38,2147483647,255);assert(readEffectVector(m,Memory::base,out)&&out=="38,255,2147483647");
 m.header(0,data,data);assert(!readEffectVector(m,Memory::base,out));
 m.header(data,data+160,data);assert(!readEffectVector(m,Memory::base,out));
 assert(!readEffectVector(m,0,out));
 std::cout<<"PASS: native MobEffect vector, remaining ticks/infinite/amplifier, readonly/tagged data, empty and malformed/concurrent guards\n";
}
