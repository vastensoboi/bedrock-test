# Terrain collision for pearl prediction

Verified against the supplied `libminecraftpe.so` (Minecraft 1.26.60.4 arm64), rather than a different version's headers. All calls run on the game thread after validating the actor's registry ownership and lifetime. No block, actor or network state is modified by these helpers.

* `Actor::getRegion`, relative address `0xfd827a0`, uses actor pointers at +480 and +488, enters the engine dimension/thread guard and dispatches dimension virtual +112. The result is the projectile system's BlockSource. Its exact primary vptr is `0x13d6dcd0`.
* The BlockSource vtable slot 51 (+408), `0x1037905c`, performs the native voxel traversal and calls block shape clipping. Slot 52 (+416), `0x10379008`, is its ClipContext adapter.
* The real projectile system invokes slot 51 at `0xc04d6b0`. Its arguments are `(source, &start, &end, component[467] & 1, 1 & ~component[467], 200, true, false, actor, &nativeFilter, false)`. The native filter is relative address `0x141db670`; it is initialized in writable BSS. Check its `std::function` implementation at +32 before use. The filter is called through its implementation virtual +48.
* Results use the arm64 x8 indirect-result register. The aggregate occupies 136 bytes. The result kind is int32 at +24, face is byte +28, BlockPos occupies +32..43, and hit position occupies +44..55. Kind 0 is a block intersection; kinds 2 and 3 are non-hits. Constructors `0x110c21f0` (block) and `0x110c20b8` (miss) directly prove these fields. Do not invent a landing point when the ray has no known hit.
* The result contains a weak reference control block at +64. Native callers test it and call `0x135d3980`. That PLT relocation resolves to `std::__ndk1::__shared_weak_count::__release_weak()`. The RAII guard in the helper performs the same release, even when result validation fails.

The native block clipping helper `0x10381b40` receives BlockPos, start, end and a block-local AABB and returns the same hit aggregate. The full BlockSource raycast uses it through the block's own shape routines; using the full raycast therefore preserves actual collision shapes instead of assuming every block is a unit cube.

The caller owns the shared ray budget and maximum number of prediction steps/pearls. The helper rejects invalid coordinates and segments longer than 16 blocks, returns an explicit unavailable result for binding/data failures, and exposes the fractional position within the tick for the landing ETA. Block tracing does not include another actor's body; that is a separate collision pass.
