#pragma once
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
namespace kulich_aim {
using A=uint64_t;
constexpr uint32_t OWNER=0x85b93800U,SHAPE=0xbac1b3cfU,ROTATION=0x75df36b7U,HEAD=0xbabe7211U;
inline A plain(A p){return p&0x00ffffffffffffffULL;}
template<class Read> A pointer(Read& read,A at){A p=0;return read(plain(at),&p,8)?plain(p):0;}
template<class Read> uint32_t integer(Read& read,A at){uint32_t p=0xffffffffU;return read(plain(at),&p,4)?p:0xffffffffU;}
template<class Read> A pool(Read& read,A registry,uint32_t key){
 A h[5]{};if(!read(registry+96,h,sizeof h))return 0;
 A buckets=plain(h[0]),end=plain(h[1]),nodes=plain(h[3]),last=plain(h[4]);
 if(!buckets||end<buckets||(end-buckets)%8||!nodes||last<nodes||(last-nodes)%32)return 0;
 A count=(end-buckets)/8,n=(last-nodes)/32;if(!count||count>4096||(count&(count-1))||!n||n>4096)return 0;
 int64_t index=-1;if(!read(buckets+(key&(count-1))*8,&index,8))return 0;
 for(int tries=0;index!=-1&&tries<64;tries++){
  if(index<0||A(index)>=n)return 0;
  A row[4]{};if(!read(nodes+A(index)*32,row,sizeof row))return 0;
  if(uint32_t(row[1])==key)return plain(row[2]);
  index=int64_t(row[0]);
 }
 return 0;
}
template<class Read> int64_t sparse(Read& read,A pages,uint32_t entity){
 A bounds[2]{};if(!read(pages,bounds,sizeof bounds))return -1;A begin=plain(bounds[0]),end=plain(bounds[1]),i=(entity>>11)&127;
 if(!begin||end<begin||(end-begin)%8||(end-begin)/8>128||i>=(end-begin)/8)return -1;
 A page=pointer(read,begin+i*8);if(!page)return -1;uint32_t packed=integer(read,page+(entity&2047)*4);
 if((packed^(entity&0xfffc0000U))>0x3fffeU)return -1;
 return packed&0x3ffffU;
}
template<class Read> A taggedComponent(Read& read,A storage,uint32_t entity,unsigned stride){
 if(!storage)return 0;
 int64_t index=sparse(read,storage+8,entity);if(index<0)return 0;
 A h[3]{};if(!read(storage+80,h,sizeof h))return 0;A begin=plain(h[0]),end=plain(h[1]),cap=plain(h[2]);
 if(!begin||end<begin||cap<end||(end-begin)%8||(end-begin)/8>2048||A(index>>7)>=(end-begin)/8)return 0;
 A page=0;if(!read(begin+A(index>>7)*8,&page,8)||plain(page)<4096)return 0;
 return page+A(index&127)*stride;
}
template<class Read> A component(Read& read,A storage,uint32_t entity,unsigned stride){return plain(taggedComponent(read,storage,entity,stride));}
struct View{A registry=0,owners=0,shapes=0,rotations=0,heads=0;};
template<class Read> View view(Read& read,A registry){
 return {registry,pool(read,registry,OWNER),pool(read,registry,SHAPE),pool(read,registry,ROTATION),pool(read,registry,HEAD)};
}
struct Vec{double x=0,y=0,z=0;};
struct Box{float lo[3]{},hi[3]{};float width=0,height=0;};
inline bool valid(const Box& b){
 for(int i=0;i<3;i++)if(!std::isfinite(b.lo[i])||!std::isfinite(b.hi[i])||std::abs(b.lo[i])>32000000||std::abs(b.hi[i])>32000000)return false;
 double x=b.hi[0]-b.lo[0],y=b.hi[1]-b.lo[1],z=b.hi[2]-b.lo[2];
 return x>=0.05&&x<=4&&y>=0.1&&y<=4&&z>=0.05&&z<=4;
}
inline Vec point(const Box& b,bool head){return {(double(b.lo[0])+b.hi[0])*0.5,b.lo[1]+(b.hi[1]-b.lo[1])*(head?0.90:0.50),(double(b.lo[2])+b.hi[2])*0.5};}
inline double distance2(const Box& a,const Box& b){auto x=point(a,false),y=point(b,false);return (x.x-y.x)*(x.x-y.x)+(x.y-y.y)*(x.y-y.y)+(x.z-y.z)*(x.z-y.z);}
struct Angles{float pitch=0,yaw=0;};
static_assert(sizeof(Box)==32&&sizeof(Angles)==8,"Exact-build component layouts");
inline bool angles(Vec eye,Vec target,float oldYaw,Angles& out){
 if(!std::isfinite(oldYaw)||std::abs(oldYaw)>1e8)return false;
 double x=target.x-eye.x,y=target.y-eye.y,z=target.z-eye.z,h=std::hypot(x,z);
 if(!std::isfinite(x)||!std::isfinite(y)||!std::isfinite(z)||(h<1e-6&&std::abs(y)<1e-6))return false;
 constexpr double deg=180.0/3.14159265358979323846;
 double yaw=h<1e-6?oldYaw:std::atan2(-x,z)*deg;
 out.pitch=float(std::fmax(-89.9,std::fmin(89.9,-std::atan2(y,h)*deg)));
 out.yaw=float(oldYaw+std::remainder(yaw-oldYaw,360.0));return std::isfinite(out.pitch)&&std::isfinite(out.yaw);
}
// Uniform angular speed measured from the current game pose, with no stored
// angle replay. A delayed update must never accumulate a large catch-up turn.
class TurnClock {
 int64_t previous=-1;
public:
 void reset(){previous=-1;}
 double allowance(int64_t now,double degreesPerSecond){
  if(!std::isfinite(degreesPerSecond)||degreesPerSecond<=0||degreesPerSecond>720)return 0;
  if(previous<0){previous=now;return degreesPerSecond*0.05;}
  int64_t elapsed=now-previous;previous=now;if(elapsed<=0)return 0;
  return degreesPerSecond*double(elapsed>100?100:elapsed)/1000.0;
 }
};
inline double angleGap(Angles a,Angles b){return std::hypot(double(b.pitch)-a.pitch,std::remainder(double(b.yaw)-a.yaw,360.0));}
inline bool turnToward(Angles current,Angles desired,double allowance,Angles& out){
 if(!std::isfinite(current.pitch)||std::abs(current.pitch)>90.01||!std::isfinite(current.yaw)||!std::isfinite(desired.pitch)||!std::isfinite(desired.yaw)||!std::isfinite(allowance)||allowance<0)return false;
 double dp=std::fmax(-89.9,std::fmin(89.9,double(desired.pitch)))-current.pitch;
 double dy=std::remainder(double(desired.yaw)-current.yaw,360.0),length=std::hypot(dp,dy);
 double scale=length>allowance&&length>0?allowance/length:1;
 out={float(current.pitch+dp*scale),float(current.yaw+dy*scale)};
 return std::isfinite(out.pitch)&&std::isfinite(out.yaw);
}
struct Actor{A address=0,shape=0,rotation=0;uint32_t entity=0xffffffffU;Box box{};Angles look{};};
template<class Read> bool actor(Read& read,A base,const View& v,A address,bool local,Actor& out,int* failure=nullptr){
 auto reject=[&](int value){if(failure)*failure=value;return false;};if(failure)*failure=0;
 address=plain(address);if(address<4096)return reject(1);
 A header[4]{};if(!read(address,header,sizeof header))return reject(1);
 A type=plain(header[0]);if(type!=base+(local?0x139f6ea0ULL:0x139f76b0ULL))return reject(1);
 if(plain(header[1])!=v.registry||plain(header[2])!=v.registry+40)return reject(2);
 uint32_t entity=uint32_t(header[3]);if((entity&0x3ffffU)==0x3ffffU||sparse(read,v.registry+216,entity)<0)return reject(3);
 A owner=component(read,v.owners,entity,8);if(!owner||pointer(read,owner)!=address)return reject(4);
 unsigned char removed=1;if(!read(address+617,&removed,1)||removed)return reject(5);
 A shape=component(read,v.shapes,entity,32);Box box{};
 if(!shape||pointer(read,address+560)!=shape||!read(shape,&box,sizeof box)||!valid(box))return reject(6);
 A rotation=0;Angles look{};
 if(local){rotation=component(read,v.rotations,entity,16);if(!rotation||pointer(read,address+568)!=rotation||!read(rotation,&look,sizeof look)||!std::isfinite(look.pitch)||!std::isfinite(look.yaw))return reject(7);}
 out={address,shape,rotation,entity,box,look};return true;
}
// Exact-build AttributesComponent (88 bytes), sorted attribute IDs and
// parallel AttributeInstance records (136 bytes, current value +124).
template<class Read> float health(Read& read,A base,A registry,uint32_t entity,bool maximum=false){
 A attributes=component(read,pool(read,registry,0xfd3b0613U),entity,88);
 uint32_t key=integer(read,base+0x141d8f4cULL);if(!attributes||key==0xffffffffU)return NAN;
 A h[5]{};if(!read(attributes,h,sizeof h))return NAN;
 A ids=plain(h[0]),end=plain(h[1]),values=plain(h[3]),last=plain(h[4]);
 if(!ids||end<ids||(end-ids)%4||(end-ids)/4>256||!values||last<values||last-values!=(end-ids)/4*136)return NAN;
 for(A i=0;i<(end-ids)/4;i++)if(integer(read,ids+i*4)==key){
  float value=NAN;A again[5]{};
  if(!read(values+i*136+(maximum?120:124),&value,4)||!std::isfinite(value)||value<0||value>100000||
     !read(attributes,again,sizeof again)||std::memcmp(h,again,sizeof h))return NAN;
  return value;
 }
 return NAN;
}
inline bool prefer(bool hp,float candidateHp,double candidateDistance,float oldHp,double oldDistance,bool switching){
 bool known=std::isfinite(candidateHp),oldKnown=std::isfinite(oldHp);
 if(hp){if(known!=oldKnown)return known;if(known&&std::abs(candidateHp-oldHp)>.01)return candidateHp<oldHp-(switching?.5:0);}
 return candidateDistance<oldDistance*(switching?.85:1);
}
struct Lock{A actor=0,registry=0;uint32_t entity=0xffffffffU;void reset(){actor=registry=0;entity=0xffffffffU;}};
template<class Read> bool retain(Read& read,A base,const View& v,const Actor& self,double range,Lock& lock,Actor& target){
 if(lock.registry!=v.registry||lock.actor==self.address||!actor(read,base,v,lock.actor,false,target)||target.entity!=lock.entity||distance2(self.box,target.box)>range*range){lock.reset();return false;}return true;
}
template<class Read> bool acquire(Read& read,A base,const View& v,const Actor& self,double range,Lock& lock,Actor& target,unsigned& checked,bool byHealth=false){
 lock.reset();checked=0;A h[3]{};if(!v.owners||!read(v.owners+80,h,sizeof h))return false;
 A begin=plain(h[0]),end=plain(h[1]),cap=plain(h[2]);if(!begin||end<begin||cap<end||(end-begin)%8||(end-begin)/8>2048)return false;
 double best=range*range;float bestHp=NAN;bool found=false;
 for(A pageIndex=0;pageIndex<(end-begin)/8&&checked<4096;pageIndex++){
  A page=pointer(read,begin+pageIndex*8);if(!page)continue;std::array<A,128> values{};if(!read(page,values.data(),sizeof values))continue;
  for(A raw:values){if(++checked>4096)break;A a=plain(raw);if(!a||a==self.address)continue;Actor candidate{};
   if(!actor(read,base,v,a,false,candidate))continue;
   double d=distance2(self.box,candidate.box);
   if(d>range*range)continue;
   float hp=health(read,base,v.registry,candidate.entity);if(std::isfinite(hp)&&hp<=0)continue;
   if(found&&!prefer(byHealth,hp,d,bestHp,best,false))continue;
   best=d;bestHp=hp;target=candidate;found=true;
  }
 }
 if(found)lock={target.address,v.registry,target.entity};
 return found;
}
}
