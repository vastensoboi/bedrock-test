package dev.custom.bedrockgui;
/** Sharp aim with shared range and range-controlled native attacks. */
public final class AimbotBridge {
 private static volatile boolean ready,enabled;private static int radius=3,cpsMin=15,cpsMax=15;
 private static String friendNames="";
 private AimbotBridge(){}
 private static native void friends(String names);
 public static synchronized void setFriends(String names){friendNames=names==null?"":names;if(ready)try{friends(friendNames);}catch(RuntimeException|LinkageError error){enabled=false;try{enable(false);pulse(false);}catch(RuntimeException|LinkageError ignored){}throw new IllegalStateException("Защита друзей не обновилась; Aimbot выключен",error);}}
 private static native String install(long base,long client);
 private static native void enable(boolean value);
 private static native void configure(int radius,int cpsMin,int cpsMax);
 private static native void pulse(boolean value);
 private static native String status();private static native String hudSnapshot();
 public static synchronized void prepare(long base,long client){try{if(!FastExpBridge.isReady())return;String error=install(base,client);if(!error.isEmpty())throw new IllegalStateException(error);configure(radius,cpsMin,cpsMax);friends(friendNames);ready=true;GameRuntime.log("Aimbot: sharp aim and attack bridge prepared");}catch(RuntimeException|LinkageError e){ready=false;GameRuntime.log("Aimbot unavailable: "+e);}}
 public static boolean isReady(){return ready;}
 public static void setEnabled(boolean value){if(value&&!ready)throw new IllegalStateException("Нужен загруженный мир");if(ready){enable(value);pulse(value);}enabled=value;GameRuntime.log("Aimbot: enabled="+value);}
 public static void settings(int reach,int minimum,int maximum){radius=Math.max(1,Math.min(5,reach));cpsMin=Math.max(1,Math.min(40,minimum));cpsMax=Math.max(cpsMin,Math.min(40,maximum));if(ready)configure(radius,cpsMin,cpsMax);}
 public static int cpsMin(){return cpsMin;}public static int cpsMax(){return cpsMax;}public static int cps(){return cpsMax;}
 public static void heartbeat(){if(ready)pulse(enabled);}
 public static String targetSnapshot(){return ready?hudSnapshot():"";}
 public static String describe(){if(!ready)return "Подключение к миру ещё не готово";return (enabled?"Резкое наведение · "+radius+" блоков · "+(cpsMin==cpsMax?Integer.toString(cpsMin):cpsMin+"–"+cpsMax)+" CPS":"Выключен")+"\n"+status();}
}
