package dev.custom.bedrockgui;
public final class HudRosterDataTest {
 static void check(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] args){
  HudRosterData d=HudRosterData.parse("200|G|416e6e;426f62",1000);check(d!=null&&d.global&&d.names.length==2&&d.names[0].equals("Ann")&&d.capturedAt==800);
  check(d.fresh(3800)&&!d.fresh(3801));d=HudRosterData.parse("0|N|416e6e",1000);check(d!=null&&!d.global);
  d=HudRosterData.parse("0|G|",1000);check(d!=null&&d.global&&d.names.length==0);
  for(String bad:new String[]{"","3001|G|416e6e","-1|G|416e6e","0|X|416e6e","0|G|00","0|G|zz","0|G|a","0|G|416e6e;","2000|G|416e6e"})check(HudRosterData.parse(bad,1000)==null);
  System.out.println("PASS: roster scope, capture age, freshness, known empty and malformed rejection");
 }
}
