#pragma once
#include "aim_core.h"
#include <cstddef>
namespace kulich_aim {
constexpr uint32_t CAMERA=0x4f6047c7U,DIRECT_LOOK=0xceb578f1U;
constexpr uint32_t ACTIVE_CAMERA=0x113040a1U,INPUT_CAMERA=0xf6c60b46U;
// Native optional<StrictEntityContext>: large aggregate returned through x8 on
// AArch64. It owns no reference; use only during the same game-thread callback.
struct CameraContext {A registry=0,storage=0;uint32_t entity=0xffffffffU,padding=0;uint8_t present=0,reserved[7]{};};
struct DirectLook {float yaw=0,pitch=0,pendingYaw=0,minPitch=0,maxPitch=0;};
struct CameraBinding {A camera=0,direct=0;DirectLook look{};};
static_assert(sizeof(CameraContext)==32&&offsetof(CameraContext,present)==24&&offsetof(CameraContext,entity)==16,"Native camera context ABI");
static_assert(sizeof(DirectLook)==20,"Direct look storage stride");
inline bool valid(const DirectLook& d){
 constexpr double pi=3.14159265358979323846;
 return std::isfinite(d.yaw)&&std::abs(d.yaw)<=100&&std::isfinite(d.pitch)&&std::abs(d.pitch)<=pi&&
  std::isfinite(d.pendingYaw)&&std::abs(d.pendingYaw)<=pi&&std::isfinite(d.minPitch)&&std::isfinite(d.maxPitch)&&
  d.minPitch>=-pi&&d.maxPitch<=pi&&d.minPitch<d.maxPitch&&d.pitch>=d.minPitch-.01&&d.pitch<=d.maxPitch+.01;
}
template<class Read> bool cameraBinding(Read& read,const CameraContext& context,CameraBinding& out){
 A registry=plain(context.registry);if(context.present!=1||registry<4096||plain(context.storage)!=registry+40||
  (context.entity&0x3ffffU)==0x3ffffU||sparse(read,registry+216,context.entity)<0)return false;
 A active=pool(read,registry,ACTIVE_CAMERA),input=pool(read,registry,INPUT_CAMERA);
 if(!active||!input||sparse(read,active+8,context.entity)<0||sparse(read,input+8,context.entity)<0)return false;
 A camera=taggedComponent(read,pool(read,registry,CAMERA),context.entity,280);
 A direct=taggedComponent(read,pool(read,registry,DIRECT_LOOK),context.entity,20);DirectLook value{};
 if(!camera||!direct||!read(plain(direct),&value,sizeof value)||!valid(value))return false;
 // CameraDirectLookSystem writes a unit quaternion here before rendering.
 float q[4]{};if(!read(plain(camera)+40,q,sizeof q))return false;
 double norm=0;for(float v:q){if(!std::isfinite(v))return false;norm+=double(v)*v;}
 if(norm<.90||norm>1.10)return false;
 out={camera,direct,value};return true;
}
// The game's input callback consumes degrees: pitch += x*rad; pendingYaw -=
// y*rad. DirectLookSystem then folds pendingYaw into yaw and rebuilds the camera
// quaternion. World yaw has the opposite sign to this camera-space yaw.
inline bool cameraInput(Angles current,Angles desired,double allowance,const DirectLook& look,Angles& value,Angles& delta){
 if(!valid(look)||!turnToward(current,desired,allowance,value))return false;
 delta={value.pitch-current.pitch,float(std::remainder(double(value.yaw)-current.yaw,360.0))};
 // Respect the active camera's native pitch limits, including custom cameras.
 constexpr double rad=3.14159265358979323846/180.0;
 double pitch=std::fmax(double(look.minPitch),std::fmin(double(look.maxPitch),look.pitch+delta.pitch*rad));
 delta.pitch=float((pitch-look.pitch)/rad);value.pitch=current.pitch+delta.pitch;
 return std::isfinite(delta.pitch)&&std::isfinite(delta.yaw)&&angleGap(current,value)<=allowance+.001;
}
}
