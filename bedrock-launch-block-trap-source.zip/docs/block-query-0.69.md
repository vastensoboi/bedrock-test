# Exact block query for Block Trap

Verified against the supplied Minecraft 1.26.60.4 ARM64 image.

`BlockSource` primary vptr is `0x13d6dcd0`. Virtual slot2 (+16),
`0x10371248`, receives `(BlockSource*, const BlockPos*)` and returns a tagged
`Block*` in x0. Its first checks compare `BlockPos.y` against signed int16
exclusive maximum at source+64 and inclusive minimum at source+66. The helper
rejects outside-world queries rather than treating the native fallback as air.

The returned state has `Block` vptr `0x13dfc0a8`. Wrapper `0x109f3fd4`
loads its `BlockType*` at +104 and dispatches that type's virtual function.
`AirBlock` is an RTTI subclass of `BlockType`; constructor `0x10a1115c`
stores AirBlock's primary vptr `0x13dfda38`. Air classification checks that
exact typed relation and rereads the state/type link before publishing.

Non-air means only non-air. It does not mean a full solid support: water,
plants, slabs and other shapes still require the game's placement validation.
The conservative `inertSupport` gate accepts only exact RTTI-derived native
types StoneBlock (`0x13e4f530`), CobblestoneBlock (`0x13ddec18`),
ObsidianBlock (`0x13db7a28`), DirtBlock (`0x13ddb3a0`), GrassBlock
(`0x13dcd2e8`), BedrockBlock (`0x13dfa648`), MetalBlock (`0x13dbe6f8`),
PlanksBlock (`0x13db9cc0`), LogBlock (`0x13dbcd00`), NetherrackBlock
(`0x13db6928`), DeepslateBlock (`0x13dda660`) and ClayBlock (`0x13dde398`).
It skips all unknown types, including ChestBlock (`0x13ddd258`) and SlabBlock
(`0x13e56128`), before any native interaction. A matching type is still subject
to the native ray, placement and server checks; it is not a promise that every
variant can be used in every context.
The helper performs no writes and must run on the game's thread with a live,
validated source and caller. Raw allocation tags are retained on native calls.
