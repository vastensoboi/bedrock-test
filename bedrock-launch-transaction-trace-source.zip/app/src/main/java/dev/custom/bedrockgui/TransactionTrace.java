package dev.custom.bedrockgui;

/** Pass-through inventory-packet observation. Does not construct or send actions. */
public final class TransactionTrace {
    private static boolean loaded;
    private static native String install(long base);
    private static native void record(boolean active);
    private static native String snapshot();
    private TransactionTrace(){}
    public static synchronized String start(long verifiedBase){
        if(!loaded){System.loadLibrary("kulichtransactions");loaded=true;}
        String error=install(verifiedBase);if(!error.isEmpty())throw new IllegalStateException(error);
        record(true);GameRuntime.log("Transaction trace: recording inventory request/response metadata; no generated actions");
        return "Запись включена. Закрой kulich, вручную перетащи «Обновить» в инвентарь один раз, затем вернись и нажми «Сохранить запись действий».";
    }
    public static synchronized void flush(){if(loaded)save();}
    public static synchronized String save(){
        if(!loaded)return "Запись действий ещё не включена";
        record(false);String value=snapshot();GameRuntime.log(value);return value;
    }
}
