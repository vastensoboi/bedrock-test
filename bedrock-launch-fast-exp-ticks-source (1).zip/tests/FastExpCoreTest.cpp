#include "../app/src/main/cpp/fast_exp_core.h"
#include <map>
#include <vector>
#include <cassert>
#include <iostream>
using kulich::Address;
struct Memory {
 std::map<Address,std::vector<unsigned char>> blocks;
 Address mutateAt=0,mutateSlot=0;
 bool operator()(Address at,void* data,size_t n){
  for(auto& entry:blocks){if(at>=entry.first&&at-entry.first<=entry.second.size()&&n<=entry.second.size()-(at-entry.first)){
   std::memcpy(data,entry.second.data()+(at-entry.first),n);
   if(at==mutateAt&&mutateSlot){int32_t value=0;put(mutateSlot,value);}
   return true;
  }}return false;
 }
 template<class T> void put(Address at,T value){
  for(auto& entry:blocks)if(at>=entry.first&&at-entry.first+sizeof(T)<=entry.second.size()){
   std::memcpy(entry.second.data()+(at-entry.first),&value,sizeof(T));return;
  }assert(false);
 }
};
int main(){
 kulich::TickWarmup warmup;
 assert(!warmup.observe(0));assert(!warmup.observe(50));assert(warmup.observe(100));
 assert(!warmup.observe(1000));assert(!warmup.observe(2000));assert(!warmup.observe(2050));
 assert(warmup.observe(2100));warmup.reset();assert(!warmup.observe(2150));
 for(int period=1;period<=10;period++){
  kulich::TickInterval timer;
  for(int tick=0;tick<100;tick++)assert(timer.due(period)==(tick%period==0));
  timer.reset();assert(timer.due(period));
 }
 kulich::TickInterval changed;
 assert(changed.due(10));assert(!changed.due(10));assert(changed.due(1));
 for(int i=0;i<20;i++)assert(changed.due(-4));
 changed.reset();for(int i=0;i<30;i++)assert(changed.due(40)==(i%10==0));

 Memory m;Address base=0x100000000ULL,mode=0x200000,player=0x210000,client=0x220000;
 Address proxy=0x230000,inventory=0x240000,stacks=0x250000,handle=0x260000,item=0x270000;
 m.blocks[mode].resize(256);m.blocks[player].resize(4304);m.blocks[client].resize(3648);
 m.blocks[proxy].resize(232);m.blocks[inventory].resize(336);m.blocks[stacks].resize(36*152);
 m.blocks[handle].resize(8);m.blocks[item].resize(8);m.blocks[base+0x13d227d0ULL].resize(21*8);
 m.put(mode,base+0x13d227d0ULL);m.put(base+0x13d227d0ULL+96,base+0x100a0060ULL);
 m.put(mode+8,player);m.put(player,base+0x139f6ea0ULL);m.put(player+2568,mode);
 m.put(player+3240,client);m.put(client,base+0x1388fe70ULL);m.put(player+1424,proxy);
 m.put(proxy,base+0x13d43520ULL);m.put(proxy+16,int32_t(8));m.put(proxy+184,inventory);
 m.put(inventory,base+0x13d42b08ULL);m.put(inventory+320,stacks);m.put(inventory+328,stacks+36*152);
 Address stack=stacks+8*152;m.put(stack,base+0x13d95ff8ULL);m.put(stack+8,handle);
 m.put(stack+34,uint8_t(64));m.put(handle,item);m.put(item,base+0x13d9eb70ULL);
 auto held=kulich::resolve(m,base,client,mode);assert(held.stack==stack&&held.slot==8&&held.count==64);
 m.put(inventory+320,stacks|0xb400000000000000ULL);
 auto tagged=kulich::resolve(m,base,client,mode|0xb400000000000000ULL);
 assert(tagged.stack==(stack|0xb400000000000000ULL));
 m.put(inventory+320,stacks);
 int reason=0;m.put(item,Address(0));assert(!kulich::resolve(m,base,client,mode,&reason).stack);assert(reason==11);m.put(item,base+0x13d9eb70ULL);
 m.put(stack+34,uint8_t(0));assert(!kulich::resolve(m,base,client,mode).stack);m.put(stack+34,uint8_t(64));
 m.put(proxy+176,uint8_t(1));assert(!kulich::resolve(m,base,client,mode).stack);m.put(proxy+176,uint8_t(0));
 m.put(proxy+16,int32_t(9));assert(!kulich::resolve(m,base,client,mode).stack);m.put(proxy+16,int32_t(8));
 m.put(player+2568,Address(0));assert(!kulich::resolve(m,base,client,mode).stack);m.put(player+2568,mode);
 m.put(player+3240,client+8);assert(!kulich::resolve(m,base,client,mode).stack);m.put(player+3240,client);
 m.put(inventory+328,stacks+36*152-1);assert(!kulich::resolve(m,base,client,mode).stack);m.put(inventory+328,stacks+36*152);
 m.put(base+0x13d227d0ULL+96,Address(0));assert(!kulich::resolve(m,base,client,mode).stack);m.put(base+0x13d227d0ULL+96,base+0x100a0060ULL);
 m.mutateAt=stack+34;m.mutateSlot=proxy+16;assert(!kulich::resolve(m,base,client,mode).stack);
 std::cout<<"PASS: tick intervals 1..10, changes/clamping/reset, rejection reason, native XP-only reader, slot/count/type, ownership, suspension, vectors, function profile and concurrent slot change\n";
}
