# Client pearl replicas and observed trails

The 0.69 phone journal contains 1,632 processed frames, no read failures or
budget stops, and cumulative zero ProjectileComponent candidates. This is not
merely a missing three-second journal sample: the cumulative counters never
observed any entity in that simulation pool.

The exact supported ARM64 binary has an explicit Throwable path without that
component. At `0x101bc0c8`, its movement method tests ProjectileComponent
`0x94488499`. The absent-component branch at `0x101bc1e0..0x101bc1f4` obtains
the actor's StateVector velocity through `0xfd80e28` and writes the received
motion to StateVector+24. Requiring ProjectileComponent for a client-rendered
pearl therefore excludes a representation the engine itself supports.

The exact primary ThrownEnderpearl vptr remains `0x13d3adf8`; its constructor
at `0x101bc5e0` calls the base Throwable constructor. The latter initializes
owner UID +944 to zero at `0x101bb91c`. Assignment at `0x101bbfa0` writes that
UID and optionally copies it into ProjectileComponent. Native getter
`0x101bc48c` returns the value at +944. Zero is an unknown owner, never proof
that the pearl belongs to the local player or an opponent.

0.70 additionally discovers exact-type pearls in ActorOwner payload pages.
It scans at most two 128-pointer pages per frame (the newest page and a
round-robin page), caches at most eight actor/entity pairs, and revalidates
their registry, generation, owner slot, removal flag and StateVector before
every observation. Kernel reads are bounded and camera time is reserved.
The fallback needs ActorOwner and StateVector, not a nonempty or even present
ProjectileComponent pool. Existing simulation-backed future predictions keep
their original physics and terrain-hit validation.

Without proven runtime drag/gravity data, a client replica is serialized as
an actual observed trail: `T,id,owner,x:y:z/x:y:z/...`. There are at most 64
real samples per trail, no extrapolated point and no landing ETA. Teleports
or observation gaps break the path; a disappeared actor's trail expires after
750 ms. Disable, local entity, world/registry or dimension changes clear the
cache. Native and Java together publish only one row per entity ID.

Current and cumulative replica counts are logged independently from the
Projectile simulation pool so the next report can identify which path found
the pearl. Device rendering still needs validation; the host tests establish
the identity, bounds, lifetime and protocol behavior rather than claiming a
phone-side outcome.
