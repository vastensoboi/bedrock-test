#pragma once

#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>

namespace kulich_marker {

using Marker = std::array<unsigned char, 13>;

inline bool make(const std::array<float, 3>& beforePos,
                 const std::array<float, 3>& afterPos,
                 uint8_t priorReplayed, uint8_t capturedMode, Marker& out) {
    static_assert(sizeof(float) == 4, "The marker stores three 4-byte floats");
    std::array<float, 3> difference{};
    for (std::size_t i = 0; i < difference.size(); ++i) {
        if (!std::isfinite(beforePos[i]) || !std::isfinite(afterPos[i])) return false;
        difference[i] = beforePos[i] - afterPos[i];
        if (!std::isfinite(difference[i])) return false;
    }
    Marker candidate{};
    std::memcpy(candidate.data(), difference.data(), 12);
    candidate[12] = priorReplayed != 0 ? capturedMode & 1U : 0;
    out = candidate;
    return true;
}

// Only the marker prefix belongs to this helper. Callers restoring it must
// retain the current padding at bytes 13..15.
inline bool owned(const Marker& marker,
                  const std::array<unsigned char, 16>& current,
                  uint8_t currentReplayed, uint8_t currentMode,
                  uint8_t capturedMode) {
    return currentReplayed == 1 && currentMode == capturedMode &&
           std::memcmp(marker.data(), current.data(), marker.size()) == 0;
}

} // namespace kulich_marker
