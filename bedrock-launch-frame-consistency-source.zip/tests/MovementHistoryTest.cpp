#include "../app/src/main/cpp/movement_history_core.h"
#include <cassert>
#include <iostream>
#include <vector>
using namespace kulich_rewind;
struct Memory {
 static constexpr A root=0x300000,tag=0xb400000000000000ULL;
 std::vector<unsigned char> bytes=std::vector<unsigned char>(0x30000);A next=root+0x10000;
 template<class T>void put(A at,T value){at=plain(at);assert(at>=root&&at-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+at-root,&value,sizeof value);}
 A alloc(size_t size){A out=next;next=(next+size+7)&~A(7);assert(next-root<bytes.size());return out;}
 bool operator()(A at,void* out,size_t size){assert(at==plain(at));if(at<root||at-root>bytes.size()||size>bytes.size()-(at-root))return false;std::memcpy(out,bytes.data()+at-root,size);return true;}
};
int main(){
 Memory m;constexpr A registry=Memory::root+0x1000,history=Memory::root+0x5000;constexpr uint32_t entity=0x40001;
 A storage=m.alloc(104),sparseVector=m.alloc(8),sparsePage=m.alloc(8192),pages=m.alloc(8),payload=m.alloc(128*32);
 std::fill(m.bytes.begin()+sparsePage-Memory::root,m.bytes.begin()+sparsePage-Memory::root+8192,255);
 m.put(storage+8,sparseVector);m.put(storage+16,sparseVector+8);m.put(sparseVector,sparsePage);
 m.put(sparsePage+(entity&2047)*4,entity&0xfffc0000U);
 m.put(storage+80,pages);m.put(storage+88,pages+8);m.put(storage+96,pages+8);m.put(pages,payload|Memory::tag);
 A bucket=m.alloc(8),node=m.alloc(32);m.put<int64_t>(bucket,0);m.put<int64_t>(node,-1);m.put(node+8,REPLAY_STATE);m.put(node+16,storage);
 m.put(registry+96,bucket);m.put(registry+104,bucket+8);m.put(registry+120,node);m.put(registry+128,node+32);
 m.put(payload+8,history|Memory::tag);m.put(history+48,std::array<uint64_t,2>{40,100});
 auto before=m.bytes;
 Window value=sample(m,registry,entity,100,0);assert(value.state==State::Inside&&value.gateKnown&&value.eligible&&value.first==100&&value.last==139&&value.count==40);
 assert(sample(m,registry,entity,139,0).state==State::Inside);
 value=sample(m,registry,entity,99,0);assert(value.state==State::Older&&value.gateKnown&&!value.eligible);
 value=sample(m,registry,entity,140,0);assert(value.state==State::Future&&value.gateKnown&&value.eligible);
 assert(describe(value).find("newer-than-window nativeLowerGate=eligible")!=std::string::npos);
 value=sample(m,registry,entity,0,0);assert(value.state==State::ZeroTick&&value.gateKnown&&!value.eligible);
 assert(sample(m,registry,entity,100,1).state==State::NotPlayer);
 assert(m.bytes==before); // Every observation is read-only.
 auto failed=[](A,void*,size_t){return false;};
 assert(sample(failed,registry,entity,100,0).state==State::Unavailable);
 assert(sample(failed,registry,entity,0,0).state==State::ZeroTick);
 assert(sample(failed,registry,entity,100,1).state==State::NotPlayer);
 m.put(payload+8,A(0));value=sample(m,registry,entity,100,0);assert(value.state==State::NoHistory&&value.gateKnown&&!value.eligible);
 m.put(payload+8,history|Memory::tag);m.put(history+48,std::array<uint64_t,2>{0,100});
 value=sample(m,registry,entity,101,0);assert(value.state==State::Empty&&value.eligible&&value.count==0);
 m.put(history+48,std::array<uint64_t,2>{2,std::numeric_limits<uint64_t>::max()});
 assert(sample(m,registry,entity,101,0).state==State::Unavailable);
 m.put(history+48,std::array<uint64_t,2>{1,std::numeric_limits<uint64_t>::max()});
 value=sample(m,registry,entity,std::numeric_limits<uint64_t>::max(),0);assert(value.state==State::Inside&&value.last==std::numeric_limits<uint64_t>::max());
 m.put(history+48,std::array<uint64_t,2>{40,100});
 m.put(sparsePage+(entity&2047)*4,uint32_t(0x80000));assert(sample(m,registry,entity,100,0).state==State::Unavailable);
 m.put(sparsePage+(entity&2047)*4,entity&0xfffc0000U);
 unsigned reads=0;
 auto moving=[&](A at,void* out,size_t size){if(at==history+48&&++reads==2)m.put(history+48,std::array<uint64_t,2>{40,101});return m(at,out,size);};
 assert(sample(moving,registry,entity,110,0).state==State::Unavailable);m.put(history+48,std::array<uint64_t,2>{40,100});
 reads=0;auto replaced=[&](A at,void* out,size_t size){if(at==payload+8&&++reads==2)m.put(payload+8,history+8);return m(at,out,size);};
 assert(sample(replaced,registry,entity,110,0).state==State::Unavailable);m.put(payload+8,history|Memory::tag);
 reads=0;auto recycled=[&](A at,void* out,size_t size){if(at==payload+8&&++reads==2)m.put(sparsePage+(entity&2047)*4,uint32_t(0x80000));return m(at,out,size);};
 assert(sample(recycled,registry,entity,110,0).state==State::Unavailable);
 std::cout<<"PASS: read-only native replay-window eligibility, first/count bounds, zero-tick direct path, player/vehicle scope, future lower-gate semantics, tagged reads, overflow and concurrent-history/generation guards\n";
}
