// kulich API v1. Runtime API, not a ProtoHax packet API adapter.
(function (global) {
  'use strict';
  global.defineModule = function (meta, schema, setup) {
    if (!meta || !/^[a-z][a-z0-9_]{0,39}$/.test(meta.id || '')) throw Error('Module needs a unique id');
    if (typeof setup !== 'function') throw Error('Module needs setup(ctx)');
    var enabled = false, listeners = {}, options = {};
    Object.keys(schema || {}).forEach(function (key) {
      var spec = schema[key], value = spec.def;
      function validate(next) {
        if (spec.type === 'boolean') { if (typeof next !== 'boolean') throw Error(key + ': boolean required'); }
        else if (spec.type === 'number') {
          if (typeof next !== 'number' || !isFinite(next) || (spec.min !== undefined && next < spec.min) ||
              (spec.max !== undefined && next > spec.max)) throw Error(key + ': number outside limits');
        } else throw Error('Unsupported setting type: ' + key);
        return next;
      }
      value = validate(value);
      var option = {};
      Object.defineProperty(option, 'value', {enumerable:true, get:function(){return value;}, set:function(next){value=validate(next);}});
      options[key] = option;
    });
    function on(name, callback) {
      if (['enable','disable','ui_tick'].indexOf(name) < 0) throw Error('Unsupported event: '+name);
      if (typeof callback !== 'function') throw Error('Callback required');
      (listeners[name] || (listeners[name] = [])).push(callback);
    }
    function emit(name) { (listeners[name] || []).forEach(function(fn){fn();}); }
    var ctx = {
      apiVersion: 1,
      options: options,
      capabilities: Object.freeze({auction:false, packets:false, inventory:false, fastExp:true}),
      log: function(message){__log(meta.id, String(message).slice(0,500));},
      onEnable:function(fn){on('enable',fn);}, onDisable:function(fn){on('disable',fn);}, on:on,
      fastExp:Object.freeze({
        isReady:function(){return __fast('ready');},
        setEnabled:function(value){if(typeof value!=='boolean')throw Error('boolean required');return __fast('enable',value);},
        setInterval:function(value){if(value%1!==0||value<1||value>10)throw Error('Interval must be 1..10');return __fast('interval',value);},
        status:function(){return __fast('status');}
      })
    };
    setup(ctx);
    __register(meta.id, String(meta.name || meta.id).slice(0,60), String(meta.description || '').slice(0,300),
      function(next) {
        if(next===enabled)return;
        if(next){emit('enable');enabled=true;}else{enabled=false;emit('disable');}
      }, function(){if(enabled)emit('ui_tick');});
  };
})(this);
