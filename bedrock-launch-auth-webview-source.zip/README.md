# Bedrock Crash Capture 0.31 — SDK WebKit Activity registration

The supplied 0.30 report provides a concrete fatal exception. The external
Microsoft browser returns through IntentHandler, and BrowserLaunchActivity
reports its operation completed successfully. That proves delivery of this
browser response, not completion of the entire account sign-in. The SDK next
starts ShowUrlType NonAuthFlow, which explicitly requests an in-process WebKit
strategy. Android throws ActivityNotFoundException for
com.microsoft.xal.browser.WebKitWebViewController, followed by a main-thread
fatal exception and process exit reason=4.

Register the installed SDK's WebKitWebViewController as exported=false, :game,
singleTask (matching the original game's public Activity metadata). It uses
an opaque framework Light.NoActionBar theme and handles the same configuration
changes as BrowserLaunchActivity. GameFactory instantiates it via the existing
game loader, including intent extras loader repair and the process-restart
guard. HostApplication's pre-created callback already covers the XAL browser
package and sets the extras/saved-state class loader before SDK onCreate.

There is no custom WebView client, TLS override, credential interception,
response rewriting or URL/token logging. Authentication remains in the
installed game's SDK. Native Fast Exp, one-step enable, Auto Buy preparation,
Application resources and log configuration are unchanged from 0.30.

Validation: Java syntax parsing; manifest coverage/process/export/mode checks
for all three XAL Activities seen in the game metadata; archive CRC/version
and unchanged native sources. Android compilation and full sign-in remain
GitHub Actions/device checks. This addresses the observed missing-Activity
crash, not a guarantee about every subsequent account/server flow.

# Bedrock Crash Capture 0.30 — one-step Fast Exp and Auto Buy preparation

The user confirmed game/server entry and Fast Exp work with 0.29. Preserve
that application resource fix, authentication setup and native item-use path.

Fast Exp's disconnected-state action is now Enable Fast Exp. It runs the
existing verified-library/client probe in a worker, then enables automatically
if the Activity still has focus. There is no separate manual probe step.
Failure leaves it disabled and explains how to retry in a world. A prepared
bridge retains the direct enable switch, 1–10-tick interval and existing
focus/menu pause behavior. Native guards and code are unchanged.

integrations/protohax contains a repaired user-supplied Auto Buy script and
extracted shopping rules, with tests and portability limitations documented.
It is not executed by the launcher: the @protohax/userscript runtime and auction
container/packet APIs are not implemented in kulich. Auto Buy remains explicitly
unconnected rather than presenting a nonfunctional enable switch.

Validation: Java syntax parse, Node module syntax and mock auction tests.
Android compilation and one-step button behavior require Actions/device tests.

# Bedrock Crash Capture 0.29 — application resources and content-log setup

The 0.28 report still lacks content logs. The user confirmed they only saved
the launcher report and could not find the game's Creator logging setting.
The report also contains numeric game resource lookup failures from SDK code
using applicationContext, whereas Activity resource attachment succeeds.
Neither this observation nor unrelated telemetry upload errors establish the
cause of the blank server screen.

GameRuntime now adds the same game ResourcesLoader to the Application Resources
in the hosted :game process before SDK initialization. Application-context
SDK lookups can see the game resources as well as Activity lookups. No Context
accessor overrides are introduced: the inherited JNI method owner compatibility
is preserved. The separate launcher process keeps its host resources. Public
resource-name availability markers are written to the launch journal, without
logging resource values, OAuth URLs, credentials or tokens.

Before starting the game (after the existing running-process guard), the host
sets only content_log_file:1 in its own Minecraft options.txt profiles. That
exact option name is present in the supplied game library. Existing unrelated
lines and line endings are preserved; an existing options.txt is copied once
to options.txt.kulich-before-content-log before replacement. The original
installed game's private data is never inspected or changed. On fresh installs,
a minimal options file is created under the launcher's data storage path.
Existing profiles in internal files and external app files are also recognized.
The replacement is atomic where supported. Link/directory/size guards apply.
A setup failure is recorded rather than blocking game launch. This configures
logging, not acceptance by the server or guaranteed creation of content logs.

Standalone tests cover preservation, backups, idempotence, fresh/external
profiles, symlink/size rejection and content-log collection. Java syntax parsing
is not Android type checking. GitHub Actions must build the APK; resource
availability, actual file logging, sign-in and server behavior require a phone.
Fast Exp native sources and XAL auth declarations are unchanged from 0.28.

# Bedrock Crash Capture 0.28 — content-log storage roots

The user clarified that the recorded blank server screen also occurred at
home with their normal connection. The mobile-data permission dialog does not
establish the cause. The report contains no fatal crash or server error.

The game log explicitly selects CurrentFileStoragePath as the application
data directory, which is above files/. 0.27 only searched files/ and external
app files. Its missing-content-log result could therefore be a collector gap.
0.28 includes the app data directory and prioritizes games/com.mojang/logs and
logs under each app-owned root before bounded traversal. Named-file and
symlink safeguards, byte/file limits, native bridge, auth and menu are unchanged.
It only reads existing content logs; it does not enable logging or edit game
options. If logging is disabled, enable file output in Minecraft Creator settings.

Standalone tests cover the data-directory case and log priority despite more
than 2048 cache files, along with previous export bounds and symlink tests.
Java syntax parsing is not an Android build. Device testing is still required.
This fixes a diagnostic collector omission, not a confirmed server-login cause.

# Bedrock Crash Capture 0.27 — server-screen diagnostics

The user reports that Nevertime works in the separately installed Minecraft,
but the hosted game displays a blank in-game screen after joining. The new
0.26 report contains no fatal exception or native crash: its only recorded
exit is the user-requested Android Settings force stop. It does not provide a
server disconnect reason or prove that the blank screen is an OAuth failure.
The unrelated telemetry database and Play services warnings are not treated
as the established cause.

This version adds a Journal button to the kulich menu header. It opens the
launcher diagnostics in a separate task, leaving the game Activity in its
own task. Android lifecycle pause still disables Fast Exp. No task-clearing
flags, process termination or sign-in restart are performed by this button.
The system document picker remains the destination for the Save Journal button.

Reports also collect up to three named Minecraft ContentLog text files from
this app's internal files and external app files, with a total 256 KiB byte
budget. Traversal is bounded and rejects symlinks. It never searches the
separately installed game's private data or reads arbitrary account files.
If Minecraft has not written content logs, the report says so; the user can
enable content-log file output in Minecraft Creator settings before joining.

This is a diagnostic and recovery change, not a confirmed fix for server login.
Fast Exp native code, game resources, and XAL authentication are unchanged.
Java parsing and standalone content-log tests can run locally. Android build,
menu navigation and Nevertime behavior require GitHub Actions/device testing.

# Bedrock Crash Capture 0.26 — XAL browser return handler

The user's 0.25 report shows BrowserLaunchActivity creating its SDK session,
selecting Chrome Custom Tabs and launching the browser. On return the SDK logs
onResume() with no intent data and cancels the operation. The process exits
normally. This does not establish a completed account sign-in or explain the
browser page's error message, which was not present in the journal.

The installed game's public Activity metadata names an exported singleTask
com.microsoft.xal.browser.IntentHandler. That component was missing in the
host. The exact literal `ms-xal-0000000048183522://auth` is present in the
supplied game library. 0.26 declares that SDK return Activity with precisely
this scheme and host, VIEW/DEFAULT/BROWSABLE, exported=true and :game process.
GameFactory loads it with the existing game loader. The pre-created extras
loader repair also applies to this XAL browser class. The original SDK handler
receives the URI and handles its state; no code, token or redirect data is
rewritten or logged by the host.

Both the original installed game and this launcher may handle the same custom
URI. If Android presents a chooser after Microsoft login, the user must select
Bedrock Crash Capture for this session. No default is forced or other handler
disabled. If the game process was killed while the browser was open, native
pending auth state cannot be fabricated; the existing factory failure path
asks the user to restart sign-in from the game.

Native Fast Exp code is byte-for-byte unchanged from confirmed working 0.23.
This patch addresses delivery of the browser response; successful sign-in,
subsequent account permissions and server acceptance remain device checks.
No guarantee of admission to arbitrary servers is made. Any error shown by the
Microsoft page needs its own text/code to diagnose beyond this journal.

Local validation: Java syntax parsing; XML handler/process/export/mode/filter
checks; exact callback literal found in supplied ELF; loader routing and native
source identity checks; ZIP CRC and existing workflow selection. Android build
and actual OAuth round-trip are not performed locally.

Build versionCode25 / versionName0.26 with Build latest launch test, try login
and save bedrock-crash-capture-0.26.txt. The useful next markers are the SDK
IntentHandler construction, BrowserLaunchActivity receiving return intent data,
and the game's sign-in outcome. Do not infer success from merely opening Chrome.

# Bedrock Crash Capture 0.25 — XAL Serializable extras loader

The 0.24 report confirms BrowserLaunchActivity is now instantiated through the
game loader. Its onCreate then fails reading BrowserLaunchParameters.FromArgs:
BadParcelableException / ClassNotFoundException for
BrowserLaunchActivity$ShowUrlType. Parcel attempts to resolve that SDK enum
through the host APK loader. The enum is supplied by the game's DEX.

0.25 sets the authentication intent extras loader in the factory, then repairs
it again using Application.ActivityLifecycleCallbacks.onActivityPreCreated.
The pre-created hook runs before the SDK's onCreate reads its parameters and
also assigns the game loader to saved state. This uses the public API available
on API29+ (the app's minimum is 30). No enum is redefined, converted or replaced.
No intent extras, URL, token or credentials are logged by the hook.

BrowserLaunchActivity's launchMode is set to singleTask, matching the original
installed-game metadata recorded in 0.24 (launchMode=2). Exported=false and the
:game process are retained. The existing unprepared-process guard remains.
The current failure is distinct from the earlier missing-component failure.

The native Fast Exp sources remain unchanged from confirmed working 0.23.
Full account sign-in/browser-return/server acceptance still require device
verification; this patch specifically addresses SDK parameter deserialization.
No OAuth client identity or return scheme is guessed or fabricated here.

Local validation: 26 Java files syntax-parsed, manifest process/launch-mode and
pre-created class-loader routing inspected, archive CRC/version/selection
verified. Android SDK compilation and runtime sign-in are not tested locally.
Build versionCode24 / versionName0.25 with Build latest launch test. Try login
and export bedrock-crash-capture-0.25.txt after success or failure.

# Bedrock Crash Capture 0.24 — XAL browser component

The user's 0.23 login report confirms ActivityNotFoundException for the explicit
component com.microsoft.xal.browser.BrowserLaunchActivity in the diagnostic
package. The native SDK subsequently calls JNI GetMethodID with that pending
exception, causing SIGABRT. This is a launcher component-registration failure;
it is not evidence that Fast Exp interferes with authentication.

0.24 declares that exact SDK Activity in the host manifest, unexported and in
the existing :game process. GameFactory instantiates it with the already
prepared game DexClassLoader, where the installed game's XAL SDK resides.
It does not call GameRuntime.prepare on the SDK's authentication intent or
replace the SDK Activity implementation. A restarted/unprepared game process
fails through the existing launch-failure Activity rather than attempting a
callback with stale native process state.

The manifest also permits browser VIEW/http/https and Custom Tabs service
queries needed on Android 11+. No OAuth scheme/client ID/redirect, token,
account identity or credential storage is fabricated. Browser-return handling,
account sign-in and server acceptance still require device verification. If
the next phase needs additional components or original redirect metadata, those
must be established from the real SDK/installed game and the next error.

Before game launch the journal inventories relevant installed-game Activity
names and public launch metadata. It does not log authentication intent extras,
OAuth URLs or credentials. Existing native Fast Exp sources are byte-for-byte
unchanged from the version the user confirmed works. Dump/text export remain.

VersionCode 23 / versionName 0.24; debug package remains
`dev.custom.bedrocklaunchtest.crashcapture`. Build with the existing **Build
latest launch test** archive workflow. On the phone try Microsoft sign-in and
export **bedrock-crash-capture-0.24.txt** after success or failure. The missing
initial Activity is addressed; full account/server compatibility is not yet
claimed. No guarantee of admission to every server is made.

Validation: Java syntax parsing and manifest/component/factory routing checks
performed locally. Android SDK/NDK compilation and sign-in runtime behavior
remain pending GitHub Actions/device tests. No login was performed here.

# Bedrock Crash Capture 0.23 — corrected client item-use call

This diagnostic build fixes the specific native argument mismatch established
by the user's 0.22 minidump. It retains the separate package and dump export
button introduced in 0.22. It has not yet been compiled with the Android SDK
or executed on the user's phone in this workspace.

## Dump evidence and the incorrect route

The 0.22 minidump contains SIGSEGV at libminecraftpe.so+0xfd898cc, fault
address 0x38. The instruction loads from a null ECS registry via x9. Its x0
is the exact tagged held ItemStack address also recorded in the user's text
log. The caller chain passes through +0x100a3770 and +0x1009cd00, then our
libkulichbridge. This is Actor interaction receiving an ItemStack in place
of an Actor. The slot-16 selection in 0.21–0.22 was wrong. It is removed.

The correct direct client item-use wrapper is 0x1009fdcc. The game's ordinary
input handler calls it at 0x9b6e6ec, with x0=GameMode, x1=ItemStack and w2=0.
The method builds the native item-use transaction (type 2) and on its client
path passes it to the player's virtual method at +1824. The module now calls
that same function with the validated live tagged ItemStack and false flag.
There is no Vec3 argument and no invocation of Actor interaction slot 16.

Before installation and each resolved action, the bridge checks the first
32 bytes of the exact entry function as well as the prior GameMode low-level
method profile. The existing complete game-file SHA-256 guard remains.
Unexpected code bytes reject actions; no alternate address is guessed.
The return register is not treated as proof that a projectile was spawned.
Calls/completed/inFlight remain diagnostic counters.

## Behavior and limits

Actions remain on the original LocalPlayer update thread, after its original
handler returns. Mode/player/client backlinks, selected slot, live XP item,
count, vector bounds and snapshots are checked again. Pointer tags are retained
for native arguments. The interval slider remains 1..10 local update ticks.
Three repeated callbacks are required before action. The UI lease, focus/menu
pause and onPause disabling remain. Fast Exp starts disabled.

The diagnostic dump explains the reported SIGSEGV, but the new wrapper's live
item behavior and actual XP projectiles still need device confirmation. Other
faults may remain. Auto Buy and Block Trap are not implemented.

## Separate install and export

The debug application ID remains
`dev.custom.bedrocklaunchtest.crashcapture`, label **Bedrock Crash Capture**.
The original launcher `dev.custom.bedrocklaunchtest` is a separate application.
This is an update of the diagnostic app, not access to the original app's data.
The uploaded 0.22 dump is already preserved outside the app for analysis.

The default applicationId literal is kept for the user's existing source ZIP
selector. The debug applicationIdSuffix is `.crashcapture`; a Gradle variant
assertion and the direct workflow's actual-APK check require the separate ID.
Only :app:assembleDebug is intended. VersionCode 22 / versionName 0.23 cause
**Build latest launch test** to select this source over 0.22.

The dump button uses ACTION_CREATE_DOCUMENT and gzip compression of only a
valid regular MDMP file in this app's private crash directory. It never deletes
or changes the source and needs no Termux/Shizuku or storage permission. Source
size, time, header and canonical parent are checked. The ordinary text journal
is also exportable. Native bridge debug symbols stay in the APK.

## Device verification

Build/install diagnostic 0.23 using the existing archive workflow. In an ordinary
single-player test world hold XP bottles, run Проверить подключение, enable
Fast Exp and close kulich for five seconds. Observe actual projectiles, reopen
kulich, disable and export bedrock-crash-capture-0.23.txt. If a new crash occurs,
use Сохранить дамп падения and export bedrock-crash-capture-0.23.dmp.gz.
The native status includes route=item-use to distinguish the corrected route.

## Validation performed here

- The exception context and frame-pointer chain were parsed from the real dump.
- The actual game binary confirms the fault instruction, canonical call target,
  false flag instruction and all 32 checked entry bytes.
- Native host tests pass for correct item-use arguments, mismatched code profile,
  independence from the Actor interaction slot, GameMode and SurvivalMode, tagged
  arguments, post-update replacement, item ownership, bounds and tick intervals.
- Native host C++ syntax checks and Java source syntax parsing pass.
- Existing binary dump-export tests pass, including source preservation.

These checks do not compile Android JNI/NDK code or execute Minecraft. Android
build and device execution remain pending. Toolchain: JDK17/Gradle8.7/AGP8.6.1,
SDK35, NDK27.0.12077973/CMake3.22.1, ARM64. Minimum30, target34, compile35.
