package dev.custom.bedrockgui;

import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.View;
import java.util.*;

/** Passive full-viewport overlay, including native render roll/bob. Unknown projection uses a labelled top-down plan. */
public final class PearlTrajectoryView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;private PearlPrediction.Frame frame;private boolean enabled;
    public PearlTrajectoryView(Context context){super(context);density=getResources().getDisplayMetrics().density;setClickable(false);setFocusable(false);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
    public void setEnabledPrediction(boolean value){enabled=value;setVisibility(value?VISIBLE:GONE);if(!value)frame=null;invalidate();}
    public void updateSnapshot(String snapshot){frame=PearlPrediction.parse(snapshot,SystemClock.uptimeMillis());invalidate();}
    private float dp(float value){return value*density;}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);long now=SystemClock.uptimeMillis();if(!enabled||frame==null||!frame.fresh(now)||frame.pearls.isEmpty()&&frame.trails.isEmpty())return;
        boolean world=frame.camera.projectsWorld();float radius=Math.min(dp(72),Math.max(dp(12),(getHeight()-dp(100))/2)),cx=getWidth()-radius-dp(14),cy=radius+dp(28);
        if(!world){
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(0x66ffffff);canvas.drawCircle(cx,cy,radius,paint);canvas.drawLine(cx-dp(5),cy,cx+dp(5),cy,paint);canvas.drawLine(cx,cy-dp(5),cx,cy+dp(5),paint);
            text(canvas,"Жемчуг · план сверху",cx-radius,cy-radius-dp(10),Color.WHITE);
        }
        int index=0;for(PearlPrediction.Pearl pearl:frame.pearls){
            double eta=PearlPrediction.secondsToLanding(pearl,now-frame.capturedAt);
            String label=(pearl.owner==0?"Твой":pearl.owner==1?"Другой":"Жемчуг")+" · "+(Double.isNaN(eta)?"время неизвестно":String.format(Locale.ROOT,"≈ %.1f с",eta));
            drawSeries(canvas,PearlPrediction.simulate(pearl,PearlPrediction.MAX_TICKS),pearl.owner,label,world,cx,cy,radius,index++);
        }
        for(PearlPrediction.Trail trail:frame.trails){
            // An observed trail must never look like a promised future landing.
            String label=trail.owner==0?"Твой след":trail.owner==1?"Чужой след":"След жемчуга";
            drawSeries(canvas,trail.points,trail.owner,label,world,cx,cy,radius,index++);
        }
        postInvalidateDelayed(50);
    }
    private void drawSeries(Canvas canvas,List<PearlPrediction.Vec> positions,int owner,String label,boolean world,float cx,float cy,float radius,int index){
        int color=owner==0?0xff87f1a8:owner==1?0xffffb36b:0xffe7e7ff;
        Path line=new Path();boolean started=false;PearlPrediction.Point previous=null,last=null;
        int save=canvas.save();if(!world)canvas.clipRect(cx-radius,cy-radius,cx+radius,cy+radius);
        for(PearlPrediction.Vec position:positions){
            PearlPrediction.Point point=world?PearlPrediction.project(position,frame.camera,getWidth(),getHeight()):PearlPrediction.topDown(position,frame.camera,cx,cy,radius/64.0);
            if(point==null){started=false;previous=null;continue;}
            if(world){
                PearlPrediction.Point[] clipped=PearlPrediction.clipSegment(previous,point,getWidth(),getHeight());
                if(clipped!=null){line.moveTo((float)clipped[0].x,(float)clipped[0].y);line.lineTo((float)clipped[1].x,(float)clipped[1].y);last=clipped[1];}
                else if(point.x>=0&&point.x<=getWidth()&&point.y>=0&&point.y<=getHeight())last=point;
                previous=point;
            }else{
                if(!started){line.moveTo((float)point.x,(float)point.y);started=true;}else line.lineTo((float)point.x,(float)point.y);last=point;
            }
        }
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(2));paint.setColor(color);canvas.drawPath(line,paint);
        // The very first observed sample is real data too: draw a dot until a
        // second sample arrives, rather than silently hiding the whole flight.
        if(last!=null){paint.setStyle(Paint.Style.FILL);canvas.drawCircle((float)last.x,(float)last.y,dp(2),paint);}
        canvas.restoreToCount(save);
        if(world&&last!=null)text(canvas,label,(float)last.x,(float)Math.max(dp(18),last.y),color);
        else if(world&&index<4)text(canvas,label+" · вне экрана",getWidth()-dp(220),dp(24+index*17),color);
        else if(!world&&index<4)text(canvas,label,cx-radius,cy+radius+dp(18+index*16),color);
    }
    private void text(Canvas canvas,String value,float x,float y,int color){
        paint.setStyle(Paint.Style.FILL);paint.setTextSize(dp(11));
        float available=Math.max(1,getWidth()-dp(12)),width=paint.measureText(value);
        if(width>available){paint.setTextSize(paint.getTextSize()*available/width);width=available;}
        x=Math.max(dp(6),Math.min(x,getWidth()-width-dp(6)));y=Math.max(-paint.ascent()+dp(4),Math.min(y,getHeight()-paint.descent()-dp(4)));
        paint.setColor(0x99000000);canvas.drawRoundRect(x-dp(4),y+paint.ascent()-dp(3),x+width+dp(4),y+paint.descent()+dp(3),dp(4),dp(4),paint);
        paint.setColor(color);paint.setShadowLayer(dp(1),0,dp(1),Color.BLACK);canvas.drawText(value,x,y,paint);paint.clearShadowLayer();
    }
}
