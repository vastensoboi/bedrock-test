package dev.custom.bedrockgui;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/** Read-only native snapshot. Server nametag health takes precedence over client attributes. */
public final class TargetHudData {
    private static final String UNKNOWN_NAME="Имя недоступно",UNKNOWN_RANK="Не указана";
    private static final Pattern FORMAT=Pattern.compile("§[0-9a-zA-Z]");
    private static final String NUMBER="([0-9]{1,6}(?:[.,][0-9]{1,3})?)",HEART="[♥❤♡]\\uFE0F?";
    private static final String LABEL="(?:(?:хп|hp|здоровье)\\s*[:=]?\\s*)?";
    private static final Pattern HP_PAIR=Pattern.compile("(?iu)(?<![\\p{L}\\p{N}_.+-])"+LABEL+"(?:"+HEART+"\\s*)?"+NUMBER+"\\s*(?:"+HEART+")?\\s*/\\s*"+NUMBER+"\\s*(?:"+HEART+")?\\s*$");
    private static final Pattern HP_AFTER=Pattern.compile("(?iu)(?<![\\p{L}\\p{N}_.+-])"+LABEL+NUMBER+"\\s*"+HEART+"\\s*$");
    private static final Pattern HP_BEFORE=Pattern.compile("(?iu)"+LABEL+HEART+"\\s*"+NUMBER+"\\s*$");
    private static final Pattern NICK=Pattern.compile("(?<![\\p{L}\\p{N}_])([A-Za-z0-9_]{1,16})(?![\\p{L}\\p{N}_])");
    private static final Set<String> RANK_WORDS=new HashSet<>(Arrays.asList("vip","mvp","premium","legend","lord","admin","moder","moderator","helper","owner","player","youtube","yt","titan","hero","elite","ultra","deluxe","default"));
    public final String name,rank,rawNameTag,displayName;
    public final float hp,maxHp;
    public final int state,actualCps,configuredCps,configuredMinCps;
    public final boolean hpFromNameTag;
    private final String nick;

    public TargetHudData(String name,String rank,float hp){this(name,rank,hp,Float.NaN,0,0,0);}
    public TargetHudData(String name,String rank,float hp,float maxHp,int state,int actual,int configured){this(name,rank,hp,maxHp,state,actual,configured,configured);}
    public TargetHudData(String name,String rank,float hp,float maxHp,int state,int actual,int configured,int minimum){
        this(name,rank,hp,maxHp,state,actual,configured,minimum,"",(UNKNOWN_RANK.equals(rank)?"":rank+" ")+name,false,"");
    }
    private TargetHudData(String name,String rank,float hp,float maxHp,int state,int actual,int configured,int minimum,String raw,String display,boolean tagged,String nick){
        this.name=name;this.rank=rank;this.hp=hp;this.maxHp=maxHp;this.state=state;actualCps=actual;configuredCps=configured;configuredMinCps=minimum;
        rawNameTag=raw;displayName=display;hpFromNameTag=tagged;this.nick=nick;
    }
    /** Empty for missing or ambiguous names. Never treats a rank token as a friend identity. */
    public String normalizedNick(){return nick.toLowerCase(Locale.ROOT);}
    public String healthSource(){return !Float.isFinite(hp)?"HP недоступно":hpFromNameTag?"HP из подписи":"HP клиента";}
    public String healthLabel(){return number(hp)+(Float.isFinite(maxHp)?"/"+number(maxHp):"");}
    private static String number(float value){if(!Float.isFinite(value))return "?";return String.format(Locale.ROOT,"%.2f",value).replaceFirst("\\.?0+$","");}
    public static String stripFormatting(String value){return FORMAT.matcher(value).replaceAll("");}

    public static TargetHudData parse(String snapshot){
        if(snapshot==null||snapshot.isEmpty())return null;
        try{
            String[] parts=snapshot.split("\\|",-1);if(parts.length!=3&&parts.length!=7&&parts.length!=8)return null;
            long age=Long.parseLong(parts[0]);if(age<0||age>5000)return null;
            float hp=parts[1].equalsIgnoreCase("nan")?Float.NaN:Float.parseFloat(parts[1]);if(!Float.isNaN(hp)&&(!Float.isFinite(hp)||hp<0||hp>100000))return null;
            String hex=parts[2];if(hex.length()>768||hex.length()%2!=0)return null;byte[] bytes=new byte[hex.length()/2];
            for(int i=0;i<bytes.length;i++){int high=Character.digit(hex.charAt(i*2),16),low=Character.digit(hex.charAt(i*2+1),16);if(high<0||low<0)return null;bytes[i]=(byte)((high<<4)|low);}
            String raw=new String(bytes,StandardCharsets.UTF_8).replace("\r\n","\n").replace('\r','\n').replaceAll("[\\p{Cc}&&[^\\n\\t]]|[\\u200B-\\u200D\\uFEFF]","");
            float maxHp=Float.NaN;int state=0,actual=0,configured=0,minimum=0;
            if(parts.length>=7){maxHp=parts[3].equalsIgnoreCase("nan")?Float.NaN:Float.parseFloat(parts[3]);state=Integer.parseInt(parts[4]);actual=Integer.parseInt(parts[5]);configured=Integer.parseInt(parts[6]);if(state<0||state>9||actual<0||actual>60||configured<1||configured>40)return null;if(!validMax(maxHp,hp))maxHp=Float.NaN;}
            if(parts.length>=7){minimum=parts.length==8?Integer.parseInt(parts[7]):configured;if(minimum<1||minimum>configured)return null;}
            List<String> identity=new ArrayList<>();Health chosen=null;
            for(String line:raw.split("\n",-1)){
                String plain=stripFormatting(line);Health found=health(plain.trim());
                if(found!=null){
                    // Native appends the current score line after the display name.
                    // The last explicit pair wins over a stale earlier pair.
                    if(chosen==null||found.pair||!chosen.pair)chosen=found;
                    int leading=plain.length()-plain.stripLeading().length();
                    String prefix=visiblePrefix(line,leading+found.start).trim();
                    if(!stripFormatting(prefix).trim().isEmpty())identity.add(prefix);
                }else if(!plain.trim().isEmpty())identity.add(line.trim());
            }
            boolean fromTag=chosen!=null;
            if(fromTag){hp=chosen.hp;if(chosen.pair)maxHp=chosen.max;else if(!validMax(maxHp,hp))maxHp=Float.NaN;}
            String display=String.join("\n",identity),plain=stripFormatting(display).trim();
            String nickname=extractNick(plain),name=nickname.isEmpty()?(plain.isEmpty()?UNKNOWN_NAME:plain):nickname,rank=UNKNOWN_RANK;
            if(!nickname.isEmpty()){
                String withoutNick=plain.replaceAll("(?<![\\p{L}\\p{N}_])"+Pattern.quote(nickname)+"(?![\\p{L}\\p{N}_])","").replaceAll("[\\[\\]⚡|•]","").replaceAll("\\s+"," ").trim();
                if(!withoutNick.isEmpty())rank=withoutNick;
            }
            if(display.isEmpty())display=UNKNOWN_NAME;
            return new TargetHudData(name,rank,hp,maxHp,state,actual,configured,minimum,raw,display,fromTag,nickname);
        }catch(RuntimeException error){return null;}
    }
    private static boolean validMax(float maximum,float current){return Float.isFinite(maximum)&&maximum>0&&maximum<=100000&&(!Float.isFinite(current)||maximum>=current);}
    private static String extractNick(String text){
        String outsideBrackets=text.replaceAll("\\[[^\\]\\n]*\\]","");LinkedHashSet<String> candidates=new LinkedHashSet<>();
        Matcher match=NICK.matcher(outsideBrackets);while(match.find()){String candidate=match.group(1);if(!RANK_WORDS.contains(candidate.toLowerCase(Locale.ROOT)))candidates.add(candidate);}
        return candidates.size()==1?candidates.iterator().next():"";
    }
    private static final class Health {final float hp,max;final int start;final boolean pair;Health(float hp,float max,int start,boolean pair){this.hp=hp;this.max=max;this.start=start;this.pair=pair;}}
    private static Health health(String line){
        Matcher match=HP_PAIR.matcher(line);if(match.find()&&boundary(line,match.start())){
            float current=Float.parseFloat(match.group(1).replace(',','.')),maximum=Float.parseFloat(match.group(2).replace(',','.'));
            if(current>=0&&current<=100000&&validMax(maximum,current))return new Health(current,maximum,match.start(),true);
        }
        for(Pattern pattern:new Pattern[]{HP_AFTER,HP_BEFORE}){match=pattern.matcher(line);if(match.find()&&boundary(line,match.start())){float current=Float.parseFloat(match.group(1).replace(',','.'));if(current>=0&&current<=100000)return new Health(current,Float.NaN,match.start(),false);}}
        return null;
    }
    private static boolean boundary(String line,int offset){return offset==0||Character.isWhitespace(line.charAt(offset-1))||"|•:".indexOf(line.charAt(offset-1))>=0;}
    /** Keep Minecraft formatting while removing an explicitly identified health suffix. */
    private static String visiblePrefix(String raw,int visibleLength){
        int visible=0,index=0;while(index<raw.length()&&visible<visibleLength){if(raw.charAt(index)=='§'&&index+1<raw.length()&&Character.isLetterOrDigit(raw.charAt(index+1)))index+=2;else{index++;visible++;}}
        return raw.substring(0,index);
    }
}
