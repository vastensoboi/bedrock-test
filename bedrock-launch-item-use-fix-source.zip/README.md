# Bedrock Crash Capture 0.23 — corrected client item-use call

This diagnostic build fixes the specific native argument mismatch established
by the user's 0.22 minidump. It retains the separate package and dump export
button introduced in 0.22. It has not yet been compiled with the Android SDK
or executed on the user's phone in this workspace.

## Dump evidence and the incorrect route

The 0.22 minidump contains SIGSEGV at libminecraftpe.so+0xfd898cc, fault
address 0x38. The instruction loads from a null ECS registry via x9. Its x0
is the exact tagged held ItemStack address also recorded in the user's text
log. The caller chain passes through +0x100a3770 and +0x1009cd00, then our
libkulichbridge. This is Actor interaction receiving an ItemStack in place
of an Actor. The slot-16 selection in 0.21–0.22 was wrong. It is removed.

The correct direct client item-use wrapper is 0x1009fdcc. The game's ordinary
input handler calls it at 0x9b6e6ec, with x0=GameMode, x1=ItemStack and w2=0.
The method builds the native item-use transaction (type 2) and on its client
path passes it to the player's virtual method at +1824. The module now calls
that same function with the validated live tagged ItemStack and false flag.
There is no Vec3 argument and no invocation of Actor interaction slot 16.

Before installation and each resolved action, the bridge checks the first
32 bytes of the exact entry function as well as the prior GameMode low-level
method profile. The existing complete game-file SHA-256 guard remains.
Unexpected code bytes reject actions; no alternate address is guessed.
The return register is not treated as proof that a projectile was spawned.
Calls/completed/inFlight remain diagnostic counters.

## Behavior and limits

Actions remain on the original LocalPlayer update thread, after its original
handler returns. Mode/player/client backlinks, selected slot, live XP item,
count, vector bounds and snapshots are checked again. Pointer tags are retained
for native arguments. The interval slider remains 1..10 local update ticks.
Three repeated callbacks are required before action. The UI lease, focus/menu
pause and onPause disabling remain. Fast Exp starts disabled.

The diagnostic dump explains the reported SIGSEGV, but the new wrapper's live
item behavior and actual XP projectiles still need device confirmation. Other
faults may remain. Auto Buy and Block Trap are not implemented.

## Separate install and export

The debug application ID remains
`dev.custom.bedrocklaunchtest.crashcapture`, label **Bedrock Crash Capture**.
The original launcher `dev.custom.bedrocklaunchtest` is a separate application.
This is an update of the diagnostic app, not access to the original app's data.
The uploaded 0.22 dump is already preserved outside the app for analysis.

The default applicationId literal is kept for the user's existing source ZIP
selector. The debug applicationIdSuffix is `.crashcapture`; a Gradle variant
assertion and the direct workflow's actual-APK check require the separate ID.
Only :app:assembleDebug is intended. VersionCode 22 / versionName 0.23 cause
**Build latest launch test** to select this source over 0.22.

The dump button uses ACTION_CREATE_DOCUMENT and gzip compression of only a
valid regular MDMP file in this app's private crash directory. It never deletes
or changes the source and needs no Termux/Shizuku or storage permission. Source
size, time, header and canonical parent are checked. The ordinary text journal
is also exportable. Native bridge debug symbols stay in the APK.

## Device verification

Build/install diagnostic 0.23 using the existing archive workflow. In an ordinary
single-player test world hold XP bottles, run Проверить подключение, enable
Fast Exp and close kulich for five seconds. Observe actual projectiles, reopen
kulich, disable and export bedrock-crash-capture-0.23.txt. If a new crash occurs,
use Сохранить дамп падения and export bedrock-crash-capture-0.23.dmp.gz.
The native status includes route=item-use to distinguish the corrected route.

## Validation performed here

- The exception context and frame-pointer chain were parsed from the real dump.
- The actual game binary confirms the fault instruction, canonical call target,
  false flag instruction and all 32 checked entry bytes.
- Native host tests pass for correct item-use arguments, mismatched code profile,
  independence from the Actor interaction slot, GameMode and SurvivalMode, tagged
  arguments, post-update replacement, item ownership, bounds and tick intervals.
- Native host C++ syntax checks and Java source syntax parsing pass.
- Existing binary dump-export tests pass, including source preservation.

These checks do not compile Android JNI/NDK code or execute Minecraft. Android
build and device execution remain pending. Toolchain: JDK17/Gradle8.7/AGP8.6.1,
SDK35, NDK27.0.12077973/CMake3.22.1, ARM64. Minimum30, target34, compile35.
