# ProtoHax reference and built-in backend

The reference script requires @protohax/userscript. The launcher does not execute
its packet API. Starting with 0.46, the built-in Auto Buy uses native game Place
transactions modeled on the real phone capture, not simulated double taps.
Its native scope, prediction and sender are game-owned. JavaScript capabilities
remain false for inventory/packets. Validate the new built-in path on the phone.

# Auto Buy preparation

This script requires @protohax/userscript and its packet/container API. The
Android launcher does not provide this API. Its legacy Auto Buy uses own-window
touch input; 0.45 adds native packet observation, not a completed packet sender.
rules.json contains the migrated rule data for that work.

The supplied script had a missing object brace, nme/ration typos, and shared
armor defaults overwriting per-item prices. These are repaired. Live auction
NBT is re-parsed instead of trusting a stack-ID/count cache. Confirmation
requires a readable matching price/seller when verification is enabled. New
enables reset previous auction samples. Dry run is enabled by default and sends
no click, refresh or pagination requests. Submitted purchase requests are not
reported as confirmed purchases. These fixes do not validate server packet ABI.

Local mock tests covered price-rule precedence, changed NBT with the same stack
ID, invalid counts, zero outgoing packets in dry run, and cancellation when the
confirmation price is missing. Actual ProtoHax/server testing is still needed.
