#include "static_items_core.h"
#include <jni.h>
#include <atomic>
#include <chrono>
#include <mutex>
#include <string>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cerrno>

namespace {
using namespace kulich_static_items;
using Render=void(*)(void*,void*,void*);
std::atomic<A> gameBase{0},boundClient{0};
std::atomic<bool> enabled{false};std::atomic<int64_t> lease{0};
std::atomic<uint64_t> renderCalls{0},modified{0},rejected{0};
std::mutex installGate;Render originalRender=nullptr;int memory=-1;
thread_local bool inside=false;
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(A address,void* out,size_t n){
 address=plain(address);
 if(memory<0||address<4096||n>65536||address>0x00ffffffffffffffULL-n)return false;
 ssize_t count;do{count=pread(memory,out,n,static_cast<off_t>(address));}while(count<0&&errno==EINTR);
 return count==ssize_t(n);
}
bool writeFlag(A taggedAddress,uint8_t value){
 if(plain(taggedAddress)<4096||value>1)return false;
 std::memcpy(reinterpret_cast<void*>(taggedAddress),&value,1);return true;
}
void render(void* renderer,void* context,void* data){
 renderCalls.fetch_add(1,std::memory_order_relaxed);
 if(inside||!enabled.load(std::memory_order_acquire)||now()>lease.load()){
  originalRender(renderer,context,data);return;
 }
 inside=true;auto read=readMemory;auto write=writeFlag;
 auto lookup=[&](Binding& value){return resolve(read,gameBase.load(),boundClient.load(),reinterpret_cast<A>(renderer),reinterpret_cast<A>(data),value);};
 auto original=[&](){originalRender(renderer,context,data);};
 try{
  if(invoke(write,lookup,original,true))modified.fetch_add(1,std::memory_order_relaxed);
  else rejected.fetch_add(1,std::memory_order_relaxed);
 }catch(...){inside=false;throw;}
 inside=false;
}
struct Profile {A offset;uint32_t words[8];};
constexpr Profile profiles[]={
 {RENDER,{0xd10503ffU,0x6d0c2bebU,0x6d0d23e9U,0xa90e7bfdU,0xa90f6ffcU,0xa91067faU,0xa9115ff8U,0xa91257f6U}},
 {0xab71a0cULL,{0x39516268U,0x37001688U,0xb9444268U,0xaa1303e0U,0x1e220100U,0x529999a8U,0x72a7a988U,0x1e270101U}},
 {0xab71da0ULL,{0x3951627aU,0xaa0003f8U,0xb4000b80U,0xaa1803e0U,0x94335600U,0x36000b20U,0x37002ffaU,0x910063e0U}},
 {0x10233438ULL,{0x120002f7U,0x120002b5U,0x9414f1a9U,0xaa1803e0U,0xaa1303e1U,0xb9044b14U,0x39116317U,0x39116715U}}
};
std::string install(A base,A client){
 std::lock_guard<std::mutex> lock(installGate);
 if(gameBase.load()){
  if(gameBase.load()!=base)return "Game base changed";
  if(pointer(readMemory,plain(client))!=base+0x1388fe70ULL)return "Static items client binding unavailable";
  boundClient.store(plain(client));return {};
 }
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0||pointer(readMemory,plain(client))!=base+0x1388fe70ULL)return "Static items client binding unavailable";
 for(const auto& profile:profiles){
  uint32_t code[8]{};
  if(!readMemory(base+profile.offset,code,sizeof code)||std::memcmp(code,profile.words,sizeof code))return "Static items code profile mismatch";
 }
 A entry=base+RENDERER_TABLE+24,original=0;
 if(!readMemory(entry,&original,8)||original!=base+RENDER)return "Static items renderer callback mismatch";
 long pageSize=sysconf(_SC_PAGESIZE);if(pageSize<=0)return "Invalid page size";
 A page=entry-entry%A(pageSize);
 if(entry+8>page+A(pageSize))return "Unexpected renderer callback page";
 FILE* maps=fopen("/proc/self/maps","r");if(!maps)return "Cannot inspect renderer callback mapping";
 char line[2048],perms[5]{};unsigned long long lo=0,hi=0;bool expected=false;
 while(fgets(line,sizeof line,maps)){
  if(sscanf(line,"%llx-%llx %4s",&lo,&hi,perms)==3&&page>=lo&&page+A(pageSize)<=hi){
   expected=perms[0]=='r'&&perms[1]=='-'&&perms[2]=='-'&&std::string(line).find("/libminecraftpe.so")!=std::string::npos;break;
  }
 }
 fclose(maps);if(!expected)return "Unexpected renderer callback mapping permissions";
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ|PROT_WRITE))return "Cannot update renderer callback table";
 originalRender=reinterpret_cast<Render>(original);boundClient.store(plain(client));gameBase.store(base);
 __atomic_store_n(reinterpret_cast<A*>(entry),reinterpret_cast<A>(&render),__ATOMIC_RELEASE);
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ)){
  __atomic_store_n(reinterpret_cast<A*>(entry),original,__ATOMIC_RELEASE);gameBase.store(0);
  return "Cannot restore renderer callback page protection";
 }
 return {};
}
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_StaticItemsBridge_install(JNIEnv* env,jclass,jlong base,jlong client){auto error=install(A(base),A(client));return env->NewStringUTF(error.c_str());}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_StaticItemsBridge_enable(JNIEnv*,jclass,jboolean value){enabled.store(value);lease.store(0);}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_StaticItemsBridge_pulse(JNIEnv*,jclass,jboolean value){lease.store(value?now()+1200:0);}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_StaticItemsBridge_status(JNIEnv* env,jclass){
 char result[400];
 snprintf(result,sizeof result,"Static items: enabled=%d render=%llu modified=%llu rejected=%llu route=scoped-render-presentation; world physics unchanged",enabled.load(),static_cast<unsigned long long>(renderCalls.load()),static_cast<unsigned long long>(modified.load()),static_cast<unsigned long long>(rejected.load()));
 return env->NewStringUTF(result);
}
