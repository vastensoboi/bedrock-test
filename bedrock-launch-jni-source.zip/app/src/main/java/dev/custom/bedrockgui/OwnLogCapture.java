package dev.custom.bedrockgui;

import android.content.Context;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/** Reads only this app UID's logs for up to one minute, bounded to 2 MiB. */
public final class OwnLogCapture {
    private static java.lang.Process current;
    private OwnLogCapture(){}
    public static synchronized void start(Context context) {
        if(current!=null)current.destroy();
        File output=new File(context.getFilesDir(),"own-logcat.txt");
        try {
            java.lang.Process process=new ProcessBuilder("/system/bin/logcat","--uid="+android.os.Process.myUid(),
                    "-v","threadtime","-T","1").redirectErrorStream(true).start();
            current=process;
            Thread reader=new Thread(()->{
                try(InputStream input=process.getInputStream();FileOutputStream out=new FileOutputStream(output)){
                    byte[] buffer=new byte[4096];int count,total=0;
                    while((count=input.read(buffer))!=-1){
                        if(total+count>2*1024*1024)break;
                        out.write(buffer,0,count);out.flush();total+=count;
                    }
                }catch(IOException ignored){}finally{process.destroy();}
            },"own-logcat-reader");reader.setDaemon(true);reader.start();
            Thread timeout=new Thread(()->{
                try{if(!process.waitFor(60,TimeUnit.SECONDS))process.destroy();}
                catch(InterruptedException error){Thread.currentThread().interrupt();process.destroy();}
            },"own-logcat-timeout");timeout.setDaemon(true);timeout.start();
        }catch(IOException error){
            try(FileOutputStream out=new FileOutputStream(output)){out.write(("Logcat недоступен: "+error).getBytes(StandardCharsets.UTF_8));}catch(IOException ignored){}
        }
    }
    public static String tail(Context context)throws IOException {
        File file=new File(context.getFilesDir(),"own-logcat.txt");
        if(!file.isFile())return "Собственный logcat не записан.";
        try(RandomAccessFile input=new RandomAccessFile(file,"r")){
            int count=(int)Math.min(input.length(),128*1024);
            input.seek(input.length()-count);byte[] data=new byte[count];input.readFully(data);
            return new String(data,StandardCharsets.UTF_8);
        }
    }
}
