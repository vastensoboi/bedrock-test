#include "../app/src/main/cpp/aim_combat.h"
#include <cassert>
#include <iostream>
#include <string>
#include <vector>
using namespace kulich_aim;
struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;
 std::vector<unsigned char> bytes=std::vector<unsigned char>(0x20000);A next=root+0x10000;A mutate=0;unsigned headerReads=0;
 template<class T> void put(A p,T value){assert(p>=root&&p-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+p-root,&value,sizeof value);}
 A alloc(size_t n){A p=next;next=(next+n+7)&~A(7);assert(next-root<bytes.size());return p;}
 bool operator()(A p,void* out,size_t n){if(p<root||p-root>bytes.size()||n>bytes.size()-(p-root))return false;std::memcpy(out,bytes.data()+p-root,n);if(p==mutate&&n==24&&++headerReads==2)static_cast<unsigned char*>(out)[0]^=2;return true;}
 void string(A p,const std::string& text,bool longForm=false){
  std::array<unsigned char,24> storage{};
  if(text.size()<=22&&!longForm){storage[0]=static_cast<unsigned char>(text.size()*2);std::memcpy(storage.data()+1,text.data(),text.size());}
  else{A allocated=((text.size()+2)&~A(1))|1,size=text.size(),buffer=alloc(text.size()+1),tagged=buffer|tag;std::memcpy(storage.data(),&allocated,8);std::memcpy(storage.data()+8,&size,8);std::memcpy(storage.data()+16,&tagged,8);std::memcpy(bytes.data()+buffer-root,text.data(),text.size());}
  put(p,storage);
 }
};
int main(){
 Memory m;constexpr A actor=Memory::root+0x1000;char out[385]{};auto before=m.bytes;
 assert(!targetName(m,actor,out,sizeof out)&&out[0]==0&&m.bytes==before);
 m.string(actor+0xb28,"Alex_1");assert(playerIdentity(m,actor|Memory::tag,out,sizeof out)&&std::string(out)=="Alex_1");
 assert(targetName(m,actor,out,sizeof out)&&std::string(out)=="Alex_1");
 m.string(actor+0xb40,"§a[Властелин] ",true);m.put<unsigned char>(actor+0xb58,1);
 m.string(actor+0xb60,"\n§c7/18 ❤");m.put<unsigned char>(actor+0xb78,1);
 before=m.bytes;assert(targetName(m,actor,out,sizeof out)&&std::string(out)=="§a[Властелин] Alex_1\n§c7/18 ❤"&&m.bytes==before);
 assert(playerIdentity(m,actor,out,sizeof out)&&std::string(out)=="Alex_1");
 // Typed metadata has priority over Player's formatted fallback.
 A data=m.alloc(16),vector=m.alloc(40),item=m.alloc(40),table=m.alloc(32),getter=m.alloc(8);
 m.put(actor+320,data|Memory::tag);m.put(data,vector);m.put(data+8,vector+40);m.put(vector+32,item|Memory::tag);m.put(item,table);m.put(table+24,getter);
 m.put<uint32_t>(getter,0x52800080);m.put<uint32_t>(getter+4,0xd65f03c0);m.string(item+16,"§6[VIP] Alex_1\n7/18",true);
 assert(targetName(m,actor,out,sizeof out)&&std::string(out)=="§6[VIP] Alex_1\n7/18");
 m.string(item+16,"Alex_1");assert(targetName(m,actor,out,sizeof out)&&std::string(out)=="§a[Властелин] Alex_1\n§c7/18 ❤");
 m.string(item+16,"§6[VIP] Alex_1\n7/18",true);
 // Explicit metadata84 (native score-line string) is appended without
 // replacing identity or inventing health; duplicates are not repeated.
 A expanded=m.alloc(85*8),scoreItem=m.alloc(40);m.put(expanded+32,item|Memory::tag);m.put(expanded+84*8,scoreItem|Memory::tag);m.put(data,expanded);m.put(data+8,expanded+85*8);
 m.put(scoreItem,table);m.string(scoreItem+16,"7/18 ❤");
 assert(targetName(m,actor,out,sizeof out)&&std::string(out)=="§6[VIP] Alex_1\n7/18\n7/18 ❤");
 m.string(scoreItem+16,"7/18");assert(targetName(m,actor,out,sizeof out)&&std::string(out)=="§6[VIP] Alex_1\n7/18");
 m.string(scoreItem+16,"");
 // Empty or wrong typed metadata falls back; it does not hide a valid raw nick.
 m.string(item+16,"");assert(targetName(m,actor,out,sizeof out)&&std::string(out).find("Властелин")!=std::string::npos);
 m.put<uint32_t>(getter,0);assert(targetName(m,actor,out,sizeof out)&&std::string(out).find("Alex_1")!=std::string::npos);
 m.string(actor+0xb40,std::string(380,'x'),true);assert(targetName(m,actor,out,sizeof out)&&std::string(out)=="Alex_1");
 // Truncation never creates a partial identity; malformed, NUL-containing or
 // changing string headers are rejected. Both short/long payload tags work.
 assert(!playerIdentity(m,actor,out,6));m.string(actor+0xb28,std::string("Ab\0Cd",5));assert(!playerIdentity(m,actor,out,sizeof out));
 m.string(actor+0xb28,"Long_player_identity",true);assert(playerIdentity(m,actor,out,sizeof out)&&std::string(out)=="Long_player_identity");
 m.mutate=actor+0xb28;m.headerReads=0;assert(!playerIdentity(m,actor,out,sizeof out));m.mutate=0;
 m.put<A>(actor+0xb28+8,385);assert(!playerIdentity(m,actor,out,sizeof out));
 m.string(actor+0xb28,"Alex");m.put<unsigned char>(actor+0xb28,46);assert(!playerIdentity(m,actor,out,sizeof out));
 assert(!playerString(m,actor,out,0)&&!playerString(m,actor,nullptr,10));
 std::cout<<"PASS: native raw player identity, formatted rank/name fallback, metadata priority, bounded tagged strings and concurrent/malformed guards\n";
}
