# Fresh-frame consistency, 0.79

The new guards address source consistency and cleanup defects. They do not
establish a working Nevertime bypass or change the multiplier to conceal the
problem. The world TPS and other actors' cadence remain outside this setting.
The existing ground/on-foot/no-active-item-use restrictions remain in force.

## Device evidence motivating this change

The 0.78 report records 325 extra native replays, 325 extra input observations,
no backend fault and no unexpected worker submissions. Enabled input cadence is
38.7861/s; disabled cadence is 19.9864/s. The cumulative receive counters show
74 prediction-correction packets and 25 own MovePlayer packets. The 64 retained,
deduplicated same-input-tick prediction comparisons all refer to accelerated
submissions. Their median position disagreement is 1.51072 blocks, while median
delta disagreement is only 0.00092573. The one correction received after disable
also refers to an accelerated submission.

Successful native replay return does not prove that one correct fresh physics
step was emitted. The report does not identify a private anticheat rule, prove
which clock domain caused the discrepancy, or establish server acceptance.

## Changes

The input trampoline now supplies its original LR and SP to the observer in
x2/x3. The observer accepts tick mapping only for the profiled native producer
return site `base+af64da8` and the exact packet at original `SP+120`, retaining
allocation tags. The original x2/x3, all other ABI arguments, original SP/LR,
FP state and native return/exception conventions are restored before tail
dispatch. The trampoline FDE covers the initial BTI and describes FP/LR as
live registers after they are restored, with CFA following restored SP.

Each extra-step reservation is counted separately from successful append,
replay and observed/verified native input. The history adapter is required to
leave the actor pose unchanged while recording its fresh snapshot. A violation
halts further extra work with `snapshot-moved-actor`, retaining the logical
offset already committed to actual history. Before a completed extra input
counts as verified, its pose must equal both the current actor and the saved
replay result, and its output tick must equal the current/history-last tick.
Mismatch is recorded as `native-input-state`. Original sender dispatch remains
intact; no position is fabricated or correction suppressed.

Every retained input may carry an owned trace with:

- `source=ordinary|extra|unexpected|unknown` and `coherent=yes|no`;
- native `world`, observed `raw`, actual `output`, `replay` and `historyLast`;
- actor and packet positions/deltas at submission;
- the extra step's `stepBefore`, `stepAppend` and `stepReplay` poses.

Trace attachment requires the same complete actor/history identity, exact sent
tick and finite matching packet data. Clock/actor incoherence remains attached
as evidence rather than being discarded. A missing or incompatible trace does
not discard an independently valid same-tick packet comparison. Traces are
copied into the input ring and correction event, so they survive mutable native
memory and later ring changes. Conflicting known origins at one tick mark that
comparison ambiguous; an unknown trace alone does not create a conflict.

The callback records only values actually read; an unavailable raw tick is never
reported as observed zero. Input takes the driver mutex with `try_to_lock`, so
a worker that loses the race with replay startup cannot deadlock a driver that
waits for it. The nonblocking unexpected path preserves original dispatch and
records its limitation. Advance and cleanup also take the driver mutex without
waiting. A lock-miss fallback reads one complete published clock bundle,
including the client identity, registry, Level, LevelData, world and offset;
an in-progress or changed publication is rejected. This avoids carrying an old
client's offset across a client rebind sharing the same world objects. The
cleanup callback must belong to the player's actual registry and cached
movement/interpolation pools before scheduling extra work. These checks do not
certify the engine's threading semantics.

## Metadata ownership

The native movement-corrected component has a 13-byte semantic prefix: three
float differences `before-after`, then the boolean produced by `bd74a8c` from
the pre-replay marker and mode. The helper is guarded by an additional exact
instruction profile. Prior metadata is recaptured after append, immediately
before replay, to include legitimate history-adapter bookkeeping.

Restoration requires the current native prefix, replay marker and mode still
match this exact step. If the same component was updated in place with other
data, it is retained and `foreignMetadataPreserved` increases. Restoring a
previous prefix writes only its 13 semantic bytes; padding bytes13..15 remain
untouched. Failure before ownership can be established does not authorize a
blind write. Synthetic history-mark cleanup also rereads other record marks
and pending events before clearing an outer work bit. These checks are
conservative validation, not a substitute for native synchronization; complete
engine concurrency behavior remains unverified.

## Validation and phone check

The source's 49-suite host runner covers the existing modules and new frame
trace, exact callsite and metadata-ownership models. New tests exercise retained
incoherent evidence, stale identity/packet rejection, known-origin conflicts,
ring-copy lifetime, stack allocation tags, overflow, foreign marker updates,
padding preservation, work arriving during synthetic cleanup, client rebinding
and concurrent clock publication without mixed session/offset bundles.

Validation also includes strict host/ARM64-conditional C++ checks, host object
generation for the conditional native path, Android35/Rhino Java17 checking,
ASan/UBSan of changed models, and offline verification of 33 native anchors and
12 table bindings. LLVM19 cross-assembles the shim; a dataflow model checks both
observer LR/SP delivery and restoration/tail dispatch. `readelf` checks emitted
DWARF frame rules. None of these checks executes the engine or an Android APK.

After installing 0.79, repeat the same grounded movement case and export the
journal. Relevant fields include `verifiedExtraInputs`, `snapshotViolations`,
`inputStateMismatches`, `callerRejected`, `foreignMetadataPreserved`, `fault` and
`submittedFrame{...}` on a corrected input. A verified local submission is not
network delivery, acknowledgement or proof that the server accepts faster
real-time movement.
