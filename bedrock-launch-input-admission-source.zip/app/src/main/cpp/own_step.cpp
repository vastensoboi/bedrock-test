#include "own_step.h"
#include "own_step_memory.h"
#include "own_step_profile.h"
#include "own_locomotion_core.h"
#include "own_input_gate.h"
#include "input_callsite_core.h"
#include "own_marker_core.h"
#include <atomic>
#include <mutex>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cerrno>
#include <algorithm>
#include <array>

extern "C" bool kulich_timer_trace_active();
extern "C" int kulich_timer_trace_multiplier();
extern "C" bool kulich_correction_input_ready();
namespace kulich_own_step {
namespace {
using Bulk=void(*)(void*,void*);using Getter=uint64_t*(*)(void*);
constexpr A ADVANCE_TABLE=0x13ad3b70ULL,ADVANCE=0xc219780ULL;
constexpr A CLEANUP_TABLE=0x1384a820ULL,CLEANUP=0x96f87a4ULL;
constexpr A LEVEL_TABLE=0x1394f510ULL,GET_TICK=0x10b17518ULL;
constexpr A INTERPOLATE_STORAGE=0x1384db48ULL,MOVEMENT_STORAGE=0x1384da78ULL,CORRECTED_STORAGE=0x13ac7070ULL;
std::atomic<A> library{0},clientInstance{0};std::atomic<bool> installed{false};
std::atomic<bool> replayInFlight{false};
std::mutex installGate;std::recursive_mutex stateGate;int memory=-1;
std::mutex traceGate;kulich_frame::Trace lastTrace{};bool haveTrace=false;
Clock clock;Binding ordinary{};bool haveOrdinary=false;A advanceSystem=0;Session advanceOwner{};
PublishedClock publishedClock;
InputGate inputGate;uint64_t ordinaryActivity=0;
std::atomic<uint64_t> settingsEpoch{1};uint64_t seenEpoch=0;
std::atomic<uint64_t> normalInputs{0},mappedInputs{0},extraInputs{0},extraSteps{0},
 advanceCalls{0},cleanupCalls{0},eligibleFrames{0},ineligibleFrames{0},offsetStatus{0},
 workerInputs{0},
 stepPlans{0},appendCompleted{0},snapshotViolations{0},verifiedExtraInputs{0},inputStateMismatches{0},
 callerRejected{0},foreignMetadata{0},traceSkipped{0},groundSteps{0},airSteps{0},verifiedAirInputs{0},
 foreignProducerInputs{0},unknownProducerInputs{0},ordinaryContentions{0},replayAdmissionsSkipped{0};
enum class Fault {None,AdvanceClock,InputClock,HistoryAppend,Replay,Binding,WorkerInput,InputSource,InputState,SnapshotChanged,MotionChanged,Exception};
std::atomic<Fault> fault{Fault::None};
enum class Eligibility {Ready,NoSubmission,ChangedState,InputActive,History,OtherHistory,Riding,Ground,Jump,JumpRequest,Travel,NativeBinding,UsingItem,MoveInput,Markers,Systems};
std::atomic<Eligibility> lastEligibility{Eligibility::NoSubmission};
thread_local bool generating=false,submittingExtra=false;
thread_local kulich_frame::Step currentStep{};
struct TickScope {
 A level=0;uint64_t tick=0;TickScope* prior=nullptr;
 static thread_local TickScope* current;
 TickScope(A object,uint64_t value):level(object),tick(value),prior(current){current=this;}
 ~TickScope(){current=prior;}
};
thread_local TickScope* TickScope::current=nullptr;
bool readMemory(A at,void* out,size_t size){
 at=plain(at);
 if(memory<0||at<4096||size>65536||at>0x00ffffffffffffffULL-size)return false;
 ssize_t count;do{count=pread(memory,out,size,static_cast<off_t>(at));}while(count<0&&errno==EINTR);
 return count==ssize_t(size);
}
template<class T>void store(A tagged,const T& value){std::memcpy(reinterpret_cast<void*>(tagged),&value,sizeof value);}
kulich_frame::Pose pose(const Binding& value){return {value.position,value.delta};}
kulich_frame::Key key(const Binding& value){return {value.session.client,plain(value.session.registry),plain(value.actor),value.history,value.entity};}
void publish(const kulich_frame::Trace& value){
 std::unique_lock<std::mutex> lock(traceGate,std::try_to_lock);
 if(!lock.owns_lock()){traceSkipped.fetch_add(1,std::memory_order_relaxed);return;}
 lastTrace=value;haveTrace=true;
}
void publishStep(const Binding& value){
 kulich_frame::Trace trace{};trace.origin=kulich_frame::Origin::Extra;trace.owner=key(value);trace.step=currentStep;publish(trace);
}
void changed(){
 // Once native append has begun, its reserved number must remain committable.
 // Apply concurrent UI settings after that in-progress step is complete.
 if(generating)return;
 uint64_t epoch=settingsEpoch.load();if(epoch!=seenEpoch){clock.pause();seenEpoch=epoch;}
}
void fail(Fault value){Fault expected=Fault::None;fault.compare_exchange_strong(expected,value);clock.pause();}
void publishClock(const Binding& value){
 publishedClock.publish(value.session,value.world,clock.offset());
 offsetStatus.store(clock.offset(),std::memory_order_relaxed);
}
bool session(Binding& out){
 Binding second{};A base=library.load(),client=clientInstance.load();
 return resolveSession(readMemory,base,client,out)&&resolveSession(readMemory,base,client,second)&&same(out,second);
}
bool binding(Binding& out){
 Binding second{};A base=library.load(),client=clientInstance.load();
 return resolve(readMemory,base,client,out)&&resolve(readMemory,base,client,second)&&same(out,second);
}
uint64_t* tickGetter(void* level){
 TickScope* scope=TickScope::current;
 if(scope&&plain(reinterpret_cast<A>(level))==plain(scope->level))return &scope->tick;
 return reinterpret_cast<Getter>(library.load()+GET_TICK)(level);
}
void advance(void* system,void* view){
 Bulk original=reinterpret_cast<Bulk>(library.load()+ADVANCE);
 advanceCalls.fetch_add(1,std::memory_order_relaxed);
 if(!installed.load(std::memory_order_acquire)||replayInFlight.load(std::memory_order_acquire)){original(system,view);return;}
 Binding value{};uint64_t tick=0;bool scoped=false;
 A registry=rawPointer(readMemory,reinterpret_cast<A>(view));
 if(!session(value)||plain(registry)!=plain(value.session.registry)){original(system,view);return;}
 {
  std::unique_lock<std::recursive_mutex> lock(stateGate,std::try_to_lock);
  if(!lock.owns_lock()){
   // Optional injected work must not make a native worker wait for its driver.
   // Retain a scoped value only for an unchanged published session/offset.
   PublishedClock::Snapshot snapshot{};Binding again{};
   bool published=publishedClock.read(snapshot)&&value.session==snapshot.session&&value.world>=snapshot.world&&
    value.world<=UINT64_MAX-snapshot.offset&&session(again)&&same(value,again)&&publishedClock.current(snapshot);
   if(published){TickScope scope(value.session.level,value.world+snapshot.offset);original(system,view);}
   else original(system,view);
   return;
  }
  changed();Binding locked{};
  if(session(locked)&&same(value,locked)){
   uint64_t previousReset=clock.resets;
   if(clock.bind(value.session,value.world)){
    if(clock.resets!=previousReset){haveOrdinary=false;advanceSystem=0;fault.store(Fault::None);}
    scoped=clock.mapped(value.world,tick);
    if(!scoped)fail(Fault::AdvanceClock);
    else publishClock(value);
   }
  }
 }
 if(!scoped){original(system,view);return;}
 // This changes the value returned only while this history-advance callback
 // is running. LevelData and registry-context CurrentTick are never written.
 // No state mutex is held while ordinary native code can dispatch/wait for
 // workers. A worker may enter input() without deadlocking its driver.
 {TickScope scope(value.session.level,tick);original(system,view);}
 {
  std::unique_lock<std::recursive_mutex> lock(stateGate,std::try_to_lock);
  if(lock.owns_lock()&&clock.matches(value.session)&&clock.world()==value.world){
   advanceSystem=reinterpret_cast<A>(system);advanceOwner=value.session;
   publishClock(value);
  }
 }
}
bool emptyStorage(A raw,A table){
 A begin=0;uint64_t count=0;
 return pointer(readMemory,raw)==library.load()+table&&packed(readMemory,raw,begin,count)&&count==0;
}
// Native sparse-set removal, using the same virtual ABI as c095bfc..c095c38.
// This preserves packed/sparse generation bookkeeping; no memcpy of ECS maps.
bool removeOne(A storage,A expectedTable,uint32_t entity){
 if(pointer(readMemory,storage)!=library.load()+expectedTable)return false;
 uint64_t index=0;Presence present=locate(readMemory,storage,entity,index);
 if(present==Presence::Unavailable)return false;
 if(present==Presence::Absent)return true;
 A begin=rawPointer(readMemory,plain(storage)+32);uint32_t packedEntity=0;
 if(plain(begin)<4096||!readMemory(plain(begin)+uint64_t(index)*4,&packedEntity,4)||packedEntity!=entity)return false;
 A target=pointer(readMemory,library.load()+expectedTable+16);
 using Pop=void(*)(void*,A*,uint64_t,A*,uint64_t);
 reinterpret_cast<Pop>(target)(reinterpret_cast<void*>(storage),&begin,uint64_t(index)+1,&begin,uint64_t(index));
 return locate(readMemory,storage,entity,index)==Presence::Absent;
}
bool addInterpolate(A storage,uint32_t entity){
 uint64_t index=0;
 if(pointer(readMemory,storage)!=library.load()+INTERPOLATE_STORAGE||locate(readMemory,storage,entity,index)!=Presence::Absent)return false;
 using Push=void(*)(void*,uint32_t*,bool,const void*);
 reinterpret_cast<Push>(library.load()+0x88dacf0ULL)(reinterpret_cast<void*>(storage),&entity,false,nullptr);
 return locate(readMemory,storage,entity,index)==Presence::Present;
}
struct Metadata {
 Binding owner{};A correctedPool=0,priorPayload=0;std::array<unsigned char,16> prior{};uint8_t priorReplayed=0,priorMode=0;
 bool saved=false,expectedKnown=false;kulich_marker::Marker expected{};
 bool capture(const Binding& value){
  bool known=false;owner=value;correctedPool=rawPool(readMemory,value.session.registry,CORRECTED,&known);
  if(!known||(correctedPool&&pointer(readMemory,correctedPool)!=library.load()+CORRECTED_STORAGE)||
     !readMemory(plain(value.replay)+1,&priorReplayed,1)||!readMemory(plain(value.replay)+2,&priorMode,1))return false;
  Presence priorState=payload(readMemory,correctedPool,value.entity,16,priorPayload);
  if(priorState==Presence::Unavailable)return false;
  if(priorPayload&&!readMemory(plain(priorPayload),prior.data(),prior.size()))return false;
  saved=true;return true;
 }
 bool expect(const Binding& completed){
  expectedKnown=kulich_marker::make(owner.position,completed.position,priorReplayed,priorMode,expected);
  return expectedKnown;
 }
 bool restore(){
  if(!saved)return true;
  if(taggedComponent(readMemory,pool(readMemory,plain(owner.session.registry),REPLAY),owner.entity,32)!=owner.replay)return false;
  // This storage can be created lazily by the native replay. An unreadable
  // lookup is not evidence of absence and must never authorize deleting data.
  bool known=false;A currentPool=rawPool(readMemory,owner.session.registry,CORRECTED,&known);
  if(!known||(correctedPool&&currentPool!=correctedPool)||
     (currentPool&&pointer(readMemory,currentPool)!=library.load()+CORRECTED_STORAGE))return false;
  correctedPool=currentPool;
  A current=0;Presence currentState=payload(readMemory,correctedPool,owner.entity,16,current);
  if(currentState==Presence::Unavailable)return false;
  std::array<unsigned char,16> bytes{};uint8_t replayed=0,mode=0;
  if(!expectedKnown||!current||!readMemory(plain(current),bytes.data(),bytes.size())||
     !readMemory(plain(owner.replay)+1,&replayed,1)||!readMemory(plain(owner.replay)+2,&mode,1))return false;
  // Pointer identity alone does not establish ownership: a genuine update can
  // replace the bytes in the same component. Undo only our exact native marker.
  if(!kulich_marker::owned(expected,bytes,replayed,mode,priorMode)){
   foreignMetadata.fetch_add(1,std::memory_order_relaxed);saved=false;return true;
  }
  if(priorPayload){if(current!=priorPayload)return false;std::memcpy(reinterpret_cast<void*>(current),prior.data(),expected.size());}
  else if(current&&!removeOne(correctedPool,CORRECTED_STORAGE,owner.entity))return false;
  store(owner.replay+1,priorReplayed);saved=false;return true;
 }
};
struct SyntheticMarks {
 Binding owner{};A frame=0;uint64_t tick=0,workers=0;bool armed=false;
 void arm(const Binding& value,uint64_t number,A at){owner=value;tick=number;frame=at;workers=workerInputs.load();armed=true;}
 bool clear(){
  if(!armed)return true;
  // An unexpected native submission may make this tick a genuine correction
  // target; preserve its marks rather than guessing which writer owns them.
  if(workerInputs.load()!=workers)return false;
  Binding current{};
  if(!binding(current)||!(current.session==owner.session)||current.actor!=owner.actor||
     current.replay!=owner.replay||current.history!=owner.history||current.world!=owner.world)return false;
  auto write=[](A tagged,const void* bytes,size_t size){std::memcpy(reinterpret_cast<void*>(tagged),bytes,size);return true;};
  if(!clearSyntheticMark(readMemory,write,owner,tick,frame))return false;
  armed=false;return true;
 }
 ~SyntheticMarks(){if(armed)try{if(!clear())fail(Fault::Binding);}catch(...){fail(Fault::Exception);}}
};
bool eligible(const Binding& value,A& interpolate,A& movement,MotionState& travel){
 A base=library.load(),registry=plain(value.session.registry);uint64_t expected=0;
 auto reject=[](Eligibility why){lastEligibility.store(why,std::memory_order_relaxed);return false;};
 if(!haveOrdinary)return reject(Eligibility::NoSubmission);
 if(!ordinaryActivity||ordinaryActivity!=inputGate.epoch())return reject(Eligibility::InputActive);
 if(!sameState(ordinary,value)||!(advanceOwner==value.session))return reject(Eligibility::ChangedState);
 if(!clock.mapped(value.world,expected)||value.current!=expected||value.historyLast!=expected||!cleanHistory(readMemory,value))return reject(Eligibility::History);
 A replayPool=pool(readMemory,registry,REPLAY),begin=0;uint64_t count=0;uint32_t sole=0;
 if(!packed(readMemory,replayPool,begin,count)||count!=1||!readMemory(plain(begin),&sole,4)||sole!=value.entity)return reject(Eligibility::OtherHistory);
 A passengers=pool(readMemory,registry,PASSENGER),valid=pool(readMemory,registry,VALID_FRAME);uint64_t index=0;
 if(!passengers||locate(readMemory,passengers,value.entity,index)!=Presence::Absent||
    !valid||locate(readMemory,valid,value.entity,index)!=Presence::Present)return reject(Eligibility::Riding);
 // Native ordinary input initiates the jump. Reuse its native airborne state
 // after release; no jump request, impulse, gravity or input bit is fabricated.
 MotionReason reason=motion(readMemory,value,travel);
 if(reason!=MotionReason::Ready)return reject(reason==MotionReason::JumpHeld?Eligibility::Jump:
  reason==MotionReason::PendingJump?Eligibility::JumpRequest:
  reason==MotionReason::Unsupported?Eligibility::Travel:Eligibility::Ground);
 uint8_t authority=0,live=0,initialized=0;A guard=rawPointer(readMemory,plain(value.session.level)+792);
 if(!readMemory(plain(value.actor)+4072,&authority,1)||authority!=1||plain(guard)<4096||
    !readMemory(plain(guard),&live,1)||!(live&1)||!advanceSystem||
    pointer(readMemory,advanceSystem)!=base+ADVANCE_TABLE||
    pointer(readMemory,advanceSystem+8)!=registry||integer(readMemory,advanceSystem+64)!=0xffffffffU||
    !readMemory(plain(advanceSystem)+72,&initialized,1)||!(initialized&1))return reject(Eligibility::NativeBinding);
 // Item-use duration and swing retain their separate own-player bridges.
 // Replaying while a live use transaction is pending is not yet established.
 A inputPool=pool(readMemory,registry,MOVE_INPUT),moveInput=0;std::array<unsigned char,100> input{};
 if(!inputPool||payload(readMemory,inputPool,value.entity,100,moveInput)!=Presence::Present||
    !readMemory(plain(moveInput),input.data(),input.size()))return reject(Eligibility::MoveInput);
 bool knownUse=false;A usePool=rawPool(readMemory,registry,ITEM_USE,&knownUse),use=0;int remaining=-1;
 if(!knownUse||payload(readMemory,usePool,value.entity,16,use)==Presence::Unavailable||
    (use&&(!readMemory(plain(use)+8,&remaining,4)||remaining< -1||remaining>=0)))return reject(Eligibility::UsingItem);
 interpolate=rawPool(readMemory,registry,INTERPOLATE);movement=rawPool(readMemory,registry,MOVEMENT);
 if(!emptyStorage(interpolate,INTERPOLATE_STORAGE)||!emptyStorage(movement,MOVEMENT_STORAGE))return reject(Eligibility::Markers);
 A manager=rawPointer(readMemory,plain(value.session.level)+832),systems=rawPointer(readMemory,manager);
 if(plain(manager)<4096||pointer(readMemory,systems)!=base+0x13ad0738ULL||
    pointer(readMemory,base+0x139f6ea0ULL+992)!=base+0xaf680d0ULL)return reject(Eligibility::Systems);
 lastEligibility.store(Eligibility::Ready,std::memory_order_relaxed);return true;
}
void extra(const Binding& candidate,A interpolate,const MotionState& travel){
 Binding before{};MotionState currentTravel{};
 if(!binding(before)||!sameState(candidate,before)||motion(readMemory,before,currentTravel)!=MotionReason::Ready||!(currentTravel==travel)){
  lastEligibility.store(Eligibility::ChangedState,std::memory_order_relaxed);return;
 }
 uint64_t next=0;if(!clock.next(before.world,next))return;
 stepPlans.fetch_add(1,std::memory_order_relaxed);
 Metadata metadata;if(!metadata.capture(before)){lastEligibility.store(Eligibility::NativeBinding);return;}
 // A contended ordinary observation invalidates its old baseline. It must not
 // race an optional replay, and it must never wait for a driver that may need it.
 const uint64_t activity=ordinaryActivity;
 if(!inputGate.tryBeginReplay(activity)){
  replayAdmissionsSkipped.fetch_add(1,std::memory_order_relaxed);
  lastEligibility.store(Eligibility::InputActive,std::memory_order_relaxed);clock.pause();return;
 }
 struct ReplayAdmission {~ReplayAdmission(){inputGate.endReplay();}} replayAdmission;
 struct Generating {
  Generating(){generating=true;currentStep={};replayInFlight.store(true,std::memory_order_release);}
  ~Generating(){replayInFlight.store(false,std::memory_order_release);generating=false;currentStep={};}
 } generatingScope;
 if(activity!=inputGate.epoch()||fault.load()!=Fault::None){clock.pause();return;}
 currentStep.tick=next;currentStep.beforeKnown=true;currentStep.before=pose(before);
 currentStep.motionKnown=true;currentStep.airborne=travel.mode==Motion::Air;publishStep(before);
 bool added=false,replayed=false;
 struct Restore {
  A storage;uint32_t entity;bool& added;bool& replayed;Metadata& metadata;
  ~Restore(){
   if(added)try{if(!removeOne(storage,INTERPOLATE_STORAGE,entity))fail(Fault::Binding);}catch(...){fail(Fault::Exception);}
   if(replayed)try{if(!metadata.restore())fail(Fault::Binding);}catch(...){fail(Fault::Exception);}
  }
 } restoreScope{interpolate,before.entity,added,replayed,metadata};
 SyntheticMarks marks;
 try{
  added=true;if(!addInterpolate(interpolate,before.entity)){fail(Fault::Binding);return;}
  // Use the original bulk adapter and its native optional wrappers, shared
  // registry lifetime guard, current MoveInput capture and external-data save.
  // ReplayState is sole-own here, so adding the marker exposes one actor only.
  A registry=before.session.registry;
  {TickScope scope(before.session.level,next);
   reinterpret_cast<Bulk>(library.load()+ADVANCE)(reinterpret_cast<void*>(advanceSystem),&registry);
  }
  if(!removeOne(interpolate,INTERPOLATE_STORAGE,before.entity)){fail(Fault::Binding);return;}
  added=false;
  Binding after{};
  if(!binding(after)||!freshHistoryAppend(before,after,next)){fail(Fault::HistoryAppend);return;}
  // The offset follows actual native history progress, even if a later replay
  // fails. It is never dropped on disable, riding, menu changes or lease expiry.
  if(!clock.commit(before.world,next)){fail(Fault::AdvanceClock);return;}
  publishClock(after);
  appendCompleted.fetch_add(1,std::memory_order_relaxed);
  currentStep.appendKnown=true;currentStep.afterAppend=pose(after);publishStep(after);
  if(!kulich_frame::snapshotStable(currentStep)){
   snapshotViolations.fetch_add(1,std::memory_order_relaxed);fail(Fault::SnapshotChanged);return;
  }
  MotionState appendedTravel{};
  if(motion(readMemory,after,appendedTravel)!=MotionReason::Ready||!(appendedTravel==travel)){
   fail(Fault::MotionChanged);return;
  }
  // Capture the exact pre-replay state, including any native bookkeeping that
  // the history adapter legitimately changed while appending this record.
  if(!metadata.capture(after)){fail(Fault::Binding);return;}
  A frame=record(readMemory,after.history,next);uint8_t flags=0;uint64_t dirty=0;
  if(!frame||!readMemory(plain(frame)+64,&flags,1)||!readMemory(plain(after.history)+64,&dirty,8)||
     (flags&1)||(dirty&3)){fail(Fault::HistoryAppend);return;}
  marks.arm(after,next,frame);
  store(frame+64,uint8_t(flags|1));store(after.history+64,uint64_t(dirty|1));
  struct ReplayResult {uint64_t tick,available;};
  using Replay=ReplayResult(*)(void*,void*);
  replayed=true;
  ReplayResult result=reinterpret_cast<Replay>(library.load()+0xccf7030ULL)(reinterpret_cast<void*>(after.replay),reinterpret_cast<void*>(after.actor));
  Binding completed{};
  if((result.available&255)!=1||result.tick!=next||fault.load()!=Fault::None||!binding(completed)||
     !(completed.session==after.session)||completed.actor!=after.actor||completed.replay!=after.replay||
     completed.history!=after.history||completed.world!=before.world||completed.current!=next||completed.historyLast!=next){fail(Fault::Replay);return;}
  currentStep.replayKnown=true;currentStep.afterReplay=pose(completed);publishStep(completed);
  if(!metadata.expect(completed)){fail(Fault::Replay);return;}
  bool cleared=marks.clear(),restored=metadata.restore();if(restored)replayed=false;
  if(!cleared||!restored){fail(Fault::Binding);return;}
  extraSteps.fetch_add(1,std::memory_order_relaxed);
  (travel.mode==Motion::Air?airSteps:groundSteps).fetch_add(1,std::memory_order_relaxed);
  // A real fresh-state submission follows native simulation. The native
  // producer clears transient actions itself (bd6cf2c) and constructs the packet.
  struct Submitting {Submitting(){submittingExtra=true;}~Submitting(){submittingExtra=false;}} submittingScope;
  reinterpret_cast<void(*)(void*)>(library.load()+0xaf64398ULL)(reinterpret_cast<void*>(after.actor));
 }catch(...){
  fail(Fault::Exception);
 }
}
void cleanup(void* system,void* view){
 reinterpret_cast<Bulk>(library.load()+CLEANUP)(system,view);
 cleanupCalls.fetch_add(1,std::memory_order_relaxed);
 if(!installed.load(std::memory_order_acquire)||replayInFlight.load(std::memory_order_acquire))return;
 std::unique_lock<std::recursive_mutex> lock(stateGate,std::try_to_lock);
 if(!lock.owns_lock())return;
 changed();Binding value{};A interpolate=0,movement=0;MotionState travel{};
 if(!binding(value)||!clock.matches(value.session)||value.world!=clock.world())return;
 // The same callback class is registered for other registries too. A cleanup
 // elsewhere must not run injected physics against the currently bound player.
 if(rawPointer(readMemory,reinterpret_cast<A>(view))!=value.session.registry||
    rawPointer(readMemory,reinterpret_cast<A>(system)+8)!=rawPool(readMemory,value.session.registry,MOVEMENT)||
    rawPointer(readMemory,reinterpret_cast<A>(system)+16)!=rawPool(readMemory,value.session.registry,INTERPOLATE))return;
 bool allowed=fault.load()==Fault::None&&eligible(value,interpolate,movement,travel);
 (allowed?eligibleFrames:ineligibleFrames).fetch_add(1,std::memory_order_relaxed);
 if(clock.plan(value.world,kulich_timer_trace_active(),kulich_timer_trace_multiplier(),allowed))extra(value,interpolate,travel);
}
bool mapping(A page,A bytes){
 FILE* maps=fopen("/proc/self/maps","r");if(!maps)return false;
 char line[2048],perms[5]{};unsigned long long first=0,last=0;bool valid=false;
 while(fgets(line,sizeof line,maps))if(sscanf(line,"%llx-%llx %4s",&first,&last,perms)==3&&page>=first&&page+bytes<=last){
  valid=perms[0]=='r'&&perms[1]=='-'&&perms[2]=='-'&&std::string(line).find("/libminecraftpe.so")!=std::string::npos;break;
 }
 fclose(maps);return valid;
}
const char* faultName(Fault value){
 switch(value){case Fault::None:return "none";case Fault::AdvanceClock:return "history-clock";
  case Fault::InputClock:return "input-clock";case Fault::HistoryAppend:return "fresh-history-record";
  case Fault::Replay:return "native-replay";case Fault::Binding:return "binding";
  case Fault::WorkerInput:return "own-input-during-replay-window";case Fault::InputSource:return "native-input-callsite";
  case Fault::InputState:return "native-input-state";case Fault::SnapshotChanged:return "snapshot-moved-actor";
  case Fault::MotionChanged:return "snapshot-changed-locomotion";
  default:return "native-exception";}
}
const char* eligibilityName(Eligibility value){
 switch(value){case Eligibility::Ready:return "ready";case Eligibility::NoSubmission:return "no-ordinary-submission";
  case Eligibility::ChangedState:return "state-changed-after-input";case Eligibility::History:return "history-pending-or-not-current";
  case Eligibility::InputActive:return "input-observer-active-or-newer";
  case Eligibility::OtherHistory:return "other-predicted-entity";case Eligibility::Riding:return "riding-or-no-frame-support";
  case Eligibility::Ground:return "locomotion-unavailable";case Eligibility::Jump:return "jump-held";
  case Eligibility::JumpRequest:return "pending-jump-request";case Eligibility::Travel:return "unsupported-travel";
  case Eligibility::NativeBinding:return "native-binding";case Eligibility::UsingItem:return "active-item-use";
  case Eligibility::MoveInput:return "move-input-unavailable";
  case Eligibility::Markers:return "movement-markers-still-active";default:return "entity-systems";}
}
}
bool ready(){return installed.load(std::memory_order_acquire);}
void settingsChanged(){settingsEpoch.fetch_add(1,std::memory_order_release);}
std::string install(uint64_t base,uint64_t client){
#if !defined(__aarch64__)
 (void)base;(void)client;return "Own-player simulation requires arm64";
#else
 std::lock_guard<std::mutex> lock(installGate);
 if(installed.load()){
  if(base!=library.load())return "Own-player simulation library changed";
  clientInstance.store(plain(client));return {};
 }
 if(!kulich_correction_input_ready())return "Own-player simulation needs the native input callback";
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0||!profileValid(readMemory,base))return "Own-player simulation code profile mismatch";
 struct Hook {A entry,expected,replacement;};
 const Hook hooks[]={
  {base+LEVEL_TABLE+640,base+GET_TICK,reinterpret_cast<A>(&tickGetter)},
  {base+ADVANCE_TABLE+48,base+ADVANCE,reinterpret_cast<A>(&advance)},
  {base+CLEANUP_TABLE+48,base+CLEANUP,reinterpret_cast<A>(&cleanup)}
 };
 long pageSize=sysconf(_SC_PAGESIZE);if(pageSize<=0)return "Invalid own-player callback page size";
 std::array<A,3> pages{};size_t count=0;
 for(const auto& h:hooks){
  if(pointer(readMemory,h.entry)!=h.expected)return "Own-player callback binding mismatch";
  A page=h.entry-h.entry%A(pageSize);
  if(h.entry+8>page+A(pageSize)||!mapping(page,A(pageSize)))return "Unexpected own-player callback mapping";
  if(std::find(pages.begin(),pages.begin()+count,page)==pages.begin()+count)pages[count++]=page;
 }
 size_t writable=0;
 for(;writable<count;++writable)if(mprotect(reinterpret_cast<void*>(pages[writable]),pageSize,PROT_READ|PROT_WRITE)){
  for(size_t i=0;i<writable;++i)mprotect(reinterpret_cast<void*>(pages[i]),pageSize,PROT_READ);
  return "Cannot update own-player callback pages";
 }
 library.store(base);clientInstance.store(plain(client));
 for(const auto& h:hooks)__atomic_store_n(reinterpret_cast<A*>(h.entry),h.replacement,__ATOMIC_RELEASE);
 bool protectedAgain=true;
 for(size_t i=0;i<count;++i)if(mprotect(reinterpret_cast<void*>(pages[i]),pageSize,PROT_READ))protectedAgain=false;
 if(!protectedAgain){
  bool canRestore=true;for(size_t i=0;i<count;++i)if(mprotect(reinterpret_cast<void*>(pages[i]),pageSize,PROT_READ|PROT_WRITE))canRestore=false;
  if(canRestore)for(const auto& h:hooks)__atomic_store_n(reinterpret_cast<A*>(h.entry),h.expected,__ATOMIC_RELEASE);
  for(size_t i=0;i<count;++i)mprotect(reinterpret_cast<void*>(pages[i]),pageSize,PROT_READ);
  return "Cannot restore own-player callback protection";
 }
 installed.store(true,std::memory_order_release);return {};
#endif
}
kulich_frame::Trace input(void* sender,void* packet,uint64_t callerLr,uint64_t callerSp,uint64_t producerActor)noexcept{
 kulich_frame::Trace trace{};
 if(!installed.load(std::memory_order_acquire))return trace;
 try{
  A base=library.load(),rawPacket=reinterpret_cast<A>(packet);
  if(pointer(readMemory,rawPacket)!=base+0x13b95240ULL)return trace;
  Binding value{};
  if(!session(value)||plain(value.sender)!=plain(reinterpret_cast<A>(sender)))return trace;
  if(!kulich_callsite::fresh(base,rawPacket,callerLr,callerSp)){
   callerRejected.fetch_add(1,std::memory_order_relaxed);
   fault.store(Fault::InputSource);return trace;
  }
  // Native af64398 keeps its actual Actor* in x19 through this exact send
  // site. A shared LoopbackSender alone cannot establish the packet's owner.
  if(!producerActor){unknownProducerInputs.fetch_add(1,std::memory_order_relaxed);return trace;}
  if(producerActor!=value.actor){foreignProducerInputs.fetch_add(1,std::memory_order_relaxed);return trace;}
  trace.origin=submittingExtra?kulich_frame::Origin::Extra:kulich_frame::Origin::Ordinary;
  auto captureTrace=[&](uint64_t rawTick,uint64_t outputTick){
   Binding full{};std::array<float,3> position{},delta{};
   bool complete=binding(full)&&full.session==value.session&&full.world==value.world&&
    full.actor==value.actor&&full.entity==value.entity&&
    readMemory(plain(rawPacket)+56,position.data(),12)&&readMemory(plain(rawPacket)+72,delta.data(),12);
   if(complete){
    trace.known=true;trace.owner=key(full);
    trace.input={value.world,rawTick,outputTick,full.current,full.historyLast,true,pose(full),{position,delta}};
   }
   if(generating)trace.step=currentStep;
   return full;
  };
  struct InputAdmission {
   InputGate::Admission value{};
   explicit InputAdmission(bool extra){if(!extra)value=inputGate.beginInput();}
   ~InputAdmission(){if(value.entered)inputGate.endInput();}
  } admission(submittingExtra);
  auto fallback=[&](bool duringReplay){
   uint64_t rawTick=0;PublishedClock::Snapshot snapshot{};
   trace.origin=duringReplay?kulich_frame::Origin::Unexpected:kulich_frame::Origin::Ordinary;
   bool observed=readMemory(plain(rawPacket)+168,&rawTick,8);uint64_t output=rawTick;
   Binding again{};
   // An admitted ordinary reader excludes replay, so retaining the same
   // session's offset into a newer native world tick is safe after revalidation.
   // A replay-window submission retains the stricter same-world fallback.
   if(observed&&publishedClock.read(snapshot)&&value.session==snapshot.session&&
      (duringReplay?value.world==snapshot.world:value.world>=snapshot.world)&&
      value.world<=UINT64_MAX-snapshot.offset&&rawTick==value.world&&
      session(again)&&same(value,again)&&publishedClock.current(snapshot)){
    output=value.world+snapshot.offset;store(rawPacket+168,output);
   }
   if(observed)captureTrace(rawTick,output);
   publish(trace);
   if(duringReplay){workerInputs.fetch_add(1,std::memory_order_relaxed);fault.store(Fault::WorkerInput);}
   else ordinaryContentions.fetch_add(1,std::memory_order_relaxed);
   return trace;
  };
  if(!submittingExtra&&!admission.value.entered)return fallback(true);
  std::unique_lock<std::recursive_mutex> lock(stateGate,std::try_to_lock);
  if(!lock.owns_lock())return fallback(submittingExtra);
  changed();Binding locked{};
  if(!session(locked)||!(locked.session==value.session)||locked.actor!=value.actor||locked.world!=value.world)return trace;
  uint64_t previousReset=clock.resets;
  if(!clock.bind(value.session,value.world))return trace;
  if(clock.resets!=previousReset){haveOrdinary=false;advanceSystem=0;fault.store(Fault::None);}
  publishClock(value);
  uint64_t rawTick=0,tick=0;
  if(!readMemory(plain(rawPacket)+168,&rawTick,8)||!clock.mapped(value.world,tick))return trace;
  if(rawTick!=value.world&&rawTick!=tick){
   captureTrace(rawTick,rawTick);publish(trace);if(clock.offset())fail(Fault::InputClock);return trace;
  }
  // Only a fresh object at the profiled native constructor's stack site may
  // be mapped. Equal numeric ticks alone no longer authorize this write.
  if(rawTick!=tick){store(rawPacket+168,tick);mappedInputs.fetch_add(1,std::memory_order_relaxed);}
  Binding full=captureTrace(rawTick,tick);publish(trace);
  if(submittingExtra){
   extraInputs.fetch_add(1,std::memory_order_relaxed);
   if(kulich_frame::coherent(trace)&&currentStep.tick==tick&&kulich_frame::snapshotStable(currentStep)&&
      currentStep.replayKnown&&kulich_frame::same(currentStep.afterReplay,trace.input.actor)){
    verifiedExtraInputs.fetch_add(1,std::memory_order_relaxed);
    if(currentStep.motionKnown&&currentStep.airborne)verifiedAirInputs.fetch_add(1,std::memory_order_relaxed);
   }else{inputStateMismatches.fetch_add(1,std::memory_order_relaxed);fail(Fault::InputState);}
   return trace;
  }
  normalInputs.fetch_add(1,std::memory_order_relaxed);
  if(!clock.submitted(value.world,tick))return trace;
  haveOrdinary=kulich_frame::coherent(trace);
  if(trace.known&&!haveOrdinary)inputStateMismatches.fetch_add(1,std::memory_order_relaxed);
  if(haveOrdinary){ordinary=full;ordinaryActivity=admission.value.token;}
 }catch(...){fault.store(Fault::Exception);}
 return trace;
}
std::string report(){
 std::string result="Own-player frame backend: ready="+std::to_string(ready())+
  " ordinaryInputs="+std::to_string(normalInputs.load())+" mappedInputs="+std::to_string(mappedInputs.load())+
  " extraSimulationSteps="+std::to_string(extraSteps.load())+" extraNativeInputs="+std::to_string(extraInputs.load())+
  " verifiedExtraInputs="+std::to_string(verifiedExtraInputs.load())+
  " extraGroundSteps="+std::to_string(groundSteps.load())+" extraAirSteps="+std::to_string(airSteps.load())+
  " verifiedAirInputs="+std::to_string(verifiedAirInputs.load())+
  " plannedExtraSteps="+std::to_string(stepPlans.load())+" appendedExtraSteps="+std::to_string(appendCompleted.load())+
  " snapshotViolations="+std::to_string(snapshotViolations.load())+" inputStateMismatches="+std::to_string(inputStateMismatches.load())+
  " callerRejected="+std::to_string(callerRejected.load())+" foreignMetadataPreserved="+std::to_string(foreignMetadata.load())+
  " foreignProducerInputs="+std::to_string(foreignProducerInputs.load())+" unknownProducerInputs="+std::to_string(unknownProducerInputs.load())+
  " ordinaryContentions="+std::to_string(ordinaryContentions.load())+" replayAdmissionsSkipped="+std::to_string(replayAdmissionsSkipped.load())+
  " traceSkipped="+std::to_string(traceSkipped.load())+
  " retainedTickOffset="+std::to_string(offsetStatus.load())+" historyCallbacks="+std::to_string(advanceCalls.load())+
  " cleanupCallbacks="+std::to_string(cleanupCalls.load())+" eligibleFrames="+std::to_string(eligibleFrames.load())+
  " ineligibleFrames="+std::to_string(ineligibleFrames.load())+" workerInputs="+std::to_string(workerInputs.load())+
  " replayWindowInputs="+std::to_string(workerInputs.load())+
  " lastEligibility="+eligibilityName(lastEligibility.load())+
  " fault="+faultName(fault.load())+
  " route=fresh-own-history/native-simulation/native-input scope=ground-and-normal-air/released-jump/on-foot/no-active-use worldClockWrites=0 speedAttributeWrites=0 serverAcceptance=unverified";
 kulich_frame::Trace captured{};bool available=false;
 {
  std::unique_lock<std::mutex> lock(traceGate,std::try_to_lock);
  if(lock.owns_lock()){captured=lastTrace;available=haveTrace;}
 }
 if(available){std::ostringstream out;kulich_frame::describe(out,captured);result+="\nLast own-frame trace: "+out.str();}
 return result;
}
}
