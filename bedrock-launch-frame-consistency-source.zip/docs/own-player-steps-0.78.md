# Own-player forward-step experiment, 0.78

This is an experimental implementation, not a verified Nevertime bypass.
The first path supports continuous grounded travel on foot with no active item
use. Jumping, riding and movement during item use retain normal movement speed.
Item-use duration and hand swing retain their existing own-player bridges.
The multiplier remains 1.00..2.00; no shared world/render TPS is changed.

## Evidence and design

The uploaded follow-up report has 45 same-input-tick corrections. Forty-two
inputs were submitted at x1.10 and three at x1.00. The long enabled run still
submits about 20 frames/s. For a stable ground velocity 0.153216793 and native
drag 0.546, the x1.10 attribute change predicts delta errors 0.00695604 after
one step and 0.01075404 after two, matching the recorded discrepancy. The
three disabled submissions retain the predicted one-step decay, 0.00379800.
This does not establish a double-multiplication bug or the server's private
anticheat thresholds. The old movement multiplier is bypassed in this build.

Exact supplied ARM64 ELF SHA-256:
`4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4`.

The native history callback `c20393c` reads Level virtual slot80 and copies
the referenced tick into ReplayState+24. The reference resolves through
Level+144 to LevelData+752. Context CurrentTick is copied from the same
LevelData field by `10b0ec40..10b0ed08`. The earlier ClientLevel+1896 getter
is unrelated to this source. No LevelData field is written by the new path.

During only the original `AdvanceReplayStateSystem` bulk callback, the Level
slot80 wrapper may return a scoped logical tick reference. All native optional
wrappers, full entity checks, registry shared-pointer guard and MoveInput/
external-data capture remain in the original adapter. The common logical
offset is applied to predicted histories without adding physics steps to
other actors. If another predicted entity exists, no extra step is scheduled.
That preserves numbering when a controlled vehicle is introduced, while
extra physical advancement stays restricted to the sole own-player history.

The outgoing AuthInput hook maps packet+168 before the comparison observer
captures it. Normal source ticks and already mapped ticks are distinguished.
The logical offset persists after disable/lease expiry and actor/history
changes in the same client/registry/Level/LevelData session. It resets for a new session
or a native world-counter rollback. Neither PlayerAction nor InventoryTransaction
has a separate PlayerInputTick field to rewrite. Transactions are associated
with the following input: extra processing therefore follows a completed
ordinary submission, not a fabricated packet ahead of ordinary actions.

## Guarded native sequence

1. The original movement-marker cleanup runs normally. Extra work requires a
   stable local actor/owner generation, current history and an ordinary input
   at the same logical tick, with unchanged position and velocity. Both native
   MovementNeeded and InterpolateNeeded storages must now be empty. The player
   must be grounded, not jumping/riding/using an item. The history must contain
   no pending events, dirty flag or previously marked record.
2. Fractional scheduling allows at most one extra step per ordinary frame.
   Ineligible/missing frames, pauses and settings changes discard credit.
   No delayed burst is accumulated. A committed extra number requires a
   successful reservation and a real newly appended native history record.
3. Temporarily add only the own interpolation marker through native sparse-set
   insertion. Invoke the original initialized history adapter with the scoped
   next tick, then remove the marker through its native sparse-set pop ABI.
   This captures current tracked state, MoveInput and external data, rather
   than replaying an old record as a new frame. The native shared registry
   lifetime guard remains intact; no C++ shared_ptr layout is manufactured.
4. Mark just that fresh record and invoke native `ccf7030`. It creates and
   restores a temporary tracked entity, applies its input, runs the native
   replay simulation and applies the resulting state through the original
   player method. The existing movement attribute hooks pass through.
5. Restore prior own MovementWasCorrected metadata and ReplayState's prior
   replay marker. If no prior correction component existed, remove only the
   newly created own component using native sparse-set bookkeeping. Existing
   genuine metadata and incoming corrections are preserved. Cleanup also runs
   on early-return/exception paths. A changed binding prevents stale writes.
   Lookup distinguishes a proven absent component from an unavailable read;
   neither failed sparse reads nor missing payload pages authorize deletion.
   A lazily created correction storage is handled after native replay returns.
6. Require a successful native result and a stable completed history binding,
   then call native `af64398` to construct/submit the fresh input. Its own
   `bd6cf2c` cleanup consumes transient input actions; no packet is synthesized
   from a stale pose. Actual simulation and submission counts are separate.

Native replay may dispatch worker tasks. The cleanup hook uses a process-wide
in-flight guard, so it cannot block a worker on a driver mutex while the driver
waits for that worker. An unexpected own AuthInput from a replay worker is
counted and faults further extra scheduling; the original packet route is
retained. A native fault stops new extra work without dropping an already
committed logical offset. Normal game callbacks continue to be forwarded.
Ordinary history advance releases the driver mutex before invoking native code.
An in-progress reservation is retained across concurrent UI settings changes;
those changes take effect after the already-started step has completed.

The caller's artificial dirty marks also have exception cleanup. It clears
only the unsent fresh record's owned bit and clears the outer work bit only
when no other marked record or pending event remains. Other bits, including
bit1, are preserved. Cleanup is disarmed before sending the fresh input, and
is withheld after an unexpected native replay submission that could make the
new tick a genuine correction target.

The source validates 32 new instruction anchors and 12 native table bindings.
All native invocation arguments preserve allocation tags. Inspection through
`/proc/self/mem` strips tags only for the kernel read, never for engine calls
or component writes. No normal player tick is repeated: the callbacks for
aim, CPS, Fast Exp, HUD and the other existing modules remain on their original
cadence. No corrections are suppressed or interpreted as an identified private
anticheat reason.

## Validation and remaining limits

Host tests cover clock budgeting/monotonic numbering, disable/resume, changed
sessions, world rollback, upper-bound overflow and duplicate/unplanned commit
rejection. Synthetic memory tests cover allocation tags, stale generations,
live Level/session guards, missing replay state, bounded deque lookups across
allocation boundaries, pending correction rejection and read-only inspection.
Cleanup regressions exercise missing-vs-unreadable components, retained genuine
marks/pending events, stale outer dirty flags and partial write failure.
These tests do not execute the engine or establish remote acceptance.

Validation passes the full 46-suite host runner, Android35/Rhino Java17
typechecking of all 67 Java sources, strict host/ARM64-conditional C++ checks,
host object generation for the conditional native path and ASan/UBSan of the
new cores. The 32 new native anchors and 12 table bindings match the supplied
ELF offline. These are model/build checks; there is no local Android SDK/NDK
APK build or phone execution.

One additional step may be paired with a normal rendered frame; perfectly even
sub-frame visual pacing is not established. The native replay path is being
used for a fresh forward record for the first time here. Its complete runtime
interaction with movement, history cleanup, rendering and server timing still
requires a device check. Physically consistent own steps do not prove that a
server accepts faster real-time input cadence.

The report must distinguish `extraSimulationSteps`, `extraNativeInputs`,
`retainedTickOffset`, `lastEligibility` and `fault`. Zero extra counts are not
reported as successful acceleration. For an initial phone check, use a loaded
world, flat ground and x1.05 briefly, then disable Timer and export the journal.
The export must identify installed launcher 0.78 without deleting saved data.
