# Native input comparison, 0.77

The clean 0.76 phone report has valid Player corrections inside the native
history window: 21 while Timer x1.05 is active, none during the following
21-second disabled interval. That rules out the suggested zero/stale-tick
explanation for this sample, but contains no submitted position at the
corrected tick. Comparing a past server position to the current actor would
measure normal travel as well as any discrepancy.

0.77 records a bounded set of native input-submission attempts and compares
an incoming correction only to an unambiguous observation at the same tick.
It does not change the Timer's speed implementation, generate extra frames,
alter ticks, discard corrections, change global clocks, or provide a verified
Nevertime bypass. The user's requirement remains acceleration of their own
player only. A full independent own-player simulation entry is not yet proved.

## Native path

Exact ARM64 reference library SHA-256:
`4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4`.

The local `SendPlayerInputPacketSystem` calls `0xaf64398`. Its on-foot branch
copies StateVector position to packet+56 and velocity to packet+72. At
`0xaf64bb0..0xaf64bbc` the registry-context CurrentTick value is copied to
packet+168. The producer loads Actor+1984 and dispatches virtual byte+24,
slot3, with the packet. `LoopbackPacketSender` vptr `0x13b3ac00`, slot3,
targets `0xcc8934c`. AuthInput vptr is `0x13b95240`; its ID getter returns 144.
Twelve exact instruction profiles, packet-ID and sender callback bindings
guard this additional optional observer.

The observer records the attempt before tail-entering the original sender.
This proves neither successful serialization nor network delivery or server
acknowledgement. The assembly entry preserves raw arguments x0-x8, q0-q7,
original SP/LR, condition/FP state and caller stack arguments, then branches
to the original target. It does not intercept a serializer with an assumed
return signature. Native returns, hidden-result conventions and exceptions
continue directly through the original caller's frame.

## Matching and limits

Capture validates the bound ClientInstance, its weak local actor and full
entity generation, owner graph, actual sender, native packet class and
ReplayState history allocation. The allocation tag is part of the history
identity. Identity and meaningful packet fields must agree between snapshots.
The callback performs no allocations, journal writes or blocking sample-lock
waits. Skipped reads and lock contention are counted; the original call is
always retained.

The ring retains 128 unique ticks. Identical submissions at a tick are counted;
different meaningful data or source context at that tick mark it ambiguous.
Changing actor/history binding or an unseen backwards tick clears the window.
Zero correction ticks, Vehicle corrections, unknown/riding source context,
missing data, conflicting submissions and observations older than 10 seconds
produce explicit unmatched statuses. Passenger-component presence is used
conservatively to exclude riding, even where a passenger input might otherwise
use the player's position. No live state is substituted for a missing record.

An exact match reports submitted position/velocity, signed server-minus-
submitted differences in game units, age and submission/Timer-state counts.
The result is retained in the existing correction event and last-on/off
summaries after the input ring changes. It is not labelled a private anticheat
reason, applied correction, or a server acceptance threshold.

Cadence reports cover the latest contiguous Timer-on and Timer-off submission
runs. They distinguish observed unique frames from progression of tick numbers.
Missing observations can lower the observed-frame rate; these metrics are
not network delivery rates. An off frame records effective multiplier 100,
even if the UI's configured multiplier remains 105.

## Validation and phone check

The 44 host suites, strict host/ARM64-conditional C++ checks and the full
Android35/Rhino Java17 typecheck pass. The changed input/correction cores pass
ASan/UBSan. All 127 exact native profiles and the additional vtable bindings
match the supplied library. LLVM19 cross-assembles the new AArch64 trampoline;
dataflow checks on the assembled instructions verify its saved arguments,
stack, FP/condition state and single tail dispatch. These are offline checks,
not execution of the APK or an ARM64 CPU test.

Upload `bedrock-launch-input-match-source.zip` and run **Build latest launch
test**. With 0.77, walk normally with Timer off for about 5 seconds, try x1.05
briefly, disable it and walk for another 5 seconds. Export **Журнал**. The
needed result is `Native input observer: ready=1` and correction rows with
`submittedComparison=same-input-tick`, or the explicit unmatched reason.
There is no script to paste into Termux or the launcher.

## Follow-up device evidence

The report uploaded as `bedrock-crash-capture-0.76 _1_.txt` contains the new
native input observer and 45 unique packet 161 events, all matched at the same
input tick. The title/version filename was a stale literal in MainActivity,
not evidence that the observer was absent. The workspace now derives report,
screen and export names from the installed launcher's package version. The
already delivered 0.77 ZIP has not been silently replaced.

Of the 45 corrected inputs, 42 were submitted with Timer x1.10 and 3 with x1.00.
At receipt the counts are 37/8: five receipts while disabled refer to earlier
accelerated submissions. The long on run observes 20.0209 frames/s; the final
on/off runs observe 20.0 and 20.0765. Horizontal position disagreement for the
same tick ranges 0.006588..1.154751 game units (median 0.662624); vertical
disagreement is zero. All reference ticks are inside the 60-frame window, with
submission ages 96..211 ms (median 106 ms). No conflicting submissions, missing
payloads, profile errors or fatal failures are identified in this report.

The user toggles Timer repeatedly; the final off interval is only 1.083 s, so
this is not a long clean off baseline. The observations establish real
same-tick position/velocity differences with unchanged approximate input
cadence. They are consistent with the per-step speed change disagreeing with
server prediction. They do not identify the private server rule, its threshold,
or a purported list of ten bypass techniques. Structured evidence is saved
in `outputs/minecraft-analysis/timer-input-device-20261123.json` in the workspace.
