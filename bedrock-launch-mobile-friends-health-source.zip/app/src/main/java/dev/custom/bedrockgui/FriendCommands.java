package dev.custom.bedrockgui;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Local friend commands; only exact, case-insensitive Minecraft nicknames are accepted. */
public final class FriendCommands {
    public static final int MAX_FRIENDS=128;
    private final Map<String,String> names=new LinkedHashMap<>();
    public static final class Result {
        public final String message;public final boolean changed;
        private Result(String message,boolean changed){this.message=message;this.changed=changed;}
    }
    public FriendCommands(){this("");}
    public FriendCommands(String saved){
        if(saved==null||saved.length()>MAX_FRIENDS*34)return;
        for(String value:saved.split("\\r?\\n")){
            String name=value.trim(),key=normalize(name);
            if(!key.isEmpty()&&names.size()<MAX_FRIENDS)names.putIfAbsent(key,name);
        }
    }
    public static String normalize(String value){return value!=null&&value.matches("[A-Za-z0-9_]{1,16}")?value.toLowerCase(Locale.ROOT):"";}
    public static boolean isCommand(String input){
        if(input==null)return false;
        String text=input.trim();if(text.isEmpty())return false;
        String verb=text.split("\\s+",2)[0];return verb.equalsIgnoreCase(".add")||verb.equalsIgnoreCase(".remove");
    }
    public Result execute(String input){
        if(input==null||input.length()>64)return result("Напиши .add Ник или .remove Ник",false);
        String[] parts=input.trim().split("\\s+");
        if(parts.length!=2||!isCommand(parts[0]))return result("Напиши .add Ник или .remove Ник",false);
        String key=normalize(parts[1]);
        if(key.isEmpty())return result("Ник: 1–16 английских букв, цифр или _",false);
        if(parts[0].equalsIgnoreCase(".add")){
            if(names.containsKey(key))return result(names.get(key)+" уже в друзьях",false);
            if(names.size()>=MAX_FRIENDS)return result("Список заполнен: максимум "+MAX_FRIENDS+" друзей",false);
            names.put(key,parts[1]);return result("Добавлен друг: "+parts[1],true);
        }
        String removed=names.remove(key);
        return removed==null?result("Этот ник не найден в друзьях",false):result("Удалён друг: "+removed,true);
    }
    private static Result result(String text,boolean changed){return new Result(text,changed);}
    public boolean contains(String nickname){return names.containsKey(normalize(nickname));}
    public String[] names(){return names.values().toArray(new String[0]);}
    public String serialized(){return String.join("\n",names.values());}
}
