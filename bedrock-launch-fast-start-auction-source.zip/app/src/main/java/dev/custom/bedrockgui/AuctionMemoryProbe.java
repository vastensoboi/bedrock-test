package dev.custom.bedrockgui;

import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.function.Consumer;

/** Read-only candidate container snapshot. It never calls game methods or clicks slots. */
public final class AuctionMemoryProbe {
    private final List<EngineMemoryProbe.Region> regions;
    private final EngineMemoryProbe.Reader reader;private final long base;private final Consumer<String> log;
    private int reads;private long deadline;
    public AuctionMemoryProbe(List<EngineMemoryProbe.Region> regions,EngineMemoryProbe.Reader reader,long base,Consumer<String> log){
        this.regions=regions;this.reader=reader;this.base=base;this.log=log;
    }
    private static long ptr(long p){return EngineMemoryProbe.untag(p);}
    private byte[] read(long address,int size)throws IOException {
        address=ptr(address);
        if(address==0||size<0||reads>=8000||System.nanoTime()>deadline)return null;
        boolean mapped=false;
        for(EngineMemoryProbe.Region r:regions)if(r.readable&&r.writable&&address>=r.start&&address<r.end&&size<=r.end-address){mapped=true;break;}
        if(!mapped)return null;
        reads++;byte[] data=new byte[size];
        try{return reader.read(address,data,size)?data:null;}catch(IOException error){return null;}
    }
    private static long q(byte[] data,int offset){return ptr(ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN).getLong(offset));}
    private long pointer(long address)throws IOException {byte[] bytes=read(address,8);return bytes==null?0:q(bytes,0);}
    public String scan(long player,long client)throws IOException {
        reads=0;deadline=System.nanoTime()+2000000000L;player=ptr(player);client=ptr(client);
        byte[] actor=read(player,4304);
        if(actor==null||q(actor,0)!=base+0x139f6ea0L||q(actor,3240)!=client||client==0)
            return "Игрок изменился. Открой аукцион и повтори чтение.";
        Set<Long> managers=new LinkedHashSet<>();
        for(int offset=0;offset+8<=actor.length;offset+=8){
            long candidate=q(actor,offset);
            if(candidate!=0&&pointer(candidate)==base+0x137e8f20L){
                managers.add(candidate);log.accept("Auto Buy: ChestContainerManagerModel at player+0x"+Integer.toHexString(offset));
            }
        }
        if(managers.isEmpty())return "Открытый сундуковый контейнер пока не найден. Покупки не выполнялись.";
        List<String> candidates=new ArrayList<>();Set<Long> seen=new HashSet<>();
        for(long manager:managers){
            byte[] state=read(manager,216);if(state==null||q(state,0)!=base+0x137e8f20L)continue;
            // Exact build: model map at +176; libc++ first-node link at +16.
            long node=q(state,192);
            for(int n=0;node!=0&&n<32&&seen.add(node);n++){
                byte[] entry=read(node,56);if(entry==null)break;
                long model=q(entry,40);
                byte[] object=read(model,240);
                if(object!=null&&q(object,0)==base+0x13d35930L){
                    // Disassembly 0x10169ba4/0x10169bd0: vector at +216,
                    // indexing uses 152-byte ItemStack objects. Do not infer names/prices.
                    long begin=q(object,216),end=q(object,224),capacity=q(object,232);
                    long bytes=end-begin;
                    if(begin!=0&&end>=begin&&capacity>=end&&capacity-begin<=152L*4096&&bytes%152==0&&(bytes/152==27||bytes/152==54)){
                        int slots=(int)(bytes/152);byte[] stacks=read(begin,(int)bytes);boolean valid=stacks!=null;
                        StringBuilder amounts=new StringBuilder();int nonEmpty=0;
                        if(valid)for(int i=0;i<slots;i++){
                            if(q(stacks,i*152)!=base+0x13d95ff8L){valid=false;break;}
                            int count=stacks[i*152+34]&255;
                            if(count>0){nonEmpty++;if(amounts.length()>0)amounts.append(", ");amounts.append(i).append(':').append(count);}
                        }
                        byte[] current=read(model,240),currentStacks=read(begin,(int)bytes);
                        if(valid&&current!=null&&currentStacks!=null&&Arrays.equals(object,current)&&Arrays.equals(stacks,currentStacks)&&
                                pointer(player)==base+0x139f6ea0L&&pointer(player+3240)==client&&pointer(manager)==base+0x137e8f20L&&pointer(node+40)==model){
                            String value="Container candidate: slots="+slots+" nonEmpty="+nonEmpty+" slotCounts={"+amounts+"}";
                            log.accept("Auto Buy: "+value);candidates.add(value);
                        }else log.accept("Auto Buy: changed/invalid container snapshot rejected");
                    }
                }
                node=q(entry,0);
            }
            if(pointer(manager+192)!=q(state,192))return "Окно контейнера изменилось. Повтори чтение. Покупки не выполнялись.";
        }
        return candidates.isEmpty()?"Менеджер контейнера найден, но лоты пока не прочитаны. Покупки не выполнялись.":
                String.join("\n",candidates)+"\nЭто снимок слотов. Названия, цены и покупка ещё не подключены.";
    }
}
