# Bedrock Launch Test 0.2 — experimental hosted launch

This is a separate test app, applicationId dev.custom.bedrocklaunchtest.
It does not overwrite the installed Minecraft or Bedrock Diagnostic app.

The test prepares installed Minecraft's base/split APKs and ARM64 libraries,
then attempts native startup and a game Activity inside this app's :game process.
This is NOT injection into an already running Minecraft process. No gameplay
modules, packet modifications, Xposed hooks or libVHax.so are included.

Implemented startup attempt:

1. Extract game native libraries using the previously tested extraction component.
2. Create a separate DexClassLoader through AppComponentFactory for the game Activity.
3. Initialize declared game Application/provider classes (static initialization
   only; full foreign Application/provider lifecycle is NOT emulated).
4. Preload known game native dependencies and libminecraftpe.so from that loader.
5. Load the small libmc.so forwarding shim.
6. Attach game resources with ResourcesLoader/ResourcesProvider public APIs.
7. Instantiate a host Activity subclass whose real MainActivity superclass is
   supplied by the installed game's DEX at runtime, and call its onCreate.
8. Write stage markers and Java failures to an app-private journal. After native
   crashes the host can show available historical process-exit reasons.

This version uses public class-loader/component/resource APIs and does not
modify private pathList/nativeLibraryDirectories fields.

## Crucial limitations

Native initialization and game Activity startup have NOT been tested on-device.
The copied Application/provider static initialization does not reproduce all
Android startup behavior. Game callbacks, resources, identity, storage, auth,
provider registration, dynamic features or native dependencies can still fail.
There is no claim of verified Minecraft 1.26.60.4 / Android 17 compatibility.
Returning from onCreate does not prove successful gameplay or menu rendering.
This app does not disable licensing checks or change the installed game.

The game runs with the host app's UID, package identity and private storage;
it does not inherit the original app's grants, private files or login state.
Application class loading and library preloading occur during factory startup;
a slow or blocked native initializer may time out or crash the :game process.
The first useful device result is a visible game title screen or an error log.
Login and joining a server are not needed for this initial test.

## Native shim origin

app/src/main/jniLibs/arm64-v8a/libmc.so is the exact 4.64 KiB binary supplied by
this session's user, not a newly built independent shim. Its ELF/functions were
statically inspected before packaging. It forwards native entry points to the
real libminecraftpe.so via dlopen/dlsym and was not executed in the development
workspace. This binary is used only to test the observed startup bridge.
A readable independent reconstruction was produced separately in mc-forwarder.c.
This prototype does not claim authorship of the supplied binary.

The game-api-stub module is a compile-only class declaration and MUST NOT be
packaged in the APK. The cloud workflow checks that the stub is absent from DEX.

## Checks performed here

- Parsed syntax of all Java sources.
- Compiled and ran extraction-component tests: split extraction, unchanged bytes,
  read-only files, path filtering, duplicates, invalid ELF and cleanup.
- Checked manifest component paths, compile-only dependency and shim identity.

Android SDK remains unavailable locally; Android compilation and device tests
have not been performed. A GitHub Actions workflow is supplied to perform the
Android build and APK packaging checks. It has not run at preparation time.

## Device test after a successful APK build

1. Install Bedrock Launch Test alongside the existing diagnostic app and game.
2. Open it and tap «Тест запуска Minecraft».
3. If the game opens, report whether the title screen actually appears.
4. If it fails/closes, return, tap «Показать журнал запуска», then «Сохранить журнал».
5. If the test process is still running, «Остановить тестовый процесс игры» stops
   only this app's own :game process. It does not kill the installed game process.

## Building

JDK 17, Android SDK Platform 35, Gradle 8.7. SDK path via ANDROID_HOME,
ANDROID_SDK_ROOT or local.properties sdk.dir.

    gradle :app:assembleDebug

Minimum Android version is 11 / API 30. Target SDK remains 34; compile SDK 35
supplies the public APIs used. Testing on Android 17 is still required.

Public Android API references:
- https://developer.android.com/reference/android/app/AppComponentFactory
- https://developer.android.com/reference/android/content/res/loader/ResourcesProvider
