#pragma once
#include "aim_core.h"
#include <algorithm>
#include <cstddef>

// Exact 1.26.60.4 ARM64 ItemUseTickDurationSystem. The native operation at
// c12884c..858 / c12964c..658 decrements remaining+8 once, storing only a
// nonnegative result. Player::normalTick101f1f88 observes zero and retains
// responsibility for the actual item-use completion; no completion is forged.
namespace kulich_use_timer {
using namespace kulich_aim;
constexpr uint32_t ITEM_USE=0x05b90aefU,USE_DURING_MOVEMENT=0x9b80c0c9U,
                   MOVEMENT_TICK=0x94154cceU,ACTOR_TICK=0x2744aa41U;
enum class Phase {Movement,Ordinary};
struct Hook {A table,bulk,single;Phase phase;};
constexpr Hook hooks[]={
 {0x13aca718ULL,0xc128648ULL,0xc128af0ULL,Phase::Movement},
 {0x13aca798ULL,0xc129214ULL,0xc129564ULL,Phase::Ordinary}
};
struct UseState {std::array<uint8_t,8> prefix{};int32_t remaining=0;uint32_t suffix=0;};
static_assert(sizeof(UseState)==16&&offsetof(UseState,remaining)==8,"Exact item-use storage layout");
struct Binding {A registry=0,actor=0,payload=0;uint32_t entity=0xffffffffU;UseState state{};};
inline bool same(const Binding& a,const Binding& b){
 return a.registry==b.registry&&a.actor==b.actor&&a.payload==b.payload&&a.entity==b.entity&&
        a.state.prefix==b.state.prefix&&a.state.suffix==b.state.suffix;
}
template<class Read>bool member(Read& read,A registry,uint32_t key,uint32_t entity){
 A storage=pool(read,registry,key);return storage&&sparse(read,storage+8,entity)>=0;
}
template<class Read>bool resolve(Read& read,A base,A client,A adapter,A entityPointer,Phase phase,Binding& out){
 out={};client=plain(client);adapter=plain(adapter);
 const Hook& hook=hooks[phase==Phase::Movement?0:1];
 if(!base||pointer(read,client)!=base+0x1388fe70ULL||pointer(read,adapter)!=base+hook.table)return false;
 A weak[3]{},againWeak[3]{};
 if(!read(client+576,weak,sizeof weak)||plain(weak[0])<4096||!plain(weak[1]))return false;
 A registry=plain(weak[0]);uint32_t entity=uint32_t(weak[2]);
 if((entity&0x3ffffU)==0x3ffffU||pointer(read,adapter+8)!=registry||
    (entityPointer&&integer(read,entityPointer)!=entity)||sparse(read,registry+216,entity)<0)return false;
 bool movementUse=member(read,registry,USE_DURING_MOVEMENT,entity);
 if(phase==Phase::Movement){
  if(!movementUse||!member(read,registry,MOVEMENT_TICK,entity))return false;
 }else if(movementUse||!member(read,registry,ACTOR_TICK,entity))return false;
 A owners=pool(read,registry,OWNER),owner=component(read,owners,entity,8),actorAddress=pointer(read,owner);
 std::array<A,4> header{},again{};
 if(!owner||!actorAddress||!read(actorAddress,header.data(),sizeof header)||plain(header[0])!=base+0x139f6ea0ULL||
    plain(header[1])!=registry||plain(header[2])!=registry+40||uint32_t(header[3])!=entity||
    pointer(read,actorAddress+3240)!=client)return false;
 uint8_t removed=1;if(!read(actorAddress+617,&removed,1)||removed)return false;
 A storage=pool(read,registry,ITEM_USE),payload=taggedComponent(read,storage,entity,sizeof(UseState));
 UseState state{},second{};
 if(!payload||(plain(payload)&3)||!read(plain(payload),&state,sizeof state)||state.remaining<0||state.remaining>72000||
    !read(plain(payload),&second,sizeof second)||std::memcmp(&state,&second,sizeof state)||
    !read(actorAddress,again.data(),sizeof again)||header!=again||
    component(read,owners,entity,8)!=owner||pointer(read,owner)!=actorAddress||
    taggedComponent(read,storage,entity,sizeof(UseState))!=payload||
    !read(client+576,againWeak,sizeof againWeak)||std::memcmp(weak,againWeak,sizeof weak))return false;
 out={registry,actorAddress,payload,entity,state};return true;
}
inline int clampHundredths(int value){return std::max(100,std::min(200,value));}
class UseClock {
 bool bound=false;Binding identity{};int expected=-1,fraction=0,setting=100;
public:
 void reset(){bound=false;expected=-1;fraction=0;setting=100;}
 unsigned take(const Binding& value,int hundredths){
  hundredths=clampHundredths(hundredths);
  if(!bound||!same(identity,value)||setting!=hundredths||value.state.remaining!=expected){
   fraction=0;identity=value;bound=true;setting=hundredths;
  }
  if(value.state.remaining<=1||hundredths==100){fraction=0;expected=std::max(0,value.state.remaining-1);return 0;}
  fraction+=hundredths-100;unsigned extra=unsigned(fraction/100);fraction%=100;
  extra=std::min(extra,unsigned(value.state.remaining-1));
  expected=value.state.remaining-int(extra)-1;return extra;
 }
};
// Commit only additional local elapsed use ticks. Do not restore them after
// success: the native decrement and remaining result are intended progress.
// Reserve one final tick so native completion still transitions through zero.
template<class Write,class Lookup,class Original>
unsigned invoke(UseClock& clock,Write& write,Lookup lookup,Original original,bool enabled,int hundredths){
 Binding before{};unsigned extra=0;bool changed=false;int32_t injected=0;
 if(enabled&&lookup(before)){
  extra=clock.take(before,hundredths);
  if(extra){
   Binding current{};injected=before.state.remaining-int32_t(extra);
   if(lookup(current)&&same(before,current)&&current.state.remaining==before.state.remaining&&
      write(before.payload+8,injected))changed=true;
   else{extra=0;clock.reset();}
  }
 }else if(!enabled)clock.reset();
 try{original();}catch(...){
  if(changed){Binding after{};if(lookup(after)&&same(before,after)&&after.state.remaining==injected)write(before.payload+8,before.state.remaining);}
  clock.reset();throw;
 }
 return extra;
}
struct Profile {A offset;uint32_t words[8];};
constexpr Profile profiles[]={
 {0xc128648ULL,{0xd10283ffU,0xa9047bfdU,0xf9002bfbU,0xa90667faU,0xa9075ff8U,0xa90857f6U,0xa9094ff4U,0x910103fdU}},
 {0xc128af0ULL,{0xd101c3ffU,0xa9047bfdU,0xa90557f6U,0xa9064ff4U,0x910103fdU,0xd53bd056U,0xaa0203f4U,0xaa0003f3U}},
 {0xc129214ULL,{0xd10243ffU,0xa9037bfdU,0xa9046ffcU,0xa90567faU,0xa9065ff8U,0xa90757f6U,0xa9084ff4U,0x9100c3fdU}},
 {0xc129564ULL,{0xd101c3ffU,0xa9047bfdU,0xa90557f6U,0xa9064ff4U,0x910103fdU,0xd53bd056U,0xaa0203f4U,0xaa0003f3U}},
 {0xc12884cULL,{0xb8408d09U,0x71000529U,0x5400004bU,0xb9000109U,0xf9400668U,0xf940c100U,0xb4fff980U,0xb9000bfaU}},
 {0xc12964cULL,{0xb8408d09U,0x71000529U,0x5400004bU,0xb9000109U,0x12800008U,0xb9003a68U,0xf94016c8U,0xf85f83a9U}}
};
template<class Read>bool profileValid(Read& read,A base){
 for(const auto& p:profiles){uint32_t words[8]{};if(!read(base+p.offset,words,sizeof words)||std::memcmp(words,p.words,sizeof words))return false;}
 return true;
}
}
