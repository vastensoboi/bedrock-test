package dev.custom.bedrockgui;
import java.nio.*;
import java.util.*;

public final class AuctionMemoryProbeTest {
    private static void check(boolean v){if(!v)throw new AssertionError();}
    private static void q(byte[] b,int at,long value){ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).putLong(at,value);}
    public static void main(String[] args)throws Exception {
        long root=0x200000,base=0x10000000,player=root,client=root+0x2000,manager=root+0x4000,node=root+0x5000,model=root+0x6000,slots=root+0x8000;
        byte[] memory=new byte[0x20000];
        q(memory,0,base+0x139f6ea0L);q(memory,3240,client);q(memory,128,0xb400000000000000L|manager);
        q(memory,(int)(manager-root),base+0x137e8f20L);q(memory,(int)(manager-root+192),node);
        q(memory,(int)(node-root+40),model);q(memory,(int)(model-root),base+0x13d35930L);
        q(memory,(int)(model-root+216),slots);q(memory,(int)(model-root+224),slots+54*152);q(memory,(int)(model-root+232),slots+54*152);
        for(int i=0;i<54;i++)q(memory,(int)(slots-root+i*152),base+0x13d95ff8L);
        memory[(int)(slots-root+34)]=64;memory[(int)(slots-root+152+34)]=1;
        List<EngineMemoryProbe.Region> regions=Arrays.asList(new EngineMemoryProbe.Region(root,root+memory.length,0,true,true,"heap"));
        EngineMemoryProbe.Reader reader=(addr,out,size)->{System.arraycopy(memory,(int)(addr-root),out,0,size);return true;};
        List<String> logs=new ArrayList<>();
        String result=new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client);
        check(result.contains("slots=54")&&result.contains("nonEmpty=2")&&result.contains("0:64"));
        byte[] original=memory.clone();
        new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client);check(Arrays.equals(original,memory));
        q(memory,3240,client+8);check(!new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client).contains("slots=54"));q(memory,3240,client);
        q(memory,(int)(slots-root),0);check(!new AuctionMemoryProbe(regions,reader,base,logs::add).scan(player,client).contains("slots=54"));q(memory,(int)(slots-root),base+0x13d95ff8L);
        final int[] n={0};EngineMemoryProbe.Reader changing=(addr,out,size)->{
            if(addr==slots&&size==54*152&&n[0]++==1)memory[(int)(slots-root+34)]=63;
            return reader.read(addr,out,size);
        };
        check(!new AuctionMemoryProbe(regions,changing,base,logs::add).scan(player,client).contains("slots=54"));
        System.out.println("PASS: tagged manager, container/vector snapshot, read-only memory, changed player/vptr/contents rejection");
    }
}
