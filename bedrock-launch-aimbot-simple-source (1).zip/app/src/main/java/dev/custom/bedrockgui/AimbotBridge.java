package dev.custom.bedrockgui;
/** Sharp aim with shared range and optional rate-controlled native attacks. */
public final class AimbotBridge {
 private static volatile boolean ready,enabled;private static int radius=3,cps=15;
 private AimbotBridge(){}
 private static native String install(long base,long client);
 private static native void enable(boolean value);
 private static native void configure(int radius,int cps);
 private static native void pulse(boolean value);
 private static native String status();private static native String hudSnapshot();
 public static void prepare(long base,long client){try{if(!FastExpBridge.isReady())return;String error=install(base,client);if(!error.isEmpty())throw new IllegalStateException(error);configure(radius,cps);ready=true;GameRuntime.log("Aimbot: sharp aim and attack bridge prepared");}catch(RuntimeException|LinkageError e){ready=false;GameRuntime.log("Aimbot unavailable: "+e);}}
 public static boolean isReady(){return ready;}
 public static void setEnabled(boolean value){if(value&&!ready)throw new IllegalStateException("Нужен загруженный мир");if(ready){enable(value);pulse(value);}enabled=value;GameRuntime.log("Aimbot: enabled="+value);}
 public static void settings(int reach,int rate){radius=Math.max(1,Math.min(5,reach));cps=Math.max(1,Math.min(30,rate));if(ready)configure(radius,cps);}
 public static void heartbeat(){if(ready)pulse(enabled);}
 public static String targetSnapshot(){return ready?hudSnapshot():"";}
 public static String describe(){if(!ready)return "Подключение к миру ещё не готово";return (enabled?"Резкое наведение · "+radius+" блоков · "+cps+" CPS":"Выключен")+"\n"+status();}
}
