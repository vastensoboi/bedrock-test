package dev.custom.bedrockgui;

import android.content.*;
import android.os.*;
import java.io.*;

/** Loaded child-first from this app's APK; superclass comes only from game APK. */
public final class HostedGameActivity extends com.mojang.minecraftpe.MainActivity {
    private static boolean playGamesInitialized;
    private GameMenu gameMenu;
    @Override protected void attachBaseContext(Context base) {
        try { super.attachBaseContext(GameRuntime.attachResources(base)); }
        catch(IOException error){ GameRuntime.log("Resource attachment failed: "+error);throw new IllegalStateException(error); }
    }
    // Keep Context accessors inherited. Native PGS caches the getClassLoader
    // method ID on this Activity and invokes it on the Application as well.
    // Game loader/resources are supplied by the attached base Context instead.
    @Override public void onCreate(Bundle state) {
        GameRuntime.log("Activity: entering game onCreate");
        try {
            Class<?> owner = getClass().getMethod("getClassLoader").getDeclaringClass();
            android.app.Application application = getApplication();
            boolean compatible = owner.isInstance(application);
            boolean activityLoader = getClassLoader() == GameRuntime.loader;
            boolean applicationLoader = application.getClassLoader() == GameRuntime.loader;
            GameRuntime.log("Activity: JNI loader owner=" + owner.getName() +
                    " applicationCompatible=" + compatible + " activityLoader=" + activityLoader +
                    " applicationLoader=" + applicationLoader);
            if (!compatible || !activityLoader || !applicationLoader)
                throw new IllegalStateException("JNI Context class loader compatibility check failed");
            String gamePackage = "com.mojang.minecraftpe";
            android.content.pm.ActivityInfo original = getPackageManager().getActivityInfo(
                    new ComponentName(gamePackage, gamePackage + ".MainActivity"), 0);
            int originalTheme = original.getThemeResource();
            if (originalTheme == 0) throw new IllegalStateException("Minecraft Activity has no theme");
            GameRuntime.log("Activity: applying original game theme " +
                    getResources().getResourceName(originalTheme) + " / 0x" + Integer.toHexString(originalTheme));
            setTheme(originalTheme);
            if (!playGamesInitialized) {
                // Loading PlayGamesInitProvider's class does not run its onCreate.
                // Initialize the SDK's actual game-loader copy before native
                // startup requests an AchievementsClient from PlayGames.
                GameRuntime.log("Services: initializing PlayGamesSdk before game onCreate");
                Class<?> sdk = Class.forName("com.google.android.gms.games.PlayGamesSdk", true, GameRuntime.loader);
                sdk.getMethod("initialize", Context.class).invoke(null, application);
                playGamesInitialized = true;
                GameRuntime.log("Services: PlayGamesSdk.initialize returned");
            }
            GameFirebase.prepare(this);
            super.onCreate(state);
            GameRuntime.log("Activity: game onCreate returned (not a gameplay success check)");
            try {
                gameMenu = new GameMenu(this);
                GameRuntime.log("Menu: installed");
            } catch (RuntimeException | LinkageError menuError) {
                GameRuntime.log("Menu installation failed: " + menuError);
            }
        }catch(Exception|LinkageError error) {
            StringWriter trace=new StringWriter();error.printStackTrace(new PrintWriter(trace));
            GameRuntime.log("Activity onCreate failed\n"+trace);
            finish();
        }
    }
    @Override public void onResume(){super.onResume();FastExpBridge.foreground(true);GameRuntime.log("Activity: resumed");}
    @Override public void onPause(){FastExpBridge.foreground(false);super.onPause();}
    @Override public void onDestroy(){
        GameRuntime.log("Activity: destroying");
        if (gameMenu != null) {
            try { gameMenu.dispose(); }
            catch (RuntimeException | LinkageError error) { GameRuntime.log("Menu cleanup failed: " + error); }
        }
        try {super.onDestroy();}
        finally { new Handler(Looper.getMainLooper()).postDelayed(()->android.os.Process.killProcess(android.os.Process.myPid()),100); }
    }
}
