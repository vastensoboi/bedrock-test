import dev.custom.bedrockgui.GameLogOptions;
import java.io.File;
import java.nio.file.*;
import java.util.*;

public final class GameLogOptionsTest {
    private static void require(boolean value){if(!value)throw new AssertionError();}
    private static void rejected(File data)throws Exception {
        try{GameLogOptions.enable(data,null,null);throw new AssertionError("Expected IOException");}
        catch(java.io.IOException expected){}
    }
    public static void main(String[] args)throws Exception {
        Path root=Files.createTempDirectory("game-log-options");
        try {
            File data=root.resolve("app").toFile();
            GameLogOptions.enable(data,null,null);
            Path options=data.toPath().resolve("games/com.mojang/minecraftpe/options.txt");
            require(Files.readString(options).equals("content_log_file:1\n"));
            byte[] original="\ufeffgfx_field_of_view:71\r\ncontent_log_file:0\r\nfoo:x:y\r\ncontent_log_file:0".getBytes(java.nio.charset.StandardCharsets.UTF_8);
            Files.write(options,original);
            GameLogOptions.enable(data,null,null);
            Path backup=options.resolveSibling("options.txt.kulich-before-content-log");
            require(Arrays.equals(original,Files.readAllBytes(backup)));
            require(Files.readString(options).equals("\ufeffgfx_field_of_view:71\r\ncontent_log_file:1\r\nfoo:x:y\r\ncontent_log_file:1"));
            byte[] enabled=Files.readAllBytes(options);
            require(GameLogOptions.enable(data,null,null).contains("changed=0"));
            require(Arrays.equals(original,Files.readAllBytes(backup)));
            require(Arrays.equals(enabled,Files.readAllBytes(options)));
            // All existing profiles are updated; their unrelated values survive.
            File ext=root.resolve("external").toFile();
            Path extOptions=ext.toPath().resolve("games/com.mojang/minecraftpe/options.txt");
            Files.createDirectories(extOptions.getParent());Files.writeString(extOptions,"sensitivity:0.4");
            GameLogOptions.enable(data,null,new File[]{null,ext});
            require(Files.readString(extOptions).equals("sensitivity:0.4\ncontent_log_file:1\n"));
            Files.delete(options);Files.createSymbolicLink(options,extOptions);rejected(data);
            require(Files.readString(extOptions).startsWith("sensitivity:0.4"));
            Files.delete(options);Files.createDirectory(options);rejected(data);
            Files.delete(options);Files.writeString(options,"X".repeat(512*1024+1));rejected(data);
            System.out.println("PASS: fresh/existing log settings, unrelated values/BOM/CRLF, duplicate keys, immutable backup, idempotence, external profile, link/directory/size guards");
        } finally {
            try(var paths=Files.walk(root)){for(Path path:paths.sorted(Comparator.reverseOrder()).toList())Files.delete(path);}
        }
    }
}
