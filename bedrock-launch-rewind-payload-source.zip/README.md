# 0.76 — inspect correction payloads and the client rewind window

The 0.75 report contains 107 verified packet-161 receive events, including 32
while the configured Timer multiplier was x1.05. The user confirms ordinary
running works with Timer disabled. The recorded off interval itself was only
504 ms; packet counts alone do not reveal the server's private thresholds.
No verified Nevertime bypass has been found.

The present Timer scales local movement attributes, item-use progress and
swing animation. It does not generate extra input frames or change input
tick IDs. The server's independent movement simulation can therefore disagree
with that locally accelerated result. The official protocol explains the
input/correction/rewind sequence in its
[movement overview](https://mojang.github.io/bedrock-protocol-docs/guides/player-movement-overview/).
Those documents describe the protocol, not Nevertime's configuration.

Extend the existing observer to record packet-161 position, velocity, input
tick, ground state and Player/Vehicle context from the verified native layout.
Read vehicle-only rotation and optional angular velocity only when applicable.
Keep received-event counts when payload data are unavailable or change during
capture, and retain the last on/off payloads beyond ring overflow.

For Player context, also read the native replay window's first tick and count
through ReplayStateComponent. Classify an incoming tick as older, inside or
newer than the observed window. Report the native lower-bound eligibility
gate separately: that gate does not reject a future tick by its upper bound.
Zero tick follows the documented direct-processing convention and is not
labelled a malformed packet. Vehicle history is not inferred from the player.

All observations precede the unchanged original handler. An old packet's
position is not compared with the player's current position and called a
prediction error. No native history function is invoked, no new callback is
hooked, and packet/tick/movement values are unchanged. Exact evidence and
limits are in docs/movement-payload-0.76.md.

Validation: all 43 host suites, full Android35/Rhino Java17 typechecking,
strict host/ARM64-conditional native syntax, all 115 exact code profiles and
ASan/UBSan for the changed capture/history cores pass. The workspace has no
Android SDK/NDK APK build; the extended capture still needs a phone test.

Upload bedrock-launch-rewind-payload-source.zip to the repository root and
run Build latest launch test. Install BedrockLaunchTest-0.76. Use x1.05 for
one short comparison, then disable Timer and walk normally for about ten
seconds before opening Журнал and exporting the report. This is a concrete
consistency probe for the investigation, not a confirmed movement bypass.

## Earlier releases

# 0.75 — record incoming movement correction traffic

The supplied 0.74 report confirms that the startup loader regression is gone:
the game reaches a verified local player and runs for about 72 seconds before
the user opens diagnostics. Timer is enabled at x1.10 and records successful
ground-input writes. The user reports that running still returns the player
backwards. The current UID logcat is fresh but contains no matching movement
packet or anticheat reason, so those counters cannot identify the source.

Add a bounded native observer for the exact inbound movement packet handlers.
Observe CorrectPlayerMovePredictionPacket for the bound client and legacy
MovePlayerPacket only when its runtime ID matches the verified current local
player. Keep original packet handling, parameters and invocation count intact.
Record Timer-on/off context and recent events without interpreting every
incoming position update as an anticheat decision or an applied correction.
The optional observer reports installation failures without preventing Timer
preparation. Exact native evidence and limitations are documented in
docs/movement-correction-trace-0.75.md.

Opening the journal now takes a fresh Timer/observer snapshot automatically,
including short tests that end before the periodic status sample. Existing
module state, movement inputs, collision handling and loader-family fix are
preserved. This release adds evidence; it does not establish a movement bypass
or suppress server corrections.

Validation: all 42 host suites, full Android35/Rhino Java17 typechecking and
strict native syntax checks pass. All 97 exact code profiles and eight
observer route bindings match the supplied library. The new native core also
passes ASan/UBSan. The supplied 0.74 device report confirms the preceding
startup fix; this new native observer still requires a phone test. No Android
SDK/NDK APK build is available in this workspace.

Upload bedrock-launch-movement-correction-trace-source.zip to the repository
root and run Build latest launch test. Install BedrockLaunchTest-0.75 and
enable the same x1.10 setting. After the rollback, disable Timer, walk briefly
without it and open kulich -> Журнал to export the 0.75 report. Observation
starts when the bridge is prepared, so an initial walk before first enabling
a module does not constitute a recorded baseline. No extra recorder setup
is needed.

## Earlier releases

# 0.74 — fix the 0.73 startup class-loader regression

Fix the startup crash shown in the supplied 0.73 report: Android cannot find
`com.mojang.minecraftpe.MainActivity` through its host-only loader while
resolving the new HostedGameActivity method-reference dependency. The game
Activity itself is child-loaded, but the old exact-name rule delegated its
D8-generated companion to the parent.

Load HostedGameActivity and NativeStartup companions through the same game
loader as their owners. Match only their `$` families; retain parent loading
for shared runtime/capture helpers and preserve the compile-only game-stub
packaging check. Keep the 0.73 recorder recovery and final Timer samples.
Details and the exact failure evidence are in docs/startup-loader-0.74.md.

Validation: all 41 host suites pass. A separated-loader regression reproduces
the old generated-callback failure and runs the same fixture with the fixed
rule; shared capture state retains parent identity. Full Android35/Rhino
Java17 typechecking passes. Native code is unchanged from 0.72. There is no
Android SDK/NDK APK build or ART/device test in this workspace.

Upload bedrock-launch-startup-loader-fix-source.zip to the repository root
and run Build latest launch test. Install BedrockLaunchTest-0.74 and check
startup first. Export the 0.74 journal if it still exits. This fixes the
reported loader regression; it does not establish a Timer anticheat bypass.

## Earlier releases

# 0.73 — recover diagnostic capture after returning to the game

The 0.72 report confirms successful Timer writes at x1.05 as well as earlier
x1.15/x2.00 tests. It does not contain a current server correction or an
anticheat check identifier. Its UID logcat recorder stopped on return from a
pause of more than two hours, about 27 seconds before the later Timer test.
The old recorder had a finite 20-minute session and no resume recovery.

Recover stopped or expired capture on HostedGameActivity resume without
erasing recent logs. Bound retries to the first ten seconds of foreground
resume, cancelling pending retries when paused. Keep the 20-minute session
limit, two 2-MiB log segments, existing UID filter and existing permissions.
One kernel file lock protects capture ownership between launcher and game
processes; local contention is rejected before opening another descriptor.
The helper classes remain parent-loaded. Stale reader or timeout cleanup
cannot overwrite a replacement session's status or release its ownership.
An expired session now reports its actual time limit explicitly.

Log multiplier changes and capture a final native Timer sample before
disabling it, so short tests do not end before the periodic status sample.
The movement implementation and collision path are unchanged from 0.72.

The report also contains fresh VoxelShape registry errors before the x1.05
test. Similar messages are present in reports as early as 0.34, before Timer
existed. They are a separate unresolved content/collision issue; the report
does not establish that they caused a position rollback. Detailed timestamps,
evidence and limits are recorded in docs/timer-journal-0.72.md.

Validation: all 40 host gameplay/capture suites pass. The capture test uses
contending recorders and a separate JVM, simulates return after expiry, EOF,
stale readers and timeouts, and checks retained bounded logs, explicit status,
failed-start lock release and fresh-launch reset. Full Android35/Rhino Java17
typechecking passes. Native code is unchanged from the validated 0.72 release.
There is no Android SDK/NDK APK build or phone lifecycle test in this workspace.

Upload bedrock-launch-capture-resume-source.zip to the repository root and run
Build latest launch test. Install BedrockLaunchTest-0.73. After a rollback,
disable Timer and export the 0.73 journal promptly. A new recovery marker
and the final Timer sample distinguish current evidence from an old capture.
This release improves diagnosis and does not establish an anticheat bypass.

## Earlier releases

# 0.72 — correct the player's Timer movement input

Fix the ground and water acceleration input introduced in 0.71. The native
player branch reads MovementAttributesComponent; the previously modified
MovementSpeedComponent is only its nonplayer fallback. A successful write to
that fallback could therefore leave the player's movement unchanged.

Ground now scales the verified local player's present land-speed attribute.
Water scales its present land and water attributes, preserving the native
selection or interpolation. Keep optional-presence flags intact and restore
each same live unchanged input separately. Each original callback runs once;
native travel output, collision processing and remote actors retain their
existing paths. Air, item-use and swing acceleration retain the 0.71 behavior.
The optional Timer screen shortcut now displays the requested multiplier.
Exact selector, layout and call-site evidence is documented in
docs/local-timer-movement-0.72.md. That document corrects the 0.71 input claim.

The two submitted video attachments are identical short recordings. They
show Timer toggling but do not expose its multiplier or native counters.
They do not establish whether acceleration was applied or a server corrected
the resulting movement. This release fixes the independently verified input
error; it does not establish a Nevertime anticheat bypass.

Validation: all 39 host gameplay suites pass, including a regression that
models the actual player/nonplayer speed selector with different inputs.
Strict native C++ syntax, the ARM64 conditional Timer path, all 86 exact code
profiles and full Android35/Rhino Java17 typechecking pass. The changed native
movement core also passes ASan/UBSan and independent review. There is no
Android SDK/NDK APK build or phone test in this workspace.

Upload bedrock-launch-timer-movement-fix-source.zip to the repository root
and run Build latest launch test. Install BedrockLaunchTest-0.72. Compare
Timer off against x1.50 in a world or server without movement validation
first, then compare the target server separately. Save the 0.72 journal with
the Timer status after testing. The multiplier remains x1.00–x2.00 in steps
of 0.05, default x1.10; the module remains disabled by default.

## Earlier releases

# 0.71 — local movement, item-use and swing acceleration

Add Вспомогательные функции -> Timer, disabled by default, with a saved
multiplier from x1.00 to x2.00 in steps of 0.05 (default x1.10). Prepare it in a
loaded world, retain its requested state across menus and provide an optional
screen shortcut, on-demand status and journal counters. This changes selected
local-player movement/control, use-duration and swing-animation paths. It is
not a change to world TPS or a complete per-player physics simulation clock:
gravity/fall timing, server time and other modules' wall-clock CPS stay intact.

Ground and water travel temporarily read a boosted MovementSpeedComponent
only for the verified current local player. Restore that input only while the
same entity/component still owns the injected value. Air control keeps the
native freshly generated MobTravel speed output, scales it once for the local
player and preserves collision/friction processing. Remote actors' inputs and
outputs are not changed, and every original callback still runs once.

The native ItemUseTickDurationSystem has two mutually exclusive local phases.
Advance only the current player's remaining-use counter by fractional extra
ticks, reserving the last tick for the engine's normal transition to zero and
item-use completion. Excluded phases/foreign-entity callbacks preserve the
fractional cadence, so x1.10 does not silently reset to x1.00. Own swing-cycle
progress uses the same requested multiplier, retaining the native duration,
interpolation and natural end. It emits no extra attacks or automatic clicks.

Install ten verified callback entries with exact profiles and read-only
mapping checks. Preserve allocation tags, reject stale/nonlocal bindings and
use a heartbeat lease, thread-local nesting guard and configuration epochs.
The global VariableTickRateComponent is deliberately untouched. Native route
and counters are documented in docs/local-timer-0.71.md.

The user reports rubberband corrections with another client's Timer on
Nevertime. This implementation does not establish an anticheat bypass or
server acceptance of faster movement, food use or other actions. Server
corrections remain possible. No Nevertime-specific preset or success claim is
included. Device video and the 0.71 journal are still needed for that behavior.

Validation: all 39 host gameplay suites pass, including local-only movement,
fractional item-use progress with interleaved excluded phases and local swing
progress. Strict C++ syntax including AArch64-only calls, all 77 exact native
code profiles, full Android35/Rhino Java17 typecheck and the three new native
ASan/UBSan suites pass. There is no Android SDK/NDK APK build or device test in
this workspace.

Upload bedrock-launch-local-timer-source.zip to the repository root and run
Build latest launch test. Install BedrockLaunchTest-0.71, enter a world and
enable Timer at a small multiplier for the first comparison. Save its status,
the version0.71 journal and a video if the server corrects movement.

## Earlier releases

# 0.70 — held-block state fix and observed client pearl trails

Fix the held-block classifier that stopped Block Trap before target selection.
The 0.69 journal records reason=3 with heldReason=0: reading the selected stack
and its native block reference succeeded, but the next classifier refused it.
The old callback at 0x10777338 returns a BlockType pointer, not a Block state.
Use the item renderer's state getter at 0x107772cc instead. Validate its Item
virtual +80 predicate as well as virtual +56, and verify the default-state
accessor at 0x10919948. The existing Block+104 type reader and conservative
support checks remain valid. Keep selected-slot, count, friend, collision,
visible-face and Survival-mode checks; no camera or hotbar selection is changed.

Add an independent read-only path for visible client pearl actors. The 0.69
journal now retains continuous counters: after 1632 processed frames, the
ProjectileComponent scan had observed zero candidates in total. This is more
specific evidence than an empty three-second journal sample. The exact native
Throwable motion path supports a missing ProjectileComponent and still writes
StateVector motion, so a rendered pearl need not have the simulation component
required by the old prediction path.

Find exact ThrownEnderpearl actors through bounded owner-page discovery and
revalidate type, registry, full entity generation, owner and StateVector before
every observation. Keep a bounded history of their actual positions. These
records are drawn and labelled as observed pearl trails, not as predicted
future positions. They carry no fabricated gravity, drag, landing point or
landing time. Unknown owners remain unclassified. Reset history on a new world
or reused identity and expire old trails. The existing future-trajectory path
still uses real ProjectileComponent physics and a known terrain hit when those
data are available. The two record types do not duplicate the same pearl.

The native/Java feed carries observed trails as separate T rows. Preserve
camera projection and the labelled top-down fallback, bounded parsing and
clipped drawing. The module status distinguishes observed trails from future
predictions; new journal counters report owner-page discovery and client actor
observations. Details and exact native evidence are in docs/0.70-fixes.md.

Validation: all 36 host gameplay suites, full Android35/Rhino Java17 typecheck
and strict C++ syntax including AArch64-only call paths pass. All 62 native
code profiles match the supplied exact ARM64 library. Changed pearl and block
guards also pass ASan/UBSan. No Android SDK/NDK APK build or
on-device gameplay test is available here. This release corrects a proven
BlockType/Block mismatch and supports an evidenced optional-component path;
actual server placement and client pearl discovery still need phone testing.

Upload bedrock-launch-client-pearls-trap-fix-source.zip to the repository root
and run Build latest launch test. Install BedrockLaunchTest-0.70, select
obsidian in a loaded world and enable Block Trap. Enable Pearl Prediction and
throw a pearl to check its observed trail. Save the version 0.70 journal after
testing; it distinguishes placement stages, observed trails and predictive
physics data.

## Earlier releases

# 0.69 — first Block Trap placement and retained pearl-flight evidence

Add Вспомогательные функции -> Block Trap with an actual native placement
route. Select an ordinary solid block in the hotbar and keep it in the main
hand; obsidian is a good first test. There is no automatic slot switching.
Choose a target radius from 2.0 to 5.0 blocks and an interval from 2 to 10 game
ticks (defaults: 4.0 blocks and 3 ticks). The module chooses the nearest eligible
player, retains that target while valid and reuses the saved friend policy.
Opening kulich or the HUD editor retains the requested toggle.

Build a bounded plan of cardinal walls and a roof around the target. Before
one placement attempt, require an empty destination, a supported ordinary cube
anchor, a reachable visible support face and no intersection with any observed
player. Recheck the selected stack/count, current player generations, target,
friend decision and block state immediately before acting. Unknown supports,
containers, slabs, plants and fluids are skipped. Blocks in the held item and
support are conservatively restricted to verified ordinary BlockType classes;
this first version does not support every placeable item or terrain type.

Use the game's selected-mainhand useItemOn API with the explicit support cell,
face and world-space face centre. Preserve allocation tags and Survival-mode
gates. No view rotation, inventory selection or arbitrary packet payload is
written. Native acceptance is separate from observing the intended block in
the client world, and neither establishes a server acknowledgement. Poll the
pending cell before another accepted placement and expose the result counters
through Статус Block Trap and the journal. Actual server behavior remains to
be checked on the phone.

The supplied 0.68 journal shows the static-item render override executing:
172733 draws, 168581 flat non-block draws, 4152 block draws and zero flat
rejections. Pearl processing records 612 frames without read failures, budget
stops or rejected frames; the sampled frames are empty. Because journal
snapshots are three seconds apart, they cannot establish whether a short
flight occurred between samples. Add cumulative candidate/type/valid counts,
peak counts and last seen/published-flight ages and reasons. Empty frames no
longer erase that evidence. Do not invent a different projectile layout or
claim an unobserved runtime fix.

Validation: all 36 host gameplay suites pass, including the three new trap,
placement and block-query suites. The full Android35/Rhino Java17 typecheck
also passes. All native C++ translation units pass strict syntax checks,
including AArch64-only calls; 56 exact native code profiles and the relevant
virtual-table relocations match the supplied ARM64 binary. The three new
native suites pass ASan/UBSan. No Android SDK/NDK APK build or device gameplay
test is available here.

Upload bedrock-launch-block-trap-source.zip to the repository root and run
Build latest launch test. Install BedrockLaunchTest-0.69, enter a world, select
obsidian and enable Block Trap. Save the version 0.69 journal after testing;
it includes placement results and retained pearl-flight evidence.

## Earlier releases

# 0.68 — readable resized HUD, flat items and pearl scan fixes

Fit every HUD's fully measured content into its saved viewport with a uniform
View scale. Staff names, effect timers, module labels, target details and
shortcut text scale together, including all rows. Use actual content height
instead of preserving empty frame space; reserve a separate caption strip in
the editor. Android's child View transform keeps shortcut touch coordinates
mapped to the drawn button. Staff, buffs, active modules and target cards now
have a rounded 60%-opaque black background with neutral text shadows.

Create module shortcut widgets only after the user enables Кнопка на экране.
Previously registered shortcuts remain hidden in the editor when disabled;
there are no automatic Fast Exp, No Slow or other shortcut placeholders.
Keep the normal HUD panels available in the editor and preserve saved choices,
positions, sizes and active gameplay modules.

Make non-block dropped items lie flat with a scoped model-matrix rotation,
alongside the existing bob/spin flag. The exact ActorRenderData+16 translation
is the pivot, preserving the item's rendered position while rotating its face
normal upward. The native ItemStack block getter leaves 3D block models intact.
Restore only the same live matrix slot when the renderer left the injected
value unchanged; preserve MTE allocation tags and mark the stack dirty. No
actor position, velocity, ground-height assumption or pickup timer is changed.

Pearl scanning now walks active ProjectileComponent IDs rather than every
player, mob and dropped item. This removes a verified path that could exhaust
the shared 6 ms frame budget before publishing a trajectory on a busy world.
The exact pearl class and physics layout were rechecked against the supplied
ARM64 binary. The absent phone journal means this is not confirmed as the only
cause of the user's missing trajectory. Add granular scan/read/budget counters,
readable waiting/error states and an on-demand Статус Pearl Prediction button.
The bridge requires the shared Fast Exp tick, independent of Aimbot readiness.
Malformed individual pearl rows no longer discard valid other pearls. Clip
projected paths before drawing and keep their labels inside the screen.

Validation: all 33 host gameplay suites, full Android35/Rhino Java17 typecheck,
strict C++ syntax including the AArch64-only call paths, and 49 exact native
code profiles pass. Changed pearl/static-item native tests also pass ASan and
UBSan. There is no Android SDK/NDK APK build or device visual test available
here. Flat item appearance, HUD touch/visual behavior and pearl prediction must
still be checked on the phone; landing times remain approximate.

Upload bedrock-launch-hud-pearl-fix-source.zip to the repository root, run
Build latest launch test and install BedrockLaunchTest-0.68. Enable the modules
inside a loaded world. For pearl failures, press Статус Pearl Prediction and
save the version 0.68 journal.

## Earlier releases

# 0.67 — pearl prediction and static dropped-item rendering

Add Вспомогательные функции -> Pearl Prediction. Display passive transparent
trajectories for loaded in-flight ender pearls from the local player and other
players. Read the exact pearl actor/ECS state, projectile owner, gravity and
current air/liquid drag; simulate native position, drag and gravity order. A
verified render camera supplies its origin, FOV, aspect and view transform,
including camera roll/bob, rather than guessing a screen FOV. Reject stale or
recycled entities and snapshots. Unknown owners remain unclassified.

Use the game's verified terrain segment trace on the game thread to estimate
impact and remaining flight time. The ETA is approximate and displayed only
when a block hit is established. It is not a promise of a server teleport or
an entity collision; unloaded terrain and future water transitions can change
the flight. Read-only prediction does not move pearls or other actors. Bounded
actor/ray work and a heartbeat lease limit processing; unavailable collision
evidence remains unknown instead of inventing a ground plane.

Add Вспомогательные функции -> No Item Physics. This is a presentation toggle:
remove dropped items' native bob/spin while retaining falling, motion and pickup.
Temporarily set the renderer's fixed-pose flag only around its original draw,
then restore it only if the same actor still owns the value. Require the exact
ItemActor type and a live registry owner, so held and stale objects are rejected.
Do not overwrite position, velocity, pickup timers or age. Both new modules are
disabled by default, have independent heartbeats/status and work through the
existing screen-shortcut/HUD editor. Opening menus does not disable them.

Validation: all32 host gameplay suites and the full Android35/Rhino Java17
typecheck pass. All native C++ translation units pass strict syntax checks;
43 native code profiles match the supplied exact ARM64 library. No Android SDK/NDK build or phone
runtime test is available in this workspace; real visual alignment, dropped-item
appearance and landing predictions still need on-device checking.

Upload bedrock-launch-pearl-static-items-source.zip to the repository root and
run Build latest launch test. Install BedrockLaunchTest-0.67, enter a world and
enable the two modules under Вспомогательные функции. If anything fails, save
the version0.67 journal from the launcher.

## Earlier releases

# 0.66 — transparent HUD and No Slow item-use movement

Remove the normal target/staff/effect/active-module card fills, cyan borders
and card elevation shadows. Keep a fully transparent background and neutral
white text with a small glyph shadow for legibility; preserve HP bar/heart,
avatar and server name formatting. HUD editor outlines and configuration-menu
controls remain separate. No tests added for the reversible colour change;
full Android Java typecheck covers the modified views.

Add Вспомогательные функции -> No Slow with a real native toggle, status,
independent heartbeat, screen shortcut and active-module HUD integration.
Prepare the bridge through the existing engine probe without enabling Aimbot;
wait for a world if necessary. Disabled by default; menu/editor/focus changes
retain the requested toggle. Dispose disables the module.

Exact native evidence: ItemUseSlowdownModifierComponent hash0x867fc92c is a
float payloadstride4. ItemUseSlowdownApplySystem's StrictTickingSystem adapter
vptr13aca618 has bulk callbackslot6/+48=c127284 and singlecallbackslot7/+56=
c127a54. Bulk inlines the apply operation and never delegates toslot7, so both
callbacks are wrapped. Each squares the modifier and multiplies MoveInput
floats+36/+40; MoveInput key018b1887,stride100. The original also clears one
VanillaClientGameplay word (keya406686e,stride80); leave that logic intact.

When enabled with fresh1200ms lease, validate adapter type/registry, current
client weaklocalentity, LocalPlayer owner/vptr/client/components and finite
modifier0..1. Temporarily set only its tagged float payload to1.0, call the
original callback exactly once, then restore if the same live component still
belongs to the same actor/entity and the engine left the factor at1.0. Preserve
engine changes and reject unknown/stale/nonlocal contexts. Singlecallback's
thirdarg is a pointerto uint32EntityID; bulk affects only the checked local
component. First uninitialized adapter invocation passes through unchanged.
No use-state flags, timers, bow charge, food consumption or potion effects are
modified. The narrow input multiplier is verified; preserving actual sprint
and server acceptance still requires on-phone testing.

Install only after five exact code profiles and expected callback addresses
match. Require the read-only nonexecuting game table mapping, change only two
vtable pointers on one page, restore page protection; no executable code patch.
Wrappers use branch protection and original callbacks remain callable while off.
Journal records bulk/singlecalls, modified/rejected and the exact route.

Validation:27 gameplay suites pass, including scoped normal/full input,
restoration, disabled/nonlocal/wrong registry/tagged payload, failed writes,
engine-changed value and exception restoration. Strict C++ syntax, full
Android35/Rhino Java typecheck and ASan/UBSan NoSlow model pass. The five new
native code profiles match the supplied library. APK linking, on-device visuals,
eating/bow behaviour and server movement remain unverified.

Upload bedrock-launch-transparent-noslow-source.zip to repository root and run
Build latest launch test. Install BedrockLaunchTest-0.66; enter a world and
enable Вспомогательные функции -> No Slow. Compare movement while holding food
use/bow draw with it off/on, and save0.66journal if it still slows or fails.

## Earlier releases

# HUD 0.65 — editor, module shortcuts, Staff List and Buff Timer

Add Кастомизация -> Менюшка. Enable/disable the Target HUD, active-function
list, Staff List and Buff Timer independently; open Редактировать HUD to drag
panels and resize at the lower corner. A cyan editor border and explicit
Пример label mark inactive previews. Background/Готово exits and reopens the
menu. Save normalized positions and DP sizes per widget, clamp to viewport and
preserve layout across rotation. Dropdown width/height controls and reset are
also available. Gameplay module heartbeats continue during editing. The editor
shade is above existing floating controls and below widgets/Done.

Every implemented module now has Кнопка на экране. It creates a saved HUD
shortcut that toggles the actual registered handler and shows its requested
state. Edit its location/size in the same editor. The active-function panel
lists actual enabled registered modules; unsupported catalog entries are never
shown as working. Synchronize Fast Exp's real enabled state for automatic start
and shortcut toggling. Existing menu/friend controls and combat settings remain.

Staff List takes up to128 case-insensitive exact ASCII nicknames, persisted in
Менюшка. Global roster reading uses the RTTI-verified Level type0x13e0a0f8:
Level getter10b16318 reads the UUID roster map pointer at+1192; its lookup
10ad97f4 returns the native name at hashnode+80 (success10ad98ac). Discover a
direct Level reference from the already checked player/client object fields,
validate exact type, bounded map size/chain/count, recheck headers and require
the current raw player name in the roster to bind it to the session. Conflicting
candidates fail closed. This can find configured staff outside loaded Actor
range. On unsupported/unavailable global data, use loaded-player evidence only
and label matches рядом plus Полный список игроков недоступен; do not claim
missing nearby staff are offline. A fresh global roster may say nobody listed
is online. Hidden/not-transmitted server roster members cannot be inferred.

Buff Timer reads the local MobEffectsComponent key0xe6a1b550, payloadstride24,
vector entries160 bytes. Exact getters prove effectid+0, durationticks+4,
amplifier+32; native tick leaves-1infinite. Read-only bounded vector/header
validation, unknown versus known empty, no guessed effects. Show localized
names, level and real remaining time, ∞for infinite, include negative effects.
Refresh native feeds every500ms with1200ms heartbeat lease. Java uses monotonic
capture age and rejects stale>3s data; unknown reads are explicitly unavailable.
The six additional native code profiles match the supplied exact library.

Validation:26 gameplay suites pass, including HUD bounds/resize/rotation,
configured staff/global-vs-nearby confidence, far-away roster entries/removal,
session membership/corrupt/cycle/concurrent guards, local effects/infinite/
amplifier/empty/header validation and timer age/expiry, plus prior regressions.
Full Android35/Rhino Java typecheck and strict C++ syntax pass; new native
roster/effect tests pass ASan/UBSan. All20 native profiles match. Full APK
linking, touchscreen rendering and server runtime data remain unverified.
The unresolved server target-HP work from0.64 is preserved without new claims.

Upload bedrock-launch-hud-editor-staff-buffs-source.zip to repository root;
run Build latest launch test and install BedrockLaunchTest-0.65. Open
Кастомизация -> Менюшка, enter staff names one per line and save; enable the
panels, then edit positions/sizes. For a module shortcut open that module and
enable Кнопка на экране. Runtime journal reports roster global/nearby/unavailable
and effect availability on feed-state changes.

## Earlier releases

# Aimbot 0.64 — mobile friend picking and honest HP confidence

Add Target -> Friends -> Добавление через прицел (off by default). When on,
a draggable round Friend+ button appears with a preview of the raw player
nickname under the current camera ray. Point at the player and tap to toggle
friend membership, including removal on a second deliberate tap. Preserve all
16 nickname characters over two lines if needed. The press captures its preview;
a fresh native pick must still match, otherwise show a target-changed message
and make no change. Existing command console remains, Minecraft chat commands
are not hooked. Normal game controls are not intercepted or remapped.

Prepare the bridge on a throttled worker without enabling Aimbot. A separate
post-player-update callback scans validated RemotePlayers intersected by the
active camera ray, selects the closest box entry, rejects ambiguous overlapping
entries, revalidates identity and returns the raw name. This uses entity boxes,
not the game's terrain HitResult: terrain occlusion is not established, hence
the preview is shown before any add/remove. Scan max4096 owner slots,6-block
ray,5ms/read budget; cache is at most150ms old. Pick mode has a1200ms heartbeat
lease independent of the Aimbot toggle and is disabled on cleanup. No attack
or native keyboard function is called for friend selection.

The user's real HP3/24 is a value above opponents' heads. Remote attributes
remaining24/24 are not a trusted source of current server health. The native
health getter layout was correct; below-name scoreboard health is a different
source, and its reliable Level/player association is not yet established.
Do not ship guessed offsets, subtract damage from clicks, or claim HP fixed.
When no explicit health text is provided in metadata, render?/24 (unknown
current HP), hide the health bar and say server HP was not received. Keep max
when available. Parse explicit health pairs surrounded by custom private-use
font glyphs or brackets as well as existing heart formats.

Add bounded native HP evidence to the journal: actual client attribute values
clearly marked non-authoritative plus typed metadata0..127, prioritizing4/84.
Validate exact small type getters, strings as UTF8hex≤384bytes and primitive
payloads as uninterpreted raw8 bytes;≤16 each,≤2048 total. Recheck metadata
vector identity. Capture on the game callback at most every3s for the current
validated target; include it in normal Aimbot journal diagnostics. Invisible
rendering does not exclude a player or text from these readers, but true HP
still depends on what the server transmits. The new journal is needed to identify
the actual below-name health source on this server.

Validation:21 gameplay suites, including fresh crosshair decoding/expiry,
nearest-ray/off-axis/behind/range/ambiguous picks, bounded metadata evidence,
customfont3/24 and unknown-client24/24 regressions. Full Android35/Rhino Java
and strict native C++ syntax checks pass. New native pick/evidence models pass
ASan/UBSan. APK linking and on-phone UI/game behaviour are unverified.

Upload bedrock-launch-mobile-friends-health-source.zip to repository root and
run Build latest launch test. Install BedrockLaunchTest-0.64; enable crosshair
friend mode, close kulich, check the preview and tap Friend+. For unresolved
server HP, fight with Aimbot for at least10seconds while real health above the
opponent changes, then save/send the0.64 journal. True3/24 HP (including during
invisibility) must not be claimed available before that source is connected.

## Earlier releases

# Aimbot 0.63 — decimal tracking/attack distances and display-alias friend veto

Split the former shared radius into two persisted controls: tracking/acquisition
and autoattack distance, each1.0–6.0 in0.1-block steps. Examples3.7 and3.9 are
preserved as integer tenths through Java/JNI and converted once natively. The
attack control cannot exceed tracking: raising it raises tracking; lowering
tracking clamps attack. Migrate old aim.radius*10 into both defaults. Store
new keys aim.rangeTenths / aim.attackTenths. CPS controls remain unchanged.

Track/retain/revalidate within the first radius; test the actual view ray
against the second before consuming cadence or dispatching. State3 distinguishes
a tracked target outside attack distance from a view miss (state4). Repeat the
fresh target-box distance test before each swing/attack in a two-attempt tick.
The bounded ray helper accepts at most6.0, and rejects larger or invalid reach.
Client configuration does not guarantee server hits or damage.

0.62 checked friend names only against raw Player+b28. A displayed server alias
can differ, so adding that alias did not veto an otherwise valid raw account.
Add a second FRIEND-only veto against targetDisplayName (metadata4 or verified
native formatted fallback; excludes score line). Strip Minecraft UTF-8 format
codes and compare complete case-insensitive ASCII tokens. Exclude bracketed
rank text and numeric health tokens; Ann never matches Anna or part of a Unicode
word. Rawfriend ORdisplayfriend blocks acquisition/retention/each attack. A
heuristic display name never grants enemy status to an unknown raw identity.
No device report was supplied, so this is a concrete covered failure case, not
proof that it explains the user's exact observation.

Native friend configuration now acknowledges its accepted count. The bridge
checks it against the saved list and the Friends menu shows whether protection
has connected and how many names the native module accepted. Re-submitting an
existing add/remove also resynchronizes the list. Bridge config/enable calls
serialize with installation; a failed sync clears readiness and disables
Aimbot. Commands still run in kulich -> Таргет -> Друзья; Minecraft chat is not
intercepted. Manual attacks remain outside this automatic-target filter.

Retain0.62 HP/name rendering and parsing. Journal phase=camera-input-v11 includes aimRange andattackRange to one
decimal. Existing game code profiles, friend checks, target identity and lease
guards remain active.

Validation:18 gameplay suites pass, including separate3.9 tracking/2.0 attack,
3.7/3.9 threshold changes,6.0 reach/rejection above limit, display/internal name
differences, case/substring/Unicode/rank/HP boundaries and previous regressions.
Full Android35/Rhino Java typecheck, strict native C++ syntax and ASan/UBSan
new distance/friend tests pass. APK linking and on-phone behaviour remain
unverified.

Upload bedrock-launch-aimbot-distance-friends-source.zip to the repository root
and run Build latest launch test. Install BedrockLaunchTest-0.63; set tracking
and attack distances separately. In Friends run.add Nick, then check native
protection count after entering a world/enabling Aimbot.

## Earlier releases

# Aimbot 0.62 — friends and server-supplied Target HUD

Add Target -> Друзья: local command field, .add Nick / .remove Nick, feedback,
and saved list (128 names, ASCII letters/digits/underscore, 1–16 characters).
Compare complete raw player names case-insensitively, never substring-match
Ann with Anna or use rank/health text as an identity. SharedPreferences changes
are committed before publishing; bridge caches names before engine setup.
Commands are implemented in the kulich console. Minecraft chat is not hooked:
its safe submit callback is not established in the available sources.

Friend exclusion runs before acquisition ranking, when retaining/revalidating
a target, at attack preparation and again before each swing/attack attempt.
A closer friend is excluded so a valid enemy can still be selected. Updating
the list clears the current target/HUD/cadence under the native action mutex.
When the list is nonempty, missing/ambiguous raw names are excluded. Invalid
native list updates block targeting, and bridge failures disable Aimbot. Manual
player-controlled attacks are outside this Aimbot filter. Block Trap remains a
catalog entry and KillAura is not implemented.

Native Player identity getter101f05ec returns Player+b28. Formatted display
builder101f0704 uses optional prefix+b40/flag+b58, name+b28, suffix+b60/flag+b78.
Preserve custom/multiline metadata4; if it is empty or just the raw name, read
the native formatted fallback. The typed metadata84 getterfda528c provides
the score line: append nonempty explicit text for HUD parsing. All libc++
strings are bounded to384 bytes, short/long allocation tags preserved for reads,
and changing/malformed headers rejected. Three accessor code profiles pin
these layouts to the existing exact Minecraft build.

The HUD preserves complete multiline server name/rank and renders Minecraft
colours and bold/italic formatting. Explicit health text such as7/18 or7❤/18
has priority over stale remote attributes18/18. Parse heart-marked single values
and labelled/decimal forms too. If both nametag and appended score line provide
pairs, use the last explicit pair. Never infer damage from attack counts. When
there is no explicit health text, label the fallback HP клиента; no server HP
or privileges are invented. Show current/max and hide a bar with unknown max.
Journal phase=camera-input-v10 records friend count, list validity and exclusions.

Validation:17 gameplay suites include full HUD parsing, stale18/18 versus7/18,
metadata84, formatted/raw fallback, exact/case-insensitive names, unknown-name
exclusion, mixed friend/enemy acquisition, list changes/restoration/limits,
malformed/tagged strings and all previous native/auction/XP/cadence guards.
Full Android35/Rhino Java typecheck and native C++ syntax checks pass; new
native models pass ASan/UBSan. All14 exact native code profiles match the
supplied library. APK linking and on-phone/server behaviour are unverified.

Upload bedrock-launch-friends-hud-source.zip to repository root; run Build latest
launch test and install BedrockLaunchTest-0.62. Open kulich -> Таргет -> Друзья
and run .add Nick (without the rank) or .remove Nick. The list survives normal
app restarts. Test a friend and an enemy together before relying on the filter.

## Earlier releases

# Aimbot 0.61 — stable torso tracking and fixed/ranged CPS

Add one two-thumb CPS control (1–40), matching the supplied range-control
reference. Left thumb sets minimum, right sets maximum. Equal endpoints are a
fixed requested rate, shown as e.g. “20 · фикс.”. Coincident thumbs separate by
drag direction, including endpoints. Store aim.cps.min/max; migrate legacy
aim.cps as a fixed rate. Colours follow the active kulich theme. Keyboard and
accessibility actions can adjust either endpoint. Radius remains 1–5 blocks.

Native configure now receives radius/min/max. Fixed mode uses fractional
periods; range mode samples an integer rate between endpoints for each next
interval. At most two attempts run per local-player update, excessive backlog
is discarded, and displayed actual CPS counts actual attack dispatches in the
last second. A selected fixed rate is a requested attempt frequency while a
valid target is in the camera ray, not a guarantee of server hits or independent
sword animations. Above 20 CPS some attempts share a 20 Hz update.

Reduce aim-induced camera shake by retaining the validated current target
until it dies, leaves range, or fails identity checks. Remove periodic nearest
switching between nearby players. Keep sharp initial acquisition, but stop
recentering to the exact chest centre while the view ray remains inside a
small inner torso region. Wider retained bounds provide hysteresis. At
horizontal centre gaps under .35 blocks preserve yaw; resume normal tracking
past .45 blocks to avoid atan2 flips as bodies cross. An exactly coincident
eye/chest keeps the validated view rather than dropping the target. Hold state
resets on identity changes, enable/install, expiry, and loss/reacquisition.
Attack still requires the fresh full-box ray and all existing native guards.
No guessed camera-origin field or animation-state writes are introduced.
Journal phase=camera-input-v9 adds cpsMin/cpsMax, aimHold and contact. The HUD
shows actual CPS alongside the selected fixed/range setting; its eight-field
snapshot accepts earlier three/seven-field models as well.

Validation: fourteen gameplay suites, including fixed rates 1–40 at 20 Hz,
interval bounds and normalization, pauses/backlog, torso/eye jitter simulation,
sharp acquisition, moving target and entity reset, contact hysteresis, exact
overlap and HUD range parsing. Full Java typecheck against Android35/Rhino,
C++ syntax (-Wall -Wextra -Werror) and ASan/UBSan new model tests pass. These
checks do not establish on-phone rendering, touch, server behaviour or absence
of all camera shake. Normal movement/damage animation is not altered.

Upload bedrock-launch-aimbot-stable-cps-source.zip to the repository root;
run Build latest launch test and install BedrockLaunchTest-0.61. In Target ->
Aimbot, move both CPS circles to the same value for fixed frequency, or apart
for a range such as 6–17. Preserve Auto Buy and Fast Exp behaviour.

## Earlier releases

# Aimbot 0.60 — simplified sharp aim, reference-style HUD, swing and CPS 1–30

Match the 1.39-second supplied reference visually: compact dark rounded card
near screen centre-right, neutral pixel head icon, single-line rank/name, HP
number with red heart and green health bar. The avatar is a neutral icon, not
an extracted player skin. Add a small live attack-state / actual-configured CPS
line to explain pauses. No unconfirmed kill notification is generated: the user's
clarification concerned intermittent CPS and missing sword animation.

Remove the old mode/priority/head-body/speed/smoothing/auto-attack controls from
Aimbot. Keep enable plus shared distance 1–5 blocks and CPS 1–30. It sharply
aims at the nearest player's chest and attacks while enabled. Old preference
values are clamped to the new ranges. The distance is the client attempt limit;
server reach and damage rules still apply. At rates above the ~20 Hz callback,
up to two attempts share a tick. Do not claim 30 independent visual swings or
server hits per second.

Fix two concrete client causes of intermittent attempts: aim and attack now
run together AFTER original player movement, using the same fresh positions;
attack ray uses effective DirectLook including pending yaw instead of the
previous rendered quaternion. Close overlapping boxes are supported rather
than rejected just because ray entry is zero. Target identity, allocation tags,
GameMode slot 16, lease and code profiles remain checked; no range bypass or
packet spoofing. The clock retains phase while waiting for a target.

Call the native LocalPlayer swing API before each attack attempt, via pinned
slot 110 (+880), function 0xaf60d78, args source=3 and main hand=0. Source 3/main
hand 0 mirrors the stock contact path at 0x1009c854..0x1009c868. The base swing
implementation 0xfa887f0 updates animation time +1032 and hand/swing state
+1076/+1077 while keeping its own minimum-cycle guard. Do not repeatedly reset
animation fields. Journal logs attackState, actualCps, swings and corrected
camera-input-v8 phase alongside attack/accepted counts.

Target HUD updates for the currently tracked target, including before the first
accepted hit, so rejection/out-of-range/view-miss conditions remain visible.
States distinguish off, lost target, range, view miss, pacing, native rejection
and unavailable data. HP max is read from AttributeInstance +120 (getter
0x101a9ac8), current remains +124. Hide the bar when max is unavailable/invalid
rather than inventing a maximum. Native ASCII/hex snapshot extends to seven
fields; legacy three-field parsing stays supported. Metadata name cache is
keyed by actor+entity and refreshed every 200 ms; lost-target card expires after
five seconds, disabling hides it immediately. Rank is extracted only from an
explicit [Rank] Name server prefix.

Validation: twelve gameplay suites, including every rate 1–30, post-update
ordering/tag preservation, stale-render vs effective-view ray regression,
reach 1/3/5 and overlapping target, swing code profile, unknown/extended HUD
snapshot and health limits. Android API 35/Rhino Java, C++ syntax and
address/undefined sanitizers pass (leak checks disabled under debugger). Full
APK linking and on-phone appearance/animation/attack behaviour remain unverified.

Upload bedrock-launch-aimbot-simple-source.zip to repository root and run Build
latest launch test. Install BedrockLaunchTest-0.60; enable Target -> Aimbot,
choose distance and CPS. Check the card's live state if attacks stop and save
the 0.60 journal if runtime problems remain. Auto Buy and Fast Exp settings and
actions are retained; their existing update stage precedes aim/attack.

## Earlier releases (superseded controls and callback phase)

# Aimbot 0.59 — up to 40 CPS and first Target HUD

Expand CPS control and native clamping to 10–40. On the existing ~20 Hz game
callback, 21–40 CPS means up to two attempts per tick; this does not provide
25 ms timing or guarantee corresponding server damage. Fractional deadlines
preserve average rate, cap each callback at two, drop excessive backlog and
revalidate target identity/GameMode before each call. Keep the corrected slot
16 attack route from 0.58. Existing CPS preferences are retained, default 15.

Add a passive rectangular TargetHud card at bottom-right. Show it after a native
accepted attack, refresh on subsequent accepted attacks, expire five seconds
after the last event and hide immediately when Aimbot is disabled. The snapshot
contains server-supplied name tag and client-visible current HP. Only an explicit
[Rank] Nick prefix is separated into privilege and name. Missing rank/name/HP
are shown as unavailable; no server privileges or health are invented. The
snapshot is a last-hit event, not proof of server damage. Manual attacks and
KillAura are not wired into this first version. TargetHud.show(TargetHudData)
is separate from Aimbot for later reuse by KillAura or other modules.

Native string evidence: Actor +320 exposes synchronized metadata; name-tag key
4 is read at 0xfda03c0..0xfda03c8 via typed string getter 0xfa4de14. That getter
reads metadata owner -> vector, item[4], validates virtual type getter at +24
returns DataItem type 4, and returns item+16 as libc++ string. Implement bounded
read-only lookup with vector limits, exact mov w0,#4;ret validation and 384-byte
cap. JNI carries UTF-8 as ASCII hex to avoid NewStringUTF limitations. Java
removes Minecraft formatting, parses explicit rank prefix and validates age,
health and malformed data. No new engine writes or native game calls.

Validation: twelve gameplay suites, including every CPS rate 10–40 at 20 Hz,
two-per-tick bounds/backlog rejection, typed name metadata, target-HUD UTF-8,
colors, rank/unknown values/expiry; Android API 35/Rhino Java type checking,
native C++ syntax and address/undefined sanitizers (leak check disabled under
debugger). Full APK linking, panel appearance and native data on the phone
remain unverified. Build BedrockLaunchTest-0.59 using Build latest launch test
with bedrock-launch-aimbot-target-hud-source.zip at repository root.

## Earlier releases

# Aimbot 0.58 — correct auto-attack dispatch

The supplied 0.57 phone journal contains autoAttack=1, cps=20, targets within
1–3 blocks, attacks up to 1277 and accepted=0. Attempts reached the engine;
the clock, target binding and ray checks were passing. The previous release
incorrectly identified GameMode slot 15 as attack. It is entity interaction.

Bind virtual slot 16 (+128) instead: GameMode 0x1009cb98, SurvivalMode
0x100a11c8. Preserve native mode/target allocation tags and use the three-pointer
bool(GameMode*,Actor*,const float[3]*) ABI. The base wrapper copies x2 into x3,
sets w2=1 and enters shared implementation 0x1009cba4; the Survival wrapper
performs its native guard before the same shared implementation. The lambda
at 0x100a36f8 writes action 1 at transaction+88 (0x100a3760..0x100a3768).
The old slot 15 callback at 0x100a3190 explicitly writes action 0 at +88
(0x100a3208): interaction, explaining rejection by ordinary players.
Both attack code prefixes are re-pinned to the supplied exact-build library.

The new attackBinding helper verifies ownership, GameMode type and the actual
slot 16 entry. Regression tests reject the old interaction function, wrong
owner/type and corrupted virtual entry; dispatch tests require three arguments,
validate the impact pointer and verify allocation tags survive. Existing CPS
10–20, range/ray checks, Head/Body, priorities, Sharp/Smooth and stabilization
are retained. No changes to account login, Auto Buy or Fast Exp behaviour.

Validation: all eleven gameplay suites, native C++ syntax with warnings as
errors, Android API 35/Rhino Java checks, exact-library code prefixes and
address/undefined sanitizers (leak checking disabled under debugger). Full ARM64
linking and auto-attack behaviour on the phone remain unverified.

Upload bedrock-launch-aimbot-attack-fix-source.zip and run Build latest launch
test. Install BedrockLaunchTest-0.58, enable Aimbot and Auto attack, approach a
player within 1–2 blocks and test. Journal phase=camera-input-v6 distinguishes
the corrected dispatch. If hits still fail, compare attacks/accepted in 0.58;
a native true return is still not a server damage acknowledgement.

## Earlier releases (0.57 dispatch identification is superseded above)

# Aimbot 0.57 — 10–20 CPS and independent-axis stabilization

Aimbot now includes Auto attack (default on, separately switchable) and CPS
10–20, default 15, persisted as aim.attack and aim.cps. With Aimbot enabled,
attack only the selected, revalidated remote player when the actual camera
forward ray intersects that player's bounding box within three blocks. Native
attack dispatch is after original LocalPlayer update and the existing Fast Exp
stage, using freshly read GameMode and preserved native allocation tags.

Fractional monotonic deadlines achieve the requested average on a 20 Hz source
without rounding 15 CPS down to 10. Never issue more than one attack per callback
or catch-up bursts after lag. Off, expired lease, missing target, bad binding or
ray miss suppress attacks. The attack range check uses a copy of target lock,
so it never clears the aiming target when standing outside attack range.
CPS counts attempts, and accepted counts native return values, not server damage.
A bounding-box ray is not a terrain visibility test; this release adds no wall
raycast or server-specific logic. Runtime behaviour needs phone verification.

Reduce small corrective motion in BOTH Sharp and Smooth by independently
stabilizing pitch and yaw (0.12 degree entry / 0.24 degree exit). A moving yaw
no longer forces tiny pitch corrections every update. Reset stabilization for
new target identity or a Head/Body change. Existing global deadzone, target
hysteresis and smooth ramp remain. Complete removal of visible shake is not
verified; the previous uploaded MP4 contained only audio.

Exact-build evidence: GameMode slot 15 (+120) is 0x1009c5e4;
SurvivalMode slot 15 is 0x100a11f0, a guarded tail call to that base function.
Native client input 0x9b6e60c..0x9b6e628 loads slot +120 with x0=GameMode,
x1=target Actor, x2=hit position (HitResult+44), w3=0. Dispatch uses the same
bool(GameMode*,Actor*,const float[3]*,bool) ABI. Both code prefixes are pinned
with the existing exact-build SHA gate. Slot 14 is an eight-argument block
interaction routine and is deliberately not used. Header aim_combat.h contains
pure clock, ray and axis helpers. New native counters are logged with
phase=camera-input-v5, autoAttack, cps, attacks and accepted.

Validation: all eleven gameplay suites, including all integer rates 10–20 over
10 seconds on 20 Hz sampling, no duplicate/catch-up dispatch, independent-axis
noise rejection, target changes, ray hit/miss/backward/range/NaN rejection;
Android API 35/Rhino Java checking, C++ syntax with warnings as errors, and aim
address/undefined sanitizers (leak checks disabled under debugger). Full ARM64
APK linking and device verification remain outstanding.

Upload bedrock-launch-aimbot-cps-source.zip to repository root, run Build latest
launch test and install BedrockLaunchTest-0.57. In Target -> Aimbot choose CPS,
Sharp/Smooth, Head/Body and priority. Auto attack can be disabled while keeping
aiming enabled. Check rates and misses in the 0.57 journal if hits do not occur.

## Earlier releases

# Aimbot 0.56 — selectable sharp and smooth modes

Target -> Aimbot -> Aim mode offers Smooth / Sharp (Режим наведения:
Плавно / Резко), persisted under aim.sharp. Smooth stays the default and keeps
its speed, easing, start ramp and final deadzone. Sharp bypasses speed/easing/
ramp and sends the full shortest-angle correction at the next eligible game
update. It respects camera pitch limits, selection radius, Head/Body, priority,
identity revalidation, lifetime and lease. It does not attack automatically.

Sharp uses camera input state including pending yaw, so subsequent callbacks
cannot replay a turn that has not yet been consumed. Allow pending yaw up to
2*pi during wrap crossings; the camera system normalizes it when consumed.
Changing modes resets the clock/ramp/deadzone but retains a valid target.
Speed and smoothness controls are clearly described as Smooth-only settings.

The submitted MP4 contains a single AAC audio stream, 10.303 seconds, with no
video stream. No visual diagnosis of residual jitter was possible. Existing
anti-jitter measures remain; this release does not claim to eliminate all
screen shake. Full APK linking and on-phone behaviour remain unverified.

Validation: all eleven gameplay suites, including one-update sharp convergence,
positive/negative pitch, yaw wrapping, pending-input replay rejection, pitch
limits and return to Smooth. Native C++ syntax and Android API 35/Rhino Java
checks pass. Upload bedrock-launch-aimbot-modes-source.zip to repository root,
run Build latest launch test and install BedrockLaunchTest-0.56. Select Резко
in the module to test instant turning. Test Голова/Тело, toggle modes and disable.

## Earlier releases

# Aimbot 0.55 — faster turns, reduced jitter and target priorities

Target -> Aimbot now offers Nearest and Lowest HP. Rescan candidates every
300 ms. Keep the current target unless a candidate is about 8% closer (squared
distance threshold .85), or has more than 0.5 fewer HP. Rank equal HP by distance.
Unknown health is never zero: prefer known HP, otherwise fall back to nearest
and display the fallback. Exclude zero-health players when the attribute is
available. Health is client-visible data; servers may omit updates or send the
same/default health for remote players.

Tune existing installs once to 240 degrees/second and 80 ms response; subsequent
user changes persist. Faster coarse acquisition uses adaptive easing, with a
180 ms smooth start ramp for each new target. Final aim uses a hysteresis band:
stop within .12 degrees, resume outside .24 degrees. Keep native input feedback,
pending-yaw accounting, exact camera binding and Head/Body points. This reduces
small corrective oscillations and repeated target switching; phone behaviour
and perceived smoothness still need testing. No new frame hook is introduced.

Health reader evidence in the exact supplied library: AttributesComponent key
0xfd3b0613, payload stride 88 from 0xfdabaa4; parallel sorted uint32 ID vector
+0/+8 and AttributeInstance vector +24/+32, stride 136 from 0x10177014.
Health attribute global 0x141d8f48 is initialized with minecraft:health at
0x1018e97c..0x1018e9a0; its ID getter at 0x101a8bf0 reads +4. Thus the runtime
ID is read from base+0x141d8f4c. Health lookup and positive-value test appear
at 0x101be38c..0x101be3a8; current-value getter 0x101a9ad0 reads float +124.
Use bounded read-only lookups, entity sparse generations, finite/range checks,
matching vector lengths and unchanged header re-read. No new native calls.

Validation: all eleven gameplay suites, including nearest vs HP selection,
unknown/NaN/dead health, hysteresis and acquisition ramp; native C++ syntax,
Android 35/Rhino Java checks and address/undefined sanitizers (leak checking
disabled under debugger). Full APK linking and on-phone behaviour are unverified.

Upload bedrock-launch-aimbot-priority-source.zip to the repository root and run
Build latest launch test. Install BedrockLaunchTest-0.55. Test priorities near
two players with different distance/health; check Head and Body and adjust
Speed/Smoothness as desired. Journal phase=camera-input-v3 includes priority,
hp, current view and goal angles. Fast Exp and Auto Buy remain unchanged.

## Earlier releases

# Bedrock Crash Capture 0.54 — correct camera feedback and smooth target aiming

The 0.53 phone video shows the view climbing into the sky. Correct the native
camera pitch/input sign and calculate aiming error from DirectLook, including
pending yaw, instead of the lagging Actor rotation. Head uses the centre of the
head area; Body uses the chest. Keep typed target binding and sticky selection.

Add a persisted Smoothness control (40–200 ms, default 100 ms). Time-based
exponential easing approaches the chosen point within the existing angular
speed cap; tiny stationary errors stop generating input. Larger values feel
softer and follow fast-moving targets with more delay. No new frame hooks,
packet writes, or changes to Fast Exp, Auto Buy, login or menu continuity.

All eleven gameplay suites pass, including native-quaternion projection tests
for the vertical sign, head/body convergence, pending-input delay and smoothing.
Android API 35/Rhino Java and native syntax checks pass; the aim core passes
address/undefined sanitizers with leak checks disabled under the debugger.
Full ARM64 APK linking and the updated phone behaviour remain unverified here.
See AIMBOT.md for build steps and exact-library evidence.

## Earlier releases

# Bedrock Crash Capture 0.53 — use active camera input for Aimbot

The user confirms that 0.51/0.52 leave the screen stationary. The old Actor
setRot/setYHeadRot calls did not establish visible camera control. Replace
those calls with Minecraft's direct-look input callback on the client's active
input camera. Keep Head/Body, radius, sticky target and bounded angular speed.
The engine now consumes the input through its camera/player update systems.

Bind the native active-camera context, entity generation, ActiveCamera and
CurrentInputCamera markers, typed Camera/DirectLook storage and native code
profiles. Preserve MTE tags on client and payload arguments. Reject invalid
camera data; verify accepted input and log camera quaternion changes separately
from the number of native calls. See AIMBOT.md for exact offsets and phone steps.

Validation: all eleven gameplay suites, Android API 35/Rhino Java type checking,
C++ syntax with warnings as errors and address/undefined sanitizers (leak check
disabled under debugger). Full APK linking and screen behaviour are not verified
locally. This release does not establish why the server flags a player. Auto Buy,
Fast Exp, account login and menu/focus continuity are unchanged.

## Earlier releases

# Bedrock Crash Capture 0.52 — bounded aim turns before player movement

The 0.51 phone journal confirms successful typed binding (bind=0), a retained
player ID and roughly 20 applied rotations per second. The user reports severe
flagging near a player on Nevertime. The log contains no authoritative server
correction/rejection message, so it cannot identify the server-side cause.

Fix two concrete client behaviours: the old callback overwrote the full target
rotation after the player update, and acquisition/close passes could turn the
camera arbitrarily far in one tick. Move the aim callback to the before-update
stage of the shared dispatcher. The original update then runs; Fast Exp still
reads the fresh GameMode after it returns, and container actions keep their
existing stage. No movement packets or server corrections are modified.

Limit the combined pitch/yaw step by elapsed monotonic time and a configurable
60–360 degrees/second (default 180). Use the current game pose, shortest yaw
wrap and no overshoot. Clamp catch-up time to 100 ms; duplicate/backwards time
produces no turn. The first update uses a 50 ms allowance. Keep Head/Body,
radius and sticky target selection. Settings persist under aim.speed. Status
separates converging from settled; journal adds speed, maxTurn and callback phase.

Validation: all eleven gameplay suites, including 1000 moving-target steps,
wrap/overshoot/lag/same-time bounds and shared callback ordering with tagged
pointers and a replaced GameMode. Aim core passes address/undefined sanitizers
with leak checking disabled for the sandbox debugger. Native source syntax and
all app Java are checked against JNI declarations and Android API 35/Rhino.
Full APK linking and behaviour on Nevertime are not locally verified. These
client fixes do not establish server compatibility or explain an unseen server
rejection. The source contains no server-specific evasion or packet spoofing.

## Earlier releases

# Bedrock Crash Capture 0.51 — built-in Aimbot in Target

Add Target -> Aimbot with an enable toggle, Head/Body choice and 2–12 block
radius (default head/6). Select the nearest loaded RemotePlayer within the
3D radius, retain its entity identity until invalid/out of range, and update
local Actor camera rotation plus head yaw each LocalPlayer game tick. There
are no automatic attacks or touch gestures. Settings persist in menu preferences.
Menu/focus changes do not disable the module; actual game teardown does.

Prepare the existing post-update bridge automatically on a worker when enabled.
Use per-frame own-process ECS reads, current client entity generation, typed
ActorOwnerComponent and AABBShapeComponent payloads. The local cached rotation
pointer must match ActorRotationComponent storage; remote targets must have the
exact RemotePlayer vptr, same registry, current sparse generations and owning
actor payload. Removed, cross-world, malformed or stale entities are rejected.
Head/body points follow the target's bounding box. Shortest yaw wrap, pitch
clamp and finite-coordinate checks avoid 360-degree flips/invalid rotation.

Native Actor setRot (0xfd8f694) and setYHeadRot (0xfdafa3c) run only on the game
update thread, using the original tagged local this pointer. Code profiles and
the existing exact game SHA check gate preparation. A renewable lease and
explicit disable prevent leftover actions; a 5 ms/8192-read budget and bounded
entity scans limit acquisition work. This is a visible camera/head lock, not
a silent packet rotation. Selection is by radius, without a visibility raycast
or team/friend filter; actors without the RemotePlayer type are excluded.

Validation: all ten gameplay suites, Android API 35/Rhino Java type checking,
JNI/native C++ syntax with warnings as errors, five aim profiles compared to
the exact library, and the aim core under address/undefined sanitizers (leak
checking disabled because the sandbox debugger blocks LeakSanitizer). Tests
cover head/body angles, yaw wrapping/clamping, NaN, nearest/sticky selection,
paged components and entity generations, stale/removed/wrong-world/type targets,
corrupt chains and read-only selection. Full ARM64 APK linking and visible
camera/head behaviour are not locally/device verified; use GitHub Actions and
test beside another player, then inspect the 0.51 journal if tracking fails.
See AIMBOT.md for the exact layout evidence and device steps.

Auto Buy development is deferred. Its selection, purchasing, prices and native
transaction code are unchanged. Existing Fast Exp tick processing is retained;
the shared hook adds the independent aim callback after original update/actions.

## Earlier releases

# Bedrock Crash Capture 0.50 — native auction selection and purchase path

Retain the original script's 17 preset names, market prices, ratios, lot caps,
blocked words and enchant requirements. Add Auto Buy -> Items and Prices, with
per-unit effective limits from the same Rule.priceLimit() used by the matcher.
For stacks apply quantity and the absolute lot cap. Karatel has no fallback
market price and stays skipped; unsupported armor type also stays skipped.
Do not invent a market price, guess armor from the custom display name or
silently relax enchant/confirmation checks.

Native REFRESH keeps the phone-verified Place-to-empty-inventory path. OPEN,
BUY and RETURN now use the game's ItemStackRequestActionTake constructor to an
empty owned cursor, following the script's take-to-cursor semantics. Cursor is
PlayerUIContainerModel, exact-build enum 59, one ItemStack, UI backing index 0.
The game serializes its internal container enums and allocates request IDs;
no external packet enum or request number is invented. Cursor occupancy/type,
model membership/vector and empty net ID are checked in Java and again on the
game thread. JNI token grows from 19 to 22 longs. Take ctor code profile is
pinned just like the existing native methods. No cursor-content cleanup or
forced replacement is attempted.

Read both inventory partitions: InventoryContainerModel enum 28 / 9 hotbar
slots and enum 29 / 27 main slots. Ignore the overlapping combined view.
Recheck both model headers/vectors at scan end, preventing a manual move between
partitions from appearing as a new purchased item. Receipt requires an actual
increase after BUY; confirmation still binds item, count, price and seller.
No retry of an uncertain BUY. Preserve 0.49's continuous menu/multi-window
behaviour and independent Fast Exp/script operation.

Validation: all nine suites, 17 canonical rule records compared with migrated
original-script data, Java type checking against Android API 35/Rhino and native
syntax with JNI declarations. Tests cover limits/stack caps, occupied/unowned/
wrong cursor, Place vs Take selection, full confirmation/receipt flow including
hotbar delivery, and rejection of cross-inventory moves while reading. Native
Take calls, full APK linking and successful live server purchases still require
GitHub Actions plus phone verification; local tests do not establish those.

## Earlier releases

# Bedrock Crash Capture 0.49 — keep modules running with menus and other windows

The 0.48 phone report repeatedly pauses Auto Buy as the menu/focus changes,
cancels unsent native actions (state=5/request=0), and disables Fast Exp when
another Activity opens. Separately, Auto Buy suppressed Fast Exp leases and
script ui_tick delivery even when the user kept those modules enabled.

Remove menu/focus gating from Auto Buy's availability check and remove its
menu-open/focus/onPause cancellation hooks. Opening kulich now only shows the
panel. Retain selection, confirmation/receipt phase, request correlation and
worker generation through focus changes. Legacy explicit calibration remains
exclusive with Auto Buy; native container/price/ownership guards are unchanged.

Fast Exp no longer switches off on Activity.onPause. Its heartbeat depends only
on its own enabled flag, runs with the menu visible and Auto Buy enabled, and
is renewed immediately on explicit enable. Script ui_tick callbacks are likewise
independent of menu visibility, focus and Auto Buy. Startup readiness checks
require a live Activity and verified player, not window focus. Manual off,
module errors and actual Activity destruction retain their existing cleanup.

Keep super.onPause/onResume and Minecraft's normal lifecycle. No background
service or forced game ticks are introduced: if Android/Minecraft suspends the
game itself, native actions wait for its game updates. On return, switches stay
as selected rather than being turned off by the launcher.

Validation: all nine auction/native suites, FastExpStart, native FastExpCore and
real Rhino script lifecycle tests; all app Java type-checked with Android API 35
and Rhino. Full APK build, visible menu/multi-window execution and concurrent
server behaviour require GitHub Actions plus phone verification. Native code,
authentication/resources and auction rules have not changed.

## Earlier releases

# Bedrock Crash Capture 0.48 — independently validated auction cells

The 0.47 phone report shows reads around 98–147 ms, frequent incomplete-snapshot
waits, and sampled refresh gaps from 369 to 640 ms. It also shows selection of
a Wyvern sphere for 29999 with a reply, followed by a purchase-window timeout.
The user confirms visible refreshes, with later slowdown. A matching native
reply is not proof that the confirmation screen opened.

Read the 54-slot auction listing per cell: keep only cells whose full ItemStack
bytes are identical across the initial, pre-decode and post-decode vector reads.
Skip changed or undecodable cells instead of discarding unaffected listing cells.
Window ownership/vector/model checks remain mandatory; the stable Refresh control
must be present. A skipped cell cannot yield an action token. No live price/NBT
is cached. Confirmation windows (27 slots) and player inventory remain strict
whole snapshots. Immediate full Java and native game-thread action validation
remain unchanged. Refresh uses slot 49; candidate listing slots are 0–44;
confirmation uses preview 13, Buy 10 and Back 16.

If an OPEN got a reply but the purchase window has not appeared within 5 seconds,
resume search only if a complete 54-slot auction is still present. Keep that
offer suppressed for the enable session. No BUY was sent in this case. Uncertain
purchase results and incomplete/unknown windows still stop rather than retrying.
Add decoded/skipped counts, observed window size/completeness, chosen source slot,
validation time and game-tick/reply duration to the journal.

Validation: all nine auction/native regression suites, including cells changing
on the second/third vector read, malformed neighbouring NBT, missing Refresh,
strict inventory/confirmation rejection, missed OPEN recovery without repeating
the offer, and existing price/receipt/native guards. All app Java type-checked
against Android API 35/Rhino. Full APK build and phone/server cadence/purchase
verification require the GitHub build and a device run. Native C++ is unchanged.

## Earlier releases

# Bedrock Crash Capture 0.47 — refresh read scheduling

The 0.46 phone report shows matched negative request IDs with reply status 0.
It does not show a purchase or prove visual lot changes. Reported snapshot reads
were 196–226 ms and sampled attempt gaps 527–560 ms, with longer outliers.

After a successful refresh reply, start reading the next fresh snapshot during
any remaining 300 ms policy delay. Estimate duration from the previous read,
reserve 25 ms, and retain the next() deadline check: an early snapshot cannot
send an early request. Slow replies never cause catch-up bursts. Purchase,
confirmation and receipt waits are unchanged. NativeInput still waits for the
matching reply before starting a new cycle; this delay is not bypassed.

Reuse the fixed rules privately across Lot evaluations, pre-normalize rule
names, compile the format/maps patterns once, clean each lore line once and
skip full lore normalization for names outside the rules. No decoded live NBT
or price is cached between reads. All existing source/price/ownership guards
remain in place. Native transaction code and descriptors are unchanged.

Validation: all nine regression suites; every app Java source type-checked with
Android API 35/Rhino; 1512 mixed verdicts identical to 0.46. A host-only warm
benchmark of 45000 mixed Lot evaluations improved from 430.2 to 212.2 ms; this
is not a measurement of total phone snapshot time. Deadline tests cover early
reads, slow replies, pauses and preserved confirmation waits. Full APK build
requires GitHub Actions; actual phone/server cadence remains to be measured.

## Earlier releases

# Bedrock Crash Capture 0.46 — native container actions

The phone's 0.45 capture contains a real request -3, one Place action from
level-entity slot 49 (net ID 13) to combined-inventory slot 9 (empty stack ID 0).
Use that action shape, with fresh IDs, instead of replaying bytes or touch input.

Auto Buy now queues one validated native Place action on the existing LocalPlayer
update hook. The game allocates/constructs the action and owns its scoped request:
Scope ctor -> manager apply -> Scope dtor -> native flush. Request numbers,
prediction and serialization use game code. Keep original MTE tags on native
manager arguments. Check live source/destination, map membership, player/window
ownership, current item/tag/count, preview/back tags, network ID and code profiles
before execution. Scope already open, unsupported IDs or occupied destination reject.

The response hook wraps the vtable-16 decoder, preserving its hidden x8 return
buffer and return registers in ARM64 assembly. Read correlated response records
only after the original decoder returns. A reply (including error status) is not
purchase success: plugins may cancel item transfers while processing auction
buttons. Existing policy separately checks confirmation and receipt, with a settle
interval before reading purchase results. Unknown purchase replies stop, no retry.

Auto Buy's normal path no longer sends MotionEvents or requires coordinates.
Expose one-shot native Refresh above the optional diagnostic controls. Preserve
white/black themes, pause/resume, filters and price limits. JavaScript's packet API
is still unavailable; this is a built-in native backend, not a ProtoHax shim.

Validation: nine regression suites; native source syntax against JNI declarations;
all Java type-checked against Android API 35; ARM64 response shim assembled and
disassembled with LLVM 19. Full Android APK/native linking and live native action
execution are not locally verified. Use the GitHub build and one-shot Refresh
on the phone first; inspect the 0.46 journal for Native container state/request/reply.

## Earlier releases

# Bedrock Crash Capture 0.45 — native inventory transaction recorder

This release is the first native integration step for replacing touch simulation.
It adds bounded, pass-through observation of real request/response packet data.
It does NOT implement the completed server-backed action sender. Existing Auto
Buy uses the legacy input path until that sender is verified and connected.

In Auto Buy choose Record Actual Container Action, close kulich, manually drag
Refresh into the inventory once, then choose Save Action Recording and export
the journal. Starting recording disables Auto Buy/Fast Exp. The recorder itself
never sends or modifies a packet. Request/response getId calls do not prove
server acceptance. See docs/container-transactions.md for verified offsets and
remaining context/ID requirements. Native trace tests run with verifyAutoBuy.

Validation: bounded capture C++ tests, all auction regressions, host native syntax
against JNI declarations and Java type checking against Android API 35. No local
ARM64 APK build or live packet capture has been performed.

## Earlier releases

# Bedrock Crash Capture 0.44 — faster reads and pause/resume

The user confirms the problem occurs in 0.43. Fix actual work on the refresh
path rather than reducing the policy interval again (it remains 300 ms):
- Quiet auction scans follow the verified player +0x578 manager field directly.
  The diagnostic path still scans all fields when explicitly requested.
- Mapped-memory range checks use binary search over sorted maps instead of a
  linear scan for every read. Read/write/bounds checks remain mandatory.
- Refresh gesture logs are throttled to once per three seconds; other actions
  retain their detailed logging. Avoid per-refresh file writes on the UI thread.
- Reuse a validated player binding at enable time, with one full rebind if the
  first cached snapshot is invalid. Do not reuse invalid data for actions.

Opening the menu or losing focus pauses the enabled controller. Returning
resumes without toggling it off or clearing duplicate/purchase state. Paused
time does not expire transaction deadlines. Interrupted listing opens return
to search; possible purchase submissions remain in receipt observation and
are never retried. Missing snapshots/other windows idle until a valid auction
returns. Actual confirmation mismatch or uncertain purchase still stops.

Show last read duration and interval between refresh attempts in Auto Buy
status. A timing record is written every three seconds on the worker; it does
not claim server refresh acknowledgement or successful purchase.

Validation: all seven suites, pointer-dense actor with 2049 unsorted mapped
regions, pause/resume deadlines, interruption and late valid-window recovery;
all Java checked against Android API 35. No new APK/native build or phone/server
verification locally. Existing white/black themes and preset layouts remain.

## Earlier releases

# Bedrock Crash Capture 0.43 — no touch-stop and menu customization

Ordinary touch events no longer disable Auto Buy: remove the Activity touch
hook and its controller stop handler entirely. Keep focus/menu, purchase
identity and uncertain-result guards. Search tolerates temporary unavailable
snapshots/footer controls for 2.5 s; stale-source refresh input failures re-read
the auction after 300 ms. Purchase input failures never enter this retry path.

Add category 03 Customization with a Menu Color setting: White and Black.
Apply palette changes immediately to existing header/panel/icon views and
re-render category/module/detail lists. Theme choice persists in the app's
private preferences. Switch/slider colors use the selected palette as well.
Three category rows share available height, retaining all three categories
when the menu is resized. This is built-in customization, not a script import.

Validation: all seven auction suites including new transient-read recovery and
bounded-wait cases, and all app Java type-checked against Android API 35.
No local APK/native build or device UI/server verification is claimed.

## Earlier releases

# Bedrock Crash Capture 0.42 — preset layout and 300 ms refresh

Both chest sizes now have a ready-to-use classic-layout preset based on the
user's successful 2340 x 1080 calibration. Uniform viewport scaling preserves
square slots and centered offsets; the 27-slot panel shifts by 1.5 cell heights.
Existing valid manual profiles retain priority; manual calibration is optional
under Advanced. No bitmap recognition or arbitrary GUI-scale inference is claimed.

Refresh policy is now 300 ms instead of 2000 ms. An independent 25 ms controller
scheduler replaces dependence on the menu's 400 ms heartbeat. The previous
500/600 ms read/completion floors no longer throttle refresh actions. Each double
tap still completes before another scan/input sequence; response and purchase
validation waits remain. Actual cadence depends on reads and server/device latency.
Focus, physical touch, menu opening and disposal stop scheduled work as before.

Validation: preset coordinate/scaling/centering/landscape tests, exact 299/300 ms
policy boundary, all seven auction regression suites and Java type checking
against Android API 35. No local APK/native build or new device verification.
See [AUTO-BUY.md](AUTO-BUY.md) for the shorter enable-only setup.

## Earlier releases

# Bedrock Crash Capture 0.41 — built-in Auto Buy cycle

Auto Buy now has a real toggle connected to a refresh → match → open listing →
validate confirmation → submit → observe inventory receipt state machine.
See [AUTO-BUY.md](AUTO-BUY.md) for setup, supported rules and limits. Existing
Fast Exp native code, game resources and account-routing configuration remain.

The controller consumes fresh, bounded own-process snapshots on one worker.
Only stable LevelContainerModel windows and typed player inventory models are
used. Action guards check current manager-map membership, owner, window/vector,
source and confirmation details before double taps in this app's own Activity.
Physical touches, menu opening and focus loss stop the module; generation checks
reject late worker/input callbacks. No global input permission is introduced.

Receipt observation is separate from input delivery. Uncertain purchases stop
without retry. Confirmed offers are suppressed for the rest of the enable session.
A retained confirmation window can return through the validated red control.
Rule limits and enchant requirements are retained; unsupported armor types and
rules without market prices are skipped. The JavaScript API remains unchanged:
the built-in auction controller does not expose a ProtoHax packet API to scripts.

Seven regression suites cover policy, live model/action guards, NBT, matcher,
window snapshots and calibrated geometry. `verifyAutoBuy` runs them before
Android preBuild, including the root archive workflow's assembleDebug path.
All application Java sources were type-checked against Android API 35 and the
actual Rhino 1.7.15 dependency. Android APK/native build and real server purchase
are not verified locally; use the GitHub build and device journal for those.

## Earlier releases

# Bedrock Crash Capture 0.40 — square-grid fit and Refresh double tap

The 0.39 report shows completed 483/484 ms gestures with all MOVE return flags
accepted. The user says the auction did not refresh; Android event delivery
was not a server acknowledgement. Their manual workflow also supports tapping
Refresh twice. Implement this stated alternative rather than assuming that
the prior drag succeeded or enabling purchases.

The report also reveals noisy calibration: horizontal step ~93 px vs vertical
~83 px (and ~89 vs ~72 in the confirmation profile). Classic chest cells in the
provided screenshot are square. The old code multiplied the one-row vertical
sample across five rows. Fit a square grid using the span over eight columns,
average the two left-column observations, and fit origin Y over three samples.
Saved raw calibration points are reused. Add regression tests where row-tap
jitter formerly displaced the footer by one cell. This corrects an observed
geometry weakness; it does not prove that it caused the reported failure.

Add Show Refresh Point, a noninteractive green marker over computed slot 49
for three seconds. It neither clicks nor consumes game touches. The explicit
input test now sends two short DOWN/UP pairs at that same point. Second DOWN
is scheduled ~180 ms from the first, and each UP ~55 ms from its own DOWN.
A delayed second tap (>250 ms after first release), overlong press, changed
window/focus, or rejected input aborts. Before the second DOWN, validate the
current Refresh source again. Live owner/window checks remain between events.
Reader/maps are reused for the sequence; no journal fsync while held down.
Logs record both accepted pairs, hold durations, gap and coordinate. Those are
input diagnostics, not successful-refresh or purchase claims.

The test no longer needs calibrated inventory coordinates, although the
existing four-point configuration UI/profile is retained for compatibility.
The current native token still requires an empty inventory cell. Calibration,
marker, disposal, late-callback and icon-over-target guards remain. Marker
visibility pauses Fast Exp leases and script UI ticks like calibration.

Validation: square-fit noisy-point regressions, original screenshot geometry,
viewport/range checks and destination geometry; Android-source Java syntax.
No Android build, touch simulation or server refresh is validated locally.
The native bridge, auth/resource fix, read-only matcher, script API and journal
remain unchanged. Purchases/green-confirm actions are still not enabled.

# Bedrock Crash Capture 0.39 — refresh transfer gesture

The user reports that a tap highlights Refresh but the server action needs a
transfer/drag into the player's inventory. 0.38 recorded accepted DOWN/UP but
that was never proof of a refresh. Its old gesture also did repeated maps/file
work and journal fsync during the hold. Preserve the distinction between an
Android dispatch flag and an actual server response.

Replace the explicit Refresh tap test with a DOWN, six MOVE samples, then UP
over roughly 480 ms, aimed at a freshly observed empty player-inventory slot.
Both DOWN and MOVE have finger pressure; release has zero pressure. Native
memory checks still gate the start and window identity throughout the drag.
During dragging, the source may be locally cleared/cursor-held and destination
may be predicted as filled, so require the same typed model/vector/ownership
rather than incorrectly cancelling on source-item disappearance. Window change,
focus loss, disposal, excessive delay or stale callbacks cancel the gesture.
MOVE return flags are logged as diagnostics, not treated as proof of handling.

Add fourth-point calibration for the player-inventory first-cell origin below
the chest (not hotbar). Reuse the known chest cell spacing for 27 inventory
cells. Old 3-point profiles must be recalibrated. Player-inventory targets come
from the stable 27-slot InventoryContainerModel and typed ItemStack counts;
occupied cells are skipped, and no available cell blocks the gesture. The
calibrated target and native slot index must match. Coordinates are still a
user-calibrated input path, not inferred semantic UI hit boxes.

A single gesture session reuses its maps/memory reader, avoiding repeated maps
scans between DOWN and MOVE/UP. Live pointer/type/layout checks remain bounded.
No journal fsync occurs while the synthetic finger is down; terminal logs
include duration, destination slot, coordinate, reason and dispatch flags.
The only automated action remains the explicit Refresh transfer test. There
is no buy/confirm dispatcher, packet API or successful-purchase assertion.

Tests cover inventory calibration geometry, valid/occupied/full inventory,
next-empty selection, window change rejection, source snapshots and typed
owner metadata. Java syntax parse is not an Android build or a live input test.
The next required device check is whether Refresh actually updates the auction
through this drag gesture. Auth, native Fast Exp, script API, rule matching and
journal behavior remain unchanged.

# Bedrock Crash Capture 0.38 — calibrated refresh input test

The user's screenshot and 0.36 confirmation report establish a 27-slot purchase
window: item preview=13, buy glass including=10, return glass including=16.
Preview name, seller and price are available. This does not establish an input
ABI, nor is a purchase enabled by those observations alone.

Add manual three-point chest-grid calibration for 54-slot auctions and 27-slot
confirmation windows. The overlay consumes touches rather than forwarding
them to the game. Points are centers of cells 0, 8, 9, in the Activity decor's
coordinate space. Geometry and viewport bounds are validated; profiles are
stored privately and rejected when viewport size changes. Recalibrate after
changing GUI scale/layout even if viewport dimensions remain the same.

The only new dispatched action is an explicit Refresh test for slot 49 of a
54-slot LevelContainerModel. Preparation performs the existing exact-build
probe and snapshots the window. Immediately before DOWN and before UP, a
bounded memory check requires player/client/manager ownership (live-confirmed
player+0x578), current model/vector size, typed slot userdata, and the exact
Refresh display name. A changed window results in cancellation. A round kulich
icon covering the target blocks the test. A rejected DOWN is cancelled instead
of sending UP. Disposing the menu cancels pending input; calibration pauses
Fast Exp leases and script ui_tick callbacks.

Touch events use this Activity's normal dispatchTouchEvent with a touchscreen
finger pointer, a DOWN then ~60ms UP, and recycled MotionEvents. No system input
permissions, other-app injection, memory writes or guessed C++ calls are used.
This is still an unverified device input path: a Java dispatch acceptance flag
is not proof of a server response. Incorrect calibration can hit a different
UI control; the test is for user-observed validation before enabling purchases.
There is no Buy/confirmation dispatch, generic JS touch API or automated trading.
The 27-slot profile can be prepared now but is not used to send any action.

Tests cover grid coordinates and viewport/shape/range validation; Refresh token
creation, metadata/type/owner/layout changes, and existing read-only container
checks. Java syntax parsing is not Android compilation. Actions/device tests
must confirm that the game receives the touch and actually refreshes. The next
step is a user-observed Refresh result plus the 0.38 journal. Native Fast Exp,
auth, resource fixes, JS API and rule matcher remain unchanged from 0.37.

# Bedrock Crash Capture 0.37 — read-only Auto Buy rule evaluation

The real 0.36 auction report successfully decoded all 52 nonempty slots of a
54-slot LevelContainerModel, including custom names, seller and formatted lot
prices. Thus the userdata+16 correction is confirmed for live display data.
Examples include Sphere of Wyvern at 120000 and Orion Talisman at 400000;
those exceed the user's original 58500 and 180000 effective rule limits.

Port the corrected user-script shopping defaults into AutoBuyDefaultRules and
add a pure AutoBuyMatcher. It strips formatting, normalizes case, requires one
readable price/seller field, validates integer/thousands price syntax and lot
count, honors blocked words/books, uses min(cap,market*count*ratio), and checks
required/custom enchant levels. Default market prices are used; market learning
and page-turning are not implemented. Missing market/type/quality data rejects
the candidate. Only the 45 item positions of a 54-slot LevelContainerModel are
evaluated; navigation/footer and inventory/confirmation models are excluded.

The read-only NBT decoder additionally attempts standard ench lists containing
CompoundTags with ShortTag id/lvl values. Type and bounds checks apply; invalid,
duplicate or changing lists discard enchant data. Exact RTTI identifies weapon
and enchanted-book item types via the existing Item weak-handle representation.
Armor item kind is not established and remains unsupported/rejected. Enchant
and item-kind reads need live validation; this is not full metadata coverage.

The existing Read Open Auction button now logs per-rule MATCH/SKIP verdicts
and a selection count in its result. It does not auto-scan, click, buy, refresh
or send packets. The full JS auction capability remains false. Before adding
purchase actions, establish whether the server opens confirmation and inspect
that screen's metadata and its input path. A diagnostic MATCH is not a
server-authorized transaction or confirmation of a purchased item.

Validation: real-report name/price examples, cap/ratio boundaries, formatted
prices, blocked names/books, required NBT/text enchants, missing/duplicate
metadata, missing market, footer exclusion; synthetic ench-list parsing plus
existing NBT and stable-container tests. No Android/device validation is claimed.
Auth, Fast Exp, launcher startup, journal screen and script API remain unchanged.

# Bedrock Crash Capture 0.36 — correct ItemStack userdata offset

The 0.35 device report confirms a LevelContainerModel with 54 slots, 52 nonempty,
and stable ItemStack/count data. The userdata matcher reports zero CompoundTags
because the collector used offset +24. Exact-library disassembly of the
ItemStackBase copy at 0x1076d6ec shows the +24 field copied separately, then
+16 passed to a deep-copy routine at 0x1076d794. The destructor at 0x1077ed80
also clears and virtually deletes the pointer at +16. Read userdata from +16,
still requiring the exact CompoundTag type before display decoding.

The new regression test follows the entire auction vector -> ItemStack+16 ->
CompoundTag display tree -> StringTag Name path. This covers the integration
that the earlier separate vector and standalone NBT tests did not exercise.
Existing bad-player/vptr/changed-content and NBT limits tests still pass.
The copied-library analysis is evidence for this game build only; live display
names/lore still need the user's auction snapshot for validation.

No purchases or clicks are enabled, and JS auction/packet capabilities remain
false. Auth, Fast Exp/native startup, script runtime, UI and journal behavior
are unchanged from 0.35. This fixes the observed missing-userdata collector
field, not first-attempt server entry or a complete Auto Buy implementation.

# Bedrock Crash Capture 0.35 — derived auction model and display NBT reader

The user's 0.34 report confirms the auction probe reached a verified player
and ChestContainerManagerModel at LocalPlayer+0x578. It did not accept a lot
model. The old reader admitted only the base ContainerModel vptr. RTTI in the
supplied exact game binary also identifies LevelContainerModel (0x13d34298),
InventoryContainerModel (0x13d341b0), and PlayerUIContainerModel (0x13d34468).
All three have the same size/index getters 0x10169ba4/0x10169bd0, confirming
vector+216 and 152-byte stride. Add these exact type checks and bounded model
vptr/vector rejection diagnostics. This is a plausible collector omission;
the report itself does not disclose the actual runtime model vptr.

For stable typed 27/54-slot vectors, additionally attempt to decode only
ItemStack userdata at +24 that identifies as CompoundTag. Exact-build RTTI
CompoundTag/ListTag/StringTag is 0x13ebe0b0/0x13ebe350/0x13ebe5f8. Static
serialization disassembly shows CompoundTag tree root+16, node key string+32,
inline variant tag+56 and discriminator+96; ListTag pointer vector+8/+16;
StringTag holds libc++ string+8 with low-bit long-string layout. The reader
looks up display.Name and display.Lore only, with typed checks, mapped-memory
reads, strict UTF-8 and length/node/depth-independent cycle limits. It rechecks
map/string/list headers and logs named lots without dumping arbitrary NBT.
All reading shares the auction read/time budget. Names/lore are diagnostic
snapshots, not an atomic server purchase/price guarantee.

Tests cover base and derived vectors, concurrent changes, tagged pointers,
synthetic display trees, inline/long UTF-8, lore vectors, bad types/lengths,
cycles and changed map roots. The real item-data/tree layout still needs the
user's live auction report. There are no clicks, purchases or packet sends;
script auction capabilities remain false. Native Fast Exp, launch button,
Microsoft flow, script runtime and dedicated journal behavior are unchanged.
This version does not claim to fix first-attempt server admission.

# Bedrock Crash Capture 0.34 — dedicated journal screen

The user reports that the launcher opens from the kulich Journal button but
its journal appears empty. Previously that intent displayed the entire launcher
control panel, with its text area below all controls, and synchronous report
collection on the UI thread. This can hide the text and block rendering;
it does not establish whether the underlying game recorded a server reason.

The same MainActivity now handles the Journal intent with a dedicated layout:
visible loading status, Save/Refresh controls and a selectable scrolling text
area filling remaining space. It bypasses the launcher controls. Collection
and export run on the existing single worker queue. Saving is unavailable until
the first collection finishes; rotation queues a new collection ahead of export.
Each refresh replaces the displayed report instead of appending duplicates.
A header, missing-log state and errors are explicit. launch-log.txt tail is
bounded at 512 KiB; own logcat and content logs keep their existing limits.
Success is shown after the output stream closes. Both main-panel journal
buttons route to this screen; Save Journal opens the document picker after load.

Only the journal UI/collection/export and version/documentation change. Auth,
resources, Fast Exp startup/native code, script API and auction snapshot remain
unchanged. No claim is made about fixing server connection or full Auto Buy.
Validation: Java syntax parse, XML/archive/version checks and comparison of
all other files with 0.33. Android build and screen/file-picker behavior still
require Actions/device verification. Routine reversible layout changes have
no implementation-mirroring UI tests in the absence of an Android runtime.

# Bedrock Crash Capture 0.33 — Fast Exp launch button and auction snapshot

Add Enable Fast Exp and Play at the top of the launcher. It uses the existing
launch preparation directly, without the separate Check Minecraft button,
and passes a startup request into the game. A UI-thread request controller
waits five seconds and retries the existing validated memory probe no more
than once per eight seconds while focused, until a live player is verified.
Only a ready bridge plus verified player and foreground Activity enables it.
A cancellation/disposal suppresses late results. Success consumes the request;
normal pause disables Fast Exp as before and does not auto-reenable it.
Manual Fast Exp actions cancel an outstanding startup request. Ordinary launch
does not request startup enabling. Native item-use guards are unchanged.

Auto Buy now has Read Open Auction, an explicitly diagnostic read-only step.
The supplied exact game binary's RTTI identifies ChestContainerManagerModel
vptr 0x137e8f20 and ContainerModel vptr 0x13d35930. Disassembly at
0x101656c4 follows the model map at manager+176 and the shared model pointer
at node+40; libc++ first-node link is a candidate at manager+192.
0x10169ba4/0x10169bd0 establish vector+216 and 152-byte ItemStack stride.
These are exact-build observations, not portable offsets.

The snapshot searches a freshly verified LocalPlayer for that manager, follows
bounded candidate map nodes and accepts only 27/54-slot vectors of matching
ItemStack vptrs, rereads object/contents/player/owner pointers, and logs slot
counts. All reads use /proc/self/mem with mapped writable-region checks,
read/time/node limits. No game methods, writes, clicks or purchase requests
are made. Names, lore, seller, price and confirmation still need adapters;
JS auction/inventory/packet capabilities remain false. The user must open the
actual auction, run this snapshot, and provide the report before implementing
purchases against an unverified live layout. Auto Buy is not yet functional.

Standalone tests cover tagged pointers, stable snapshot/counts, player/type/
content replacement rejection and unchanged memory, plus Fast Exp startup
world/focus/retry/cancel/consumed-request states and existing ECS probe tests.
Android builds and live container layout/startup behavior remain device checks.
Authentication, Application resources, script API and native sources remain
unchanged. This version does not claim to fix first-attempt server admission.

# Bedrock Crash Capture 0.32 — kulich script API v1

The user confirms Microsoft sign-in works in 0.31, but reports first-attempt
server connection failures. Their 0.31 journal shows WebKit returning its end
URL and Activity result, without the prior missing-Activity crash. It contains
no actionable server rejection reason or content logs. This version does not
claim to fix first-attempt server connection.

Add a real interpreted JavaScript module API via Rhino 1.7.15. Imported scripts
register utility modules with enable/disable handlers, validated number/boolean
settings in code, bounded journal output and a distinct ui_tick menu timer.
Fast Exp exposes its existing validated bridge (must already be prepared).
No raw native addresses, packet API, inventory or auction container interface
is exposed. Capabilities report those omissions and ProtoHax imports are
explicitly rejected. Auto Buy remains unconnected.

Scripts are imported using Android's document picker, stored as bounded text
under private content hashes, and loaded at the next game start, disabled by
default. Duplicate imports deduplicate. Removing imports moves copies to a
backup folder. The whole launcher screen now scrolls in landscape so import,
export and stop buttons remain reachable. Separate per-script scopes have no
Java globals, instruction deadlines and log-rate limits; this is not a separate
memory-isolated process for untrusted code. See KULICH-API.md and examples/.

Validation: compile and execute standalone API tests against the actual Rhino
1.7.15 dependency; lifecycle/example, range errors, capabilities/Java globals,
timeout shutdown, atomic registration, duplicate handling, bounded imports,
link rejection and backup moves. Java syntax parsing of Android source is not
an Android build. Actions must build the APK; script import/menu behavior needs
a phone. Native code, auth/resource fixes and Fast Exp behavior are preserved.

# Bedrock Crash Capture 0.31 — SDK WebKit Activity registration

The supplied 0.30 report provides a concrete fatal exception. The external
Microsoft browser returns through IntentHandler, and BrowserLaunchActivity
reports its operation completed successfully. That proves delivery of this
browser response, not completion of the entire account sign-in. The SDK next
starts ShowUrlType NonAuthFlow, which explicitly requests an in-process WebKit
strategy. Android throws ActivityNotFoundException for
com.microsoft.xal.browser.WebKitWebViewController, followed by a main-thread
fatal exception and process exit reason=4.

Register the installed SDK's WebKitWebViewController as exported=false, :game,
singleTask (matching the original game's public Activity metadata). It uses
an opaque framework Light.NoActionBar theme and handles the same configuration
changes as BrowserLaunchActivity. GameFactory instantiates it via the existing
game loader, including intent extras loader repair and the process-restart
guard. HostApplication's pre-created callback already covers the XAL browser
package and sets the extras/saved-state class loader before SDK onCreate.

There is no custom WebView client, TLS override, credential interception,
response rewriting or URL/token logging. Authentication remains in the
installed game's SDK. Native Fast Exp, one-step enable, Auto Buy preparation,
Application resources and log configuration are unchanged from 0.30.

Validation: Java syntax parsing; manifest coverage/process/export/mode checks
for all three XAL Activities seen in the game metadata; archive CRC/version
and unchanged native sources. Android compilation and full sign-in remain
GitHub Actions/device checks. This addresses the observed missing-Activity
crash, not a guarantee about every subsequent account/server flow.

# Bedrock Crash Capture 0.30 — one-step Fast Exp and Auto Buy preparation

The user confirmed game/server entry and Fast Exp work with 0.29. Preserve
that application resource fix, authentication setup and native item-use path.

Fast Exp's disconnected-state action is now Enable Fast Exp. It runs the
existing verified-library/client probe in a worker, then enables automatically
if the Activity still has focus. There is no separate manual probe step.
Failure leaves it disabled and explains how to retry in a world. A prepared
bridge retains the direct enable switch, 1–10-tick interval and existing
focus/menu pause behavior. Native guards and code are unchanged.

integrations/protohax contains a repaired user-supplied Auto Buy script and
extracted shopping rules, with tests and portability limitations documented.
It is not executed by the launcher: the @protohax/userscript runtime and auction
container/packet APIs are not implemented in kulich. Auto Buy remains explicitly
unconnected rather than presenting a nonfunctional enable switch.

Validation: Java syntax parse, Node module syntax and mock auction tests.
Android compilation and one-step button behavior require Actions/device tests.

# Bedrock Crash Capture 0.29 — application resources and content-log setup

The 0.28 report still lacks content logs. The user confirmed they only saved
the launcher report and could not find the game's Creator logging setting.
The report also contains numeric game resource lookup failures from SDK code
using applicationContext, whereas Activity resource attachment succeeds.
Neither this observation nor unrelated telemetry upload errors establish the
cause of the blank server screen.

GameRuntime now adds the same game ResourcesLoader to the Application Resources
in the hosted :game process before SDK initialization. Application-context
SDK lookups can see the game resources as well as Activity lookups. No Context
accessor overrides are introduced: the inherited JNI method owner compatibility
is preserved. The separate launcher process keeps its host resources. Public
resource-name availability markers are written to the launch journal, without
logging resource values, OAuth URLs, credentials or tokens.

Before starting the game (after the existing running-process guard), the host
sets only content_log_file:1 in its own Minecraft options.txt profiles. That
exact option name is present in the supplied game library. Existing unrelated
lines and line endings are preserved; an existing options.txt is copied once
to options.txt.kulich-before-content-log before replacement. The original
installed game's private data is never inspected or changed. On fresh installs,
a minimal options file is created under the launcher's data storage path.
Existing profiles in internal files and external app files are also recognized.
The replacement is atomic where supported. Link/directory/size guards apply.
A setup failure is recorded rather than blocking game launch. This configures
logging, not acceptance by the server or guaranteed creation of content logs.

Standalone tests cover preservation, backups, idempotence, fresh/external
profiles, symlink/size rejection and content-log collection. Java syntax parsing
is not Android type checking. GitHub Actions must build the APK; resource
availability, actual file logging, sign-in and server behavior require a phone.
Fast Exp native sources and XAL auth declarations are unchanged from 0.28.

# Bedrock Crash Capture 0.28 — content-log storage roots

The user clarified that the recorded blank server screen also occurred at
home with their normal connection. The mobile-data permission dialog does not
establish the cause. The report contains no fatal crash or server error.

The game log explicitly selects CurrentFileStoragePath as the application
data directory, which is above files/. 0.27 only searched files/ and external
app files. Its missing-content-log result could therefore be a collector gap.
0.28 includes the app data directory and prioritizes games/com.mojang/logs and
logs under each app-owned root before bounded traversal. Named-file and
symlink safeguards, byte/file limits, native bridge, auth and menu are unchanged.
It only reads existing content logs; it does not enable logging or edit game
options. If logging is disabled, enable file output in Minecraft Creator settings.

Standalone tests cover the data-directory case and log priority despite more
than 2048 cache files, along with previous export bounds and symlink tests.
Java syntax parsing is not an Android build. Device testing is still required.
This fixes a diagnostic collector omission, not a confirmed server-login cause.

# Bedrock Crash Capture 0.27 — server-screen diagnostics

The user reports that Nevertime works in the separately installed Minecraft,
but the hosted game displays a blank in-game screen after joining. The new
0.26 report contains no fatal exception or native crash: its only recorded
exit is the user-requested Android Settings force stop. It does not provide a
server disconnect reason or prove that the blank screen is an OAuth failure.
The unrelated telemetry database and Play services warnings are not treated
as the established cause.

This version adds a Journal button to the kulich menu header. It opens the
launcher diagnostics in a separate task, leaving the game Activity in its
own task. Android lifecycle pause still disables Fast Exp. No task-clearing
flags, process termination or sign-in restart are performed by this button.
The system document picker remains the destination for the Save Journal button.

Reports also collect up to three named Minecraft ContentLog text files from
this app's internal files and external app files, with a total 256 KiB byte
budget. Traversal is bounded and rejects symlinks. It never searches the
separately installed game's private data or reads arbitrary account files.
If Minecraft has not written content logs, the report says so; the user can
enable content-log file output in Minecraft Creator settings before joining.

This is a diagnostic and recovery change, not a confirmed fix for server login.
Fast Exp native code, game resources, and XAL authentication are unchanged.
Java parsing and standalone content-log tests can run locally. Android build,
menu navigation and Nevertime behavior require GitHub Actions/device testing.

# Bedrock Crash Capture 0.26 — XAL browser return handler

The user's 0.25 report shows BrowserLaunchActivity creating its SDK session,
selecting Chrome Custom Tabs and launching the browser. On return the SDK logs
onResume() with no intent data and cancels the operation. The process exits
normally. This does not establish a completed account sign-in or explain the
browser page's error message, which was not present in the journal.

The installed game's public Activity metadata names an exported singleTask
com.microsoft.xal.browser.IntentHandler. That component was missing in the
host. The exact literal `ms-xal-0000000048183522://auth` is present in the
supplied game library. 0.26 declares that SDK return Activity with precisely
this scheme and host, VIEW/DEFAULT/BROWSABLE, exported=true and :game process.
GameFactory loads it with the existing game loader. The pre-created extras
loader repair also applies to this XAL browser class. The original SDK handler
receives the URI and handles its state; no code, token or redirect data is
rewritten or logged by the host.

Both the original installed game and this launcher may handle the same custom
URI. If Android presents a chooser after Microsoft login, the user must select
Bedrock Crash Capture for this session. No default is forced or other handler
disabled. If the game process was killed while the browser was open, native
pending auth state cannot be fabricated; the existing factory failure path
asks the user to restart sign-in from the game.

Native Fast Exp code is byte-for-byte unchanged from confirmed working 0.23.
This patch addresses delivery of the browser response; successful sign-in,
subsequent account permissions and server acceptance remain device checks.
No guarantee of admission to arbitrary servers is made. Any error shown by the
Microsoft page needs its own text/code to diagnose beyond this journal.

Local validation: Java syntax parsing; XML handler/process/export/mode/filter
checks; exact callback literal found in supplied ELF; loader routing and native
source identity checks; ZIP CRC and existing workflow selection. Android build
and actual OAuth round-trip are not performed locally.

Build versionCode25 / versionName0.26 with Build latest launch test, try login
and save bedrock-crash-capture-0.26.txt. The useful next markers are the SDK
IntentHandler construction, BrowserLaunchActivity receiving return intent data,
and the game's sign-in outcome. Do not infer success from merely opening Chrome.

# Bedrock Crash Capture 0.25 — XAL Serializable extras loader

The 0.24 report confirms BrowserLaunchActivity is now instantiated through the
game loader. Its onCreate then fails reading BrowserLaunchParameters.FromArgs:
BadParcelableException / ClassNotFoundException for
BrowserLaunchActivity$ShowUrlType. Parcel attempts to resolve that SDK enum
through the host APK loader. The enum is supplied by the game's DEX.

0.25 sets the authentication intent extras loader in the factory, then repairs
it again using Application.ActivityLifecycleCallbacks.onActivityPreCreated.
The pre-created hook runs before the SDK's onCreate reads its parameters and
also assigns the game loader to saved state. This uses the public API available
on API29+ (the app's minimum is 30). No enum is redefined, converted or replaced.
No intent extras, URL, token or credentials are logged by the hook.

BrowserLaunchActivity's launchMode is set to singleTask, matching the original
installed-game metadata recorded in 0.24 (launchMode=2). Exported=false and the
:game process are retained. The existing unprepared-process guard remains.
The current failure is distinct from the earlier missing-component failure.

The native Fast Exp sources remain unchanged from confirmed working 0.23.
Full account sign-in/browser-return/server acceptance still require device
verification; this patch specifically addresses SDK parameter deserialization.
No OAuth client identity or return scheme is guessed or fabricated here.

Local validation: 26 Java files syntax-parsed, manifest process/launch-mode and
pre-created class-loader routing inspected, archive CRC/version/selection
verified. Android SDK compilation and runtime sign-in are not tested locally.
Build versionCode24 / versionName0.25 with Build latest launch test. Try login
and export bedrock-crash-capture-0.25.txt after success or failure.

# Bedrock Crash Capture 0.24 — XAL browser component

The user's 0.23 login report confirms ActivityNotFoundException for the explicit
component com.microsoft.xal.browser.BrowserLaunchActivity in the diagnostic
package. The native SDK subsequently calls JNI GetMethodID with that pending
exception, causing SIGABRT. This is a launcher component-registration failure;
it is not evidence that Fast Exp interferes with authentication.

0.24 declares that exact SDK Activity in the host manifest, unexported and in
the existing :game process. GameFactory instantiates it with the already
prepared game DexClassLoader, where the installed game's XAL SDK resides.
It does not call GameRuntime.prepare on the SDK's authentication intent or
replace the SDK Activity implementation. A restarted/unprepared game process
fails through the existing launch-failure Activity rather than attempting a
callback with stale native process state.

The manifest also permits browser VIEW/http/https and Custom Tabs service
queries needed on Android 11+. No OAuth scheme/client ID/redirect, token,
account identity or credential storage is fabricated. Browser-return handling,
account sign-in and server acceptance still require device verification. If
the next phase needs additional components or original redirect metadata, those
must be established from the real SDK/installed game and the next error.

Before game launch the journal inventories relevant installed-game Activity
names and public launch metadata. It does not log authentication intent extras,
OAuth URLs or credentials. Existing native Fast Exp sources are byte-for-byte
unchanged from the version the user confirmed works. Dump/text export remain.

VersionCode 23 / versionName 0.24; debug package remains
`dev.custom.bedrocklaunchtest.crashcapture`. Build with the existing **Build
latest launch test** archive workflow. On the phone try Microsoft sign-in and
export **bedrock-crash-capture-0.24.txt** after success or failure. The missing
initial Activity is addressed; full account/server compatibility is not yet
claimed. No guarantee of admission to every server is made.

Validation: Java syntax parsing and manifest/component/factory routing checks
performed locally. Android SDK/NDK compilation and sign-in runtime behavior
remain pending GitHub Actions/device tests. No login was performed here.

# Bedrock Crash Capture 0.23 — corrected client item-use call

This diagnostic build fixes the specific native argument mismatch established
by the user's 0.22 minidump. It retains the separate package and dump export
button introduced in 0.22. It has not yet been compiled with the Android SDK
or executed on the user's phone in this workspace.

## Dump evidence and the incorrect route

The 0.22 minidump contains SIGSEGV at libminecraftpe.so+0xfd898cc, fault
address 0x38. The instruction loads from a null ECS registry via x9. Its x0
is the exact tagged held ItemStack address also recorded in the user's text
log. The caller chain passes through +0x100a3770 and +0x1009cd00, then our
libkulichbridge. This is Actor interaction receiving an ItemStack in place
of an Actor. The slot-16 selection in 0.21–0.22 was wrong. It is removed.

The correct direct client item-use wrapper is 0x1009fdcc. The game's ordinary
input handler calls it at 0x9b6e6ec, with x0=GameMode, x1=ItemStack and w2=0.
The method builds the native item-use transaction (type 2) and on its client
path passes it to the player's virtual method at +1824. The module now calls
that same function with the validated live tagged ItemStack and false flag.
There is no Vec3 argument and no invocation of Actor interaction slot 16.

Before installation and each resolved action, the bridge checks the first
32 bytes of the exact entry function as well as the prior GameMode low-level
method profile. The existing complete game-file SHA-256 guard remains.
Unexpected code bytes reject actions; no alternate address is guessed.
The return register is not treated as proof that a projectile was spawned.
Calls/completed/inFlight remain diagnostic counters.

## Behavior and limits

Actions remain on the original LocalPlayer update thread, after its original
handler returns. Mode/player/client backlinks, selected slot, live XP item,
count, vector bounds and snapshots are checked again. Pointer tags are retained
for native arguments. The interval slider remains 1..10 local update ticks.
Three repeated callbacks are required before action. The UI lease, focus/menu
pause and onPause disabling remain. Fast Exp starts disabled.

The diagnostic dump explains the reported SIGSEGV, but the new wrapper's live
item behavior and actual XP projectiles still need device confirmation. Other
faults may remain. Auto Buy and Block Trap are not implemented.

## Separate install and export

The debug application ID remains
`dev.custom.bedrocklaunchtest.crashcapture`, label **Bedrock Crash Capture**.
The original launcher `dev.custom.bedrocklaunchtest` is a separate application.
This is an update of the diagnostic app, not access to the original app's data.
The uploaded 0.22 dump is already preserved outside the app for analysis.

The default applicationId literal is kept for the user's existing source ZIP
selector. The debug applicationIdSuffix is `.crashcapture`; a Gradle variant
assertion and the direct workflow's actual-APK check require the separate ID.
Only :app:assembleDebug is intended. VersionCode 22 / versionName 0.23 cause
**Build latest launch test** to select this source over 0.22.

The dump button uses ACTION_CREATE_DOCUMENT and gzip compression of only a
valid regular MDMP file in this app's private crash directory. It never deletes
or changes the source and needs no Termux/Shizuku or storage permission. Source
size, time, header and canonical parent are checked. The ordinary text journal
is also exportable. Native bridge debug symbols stay in the APK.

## Device verification

Build/install diagnostic 0.23 using the existing archive workflow. In an ordinary
single-player test world hold XP bottles, run Проверить подключение, enable
Fast Exp and close kulich for five seconds. Observe actual projectiles, reopen
kulich, disable and export bedrock-crash-capture-0.23.txt. If a new crash occurs,
use Сохранить дамп падения and export bedrock-crash-capture-0.23.dmp.gz.
The native status includes route=item-use to distinguish the corrected route.

## Validation performed here

- The exception context and frame-pointer chain were parsed from the real dump.
- The actual game binary confirms the fault instruction, canonical call target,
  false flag instruction and all 32 checked entry bytes.
- Native host tests pass for correct item-use arguments, mismatched code profile,
  independence from the Actor interaction slot, GameMode and SurvivalMode, tagged
  arguments, post-update replacement, item ownership, bounds and tick intervals.
- Native host C++ syntax checks and Java source syntax parsing pass.
- Existing binary dump-export tests pass, including source preservation.

These checks do not compile Android JNI/NDK code or execute Minecraft. Android
build and device execution remain pending. Toolchain: JDK17/Gradle8.7/AGP8.6.1,
SDK35, NDK27.0.12077973/CMake3.22.1, ARM64. Minimum30, target34, compile35.
