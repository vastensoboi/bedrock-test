package dev.custom.bedrockgui;
import java.nio.charset.StandardCharsets;
import java.util.regex.*;
/** Read-only view of a native hit event; future modules can publish the same model. */
public final class TargetHudData {
    public final String name,rank;public final float hp,maxHp;public final int state,actualCps,configuredCps,configuredMinCps;
    public TargetHudData(String name,String rank,float hp){this(name,rank,hp,Float.NaN,0,0,0);}
    public TargetHudData(String name,String rank,float hp,float maxHp,int state,int actual,int configured){this(name,rank,hp,maxHp,state,actual,configured,configured);}
    public TargetHudData(String name,String rank,float hp,float maxHp,int state,int actual,int configured,int minimum){this.configuredMinCps=minimum;this.name=name;this.rank=rank;this.hp=hp;this.maxHp=maxHp;this.state=state;this.actualCps=actual;this.configuredCps=configured;}
    public static TargetHudData parse(String snapshot){
        if(snapshot==null||snapshot.isEmpty())return null;
        try{
            String[] parts=snapshot.split("\\|",-1);if(parts.length!=3&&parts.length!=7&&parts.length!=8)return null;
            long age=Long.parseLong(parts[0]);if(age<0||age>5000)return null;
            float hp=parts[1].equalsIgnoreCase("nan")?Float.NaN:Float.parseFloat(parts[1]);if(!Float.isNaN(hp)&&(!Float.isFinite(hp)||hp<0||hp>100000))return null;
            String hex=parts[2];if(hex.length()>768||hex.length()%2!=0)return null;byte[] bytes=new byte[hex.length()/2];
            for(int i=0;i<bytes.length;i++){int high=Character.digit(hex.charAt(i*2),16),low=Character.digit(hex.charAt(i*2+1),16);if(high<0||low<0)return null;bytes[i]=(byte)((high<<4)|low);}
            String text=new String(bytes,StandardCharsets.UTF_8).replaceAll("§[0-9a-zA-Z]","").replace('\r','\n').split("\n",2)[0].trim();
            String rank="Не указана",name=text.isEmpty()?"Имя недоступно":text;
            Matcher match=Pattern.compile("^\\[([^\\]\\n]{1,32})\\]\\s*([A-Za-z0-9_]{1,16})(?:\\s.*)?$").matcher(text);
            if(match.matches()){rank=match.group(1);name=match.group(2);}
            float maxHp=Float.NaN;int state=0,actual=0,configured=0,minimum=0;
            if(parts.length>=7){maxHp=parts[3].equalsIgnoreCase("nan")?Float.NaN:Float.parseFloat(parts[3]);state=Integer.parseInt(parts[4]);actual=Integer.parseInt(parts[5]);configured=Integer.parseInt(parts[6]);if(state<0||state>7||actual<0||actual>60||configured<1||configured>40)return null;if(!Float.isFinite(maxHp)||maxHp<=0||maxHp<hp||maxHp>100000)maxHp=Float.NaN;}
            if(parts.length>=7){minimum=parts.length==8?Integer.parseInt(parts[7]):configured;if(minimum<1||minimum>configured)return null;}
            return new TargetHudData(name,rank,hp,maxHp,state,actual,configured,minimum);
        }catch(RuntimeException error){return null;}
    }
}
