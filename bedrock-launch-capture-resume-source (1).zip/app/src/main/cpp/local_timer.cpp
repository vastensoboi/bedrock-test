#include "local_timer_core.h"
#include "local_use_time_core.h"
#include "swing_timer_core.h"
#include <jni.h>
#include <atomic>
#include <chrono>
#include <mutex>
#include <vector>
#include <string>
#include <iterator>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cerrno>

namespace {
using kulich_aim::A;using kulich_aim::plain;
namespace move=kulich_timer_move;namespace use=kulich_use_timer;namespace swing=kulich_swing;
using Bulk=void(*)(void*,void*);using Single=void(*)(void*,void*,void*);using PlayerUpdate=void(*)(void*);
std::atomic<A> gameBase{0},boundClient{0};
std::atomic<bool> enabled{false};std::atomic<int> multiplier{110};
std::atomic<int64_t> lease{0};std::atomic<uint64_t> epoch{1};
std::atomic<uint64_t> calls{0},groundChanges{0},waterChanges{0},airChanges{0},useExtra{0},swingChanges{0};
int memory=-1;std::mutex installGate;bool installed=false,usable=false;
thread_local unsigned depth=0;
struct ThreadState {
 uint64_t generation=0;use::UseClock useClock;swing::Clock swingClock;
 void reset(uint64_t value){generation=value;useClock.reset();swingClock.reset();}
};
thread_local ThreadState state;
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(A address,void* out,size_t size){
 address=plain(address);
 if(memory<0||address<4096||size>65536||address>0x00ffffffffffffffULL-size)return false;
 ssize_t count;do{count=pread(memory,out,size,static_cast<off_t>(address));}while(count<0&&errno==EINTR);
 return count==ssize_t(size);
}
bool writeFloat(A address,float value){
 if(plain(address)<4096||(plain(address)&3)||!std::isfinite(value))return false;
 std::memcpy(reinterpret_cast<void*>(address),&value,4);return true;
}
bool writeCounter(A address,int32_t value){
 if(plain(address)<4096||(plain(address)&3)||value< -1||value>72000)return false;
 std::memcpy(reinterpret_cast<void*>(address),&value,4);return true;
}
bool active(){
 uint64_t current=epoch.load(std::memory_order_acquire);
 if(state.generation!=current)state.reset(current);
 if(!enabled.load(std::memory_order_acquire)||now()>lease.load()||multiplier.load()<=100){state.reset(current);return false;}
 return true;
}
struct Guard {Guard(){++depth;}~Guard(){--depth;}};
enum Kind {Ground2,Ground1,Water,AirBulk,AirSingle,UseMoveBulk,UseMoveSingle,UseOrdinaryBulk,UseOrdinarySingle,Swing};
struct Hook {A entry,expected,original=0,replacement=0;Kind kind;};
Hook hooks[]={
 {move::GROUND_V2_TABLE+48,move::GROUND_V2_BULK,0,0,Ground2},
 {move::GROUND_V1_TABLE+48,move::GROUND_V1_BULK,0,0,Ground1},
 {move::WATER_TABLE+48,move::WATER_BULK,0,0,Water},
 {move::AIR_TABLE+48,move::AIR_BULK,0,0,AirBulk},
 {move::AIR_TABLE+56,move::AIR_SINGLE,0,0,AirSingle},
 {use::hooks[0].table+48,use::hooks[0].bulk,0,0,UseMoveBulk},
 {use::hooks[0].table+56,use::hooks[0].single,0,0,UseMoveSingle},
 {use::hooks[1].table+48,use::hooks[1].bulk,0,0,UseOrdinaryBulk},
 {use::hooks[1].table+56,use::hooks[1].single,0,0,UseOrdinarySingle},
 {swing::LOCAL_TABLE+swing::SLOT*8,swing::UPDATE,0,0,Swing}
};
template<class Original>void around(unsigned index,void* system,void* entity,Original original){
 calls.fetch_add(1,std::memory_order_relaxed);
 if(depth||!active()){original();return;}
 Guard scope;A base=gameBase.load(),client=boundClient.load();int factor=multiplier.load();
 auto read=readMemory;auto floatWrite=writeFloat;auto counterWrite=writeCounter;
 switch(hooks[index].kind){
  case Ground2:case Ground1:case Water:{
   Kind kind=hooks[index].kind;A table=kind==Ground2?move::GROUND_V2_TABLE:kind==Ground1?move::GROUND_V1_TABLE:move::WATER_TABLE;
   auto lookup=[&](size_t field,move::Scalar& value){return move::input(read,base,client,reinterpret_cast<A>(system),table,kind==Water?move::WATER:move::GROUND,value,unsigned(field));};
   // Water blends its water-speed and land-speed attributes. Scaling both
   // preserves that native blend; neither path reads MovementSpeed for players.
   bool changed=kind==Water?move::invokeInputs<2>(floatWrite,lookup,original,factor):move::invokeInputs<1>(floatWrite,lookup,original,factor);
   if(changed){
    if(kind==Water)waterChanges.fetch_add(1,std::memory_order_relaxed);else groundChanges.fetch_add(1,std::memory_order_relaxed);
   }
   break;
  }
  case AirBulk:case AirSingle:{
   auto lookup=[&](move::Scalar& value){return move::airOutput(read,base,client,reinterpret_cast<A>(system),reinterpret_cast<A>(entity),value);};
   if(move::invokeAir(floatWrite,lookup,original,factor))airChanges.fetch_add(1,std::memory_order_relaxed);
   break;
  }
  case UseMoveBulk:case UseMoveSingle:case UseOrdinaryBulk:case UseOrdinarySingle:{
   auto phase=(hooks[index].kind==UseMoveBulk||hooks[index].kind==UseMoveSingle)?use::Phase::Movement:use::Phase::Ordinary;
   auto lookup=[&](use::Binding& value){return use::resolve(read,base,client,reinterpret_cast<A>(system),reinterpret_cast<A>(entity),phase,value);};
   // The helper preserves cadence on calls for the other phase/another actor;
   // neither can turn fractional x1.10 progress into repeated x1.00 resets.
   useExtra.fetch_add(use::invoke(state.useClock,counterWrite,lookup,original,true,factor),std::memory_order_relaxed);
   break;
  }
  case Swing:{
   A self=reinterpret_cast<A>(system);
   if(kulich_aim::pointer(read,plain(self)+3240)!=client){original();break;}
   auto lookup=[&](swing::Binding& value){return swing::resolve(read,base,client,self,value);};
   if(swing::invoke(state.swingClock,lookup,counterWrite,original,factor,true))swingChanges.fetch_add(1,std::memory_order_relaxed);
   break;
  }
 }
}
template<unsigned I>void bulk(void* system,void* view){around(I,system,nullptr,[&](){reinterpret_cast<Bulk>(hooks[I].original)(system,view);});}
template<unsigned I>void single(void* system,void* view,void* entity){around(I,system,entity,[&](){reinterpret_cast<Single>(hooks[I].original)(system,view,entity);});}
void player(void* self){around(9,self,nullptr,[&](){reinterpret_cast<PlayerUpdate>(hooks[9].original)(self);});}
struct Profile {A offset;uint32_t words[8];size_t count=8;};
constexpr Profile movementProfiles[]={
 {move::GROUND_V2_BULK,{0xd100c3ffU,0xa9017bfdU,0xa9024ff4U,0x910043fdU,0xd53bd054U,0xaa0003f3U,0xf9401688U,0xf90007e8U}},
 {move::GROUND_V1_BULK,{0xd100c3ffU,0xa9017bfdU,0xa9024ff4U,0x910043fdU,0xd53bd054U,0xaa0003f3U,0xf9401688U,0xf90007e8U}},
 {move::WATER_BULK,{0xd10583ffU,0xa9107bfdU,0xf9008bfcU,0xa91267faU,0xa9135ff8U,0xa91457f6U,0xa9154ff4U,0x910403fdU}},
 {move::AIR_BULK,{0xd10243ffU,0xfd0013e8U,0xa9037bfdU,0xa9046ffcU,0xa90567faU,0xa9065ff8U,0xa90757f6U,0xa9084ff4U}},
 {move::AIR_SINGLE,{0xd10103ffU,0xa9017bfdU,0xa90257f6U,0xa9034ff4U,0x910043fdU,0xd53bd056U,0xaa0203f5U,0xaa0003f3U}},
 // Player selection, optional attributes, actual call sites, and the shared
 // component layout must agree; wrapper prologues alone do not prove inputs.
 {0xcd27160ULL,{0x36000042U,0x15477badU,0xbd400020U,0xd65f03c0U},4},
 {0x11f06018ULL,{0x2f00e400U,0x39401008U,0xbd400001U,0x7100011fU,0x1e210c00U,0xd65f03c0U},6},
 {0x11f06030ULL,{0x2f00e400U,0x39403008U,0xbd400801U,0x7100011fU,0x1e210c00U,0xd65f03c0U},6},
 {0xc1af970ULL,{0xaa1a03e0U,0xaa1903e1U,0x942dddfaU},3},
 {0xc1b0a00ULL,{0xaa1a03e0U,0xaa1903e1U,0x942dd9d6U},3},
 {0xcdb6684ULL,{0xaa1903e0U,0xaa1803e1U,0x97fdc2b5U},3},
 {0xc1aef14ULL,{0x5294d181U,0xaa0003f5U,0x9100a320U,0x72b4f2a1U,0x976ab1edU},5},
 {0xc1afda8ULL,{0x52800908U},1},
 {0xc1afedcULL,{0x9ba825c4U},1}
};
bool expectedMapping(A page,A size){
 FILE* maps=fopen("/proc/self/maps","r");if(!maps)return false;
 char line[2048],perms[5]{};unsigned long long first=0,last=0;bool valid=false;
 while(fgets(line,sizeof line,maps))if(sscanf(line,"%llx-%llx %4s",&first,&last,perms)==3&&page>=first&&page+size<=last){
  valid=perms[0]=='r'&&perms[1]=='-'&&perms[2]=='-'&&std::string(line).find("/libminecraftpe.so")!=std::string::npos;break;
 }
 fclose(maps);return valid;
}
std::string install(A base,A client){
 std::lock_guard<std::mutex> lock(installGate);client=plain(client);
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0||kulich_aim::pointer(readMemory,client)!=base+0x1388fe70ULL)return "Timer local client binding unavailable";
 if(installed){
  if(gameBase.load()!=base)return "Game library base changed";
  if(!usable)return "Timer callback protection failed during installation";
  boundClient.store(client);epoch.fetch_add(1);return {};
 }
 for(const auto& profile:movementProfiles){uint32_t words[8]{};size_t bytes=profile.count*sizeof(uint32_t);if(!readMemory(base+profile.offset,words,bytes)||std::memcmp(words,profile.words,bytes))return "Timer movement code profile mismatch";}
 if(!use::profileValid(readMemory,base)||!swing::profile(readMemory,base))return "Timer action code profile mismatch";
 const A replacements[]={reinterpret_cast<A>(&bulk<0>),reinterpret_cast<A>(&bulk<1>),reinterpret_cast<A>(&bulk<2>),reinterpret_cast<A>(&bulk<3>),reinterpret_cast<A>(&single<4>),reinterpret_cast<A>(&bulk<5>),reinterpret_cast<A>(&single<6>),reinterpret_cast<A>(&bulk<7>),reinterpret_cast<A>(&single<8>),reinterpret_cast<A>(&player)};
 long pageSize=sysconf(_SC_PAGESIZE);if(pageSize<=0)return "Invalid page size";
 std::vector<A> pages;
 for(size_t i=0;i<std::size(hooks);i++){
  auto& hook=hooks[i];A original=0,entry=base+hook.entry;
  if(!readMemory(entry,&original,8)||original!=base+hook.expected)return "Timer callback binding mismatch";
  A page=entry-entry%A(pageSize);if(entry+8>page+A(pageSize))return "Unexpected Timer callback page";
  if(std::find(pages.begin(),pages.end(),page)==pages.end()){if(!expectedMapping(page,A(pageSize)))return "Unexpected Timer callback mapping";pages.push_back(page);}
  hook.original=original;hook.replacement=replacements[i];
 }
 size_t writable=0;
 for(A page:pages){
  if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ|PROT_WRITE)){
   for(size_t i=0;i<writable;i++)mprotect(reinterpret_cast<void*>(pages[i]),pageSize,PROT_READ);
   return "Cannot update Timer callback pages";
  }
  ++writable;
 }
 boundClient.store(client);gameBase.store(base);installed=true;enabled.store(false);
 for(const auto& hook:hooks)__atomic_store_n(reinterpret_cast<A*>(base+hook.entry),hook.replacement,__ATOMIC_RELEASE);
 usable=true;
 for(A page:pages)if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ))usable=false;
 if(!usable){
  // If protection restoration failed, disable all effects. Roll back every
  // entry only after all its pages are writable; pass-through wrappers remain
  // valid if the OS prevents a complete rollback.
  bool allWritable=true;
  for(A page:pages)if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ|PROT_WRITE))allWritable=false;
  if(allWritable){for(const auto& hook:hooks)__atomic_store_n(reinterpret_cast<A*>(base+hook.entry),hook.original,__ATOMIC_RELEASE);installed=false;gameBase.store(0);}
  for(A page:pages)mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ);
  return "Cannot restore Timer callback protection";
 }
 return {};
}
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_LocalTimerBridge_install(JNIEnv* env,jclass,jlong base,jlong client){auto result=install(A(base),A(client));return env->NewStringUTF(result.c_str());}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_LocalTimerBridge_enable(JNIEnv*,jclass,jboolean value){enabled.store(bool(value));lease.store(0);epoch.fetch_add(1);}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_LocalTimerBridge_pulse(JNIEnv*,jclass,jboolean value){lease.store(value?now()+1200:0);}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_LocalTimerBridge_settings(JNIEnv*,jclass,jint value){multiplier.store(move::clamp(int(value)));epoch.fetch_add(1);}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_LocalTimerBridge_status(JNIEnv* env,jclass){
 char result[640];
 snprintf(result,sizeof result,"Local Timer: enabled=%d multiplier=%.2f calls=%llu ground=%llu water=%llu air=%llu extraUseTicks=%llu swing=%llu route=own-player-attributes/use-duration/swing; worldTPS=unchanged gravity=unchanged otherActors=unchanged serverAcceptance=unverified",enabled.load(),multiplier.load()/100.0,static_cast<unsigned long long>(calls.load()),static_cast<unsigned long long>(groundChanges.load()),static_cast<unsigned long long>(waterChanges.load()),static_cast<unsigned long long>(airChanges.load()),static_cast<unsigned long long>(useExtra.load()),static_cast<unsigned long long>(swingChanges.load()));
 return env->NewStringUTF(result);
}
