#include "../app/src/main/cpp/movement_correction_core.h"
#include <cassert>
#include <vector>
#include <iostream>
using namespace kulich_correction;
struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;
 std::vector<unsigned char> bytes=std::vector<unsigned char>(0x40000);A next=root+0x10000;
 template<class T>void put(A at,T value){at=plain(at);assert(at>=root&&at-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+at-root,&value,sizeof value);}
 A alloc(size_t size){A at=next;next=(next+size+7)&~A(7);assert(next-root<bytes.size());return at;}
 bool operator()(A at,void* out,size_t size){
  assert(at==plain(at));
  if(at<root||at-root>bytes.size()||size>bytes.size()-(at-root))return false;
  std::memcpy(out,bytes.data()+at-root,size);return true;
 }
};
A storage(Memory& m,uint32_t entity,unsigned stride){
 A pool=m.alloc(104),vector=m.alloc(8),sparsePage=m.alloc(8192),pages=m.alloc(8),payload=m.alloc(128*stride);
 std::fill(m.bytes.begin()+sparsePage-Memory::root,m.bytes.begin()+sparsePage-Memory::root+8192,255);
 m.put(pool+8,vector);m.put(pool+16,vector+8);m.put(vector,sparsePage);m.put(sparsePage+(entity&2047)*4,entity&0xfffc0000U);
 m.put(pool+80,pages);m.put(pool+88,pages+8);m.put(pool+96,pages+8);m.put(pages,payload|Memory::tag);return pool;
}
int main(){
 Memory m;constexpr A base=0x10000000,client=Memory::root+0x1000,registry=Memory::root+0x3000;
 constexpr A actorAddress=Memory::root+0x5000,handler=Memory::root+0x7000,packet=Memory::root+0x8000;
 constexpr uint32_t id=0x40001;constexpr uint64_t runtime=0x987654321234ULL;
 uint32_t keys[]{OWNER,SHAPE,ROTATION,RUNTIME_ID};unsigned strides[]{8,32,16,8};A pools[4]{};
 for(int i=0;i<4;++i)pools[i]=storage(m,id,strides[i]);
 A buckets=m.alloc(128),nodes=m.alloc(4*32);for(int i=0;i<16;++i)m.put<int64_t>(buckets+i*8,-1);
 for(int i=0;i<4;++i){int64_t prev=-1;m(buckets+(keys[i]&15)*8,&prev,8);m.put(nodes+i*32,prev);m.put(nodes+i*32+8,keys[i]);m.put(nodes+i*32+16,pools[i]);m.put<int64_t>(buckets+(keys[i]&15)*8,i);}
 m.put(registry+96,buckets);m.put(registry+104,buckets+128);m.put(registry+120,nodes);m.put(registry+128,nodes+4*32);
 A entityPages=m.alloc(8),entitySparse=m.alloc(8192);
 m.put(registry+216,entityPages);m.put(registry+224,entityPages+8);m.put(entityPages,entitySparse);m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|1);
 m.put(client,base+CLIENT);m.put(client+576,std::array<A,3>{registry|Memory::tag,(Memory::root+0x9000)|Memory::tag,id});
 m.put(actorAddress,base+0x139f6ea0ULL);m.put(actorAddress+8,registry);m.put(actorAddress+16,registry+40);m.put(actorAddress+24,id);m.put(actorAddress+3240,client);
 m.put(component(m,pools[0],id,8),actorAddress|Memory::tag);
 A shape=component(m,pools[1],id,32),rotation=component(m,pools[2],id,16),runtimeAddress=component(m,pools[3],id,8);
 m.put(actorAddress+560,shape);m.put(actorAddress+568,rotation);
 m.put(shape,Box{{-.3f,0,-.3f},{.3f,1.8f,.3f},.6f,1.8f});m.put(rotation,Angles{});m.put(runtimeAddress,runtime);
 m.put(handler,base+HANDLER);m.put(handler+88,client|Memory::tag);m.put(packet,base+CORRECT_PACKET);
 Binding value{};auto prediction=[&](){return capture(m,base,client|Memory::tag,handler|Memory::tag,packet|Memory::tag,value);};
 assert(prediction()&&value.client==client&&value.registry==registry&&value.actor==actorAddress&&value.entity==id);
 m.put(handler,base+LEGACY);assert(prediction());
 m.put(handler+88,client+8);assert(!prediction());m.put(handler+88,client|Memory::tag);
 m.put(packet,base+MOVE_PACKET);assert(!prediction());m.put(packet,base+CORRECT_PACKET);
 m.put(actorAddress+3240,client+8);assert(!prediction());m.put(actorAddress+3240,client);
 m.put(client+576,std::array<A,3>{registry,0,id});assert(!prediction());m.put(client+576,std::array<A,3>{registry,Memory::root+0x9000,id});
 m.put(actorAddress+24,id+1);assert(!prediction());m.put(actorAddress+24,id);
 m.put(entitySparse+(id&2047)*4,uint32_t(0x80001));assert(!prediction());m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|1);
 m.put<uint8_t>(actorAddress+617,1);assert(!prediction());m.put<uint8_t>(actorAddress+617,0);
 auto unreadable=[](A,void*,size_t){return false;};assert(!capture(unreadable,base,client,handler,packet,value));
 unsigned weakReads=0;auto recycled=[&](A at,void* out,size_t size){
  if(at==client+576&&++weakReads==2)m.put(actorAddress+24,id+1);
  return m(at,out,size);
 };
 assert(!capture(recycled,base,client,handler,packet,value));m.put(actorAddress+24,id);
 unsigned packetReads=0;auto changedPacket=[&](A at,void* out,size_t size){
  if(at==packet&&++packetReads==2)m.put(packet,base+MOVE_PACKET);
  return m(at,out,size);
 };
 assert(!capture(changedPacket,base,client,handler,packet,value));
 m.put(packet,base+MOVE_PACKET);m.put(packet+48,runtime);m.put<uint8_t>(packet+80,2);
 auto move=[&](){return capture(m,base,client,handler,packet,value,Kind::MovePlayer);};
 assert(move()&&value.runtimeId==runtime&&value.mode==2);
 m.put(handler,base+HANDLER);assert(!move());m.put(handler,base+LEGACY);
 // Other players' updates must be rejected before any actor graph read.
 m.put(packet+48,runtime+1);unsigned actorReads=0;
 auto cheap=[&](A at,void* out,size_t size){if(at==actorAddress)++actorReads;return m(at,out,size);};
 assert(!capture(cheap,base,client,handler,packet,value,Kind::MovePlayer)&&actorReads==0);m.put(packet+48,runtime);
 m.put(runtimeAddress,uint64_t(0));assert(!move());m.put(runtimeAddress,runtime);
 weakReads=0;auto changedRuntime=[&](A at,void* out,size_t size){if(at==client+576&&++weakReads==2)m.put(runtimeAddress,runtime+1);return m(at,out,size);};
 assert(!capture(changedRuntime,base,client,handler,packet,value,Kind::MovePlayer));m.put(runtimeAddress,runtime);

 void* rawHandler=reinterpret_cast<void*>(handler|Memory::tag);
 void* rawNetwork=reinterpret_cast<void*>((Memory::root+0xa000)|Memory::tag);
 void* rawPacket=reinterpret_cast<void*>(packet|Memory::tag);
 unsigned forwarded=0,observed=0;
 auto original=[&](void* h,void* n,void* p){assert(h==rawHandler&&n==rawNetwork&&p==rawPacket);++forwarded;};
 forward([&](){++observed;assert(move());},original,rawHandler,rawNetwork,rawPacket);
 forward([&](){++observed;assert(!capture(unreadable,base,client,handler,packet,value));},original,rawHandler,rawNetwork,rawPacket);
 forward([&](){++observed;throw 7;},original,rawHandler,rawNetwork,rawPacket);
 assert(forwarded==3&&observed==3);
 bool nativeThrew=false;try{forward([](){},[&](void*,void*,void*){++forwarded;throw 9;},rawHandler,rawNetwork,rawPacket);}catch(int x){nativeThrew=x==9;}
 assert(nativeThrew&&forwarded==4);

 Book book;assert(age(100,book.lastOn)==-1);
 book.add(100,true,110,Kind::MovePlayer,2,id,runtime);
 for(int i=0;i<40;++i)book.add(200+i,false,100,Kind::Prediction,255,id+1);
 assert(book.size==16&&book.on==1&&book.off==40&&book.prediction==40&&book.moves==1);
 assert(book.lastOn.sequence==1&&book.lastOn.entity==id&&book.lastOn.runtimeId==runtime&&book.lastOn.mode==2);
 assert(book.lastOff.entity==id+1&&age(300,book.lastOn)==200&&age(300,book.lastOff)==61&&age(99,book.lastOn)==-1);
 auto description=describe(book,300);
 assert(description.find("timerOn=1 timerOff=40")!=std::string::npos&&description.find("lastOnPacket=19")!=std::string::npos&&description.find("lastOnAgeMs=200")!=std::string::npos);
 assert(description.find("lastOnRawMode=2")!=std::string::npos&&description.find("lastOnRuntimeId="+std::to_string(runtime))!=std::string::npos&&description.find("lastOffRawMode=unavailable")!=std::string::npos);
 assert(book.events[book.next].sequence==26); // First retained row after overflow.
 book.add(400,true,999);assert(book.lastOn.hundredths==200);
 book.add(401,true,1);assert(book.lastOn.hundredths==100);
 std::cout<<"PASS: typed inbound correction/client and weak local-actor filters; own runtime ID excludes remote MovePlayer before actor reads; stable generations and packets; raw tagged original forwarded once even observation fails; bounded phase-retaining ring and ages\n";
}
