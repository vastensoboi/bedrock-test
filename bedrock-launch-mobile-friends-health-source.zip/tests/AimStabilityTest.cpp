#include "../app/src/main/cpp/aim_stability.h"
#include <cassert>
#include <iostream>
using namespace kulich_aim;
Box box(float x,float y,float z){return {{x-.3f,y,z-.3f},{x+.3f,y+1.8f,z+.3f},.6f,1.8f};}
Angles goal(Vec eye,const Box& target,Angles view){Angles out{};assert(angles(eye,aimPoint(target,false),view.yaw,out));return out;}
int main(){
 AimStability stable;Vec eye{0,1.62,0};Angles view{0,90};Box target=box(0,0,3);
 auto desired=goal(eye,target,view);auto next=stable.apply(100,1,eye,target,view,desired,5);
 assert(angleGap(next,desired)<.001&&!stable.holding()); // sharp acquisition
 view=next;
 for(int i=0;i<1000;i++){
  Box jitter=box(float(.02*std::sin(i*.71)),float(.02*std::cos(i*.31)),float(3+.02*std::sin(i*.19)));
  Vec movingEye{.01*std::sin(i*.41),1.62+.01*std::cos(i*.51),0};
  next=stable.apply(100,1,movingEye,jitter,view,goal(movingEye,jitter,view),5);
  assert(stable.holding()&&angleGap(next,view)<.00001);
 }
 // Meaningful movement exits the retained chest region and tracks immediately.
 target=box(.9,0,3);desired=goal(eye,target,view);next=stable.apply(100,1,eye,target,view,desired,5);
 assert(!stable.holding()&&angleGap(next,desired)<.001&&angleGap(next,view)>10);
 view=next;stable.apply(100,1,eye,target,view,desired,5);assert(stable.holding());
 // New entity generation clears the old hold even if it occupies the same box.
 next=stable.apply(100,2,eye,target,view,desired,5);assert(!stable.holding()&&angleGap(next,desired)<.001);
 stable.reset();assert(!stable.holding()&&!stable.overlapping());
 // Crossed centres used to alternate raw yaw between -90 and +90. Contact
 // lock must never replay those 180 degree flips, while pitch remains bounded.
 view={60,17};
 for(int i=0;i<200;i++){
  target=box(i%2?.01f:-.01f,0,0);desired=goal(eye,target,view);
  next=stable.apply(200,3,eye,target,view,desired,5);
  assert(stable.overlapping()&&std::abs(next.yaw-view.yaw)<.0001&&std::abs(next.pitch)<=89.9);
  view=next;
 }
 target=box(.40,0,0);next=stable.apply(200,3,eye,target,view,goal(eye,target,view),5);assert(stable.overlapping());
 target=box(.46,0,0);desired=goal(eye,target,view);next=stable.apply(200,3,eye,target,view,desired,5);
 assert(!stable.overlapping()&&!stable.holding()&&angleGap(next,desired)<.001);
 // New targets acquire sharply even when old view crosses the torso region.
 target=box(0,0,3);desired=goal(eye,target,view);view=desired;view.yaw+=1;
 next=stable.apply(300,1,eye,target,view,desired,5);assert(!stable.holding()&&angleGap(next,desired)<.001);
 // Narrow/small valid boxes cannot accidentally retain an invalid inner box.
 target={{-.03f,0,3},{.03f,.11f,3.06f},.06f,.11f};desired=goal(eye,target,view);
 next=stable.apply(300,1,eye,target,view,desired,5);assert(!stable.holding()&&angleGap(next,desired)<.001);
 target=box(0,.54f,0);Angles coincident{};assert(stableAimAngles(eye,target,{22,77},coincident));assert(angleGap(coincident,{22,77})<.001);
 assert(!stableAimAngles({NAN,0,0},target,view,coincident));
 std::cout<<"PASS: sharp acquisition, stationary torso/eye jitter hold, moving target reacquisition, identity reset and overlap yaw hysteresis\n";
}
