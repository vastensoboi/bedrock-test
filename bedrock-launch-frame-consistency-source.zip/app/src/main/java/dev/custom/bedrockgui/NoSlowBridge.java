package dev.custom.bedrockgui;

/** Exact-build bridge for the local item-use movement modifier only. */
public final class NoSlowBridge {
    private static volatile boolean ready,enabled;
    private NoSlowBridge(){}
    private static native String install(long base,long client);
    private static native void enable(boolean value);
    private static native void pulse(boolean active);
    private static native String status();
    public static synchronized void prepare(long base,long client){
        if(!FastExpBridge.isReady())return;
        try{
            String error=install(base,client);
            if(error==null||!error.isEmpty())throw new IllegalStateException(error==null?"No native install result":error);
            ready=true;pulse(enabled);GameRuntime.log("No Slow: local movement modifier bridge prepared");
        }catch(RuntimeException|LinkageError error){
            ready=false;enabled=false;GameRuntime.log("No Slow unavailable: "+error);
        }
    }
    public static boolean isReady(){return ready;}
    public static boolean isEnabled(){return enabled;}
    public static synchronized void setEnabled(boolean value){
        if(value&&!ready)throw new IllegalStateException("Нужен загруженный мир");
        if(ready){enable(value);pulse(value);}
        enabled=value;GameRuntime.log("No Slow: enabled="+value);
    }
    public static void heartbeat(){if(ready)pulse(enabled);}
    public static String describe(){
        if(!ready)return "No Slow ещё не подключён к миру";
        return (enabled?"No Slow включён · еда и лук":"Выключен")+"\n"+status();
    }
}
