package dev.custom.bedrockgui;
/** Read-only HUD feed; preparation shares the verified engine bridge. */
public final class HudDataBridge {
 private static volatile HudRosterData roster;
 private static volatile String effects="";private static String lastState="";
 private HudDataBridge(){}
 private static native void pulse(boolean requested);
 private static native String rosterSnapshot();
 private static native String effectsSnapshotNative();
 public static boolean isReady(){return AimbotBridge.isReady();}
 public static void heartbeat(boolean requested){
  if(!isReady()){roster=null;effects="";return;}
  try{
   pulse(requested);if(!requested){roster=null;effects="";return;}
   long now=android.os.SystemClock.uptimeMillis();
   roster=HudRosterData.parse(rosterSnapshot(),now);effects=effectsSnapshotNative();
   String state=(roster==null?"roster=unavailable":"roster="+(roster.global?"global":"nearby")+" count="+roster.names.length)+" effects="+(effects.isEmpty()?"unavailable":"available");
   if(!state.equals(lastState)){lastState=state;GameRuntime.log("HUD: "+state);}
  }catch(RuntimeException|LinkageError error){roster=null;effects="";GameRuntime.log("HUD data unavailable: "+error.getClass().getSimpleName());}
 }
 public static String[] rosterNames(){HudRosterData current=roster;return current!=null&&current.fresh(android.os.SystemClock.uptimeMillis())?current.names.clone():null;}
 public static boolean rosterIsGlobal(){HudRosterData current=roster;return current!=null&&current.global&&current.fresh(android.os.SystemClock.uptimeMillis());}
 public static String effectsSnapshot(){return effects;}
}
