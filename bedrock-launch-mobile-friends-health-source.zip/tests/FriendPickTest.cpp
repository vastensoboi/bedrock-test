#include "../app/src/main/cpp/friend_pick_core.h"
#include <cassert>
#include <iostream>
using namespace kulich_aim;
Box box(float x,float z){return {{x-.3f,0,z-.3f},{x+.3f,1.8f,z+.3f},.6f,1.8f};}
int main(){
 Vec eye{0,1.62,0};DirectLook forward{float(3.14159265358979323846),0,0,-1.5708f,1.5708f};
 FriendRayChoice c;c.consider(1,1,eye,forward,box(2,1));assert(!c.valid());
 c.consider(2,2,eye,forward,box(0,4));assert(c.valid()&&c.actor==2);
 c.consider(3,3,eye,forward,box(0,2));assert(c.valid()&&c.actor==3); // closest ray hit, not nearest off-axis
 c.consider(4,4,eye,forward,box(0,2.02f));assert(!c.valid()); // two overlapping picks are ambiguous
 c.consider(5,5,eye,forward,box(0,1));assert(c.valid()&&c.actor==5);
 c=FriendRayChoice{};c.consider(1,1,eye,forward,box(0,7));assert(!c.valid());
 c.consider(2,2,eye,forward,box(0,-2));assert(!c.valid());
 std::cout<<"PASS: crosshair ray selection, off-axis/behind/range rejection, closest target and ambiguous overlap\n";
}
