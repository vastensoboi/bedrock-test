package dev.custom.bedrockgui;

import java.io.*;
import java.nio.file.Files;
import java.util.Locale;
import java.util.zip.GZIPOutputStream;

/** Exports only a regular MDMP file from this app's own crash directory. */
public final class CrashDumpExporter {
    private static final long MAX_BYTES=256L*1024*1024;
    private CrashDumpExporter(){}

    public static File latest(File directory)throws IOException {
        File root=directory.getCanonicalFile();
        File[] entries=root.listFiles();if(entries==null)return null;
        File selected=null;
        for(File entry:entries){
            try {
                File valid=validate(root,entry.getName());
                if(selected==null||valid.lastModified()>selected.lastModified()||
                        (valid.lastModified()==selected.lastModified()&&valid.getName().compareTo(selected.getName())>0))
                    selected=valid;
            }catch(IOException ignored){/* Ignore unrelated/unfinished entries. */}
        }
        return selected;
    }

    public static File validate(File directory,String name)throws IOException {
        if(name==null||name.isEmpty()||!name.equals(new File(name).getName())||
                !name.toLowerCase(Locale.ROOT).endsWith(".dmp"))
            throw new IOException("Недопустимое имя дампа");
        File root=directory.getCanonicalFile(),candidate=new File(root,name);
        if(Files.isSymbolicLink(candidate.toPath()))throw new IOException("Ссылка вместо дампа");
        File file=candidate.getCanonicalFile();
        if(!root.equals(file.getParentFile())||!file.isFile())throw new IOException("Дамп не найден");
        if(file.length()<32||file.length()>MAX_BYTES)throw new IOException("Неподдерживаемый размер дампа");
        try(InputStream input=new FileInputStream(file)){
            if(input.read()!='M'||input.read()!='D'||input.read()!='M'||input.read()!='P')
                throw new IOException("Файл не является дампом MDMP");
        }
        return file;
    }

    /** Closes destination after gzip completion. Never modifies or deletes the source. */
    public static long writeGzip(File directory,String name,OutputStream destination)throws IOException {
        File source=validate(directory,name);
        long expected=source.length(),modified=source.lastModified(),total=0;
        try(InputStream input=new FileInputStream(source);
                GZIPOutputStream gzip=new GZIPOutputStream(destination,64*1024)){
            byte[] buffer=new byte[64*1024];int count;
            while((count=input.read(buffer))!=-1){
                if(total>MAX_BYTES-count)throw new IOException("Дамп вырос во время копирования");
                gzip.write(buffer,0,count);total+=count;
            }
            if(total!=expected||source.length()!=expected||source.lastModified()!=modified)
                throw new IOException("Дамп изменился во время копирования; повтори экспорт");
        }
        return total;
    }
}
