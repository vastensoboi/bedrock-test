#include "../app/src/main/cpp/own_frame_trace.h"
#include <cassert>
#include <iostream>
#include <string>
#include <utility>

using namespace kulich_frame;

static Trace sample(){
 Trace trace;
 trace.origin=Origin::Ordinary;trace.known=true;trace.owner={1,2,3,4,5};
 trace.input.world=100;trace.input.rawTick=101;trace.input.outputTick=111;
 trace.input.replayTick=111;trace.input.historyLast=111;trace.input.historyKnown=true;
 trace.input.actor={{1.25f,64.f,-2.5f},{.1f,-.2f,.3f}};
 trace.input.packet=trace.input.actor;
 trace.step.tick=112;trace.step.beforeKnown=trace.step.appendKnown=trace.step.replayKnown=true;
 trace.step.before=trace.input.actor;trace.step.afterAppend=trace.step.before;
 trace.step.afterReplay={{2.f,64.f,-3.f},{.2f,-.3f,.4f}};
 return trace;
}

static std::string description(const Trace& trace){
 std::ostringstream out;describe(out,trace);return out.str();
}

static void identityAndStages(){
 const Trace trace=sample();
 assert(coherent(trace)&&compatible(trace,trace.owner,111,trace.input.packet));
 assert(!compatible(trace,trace.owner,trace.input.rawTick,trace.input.packet));
 // Every identity component is part of the capture owner, including history
 // generation and the complete entity generation bits.
 for(unsigned field=0;field<5;++field){
  Key changed=trace.owner;
  switch(field){
   case 0:++changed.client;break;case 1:++changed.registry;break;
   case 2:++changed.actor;break;case 3:changed.history^=uint64_t(1)<<56;break;
   default:changed.entity^=0x40000U;break;
  }
  assert(!same(trace.owner,changed)&&!compatible(trace,changed,111,trace.input.packet));
 }
 Pose changed=trace.input.packet;changed.position[0]+=.25f;
 assert(!compatible(trace,trace.owner,111,changed));
 changed=trace.input.packet;changed.delta[2]+=.25f;
 assert(!compatible(trace,trace.owner,111,changed));
 Trace mismatch=trace;mismatch.input.packet=trace.step.afterReplay;
 assert(!coherent(mismatch)&&compatible(mismatch,mismatch.owner,111,mismatch.input.packet));
 assert(description(mismatch).find("coherent=no")!=std::string::npos);
 mismatch=trace;++mismatch.input.replayTick;
 assert(!coherent(mismatch)&&compatible(mismatch,mismatch.owner,111,mismatch.input.packet));
 assert(description(mismatch).find("output=111 replay=112 historyLast=111")!=std::string::npos);
 mismatch=trace;++mismatch.input.historyLast;
 assert(!coherent(mismatch)&&compatible(mismatch,mismatch.owner,111,mismatch.input.packet));
 assert(description(mismatch).find("output=111 replay=111 historyLast=112")!=std::string::npos);
 mismatch=trace;++mismatch.input.outputTick;
 assert(!coherent(mismatch)&&compatible(mismatch,mismatch.owner,112,mismatch.input.packet));
 assert(!compatible(mismatch,mismatch.owner,111,mismatch.input.packet));
 mismatch=trace;mismatch.input.rawTick=9000;assert(coherent(mismatch));
 // Replay is expected to move the actor; append must preserve its snapshot.
 assert(snapshotStable(trace.step)&&!same(trace.step.before,trace.step.afterReplay));
 mismatch=trace;mismatch.step.afterAppend.position[1]+=.5f;assert(!snapshotStable(mismatch.step));
 mismatch=trace;mismatch.step.afterAppend.delta[0]+=.5f;assert(!snapshotStable(mismatch.step));
 mismatch=trace;mismatch.step.beforeKnown=false;assert(!snapshotStable(mismatch.step));
 mismatch=trace;mismatch.step.appendKnown=false;assert(!snapshotStable(mismatch.step));
 mismatch=trace;mismatch.step.replayKnown=false;assert(snapshotStable(mismatch.step));
}

static void unknownAndNonfinite(){
 Trace trace=sample();trace.known=false;
 assert(!coherent(trace)&&!compatible(trace,trace.owner,111,trace.input.packet));
 trace=sample();trace.input.historyKnown=false;
 assert(!coherent(trace)&&compatible(trace,trace.owner,111,trace.input.packet));
 assert(description(trace).find("replay=unavailable historyLast=unavailable")!=std::string::npos);
 assert(!coherent(Trace{})&&!snapshotStable(Step{}));
 for(unsigned component=0;component<6;++component){
  for(float invalid:{std::numeric_limits<float>::quiet_NaN(),std::numeric_limits<float>::infinity(),
                     -std::numeric_limits<float>::infinity()}){
   trace=sample();
   if(component<3)trace.input.actor.position[component]=invalid;
   else trace.input.actor.delta[component-3]=invalid;
   assert(!finite(trace.input.actor)&&!coherent(trace));
   assert(compatible(trace,trace.owner,111,trace.input.packet));
   trace.input.packet=trace.input.actor;
   assert(!finite(trace.input.actor)&&!coherent(trace));
   assert(!compatible(trace,trace.owner,111,trace.input.packet));
   trace.step.before=trace.step.afterAppend=trace.input.actor;
   assert(!snapshotStable(trace.step));
  }
 }
 // Bit identity distinguishes signed zero, and retains NaN payload identity;
 // finite() is the separate gate that rejects invalid coordinates.
 Pose plus{},minus{};minus.delta[2]=-0.f;
 assert(finite(plus)&&finite(minus)&&!same(plus,minus));
 uint32_t firstBits=0x7fc00001U,secondBits=0x7fc00002U;
 std::memcpy(&plus.position[0],&firstBits,sizeof(float));minus=plus;
 assert(same(plus,minus));
 std::memcpy(&minus.position[0],&secondBits,sizeof(float));assert(!same(plus,minus));
}

static void ownedCaptureAndFormatting(){
 Trace source=sample();const Trace retained=source;
 const std::string before=description(retained);
 source.owner.history++;source.input.rawTick++;source.input.actor.position[0]=999.f;
 source.input.packet.delta[0]=999.f;source.step.before.position[0]=999.f;
 source.step.afterAppend.delta[0]=999.f;source.step.afterReplay.position[0]=999.f;
 assert(description(retained)==before&&coherent(retained)&&snapshotStable(retained.step));
 assert(before.find("source=ordinary known=yes coherent=yes") == 0);
 assert(before.find("world=100 raw=101 output=111 replay=111 historyLast=111")!=std::string::npos);
 assert(before.find("actor={pos=(1.25,64,-2.5) delta=(0.100000001,-0.200000003,0.300000012)}")!=std::string::npos);
 assert(before.find("packet={pos=(1.25,64,-2.5) delta=(0.100000001,-0.200000003,0.300000012)}")!=std::string::npos);
 assert(before.find("stepTick=112 stepBefore={pos=(1.25,64,-2.5)")!=std::string::npos);
 assert(before.find("stepAppend={pos=(1.25,64,-2.5)")!=std::string::npos);
 assert(before.find("stepReplay={pos=(2,64,-3) delta=(0.200000003,-0.300000012,0.400000006)}")!=std::string::npos);
 assert(before.find("stepMode=unavailable")!=std::string::npos);
 source=sample();source.step.motionKnown=true;
 assert(description(source).find("stepMode=ground")!=std::string::npos);
 source.step.airborne=true;assert(description(source).find("stepMode=air")!=std::string::npos);
 for(const auto& entry:std::array<std::pair<Origin,const char*>,4>{{
      {Origin::Unknown,"unknown"},{Origin::Ordinary,"ordinary"},
      {Origin::Extra,"extra"},{Origin::Unexpected,"unexpected"}}}){
  source=sample();source.origin=entry.first;
  assert(description(source).find(std::string("source=")+entry.second+" known=yes coherent=yes")==0);
 }
 const std::string unavailable=description(Trace{});
 assert(unavailable.find("source=unknown known=no coherent=no")==0);
 assert(unavailable.find("world=unavailable raw=unavailable output=unavailable replay=unavailable historyLast=unavailable")!=std::string::npos);
 assert(unavailable.find("actor=unavailable packet=unavailable stepTick=unavailable stepBefore=unavailable stepAppend=unavailable stepReplay=unavailable")!=std::string::npos);
 source=sample();source.step.appendKnown=source.step.replayKnown=false;
 assert(description(source).find("stepAppend=unavailable stepReplay=unavailable")!=std::string::npos);
 std::ostringstream out;out<<std::hex<<std::scientific<<std::setprecision(2);
 const auto flags=out.flags();const auto precision=out.precision();describe(out,retained);
 assert(out.flags()==flags&&out.precision()==precision&&out.str()==before);
}

int main(){
 identityAndStages();unknownAndNonfinite();ownedCaptureAndFormatting();
 std::cout<<"PASS: OwnFrameTraceTest\n";
}
