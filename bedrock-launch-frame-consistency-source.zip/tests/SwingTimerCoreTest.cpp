#include "../app/src/main/cpp/swing_timer_core.h"
#include <cassert>
#include <iostream>
#include <vector>
using namespace kulich_swing;
struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;
 std::vector<unsigned char> bytes=std::vector<unsigned char>(0x40000);A next=root+0x10000;
 template<class T>void put(A at,T value){at=plain(at);assert(at>=root&&at-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+at-root,&value,sizeof value);}
 A alloc(size_t n){A out=next;next=(next+n+7)&~A(7);assert(next-root<bytes.size());return out;}
 bool operator()(A at,void* out,size_t n){at=plain(at);if(at<root||at-root>bytes.size()||n>bytes.size()-(at-root))return false;std::memcpy(out,bytes.data()+at-root,n);return true;}
};
struct Fixture {
 Memory m;static constexpr A base=0x10000000,client=Memory::root+0x1000,registry=Memory::root+0x3000,self=Memory::root+0x5000;
 static constexpr uint32_t id=0x40001;A ownerValue=0,entitySparse=0;
 Fixture(){
  A owners=m.alloc(104),sparsePages=m.alloc(8),sparseData=m.alloc(8192),payloadPages=m.alloc(8),payload=m.alloc(128*8);
  std::fill(m.bytes.begin()+sparseData-Memory::root,m.bytes.begin()+sparseData-Memory::root+8192,255);
  m.put(owners+8,sparsePages);m.put(owners+16,sparsePages+8);m.put(sparsePages,sparseData);
  m.put(sparseData+(id&2047)*4,id&0xfffc0000U);m.put(owners+80,payloadPages);m.put(owners+88,payloadPages+8);m.put(owners+96,payloadPages+8);
  m.put(payloadPages,payload|Memory::tag);ownerValue=payload;m.put(ownerValue,self|Memory::tag);
  A buckets=m.alloc(8),node=m.alloc(32);m.put<int64_t>(buckets,0);m.put<int64_t>(node,-1);m.put(node+8,OWNER);m.put(node+16,owners);
  m.put(registry+96,buckets);m.put(registry+104,buckets+8);m.put(registry+120,node);m.put(registry+128,node+32);
  A pages=m.alloc(8);entitySparse=m.alloc(8192);std::fill(m.bytes.begin()+entitySparse-Memory::root,m.bytes.begin()+entitySparse-Memory::root+8192,255);
  m.put(registry+216,pages);m.put(registry+224,pages+8);m.put(pages,entitySparse);m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|1);
  m.put(client,base+0x1388fe70ULL);m.put(client+576,std::array<A,3>{registry,Memory::root+0x9000,id});
  m.put(self,base+LOCAL_TABLE);m.put(self+8,registry);m.put(self+16,registry+40);m.put(self+24,id);m.put(self+3240,client);
  m.put<uint8_t>(self+1076,0);m.put<uint8_t>(self+1077,1);m.put<int32_t>(self+1032,0);
 }
};
int main(){
 Fixture f;Binding binding{};unsigned durationCalls=0;A observedActor=0;uint8_t observedHand=255;
 auto duration=[&](A actor,uint8_t hand){++durationCalls;observedActor=actor;observedHand=hand;return 6;};
 auto lookup=[&](Binding& out){return resolve(f.m,Fixture::base,Fixture::client,Fixture::self|Memory::tag,out,duration);};
 auto before=f.m.bytes;assert(lookup(binding)&&f.m.bytes==before);
 assert(binding.cycleAddress==((Fixture::self+1032)|Memory::tag)&&binding.actor==(Fixture::self|Memory::tag)&&binding.entity==Fixture::id&&binding.active&&binding.duration==6);
 assert(observedActor==binding.actor&&observedHand==0&&durationCalls==1);
 Clock clock;unsigned writes=0,originals=0;bool failWrite=false;
 auto write=[&](A at,int32_t value){assert(at==((Fixture::self+1032)|Memory::tag));if(failWrite)return false;++writes;f.m.put(at,value);return true;};
 auto original=[&](){
  ++originals;int32_t cycle=0;uint8_t active=0;f.m(Fixture::self+1032,&cycle,4);f.m(Fixture::self+1077,&active,1);
  if(active){++cycle;if(cycle>=6){cycle=0;f.m.put<uint8_t>(Fixture::self+1077,0);}f.m.put(Fixture::self+1032,cycle);}
 };
 assert(invoke(clock,lookup,write,original,200,true));int32_t cycle=0;f.m(Fixture::self+1032,&cycle,4);assert(cycle==2&&writes==1&&originals==1);
 // Output is deliberately not restored: the engine keeps its committed phase.
 f.m.put<int32_t>(Fixture::self+1032,5);assert(!invoke(clock,lookup,write,original,200,true));uint8_t active=1;f.m(Fixture::self+1077,&active,1);assert(active==0);f.m(Fixture::self+1032,&cycle,4);assert(cycle==0);
 unsigned calls=durationCalls;assert(!invoke(clock,lookup,write,original,200,true)&&durationCalls==calls); // never synthesize a swing.
 // Cadence progresses during idle callbacks too: x1.10 can affect a short
 // swing without accumulating a catch-up burst across an idle animation.
 clock.reset();for(int i=0;i<9;i++)assert(!invoke(clock,lookup,write,original,110,true));
 f.m.put<uint8_t>(Fixture::self+1077,1);f.m.put<int32_t>(Fixture::self+1032,0);assert(invoke(clock,lookup,write,original,110,true));f.m(Fixture::self+1032,&cycle,4);assert(cycle==2);
 f.m.put<int32_t>(Fixture::self+1032,0);writes=0;assert(!invoke(clock,lookup,write,original,200,false)&&writes==0);f.m(Fixture::self+1032,&cycle,4);assert(cycle==1);
 f.m.put<int32_t>(Fixture::self+1032,0);assert(!invoke(clock,lookup,write,original,100,true)&&writes==0);
 failWrite=true;f.m.put<int32_t>(Fixture::self+1032,0);assert(!invoke(clock,lookup,write,original,200,true));f.m(Fixture::self+1032,&cycle,4);assert(cycle==1);failWrite=false;
 // Unknown/remote/stale identities cannot become writable merely by matching
 // swing field values; all native duration arguments retain their raw tag.
 f.m.put(Fixture::self,Fixture::base+0x139f76b0ULL);assert(!lookup(binding));f.m.put(Fixture::self,Fixture::base+LOCAL_TABLE);
 f.m.put(Fixture::self+3240,Fixture::client+8);assert(!lookup(binding));f.m.put(Fixture::self+3240,Fixture::client);
 f.m.put(f.ownerValue,Fixture::self+8);assert(!lookup(binding));f.m.put(f.ownerValue,Fixture::self|Memory::tag);
 f.m.put(f.entitySparse+(Fixture::id&2047)*4,uint32_t(0xffffffffU));assert(!lookup(binding));f.m.put(f.entitySparse+(Fixture::id&2047)*4,(Fixture::id&0xfffc0000U)|1);
 f.m.put<uint8_t>(Fixture::self+1076,2);assert(!lookup(binding));f.m.put<uint8_t>(Fixture::self+1076,0);
 f.m.put<uint8_t>(Fixture::self+617,1);assert(!lookup(binding));f.m.put<uint8_t>(Fixture::self+617,0);
 assert(!resolve(f.m,Fixture::base,Fixture::client,Fixture::self|Memory::tag,binding,[](A,uint8_t){return 0;}));
 assert(!resolve(f.m,Fixture::base,Fixture::client,Fixture::self|Memory::tag,binding,[](A,uint8_t){return 257;}));
 auto changeHand=[&](A,uint8_t){f.m.put<uint8_t>(Fixture::self+1076,1);return 6;};
 assert(!resolve(f.m,Fixture::base,Fixture::client,Fixture::self|Memory::tag,binding,changeHand));f.m.put<uint8_t>(Fixture::self+1076,0);
 bool threw=false;try{invoke(clock,lookup,write,[](){throw 7;},200,true);}catch(int){threw=true;}assert(threw);
 std::cout<<"PASS: own swing cadence/phase, idle fractional scheduling, normal completion, original once, no synthetic attacks, tagged duration/write args, stale/nonlocal/malformed guards\n";
}
