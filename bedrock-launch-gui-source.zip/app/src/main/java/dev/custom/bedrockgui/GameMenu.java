package dev.custom.bedrockgui;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.*;

/** An in-window menu: empty screen space passes touches to the game when closed. */
public final class GameMenu {
    public interface Toggle { void setEnabled(boolean enabled) throws Exception; }
    private final Activity activity;
    private final SharedPreferences preferences;
    private final FrameLayout root;
    private final Button floating;
    private final View shade;
    private final LinearLayout panel, modules;
    private final TextView empty;
    private final Set<String> ids = new HashSet<>();
    private final List<Runnable> cleanup = new ArrayList<>();
    private float pointerX, pointerY, startX, startY;
    private boolean dragging;

    public GameMenu(Activity activity) {
        this.activity = activity;
        preferences = activity.getSharedPreferences("game-menu-ui", 0);
        root = new FrameLayout(activity);
        floating = button("GUI");
        floating.setContentDescription("Открыть меню модулей. Кнопку можно перетаскивать");
        root.addView(floating, new FrameLayout.LayoutParams(dp(64), dp(48)));
        floating.setOnClickListener(v -> open());
        floating.setOnTouchListener((v, event) -> drag(event));

        shade = new View(activity);
        shade.setBackgroundColor(Color.argb(95, 0, 0, 0));
        shade.setVisibility(View.GONE);
        shade.setOnClickListener(v -> close());
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(12), dp(16), dp(16));
        panel.setBackground(background(Color.rgb(18, 29, 33), 18));
        panel.setElevation(dp(8));
        panel.setClickable(true);
        panel.setVisibility(View.GONE);
        LinearLayout header = new LinearLayout(activity);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("Модули", 22);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button close = button("×");
        close.setContentDescription("Закрыть меню");
        close.setOnClickListener(v -> close());
        header.addView(close, new LinearLayout.LayoutParams(dp(48), dp(48)));
        panel.addView(header);
        ScrollView scroll = new ScrollView(activity);
        modules = new LinearLayout(activity);
        modules.setOrientation(LinearLayout.VERTICAL);
        empty = label("Пока нет модулей", 16);
        empty.setTextColor(Color.rgb(169, 190, 194));
        empty.setPadding(0, dp(24), 0, dp(24));
        modules.addView(empty);
        scroll.addView(modules);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(panel, new FrameLayout.LayoutParams(dp(340), dp(300), Gravity.CENTER));
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> fit());
        activity.getWindow().addContentView(root, new ViewGroup.LayoutParams(-1, -1));
        root.post(this::fit);
    }

    /** Register real functionality here; no demonstration toggles are installed. */
    public void addToggle(String id, String title, String description, Toggle callback) {
        if (callback == null || id == null || id.isEmpty()) throw new IllegalArgumentException("Module requires an ID and callback");
        if (!ids.add(id)) throw new IllegalArgumentException("Duplicate module ID: " + id);
        empty.setVisibility(View.GONE);
        Switch control = new Switch(activity);
        control.setText(title);control.setTextColor(Color.WHITE);control.setTextSize(17);
        control.setPadding(0, dp(12), 0, dp(12));
        boolean[] reverting = {false};
        control.setOnCheckedChangeListener((v, enabled) -> {
            if (reverting[0]) return;
            try { callback.setEnabled(enabled); }
            catch (Exception | LinkageError error) {
                reverting[0] = true;control.setChecked(!enabled);reverting[0] = false;
                GameRuntime.log("Menu module failed: " + id + " / " + error);
                Toast.makeText(activity, "Не удалось изменить модуль", Toast.LENGTH_SHORT).show();
            }
        });
        modules.addView(control, new LinearLayout.LayoutParams(-1, -2));
        if (description != null && !description.isEmpty()) {
            TextView text = label(description, 13);text.setTextColor(Color.rgb(169, 190, 194));
            modules.addView(text, new LinearLayout.LayoutParams(-1, -2));
        }
        cleanup.add(() -> { if (control.isChecked()) control.setChecked(false); });
    }

    public void open() { shade.setVisibility(View.VISIBLE);panel.setVisibility(View.VISIBLE);floating.setVisibility(View.GONE); }
    public void close() { panel.setVisibility(View.GONE);shade.setVisibility(View.GONE);floating.setVisibility(View.VISIBLE); }
    public void dispose() {
        for (Runnable action : cleanup) action.run();
        if (root.getParent() instanceof ViewGroup) ((ViewGroup) root.getParent()).removeView(root);
    }
    private boolean drag(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pointerX = event.getRawX();pointerY = event.getRawY();
                startX = floating.getX();startY = floating.getY();dragging = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                float dx = event.getRawX() - pointerX, dy = event.getRawY() - pointerY;
                if (Math.hypot(dx, dy) > ViewConfiguration.get(activity).getScaledTouchSlop()) dragging = true;
                if (dragging) position(startX + dx, startY + dy);
                return true;
            case MotionEvent.ACTION_UP:
                if (dragging) savePosition(); else floating.performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                if (dragging) savePosition();
                return true;
            default: return true;
        }
    }
    private void fit() {
        if (root.getWidth() == 0 || root.getHeight() == 0) return;
        FrameLayout.LayoutParams bounds = (FrameLayout.LayoutParams) panel.getLayoutParams();
        int width = Math.min(dp(360), Math.max(1, root.getWidth() - dp(24)));
        int height = Math.min(dp(440), Math.max(1, root.getHeight() - dp(24)));
        if (bounds.width != width || bounds.height != height) {
            bounds.width = width;bounds.height = height;panel.setLayoutParams(bounds);
        }
        position(preferences.getFloat("x", 0.04f) * Math.max(0, root.getWidth() - floating.getWidth()),
                preferences.getFloat("y", 0.2f) * Math.max(0, root.getHeight() - floating.getHeight()));
    }
    private void position(float x, float y) {
        floating.setX(Math.max(0, Math.min(x, Math.max(0, root.getWidth() - floating.getWidth()))));
        floating.setY(Math.max(0, Math.min(y, Math.max(0, root.getHeight() - floating.getHeight()))));
    }
    private void savePosition() {
        preferences.edit().putFloat("x", floating.getX() / Math.max(1, root.getWidth() - floating.getWidth()))
                .putFloat("y", floating.getY() / Math.max(1, root.getHeight() - floating.getHeight())).apply();
    }
    private int dp(int value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }
    private TextView label(String text, int size) {
        TextView view = new TextView(activity);view.setText(text);view.setTextSize(size);
        view.setTextColor(Color.WHITE);view.setGravity(Gravity.CENTER_VERTICAL);return view;
    }
    private Button button(String text) {
        Button view = new Button(activity);view.setText(text);view.setTextColor(Color.rgb(218, 255, 248));
        view.setTextSize(17);view.setAllCaps(false);view.setMinWidth(0);view.setMinimumWidth(0);
        view.setPadding(dp(4), 0, dp(4), 0);view.setBackground(background(Color.rgb(21, 81, 77), 14));return view;
    }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();shape.setColor(color);shape.setCornerRadius(dp(radius));
        shape.setStroke(dp(1), Color.rgb(52, 104, 99));return shape;
    }
}
