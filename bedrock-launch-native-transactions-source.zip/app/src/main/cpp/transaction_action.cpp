#include "transaction_action_core.h"
#include "transaction_action_profile.h"
#include <jni.h>
#include <atomic>
#include <mutex>
#include <chrono>
#include <string>
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>
extern "C" bool kulich_transaction_observer_ready();
namespace {
using namespace kulich_transaction;
std::mutex gate;int memory=-1;A base=0;Fields fields{};
std::atomic<int> state{0},requestId{0},replyStatus{-1};
int64_t queuedAt=0;int queuedNetId=0;std::atomic<int> failure{0};
int64_t now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(A at,void* out,size_t size){at=plain(at);if(memory<0||at<4096||size>4096||at>0x00ffffffffffffffULL-size)return false;ssize_t n;do{n=pread(memory,out,size,static_cast<off_t>(at));}while(n<0&&errno==EINTR);return n==ssize_t(size);}
A ptr(A at){A v=0;return readMemory(at,&v,8)?plain(v):0;}
template<class F> F function(A offset){return reinterpret_cast<F>(base+offset);}
void destroy(void* object){if(object){A table=ptr(reinterpret_cast<A>(object));A fn=ptr(table+8);if(fn)reinterpret_cast<void(*)(void*)>(fn)(object);}}
}
extern "C" void kulich_transaction_ack(int32_t id,int status){
 if(id>=0||requestId.load(std::memory_order_acquire)!=id)return;
 int expected=2;replyStatus.store(status);state.compare_exchange_strong(expected,3);
}
extern "C" void kulich_transaction_tick(uint64_t taggedPlayer){
 std::unique_lock<std::mutex> lock(gate,std::try_to_lock);if(!lock.owns_lock()||state.load()!=1||plain(taggedPlayer)!=fields[0])return;
 if(now()-queuedAt>500){failure=1;state=4;return;}
 auto transfer=validate(readMemory,base,fields);if(!transfer.manager||transfer.netId!=queuedNetId){failure=2;state=4;return;}
 if(!function<void*(*)(void*)>(GET_SCREEN)(reinterpret_cast<void*>(transfer.manager))){failure=3;state=4;return;}
 void* action=nullptr;alignas(8) unsigned char scope[16]{};bool scopeLive=false;
 try{
  auto src=descriptor(7,transfer.slot,transfer.netId,0),dst=descriptor(29,transfer.target,0,0);
  action=function<void*(*)(size_t)>(ALLOC)(96);
  if(!action){failure=7;state=4;return;}
  std::memset(action,0,96);
  function<void(*)(void*,int,const void*,const void*)>(PLACE_CTOR)(action,transfer.count,src.data(),dst.data());
  function<void(*)(void*,void*)>(SCOPE_CTOR)(scope,reinterpret_cast<void*>(transfer.manager));scopeLive=true;
  A current=ptr(transfer.manager+96);int32_t id=0;
  if(!current||!readMemory(current+8,&id,4)||id>=0){failure=4;}
  else{
   requestId.store(id,std::memory_order_release);replyStatus=-1;
   function<void(*)(void*,void**)>(APPLY)(reinterpret_cast<void*>(transfer.manager),&action);
   if(action)failure=5;else failure=0;
  }
  if(action){destroy(action);action=nullptr;}
  function<void(*)(void*)>(SCOPE_DTOR)(scope);scopeLive=false;
  if(failure.load()){state=4;return;}
  state.store(2,std::memory_order_release);
  function<void(*)(void*)>(FLUSH)(reinterpret_cast<void*>(transfer.manager));
 }catch(...){
  if(action)destroy(action);
  if(scopeLive)function<void(*)(void*)>(SCOPE_DTOR)(scope);
  failure=6;state=4;
 }
}
extern "C" JNIEXPORT jint JNICALL Java_dev_custom_bedrockgui_NativeContainerInput_submit(JNIEnv* env,jclass,jlong verifiedBase,jlongArray data){
 std::lock_guard<std::mutex> lock(gate);
 if(state.load()==1||state.load()==2)return -1;
 if(!kulich_transaction_observer_ready())return -2;
 if(!data||env->GetArrayLength(data)!=19)return -3;
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0)return -4;
 A candidate=static_cast<A>(verifiedBase);if(base&&base!=candidate)return -5;
 for(const auto& p:profiles){uint32_t actual[8]{};if(!readMemory(candidate+p.offset,actual,sizeof(actual))||std::memcmp(actual,p.words,sizeof(actual)))return -6;}
 Fields incoming{};jlong raw[19]{};env->GetLongArrayRegion(data,0,19,raw);
 for(size_t i=0;i<incoming.size();i++)incoming[i]=static_cast<A>(raw[i]);
 auto current=validate(readMemory,candidate,incoming);if(!current.manager)return -7;
 queuedNetId=current.netId;
 base=candidate;fields=incoming;queuedAt=now();failure=0;requestId=0;replyStatus=-1;state.store(1,std::memory_order_release);return 1;
}
extern "C" JNIEXPORT jint JNICALL Java_dev_custom_bedrockgui_NativeContainerInput_progress(JNIEnv*,jclass){return state.load(std::memory_order_acquire);}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_NativeContainerInput_cancel(JNIEnv*,jclass){std::lock_guard<std::mutex> lock(gate);state=5;}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_NativeContainerInput_details(JNIEnv* env,jclass){
 std::string text="Native container: state="+std::to_string(state.load())+" request="+std::to_string(requestId.load())+" reply="+std::to_string(replyStatus.load())+" reason="+std::to_string(failure.load());return env->NewStringUTF(text.c_str());
}

extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_NativeContainerInput_cancelQueued(JNIEnv*,jclass){std::lock_guard<std::mutex> lock(gate);if(state.load()==1)state=5;}
extern "C" JNIEXPORT jint JNICALL Java_dev_custom_bedrockgui_NativeContainerInput_reason(JNIEnv*,jclass){return failure.load();}
