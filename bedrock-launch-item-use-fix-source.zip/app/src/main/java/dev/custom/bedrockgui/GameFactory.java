package dev.custom.bedrockgui;

import android.app.*;
import android.content.Intent;
import java.io.*;

public final class GameFactory extends AppComponentFactory {
    @Override public Activity instantiateActivity(ClassLoader cl,String name,Intent intent)
            throws InstantiationException,IllegalAccessException,ClassNotFoundException {
        if(!name.equals(GameRuntime.ACTIVITY))return super.instantiateActivity(cl,name,intent);
        try {
            GameRuntime.prepare(intent,cl);
            GameRuntime.log("Factory: instantiate game Activity");
            return super.instantiateActivity(GameRuntime.loader,name,intent);
        }catch(Exception|LinkageError error) {
            StringWriter trace=new StringWriter();error.printStackTrace(new PrintWriter(trace));
            GameRuntime.log("JAVA FAILURE\n"+trace);
            // No Context access on the returned Activity until Android attaches it.
            return super.instantiateActivity(cl,"dev.custom.bedrockgui.LaunchFailureActivity",intent);
        }
    }
}
