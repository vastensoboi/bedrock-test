#include "../app/src/main/cpp/aim_distance.h"
#include <cassert>
#include <iostream>
using namespace kulich_aim;
Box box(float z){return {{-.3f,0,z-.3f},{.3f,1.8f,z+.3f},.6f,1.8f};}
int main(){
 DirectLook forward{float(3.14159265358979323846),0,0,-1.5708f,1.5708f};Vec eye{0,1.62,0},hit{};
 auto ranges=AimDistances::fromTenths(39,20);
 assert(std::abs(ranges.acquire-3.9)<1e-9&&ranges.attack==2);
 assert(attackDistanceState(eye,forward,box(3),ranges,hit)==3); // tracked but no attack
 assert(attackDistanceState(eye,forward,box(2.2f),ranges,hit)==0);
 ranges=AimDistances::fromTenths(60,37);
 assert(attackDistanceState(eye,forward,box(4.0f),ranges,hit)==0);
 assert(attackDistanceState(eye,forward,box(4.05f),ranges,hit)==3);
 ranges=AimDistances::fromTenths(60,39);
 assert(attackDistanceState(eye,forward,box(4.05f),ranges,hit)==0);
 assert(attackDistanceState(eye,forward,box(5.9f),ranges,hit)==3);
 ranges=AimDistances::fromTenths(60,60);
 assert(attackDistanceState(eye,forward,box(5.9f),ranges,hit)==0);
 assert(!rayHitView(eye,forward,box(5.9f),6.1,hit));
 DirectLook away{0,0,0,-1.5708f,1.5708f};assert(attackDistanceState(eye,away,box(2),ranges,hit)==4);
 auto clamped=AimDistances::fromTenths(20,60);assert(clamped.acquire==2&&clamped.attack==2);
 clamped=AimDistances::fromTenths(-1,0);assert(clamped.acquire==1&&clamped.attack==1);
 clamped=AimDistances::fromTenths(90,80);assert(clamped.acquire==6&&clamped.attack==6);
 assert(attackDistanceState(eye,forward,box(2),{NAN,2},hit)==3);
 std::cout<<"PASS: separate tracking/attack ranges, decimal 3.7/3.9 thresholds, 6-block ray, clamping and view miss\n";
}
