# Exact block query for Block Trap

Verified against the supplied Minecraft 1.26.60.4 ARM64 image.

`BlockSource` primary vptr is `0x13d6dcd0`. Virtual slot2 (+16),
`0x10371248`, receives `(BlockSource*, const BlockPos*)` and returns a tagged
`Block*` in x0. Its first checks compare `BlockPos.y` against signed int16
exclusive maximum at source+64 and inclusive minimum at source+66. The helper
rejects outside-world queries rather than treating the native fallback as air.

The returned state has `Block` vptr `0x13dfc0a8`. Wrapper `0x109f3fd4`
loads its `BlockType*` at +104 and dispatches that type's virtual function.
`AirBlock` is an RTTI subclass of `BlockType`; constructor `0x10a1115c`
stores AirBlock's primary vptr `0x13dfda38`. Air classification checks that
exact typed relation and rereads the state/type link before publishing.

Non-air means only non-air. It does not mean a full solid support: water,
plants, slabs and other shapes still require the game's placement validation.
The conservative `inertSupport` gate accepts only exact RTTI-derived native
types StoneBlock (`0x13e4f530`), CobblestoneBlock (`0x13ddec18`),
ObsidianBlock (`0x13db7a28`), DirtBlock (`0x13ddb3a0`), GrassBlock
(`0x13dcd2e8`), BedrockBlock (`0x13dfa648`), MetalBlock (`0x13dbe6f8`),
PlanksBlock (`0x13db9cc0`), LogBlock (`0x13dbcd00`), NetherrackBlock
(`0x13db6928`), DeepslateBlock (`0x13dda660`) and ClayBlock (`0x13dde398`).
It skips all unknown types, including ChestBlock (`0x13ddd258`) and SlabBlock
(`0x13e56128`), before any native interaction. A matching type is still subject
to the native ray, placement and server checks; it is not a promise that every
variant can be used in every context.
The helper performs no writes and must run on the game's thread with a live,
validated source and caller. Raw allocation tags are retained on native calls.

## Held item representation correction in 0.70

The source-query layout above remains valid. The 0.69 held-item path supplied
the wrong representation to it: `0x10777338` dispatches the Item's virtual slot
7 (+56), whose ordinary implementation `0x107a0ba8` returns Item+312. That is
a `BlockType*`, such as the ObsidianBlock object, rather than a `Block*` state.
Passing it to `inspect` therefore correctly rejects the object before target
selection. This explains a non-null held block with `heldReason=0` followed by
the module's classification failure.

The actual item renderer calls `0x107772cc` at `0xab71d9c`, not the type-only
wrapper. That state getter tests Item virtual +80, obtains the BlockType via
+56 and tail-calls `0x10919948`, which returns the type's default Block state
at +512. Its alternative returns the ItemStack's cached Block state at +24.
The corrected held-item binding must use this state getter. Do not relax
`inspect` to accept a BlockType as if it were a Block: terrain source queries
and held item type accessors have different return representations.
