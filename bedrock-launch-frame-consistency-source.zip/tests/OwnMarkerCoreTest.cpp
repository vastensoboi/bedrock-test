#include "../app/src/main/cpp/own_marker_core.h"

#include <algorithm>
#include <cassert>
#include <iostream>
#include <limits>

using namespace kulich_marker;
using Metadata = std::array<unsigned char, 16>;

Metadata metadata(const Marker& marker) {
    Metadata result{};
    std::copy(marker.begin(), marker.end(), result.begin());
    result[13] = 0x9a;
    result[14] = 0xbc;
    result[15] = 0xde;
    return result;
}

void exactMarker() {
    Marker marker{};
    assert(make({8.f, -3.f, 2.5f}, {3.f, 4.f, 3.f}, 1, 3, marker));
    const std::array<float, 3> expected{5.f, -7.f, -.5f};
    assert(std::memcmp(marker.data(), expected.data(), 12) == 0);
    assert(marker[12] == 1);
    const auto current = metadata(marker);
    assert(owned(marker, current, 1, 3, 3));

    for (uint8_t mode : {0, 1, 2, 3, 254, 255}) {
        for (uint8_t replayed : {0, 1, 2, 255}) {
            assert(make({8.f, -3.f, 2.5f}, {3.f, 4.f, 3.f}, replayed, mode, marker));
            assert(marker[12] == (replayed ? (mode & 1U) : 0));
            assert(owned(marker, metadata(marker), 1, mode, mode));
        }
    }
}

void foreignChanges() {
    Marker marker{};
    assert(make({8.f, -3.f, 2.5f}, {3.f, 4.f, 3.f}, 1, 1, marker));
    auto current = metadata(marker);
    const auto original = current;
    for (std::size_t axis = 0; axis < 3; ++axis) {
        current = original;
        const float foreign = 42.f + static_cast<float>(axis);
        std::memcpy(current.data() + axis * 4, &foreign, 4);
        const auto snapshot = current;
        assert(!owned(marker, current, 1, 1, 1));
        assert(current == snapshot);
    }
    current = original;
    current[12] = 0;
    assert(!owned(marker, current, 1, 1, 1));
    current[12] = 2;
    assert(!owned(marker, current, 1, 1, 1));

    for (uint8_t replayed : {0, 2, 255})
        assert(!owned(marker, original, replayed, 1, 1));
    for (uint8_t mode : {0, 2, 3, 255})
        assert(!owned(marker, original, 1, mode, 1));
    assert(!owned(marker, original, 1, 1, 3));

    // Equal numeric values with different float representations are foreign.
    assert(make({0.f, 0.f, 0.f}, {0.f, 0.f, 0.f}, 0, 0, marker));
    current = metadata(marker);
    const float negativeZero = -0.f;
    std::memcpy(current.data() + 4, &negativeZero, 4);
    assert(!owned(marker, current, 1, 0, 0));
}

void paddingAndPrefixRestore() {
    Marker marker{};
    assert(make({8.f, -3.f, 2.5f}, {3.f, 4.f, 3.f}, 1, 1, marker));
    auto current = metadata(marker);
    Metadata saved{};
    saved.fill(0x36);
    for (std::size_t padding = 13; padding < current.size(); ++padding) {
        current[padding] ^= 0xff;
        assert(owned(marker, current, 1, 1, 1));
    }
    const auto beforeRestore = current;
    if (owned(marker, current, 1, 1, 1))
        std::copy_n(saved.begin(), marker.size(), current.begin());
    assert(std::equal(saved.begin(), saved.begin() + marker.size(), current.begin()));
    assert(std::equal(current.begin() + marker.size(), current.end(),
                      beforeRestore.begin() + marker.size()));

    current = metadata(marker);
    current[0] ^= 1;
    const auto foreign = current;
    if (owned(marker, current, 1, 1, 1))
        std::copy_n(saved.begin(), marker.size(), current.begin());
    assert(current == foreign);
}

void invalidPositionsLeaveOutputUntouched() {
    const std::array<float, 3> finite{1.f, 2.f, 3.f};
    Marker sentinel{};
    sentinel.fill(0xa5);
    const float infinity = std::numeric_limits<float>::infinity();
    const float nan = std::numeric_limits<float>::quiet_NaN();
    for (std::size_t axis = 0; axis < finite.size(); ++axis) {
        for (float invalid : {nan, infinity, -infinity}) {
            auto position = finite;
            position[axis] = invalid;
            auto out = sentinel;
            assert(!make(position, finite, 1, 1, out));
            assert(out == sentinel);
            assert(!make(finite, position, 1, 1, out));
            assert(out == sentinel);
        }
        // Finite operands can still overflow their float difference.
        auto before = finite;
        auto after = finite;
        before[axis] = std::numeric_limits<float>::max();
        after[axis] = -std::numeric_limits<float>::max();
        auto out = sentinel;
        assert(!make(before, after, 1, 1, out));
        assert(out == sentinel);
        assert(!make(after, before, 1, 1, out));
        assert(out == sentinel);
    }
}

int main() {
    exactMarker();
    foreignChanges();
    paddingAndPrefixRestore();
    invalidPositionsLeaveOutputUntouched();
    std::cout << "PASS: OwnMarkerCoreTest\n";
}
