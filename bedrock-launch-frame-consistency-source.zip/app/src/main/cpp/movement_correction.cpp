#include "movement_correction_core.h"
#include "movement_input_profile.h"
#include "own_step.h"
#include <atomic>
#include <chrono>
#include <mutex>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cerrno>
#include <time.h>

extern "C" bool kulich_timer_trace_active();
extern "C" int kulich_timer_trace_multiplier();
extern "C" void kulich_auth_input_hook();
namespace kulich_correction {
namespace {
using Handler=void(*)(void*,void*,void*);
std::atomic<Handler> originals[2];
std::atomic<A> gameBase{0},boundClient{0};
std::atomic<bool> ready{false};std::atomic<uint64_t> generation{1},calls{0},skipped{0},busy{0};
std::mutex installGate,samplesGate;Book book;
kulich_input::Book inputBook;std::atomic<A> inputOriginal{0};
std::atomic<bool> inputReady{false};std::atomic<uint64_t> inputCalls{0},inputSkipped{0},inputBusy{0};
bool inputInstalled=false;std::string inputFailure="not prepared";
int memory=-1;bool installed=false;std::string failure="not prepared";
int64_t now(){
#if defined(CLOCK_BOOTTIME)
 timespec value{};
 if(clock_gettime(CLOCK_BOOTTIME,&value)==0)return int64_t(value.tv_sec)*1000+value.tv_nsec/1000000;
#endif
 return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
}
bool readMemory(A address,void* out,size_t size){
 address=plain(address);
 if(memory<0||address<4096||size>65536||address>0x00ffffffffffffffULL-size)return false;
 ssize_t count;do{count=pread(memory,out,size,static_cast<off_t>(address));}while(count<0&&errno==EINTR);
 return count==ssize_t(size);
}
void receive(Kind kind,void* handler,void* network,void* packet){
 Handler target=originals[kind==Kind::Prediction?0:1].load(std::memory_order_acquire);
 forward([&](){
  calls.fetch_add(1,std::memory_order_relaxed);
  if(!ready.load(std::memory_order_acquire))return;
  uint64_t version=generation.load(std::memory_order_acquire);
  A base=gameBase.load(),client=boundClient.load();bool active=kulich_timer_trace_active();int factor=kulich_timer_trace_multiplier();
  Binding binding{};Payload payload{};auto read=readMemory;
  if(!capture(read,base,client,reinterpret_cast<A>(handler),reinterpret_cast<A>(packet),binding,kind,&payload)){skipped.fetch_add(1,std::memory_order_relaxed);return;}
  kulich_input::Identity identity{};bool inputBinding=inputReady.load()&&payload.available&&
   kulich_input::identity(read,base,client,0,identity)&&identity.key.registry==binding.registry&&identity.key.actor==binding.actor&&identity.key.entity==binding.entity;
  std::unique_lock<std::mutex> guard(samplesGate,std::try_to_lock);
  if(!guard.owns_lock()){busy.fetch_add(1,std::memory_order_relaxed);return;}
  if(!ready.load(std::memory_order_acquire)||version!=generation.load(std::memory_order_acquire)||client!=boundClient.load()){
   skipped.fetch_add(1,std::memory_order_relaxed);return;
  }
  int64_t received=now();
  if(inputBinding)payload.submitted=inputBook.compare(identity.key,payload.inputTick,received,payload.context,payload.position,payload.delta);
  book.add(received,active,factor,kind,binding.mode,binding.entity,binding.runtimeId,payload);
 },[&](void* rawHandler,void* rawNetwork,void* rawPacket){target(rawHandler,rawNetwork,rawPacket);},handler,network,packet);
}
void receivePrediction(void* handler,void* network,void* packet){receive(Kind::Prediction,handler,network,packet);}
void receiveMove(void* handler,void* network,void* packet){receive(Kind::MovePlayer,handler,network,packet);}
struct Profile {A offset;uint32_t words[8];size_t count;};
constexpr Profile profiles[]={
 {0xa2eaf70ULL,{0xa9be7bfdU,0xa9014ff4U,0x910003fdU,0xf9405808U,0xb4000368U,0x39400108U,0x34000328U,0xaa0003f4U},8},
 {0xa2eafc8ULL,{0xf9402e80U,0xf9400008U,0xf9407d08U,0xd63f0100U,0xb40000a0U,0xaa1303e1U,0xa9414ff4U,0xa8c27bfdU},8},
 {0xcc5516cULL,{0xf9400048U,0xaa0203e0U,0xf9400062U,0xf9433103U,0xd61f0060U},5},
 {0xc7703a4ULL,{0x52801420U,0xd65f03c0U},2},
 {0xa2f72c4ULL,{0xf9401a88U,0xf9002e68U},2},
 {0x9b7f630ULL,{0x91090101U,0xf81f83a9U,0x9532c0a2U,0x910023e0U,0x9532c0a1U,0x360000a0U,0x910023e0U,0x52800021U},8},
 {0xa300578ULL,{0xd10243ffU,0xfd0023eaU,0x6d0523e9U,0xa9067bfdU,0xa90757f6U,0xa9084ff4U,0x910183fdU,0xd53bd056U},8},
 {0xcc51458ULL,{0xf9400048U,0xaa0203e0U,0xf9400062U,0xf940bd03U,0xd61f0060U},5},
 {0xdc16c24ULL,{0x52800260U,0xd65f03c0U},2},
 {0xfd898b8ULL,{0xa9bf7bfdU,0x910003fdU,0xf9400809U,0x529776aaU,0x72bf81aaU,0xa943a12bU,0xcb0b0108U,0xd343fd08U},8},
 {0xfd89958ULL,{0xd344fd48U,0xf9402929U,0x927d2908U,0xf8686928U,0xb40000c8U,0x92404549U,0x92401929U,0xf8697900U},8},
 // Packet layout, decoded-field commit and native queued application.
 {0xc77044cULL,{0xf9400268U,0x39418681U,0x90fb0062U,0x912fb842U,0xb0fae9c3U,0x91074c63U,0xf9401108U,0xaa1303e0U},8},
 {0xc770470ULL,{0xf9400268U,0xbd403280U,0xb0fae855U,0x91358ab5U,0xaa1303e0U,0xaa1f03e2U,0xf9404908U,0xaa1503e1U},8},
 {0xc7704dcULL,{0xf9400268U,0xbd403e80U,0xaa1303e0U,0xaa1503e1U,0xaa1f03e2U,0xf9404908U,0xd63f0100U,0xf9400268U},8},
 {0xc770530ULL,{0xf9400268U,0xbd404a80U,0xaa1303e0U,0xaa1503e1U,0xaa1f03e2U,0xf9404908U,0xd63f0100U,0xf9400268U},8},
 {0xc770568ULL,{0xf9400268U,0x39415295U,0xb0fb0462U,0x91363842U,0x90fb0163U,0x9122a063U,0xf9400d08U,0xaa1303e0U},8},
 {0xc770590ULL,{0x34000095U,0x91014280U,0xaa1303e1U,0x95b4f311U,0xf9400268U,0x39418281U,0x90fb0062U},7},
 {0xc7705c4ULL,{0x91016280U,0xaa1303e1U,0xa9434ff4U,0xf9400bf7U,0xa94257f6U,0xa8c47bfdU,0x144d545aU},7},
 {0xc771cd0ULL,{0xfd002680U,0x6f00e400U,0xf9000aa8U,0x7941e3e8U,0x3d801682U,0x7900c288U},6},
 {0xdac573cULL,{0xf9400000U,0xd65f03c0U},2},
 {0xa458130ULL,{0xf9400680U,0x528a4701U,0xb9401297U,0x72a36ba1U,0x97985cc6U,0xa940a808U},6},
 {0xa4581e0ULL,{0xb8410269U,0xf840826aU,0xb9000909U,0xf900010aU,0xb9401e69U,0xf841426aU,0xb9002109U,0xf9000d0aU},8},
 {0xa458200ULL,{0x3940e668U,0xf9400680U,0xb9401297U,0x7100051fU,0x54000301U},5}
};
bool mapping(A page,A bytes){
 FILE* maps=fopen("/proc/self/maps","r");if(!maps)return false;
 char line[2048],perms[5]{};unsigned long long first=0,last=0;bool valid=false;
 while(fgets(line,sizeof line,maps))if(sscanf(line,"%llx-%llx %4s",&first,&last,perms)==3&&page>=first&&page+bytes<=last){
  valid=perms[0]=='r'&&perms[1]=='-'&&perms[2]=='-'&&std::string(line).find("/libminecraftpe.so")!=std::string::npos;break;
 }
 fclose(maps);return valid;
}
std::string install(A base,A client){
 client=plain(client);
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0||pointer(readMemory,client)!=base+CLIENT)return "local client binding unavailable";
 if(installed){
  if(base!=gameBase.load())return "library base changed";
  if(!ready.load())return failure;
  if(client!=boundClient.load()){
   ready.store(false,std::memory_order_release);generation.fetch_add(1);
   std::lock_guard<std::mutex> samples(samplesGate);book={};inputBook={};calls=0;skipped=0;busy=0;inputCalls=0;inputSkipped=0;inputBusy=0;boundClient.store(client);ready.store(true,std::memory_order_release);
  }
  return {};
 }
 for(const auto& profile:profiles){uint32_t words[8]{};size_t bytes=profile.count*4;
  if(!readMemory(base+profile.offset,words,bytes)||std::memcmp(words,profile.words,bytes))return "code profile mismatch";
 }
 if(!kulich_rewind::profileValid(readMemory,base))return "history code profile mismatch";
 const A entries[]{base+HANDLER+SLOT*8,base+LEGACY+SLOT*8,base+LEGACY+47*8};
 const A expected[]{base+HANDLE,base+HANDLE,base+MOVE_HANDLE};
 const A replacements[]{reinterpret_cast<A>(&receivePrediction),reinterpret_cast<A>(&receivePrediction),reinterpret_cast<A>(&receiveMove)};
 long pageSize=sysconf(_SC_PAGESIZE);if(pageSize<=0)return "invalid page size";
 std::array<A,3> pages{};size_t pageCount=0;
 for(size_t index=0;index<3;++index){A entry=entries[index];
  A value=0;if(!readMemory(entry,&value,8)||value!=expected[index])return "callback binding mismatch";
  A page=entry-entry%A(pageSize);if(entry+8>page+A(pageSize))return "callback crosses page";
  bool present=false;for(size_t i=0;i<pageCount;++i)present=present||pages[i]==page;
  if(!present){if(!mapping(page,A(pageSize)))return "unexpected callback mapping";pages[pageCount++]=page;}
 }
 size_t writable=0;
 for(size_t i=0;i<pageCount;++i){
  if(mprotect(reinterpret_cast<void*>(pages[i]),pageSize,PROT_READ|PROT_WRITE)){
   for(size_t j=0;j<writable;++j)mprotect(reinterpret_cast<void*>(pages[j]),pageSize,PROT_READ);
   return "cannot update callback page";
  }
  ++writable;
 }
 // Forwarding targets are published before either entry, and retained after a
 // rollback because another thread may already have entered the observer.
 originals[0].store(reinterpret_cast<Handler>(base+HANDLE),std::memory_order_release);
 originals[1].store(reinterpret_cast<Handler>(base+MOVE_HANDLE),std::memory_order_release);
 gameBase.store(base);boundClient.store(client);installed=true;
 for(size_t i=0;i<3;++i)__atomic_store_n(reinterpret_cast<A*>(entries[i]),replacements[i],__ATOMIC_RELEASE);
 bool protectedAgain=true;
 for(size_t i=0;i<pageCount;++i)if(mprotect(reinterpret_cast<void*>(pages[i]),pageSize,PROT_READ))protectedAgain=false;
 if(!protectedAgain){
  bool allWritable=true;
  for(size_t i=0;i<pageCount;++i)if(mprotect(reinterpret_cast<void*>(pages[i]),pageSize,PROT_READ|PROT_WRITE))allWritable=false;
  if(allWritable){for(size_t i=0;i<3;++i)__atomic_store_n(reinterpret_cast<A*>(entries[i]),expected[i],__ATOMIC_RELEASE);installed=false;}
  for(size_t i=0;i<pageCount;++i)mprotect(reinterpret_cast<void*>(pages[i]),pageSize,PROT_READ);
  return "callback protection restore failed; observer disabled";
 }
 ready.store(true,std::memory_order_release);return {};
}
std::string installInput(A base){
#if defined(__aarch64__)
 if(inputInstalled)return inputReady.load()?std::string{}:inputFailure;
 if(!kulich_input::profileValid(readMemory,base))return "native input code profile mismatch";
 A entry=base+kulich_input::SENDER+24,original=0;
 if(!readMemory(entry,&original,8)||original!=base+kulich_input::SEND)return "native input callback binding mismatch";
 long pageSize=sysconf(_SC_PAGESIZE);if(pageSize<=0)return "invalid input callback page size";
 A page=entry-entry%A(pageSize);
 if(entry+8>page+A(pageSize)||!mapping(page,A(pageSize)))return "unexpected native input callback mapping";
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ|PROT_WRITE))return "cannot update native input callback page";
 inputOriginal.store(original,std::memory_order_release);
 inputInstalled=true;
 __atomic_store_n(reinterpret_cast<A*>(entry),reinterpret_cast<A>(&kulich_auth_input_hook),__ATOMIC_RELEASE);
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ)){
  if(!mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ|PROT_WRITE)){
   __atomic_store_n(reinterpret_cast<A*>(entry),original,__ATOMIC_RELEASE);inputInstalled=false;
  }
  mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ);
  return "native input callback protection restore failed; input observation disabled";
 }
 inputReady.store(true,std::memory_order_release);return {};
#else
 (void)base;return "native input observer requires arm64";
#endif
}
}
void prepare(uint64_t base,uint64_t client){
 std::lock_guard<std::mutex> guard(installGate);
 try{
  failure=install(base,client);
  if(!failure.empty()){ready.store(false,std::memory_order_release);inputReady.store(false,std::memory_order_release);}
  else{inputFailure=installInput(base);if(!inputFailure.empty())inputReady.store(false,std::memory_order_release);}
 }
 catch(...){ready.store(false,std::memory_order_release);inputReady.store(false,std::memory_order_release);failure="observer preparation failed";}
}
uint64_t observeInput(void* sender,void* packet,uint64_t callerLr,uint64_t callerSp)noexcept{
 A original=inputOriginal.load(std::memory_order_acquire);
 const auto trace=kulich_own_step::input(sender,packet,callerLr,callerSp);
 try{
  inputCalls.fetch_add(1,std::memory_order_relaxed);
  if(!inputReady.load(std::memory_order_acquire)||!ready.load(std::memory_order_acquire))return original;
  uint64_t version=generation.load(std::memory_order_acquire);A base=gameBase.load(),client=boundClient.load();
  auto read=readMemory;kulich_input::Sample sample{};
  if(!kulich_input::capture(read,base,client,reinterpret_cast<A>(sender),reinterpret_cast<A>(packet),sample)){
   inputSkipped.fetch_add(1,std::memory_order_relaxed);return original;
  }
  kulich_input::attachTrace(sample,trace);
  int64_t when=now();bool active=kulich_timer_trace_active();int factor=kulich_timer_trace_multiplier();
  std::unique_lock<std::mutex> guard(samplesGate,std::try_to_lock);
  if(!guard.owns_lock()){inputBusy.fetch_add(1,std::memory_order_relaxed);return original;}
  if(version!=generation.load(std::memory_order_acquire)||client!=boundClient.load()||!inputReady.load()||!ready.load()){
   inputSkipped.fetch_add(1,std::memory_order_relaxed);return original;
  }
  inputBook.add(when,active,factor,sample);
 }catch(...){inputSkipped.fetch_add(1,std::memory_order_relaxed);}
 return original;
}
std::string report(){
 std::lock_guard<std::mutex> install(installGate);
 std::lock_guard<std::mutex> samples(samplesGate);
 return "Movement correction observer: ready="+std::to_string(ready.load())+" calls="+std::to_string(calls.load())+
  " skipped="+std::to_string(skipped.load())+" busy="+std::to_string(busy.load())+" "+describe(book,now())+
  (failure.empty()?"":"\n  unavailable="+failure)+
  "\nNative input observer: ready="+std::to_string(inputReady.load())+" calls="+std::to_string(inputCalls.load())+
  " skipped="+std::to_string(inputSkipped.load())+" busy="+std::to_string(inputBusy.load())+" "+kulich_input::describe(inputBook)+
  (inputFailure.empty()?"":"\n  inputUnavailable="+inputFailure)+
  "\nReceived typed packets at bound client; packet19 also matches own runtime ID. Same-input-tick comparisons use prior native submissions, not current actor position. Duplicate conflicting inputs and riding are excluded. Submission is not a server acknowledgement. Application, anticheat reason and server acceptance remain unverified. The comparison observers do not discard corrections; the separate own-player frame backend reports its tick mapping above.";
}
bool inputIsReady(){return inputReady.load(std::memory_order_acquire);}
}
extern "C" uint64_t kulich_auth_input_observe(void* sender,void* packet,uint64_t callerLr,uint64_t callerSp)noexcept{
 return kulich_correction::observeInput(sender,packet,callerLr,callerSp);
}
extern "C" bool kulich_correction_input_ready(){return kulich_correction::inputIsReady();}
