package dev.custom.bedrockgui;

/** Keeps Application-based SDK lookups in the same loader as the hosted game. */
public final class HostApplication extends android.app.Application {
    @Override public void onCreate(){
        super.onCreate();
        registerActivityLifecycleCallbacks(new android.app.Application.ActivityLifecycleCallbacks(){
            @Override public void onActivityPreCreated(android.app.Activity activity,android.os.Bundle state){
                if(!activity.getClass().getName().startsWith("com.microsoft.xal.browser."))return;
                ClassLoader loader=GameRuntime.loader;
                if(loader==null)return;
                // ActivityThread may replace the factory's extras loader with
                // the host APK loader. Repair it before the SDK reads enums.
                if(activity.getIntent()!=null)activity.getIntent().setExtrasClassLoader(loader);
                if(state!=null)state.setClassLoader(loader);
                GameRuntime.log("Auth: game class loader applied before SDK onCreate");
            }
            @Override public void onActivityCreated(android.app.Activity a,android.os.Bundle b){}
            @Override public void onActivityStarted(android.app.Activity a){}
            @Override public void onActivityResumed(android.app.Activity a){}
            @Override public void onActivityPaused(android.app.Activity a){}
            @Override public void onActivityStopped(android.app.Activity a){}
            @Override public void onActivitySaveInstanceState(android.app.Activity a,android.os.Bundle b){}
            @Override public void onActivityDestroyed(android.app.Activity a){}
        });
    }
    @Override public ClassLoader getClassLoader() {
        ClassLoader gameLoader = GameRuntime.loader;
        return gameLoader != null ? gameLoader : super.getClassLoader();
    }
}
