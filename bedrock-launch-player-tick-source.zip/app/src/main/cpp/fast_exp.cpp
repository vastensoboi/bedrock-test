#include "fast_exp_core.h"
#include <jni.h>
#include <atomic>
#include <mutex>
#include <chrono>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cerrno>
#include <string>
namespace {
using kulich::Address;
using Tick=void(*)(void*);
using Use=bool(*)(void*,void*,bool);
std::atomic<Address> gameBase{0},boundClient{0};
std::atomic<bool> enabled{false},inFlight{false};
std::atomic<int64_t> lease{0};
std::atomic<uint64_t> tickEntries{0},ticks{0},attempts{0},returnedTrue{0},completed{0};
std::atomic<int> lastSlot{-1},lastCount{0},interval{3},lastReason{0};
std::atomic<uint64_t> validTicks{0},localTicks{0},rejected{0},epoch{0};
kulich::TickInterval cadence;
kulich::TickWarmup warmup;
uint64_t appliedEpoch=0;
int memory=-1;Tick playerTick=nullptr;
std::mutex installMutex,callMutex;
int64_t millis(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
bool readMemory(Address at,void* dest,size_t size){
 at=kulich::untag(at);
 if(memory<0||at<4096||size>65536||at>0x00ffffffffffffffULL-size)return false;
 ssize_t n;do{n=pread(memory,dest,size,static_cast<off_t>(at));}while(n<0&&errno==EINTR);
 return n==static_cast<ssize_t>(size);
}
void act(void* mode){
 int64_t now=millis();
 std::unique_lock<std::mutex> lock(callMutex,std::try_to_lock);if(!lock.owns_lock())return;
 uint64_t currentEpoch=epoch.load();
 if(appliedEpoch!=currentEpoch){appliedEpoch=currentEpoch;cadence.reset();warmup.reset();}
 if(!enabled.load(std::memory_order_acquire)||now>lease.load()){cadence.reset();warmup.reset();return;}
 auto read=readMemory;auto base=gameBase.load();
 // Server/remote-player GameModes must not reset this local player's cadence.
 Address player=0,playerTable=0,owner=0;
 if(!readMemory(kulich::untag(reinterpret_cast<Address>(mode))+8,&player,8)||
    !readMemory(player,&playerTable,8)||kulich::untag(playerTable)!=base+0x139f6ea0ULL||
    !readMemory(kulich::untag(player)+3240,&owner,8)||kulich::untag(owner)!=boundClient.load())return;
 localTicks.fetch_add(1);
 int reason=0;
 auto held=kulich::resolve(read,base,boundClient.load(),reinterpret_cast<Address>(mode),&reason);
 if(!held.stack){lastReason.store(reason);rejected.fetch_add(1);cadence.reset();return;}
 lastReason.store(0);validTicks.fetch_add(1);
 // Observe repeated local callbacks before issuing any native action. A lone
 // setup callback (as observed in 0.18) is not a periodic game tick source.
 if(!warmup.observe(now)){lastReason.store(13);return;}
 if(!cadence.due(interval.load()))return;
 // The mode and player belong to the engine tick that invoked this callback.
 // No cached object or Java worker thread is used to call useItem.
 if(!enabled.load()||millis()>lease.load())return;
 Address table=0;if(!readMemory(reinterpret_cast<Address>(mode),&table,8))return;
 auto use=reinterpret_cast<Use>(table==base+0x13d227d0ULL?base+0x100a0060ULL:base+0x100a142cULL);
 lastSlot.store(held.slot);lastCount.store(held.count);attempts.fetch_add(1);
 inFlight.store(true);
 bool result=use(mode,reinterpret_cast<void*>(held.stack),false);
 completed.fetch_add(1);inFlight.store(false);
 if(result)returnedTrue.fetch_add(1);
}
void tickPlayer(void* self){
 tickEntries.fetch_add(1,std::memory_order_relaxed);
 auto read=readMemory;
 kulich::dispatchPlayerUpdate(reinterpret_cast<Address>(self),read,
  [](Address tagged){playerTick(reinterpret_cast<void*>(tagged));},
  [](){ticks.fetch_add(1,std::memory_order_relaxed);},
  [](Address taggedMode){act(reinterpret_cast<void*>(taggedMode));});
}
std::string install(Address base,Address client){
 std::lock_guard<std::mutex> guard(installMutex);
 if(gameBase.load()){if(gameBase.load()!=base)return "Game library base changed";boundClient.store(client);return {};}
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0)return "Cannot open own process memory";
 Address cv=0;if(!readMemory(client,&cv,8)||cv!=base+0x1388fe70ULL)return "Client type mismatch";
 // The LocalPlayer update at 0xaf5e460 calls Player's update at 0x101f10fc
 // (BL at 0xaf5e560). It occupies primary vtable slot 25, unlike the unused
 // GameMode callback source observed on the user's 0.19 run.
 Address a=base+0x139f6ea0ULL+25*8;
 Address original=0,useA=0,useB=0;
 if(!readMemory(a,&original,8)||original!=base+0xaf5e460ULL||
    !readMemory(base+0x13d227d0ULL+96,&useA,8)||
    !readMemory(base+0x13d22900ULL+96,&useB,8)||
    useA!=base+0x100a0060ULL||useB!=base+0x100a142cULL)return "Player update or useItem profile mismatch";
 long pageSize=sysconf(_SC_PAGESIZE);if(pageSize<=0)return "Invalid page size";
 Address page=a-a%pageSize;
 if(a+8>page+static_cast<Address>(pageSize))return "Unexpected vtable page";
 // Require the expected read-only, non-executable game mapping before changing
 // only its LocalPlayer update entry. The original is saved before publishing.
 FILE* maps=fopen("/proc/self/maps","r");if(!maps)return "Cannot inspect vtable mapping";
 char line[2048],perms[5]={};unsigned long long lo,hi;bool found=false;
 while(fgets(line,sizeof(line),maps)){
  if(sscanf(line,"%llx-%llx %4s",&lo,&hi,perms)==3&&page>=lo&&page+pageSize<=hi){
   found=perms[0]=='r'&&perms[1]=='-'&&perms[2]=='-'&&std::string(line).find("/libminecraftpe.so")!=std::string::npos;break;
  }
 }
 fclose(maps);if(!found)return "Unexpected vtable mapping permissions";
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ|PROT_WRITE))return "Cannot update tick table";
 playerTick=reinterpret_cast<Tick>(original);
 boundClient.store(client);gameBase.store(base);
 __atomic_store_n(reinterpret_cast<Address*>(a),reinterpret_cast<Address>(&tickPlayer),__ATOMIC_RELEASE);
 if(mprotect(reinterpret_cast<void*>(page),pageSize,PROT_READ)){
  __atomic_store_n(reinterpret_cast<Address*>(a),original,__ATOMIC_RELEASE);
  gameBase.store(0);return "Cannot restore vtable read-only protection";
 }
 return {};
}
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_FastExpBridge_install(JNIEnv* env,jclass,jlong base,jlong client){
 auto error=install(static_cast<Address>(base),static_cast<Address>(client));return env->NewStringUTF(error.c_str());
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_FastExpBridge_enable(JNIEnv*,jclass,jboolean value){
 enabled.store(value);lease.store(0);epoch.fetch_add(1);lastReason.store(0);
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_FastExpBridge_configure(JNIEnv*,jclass,jint ticksValue){
 interval.store(kulich::clampTicks(ticksValue));epoch.fetch_add(1);
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_FastExpBridge_pulse(JNIEnv*,jclass,jboolean active){lease.store(active?millis()+1200:0);}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_FastExpBridge_status(JNIEnv* env,jclass){
 char text[512];snprintf(text,sizeof(text),"Fast Exp: enabled=%d entered=%llu ticks=%llu useItem calls=%llu returnedTrue=%llu slot=%d count=%d interval=%d localTicks=%llu validTicks=%llu rejected=%llu completed=%llu inFlight=%d reason=%d",
 enabled.load(),static_cast<unsigned long long>(tickEntries.load()),static_cast<unsigned long long>(ticks.load()),static_cast<unsigned long long>(attempts.load()),
 static_cast<unsigned long long>(returnedTrue.load()),lastSlot.load(),lastCount.load(),interval.load(),static_cast<unsigned long long>(localTicks.load()),
 static_cast<unsigned long long>(validTicks.load()),static_cast<unsigned long long>(rejected.load()),static_cast<unsigned long long>(completed.load()),inFlight.load(),lastReason.load());return env->NewStringUTF(text);
}
