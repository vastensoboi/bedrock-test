# Bedrock Diagnostic — diagnostic app source

Independent diagnostic implementation for an Android ARM64 device, including
Samsung Galaxy S24 Ultra. Runtime Android 17 support has NOT been verified.
No VHax binaries, Minecraft binaries or decompiled implementation are bundled.

Implemented:

- Discover installed com.mojang.minecraftpe and list its base/split APK files.
- Record Android version, device model, supported ABIs and page size.
- Extract lib/arm64-v8a/*.so into the app's private code cache.
- Mark extracted files read-only before writing through an open descriptor.
- Validate ZIP CRC/length and ELF64 little-endian AArch64 shared-object headers.
- Filter traversal paths, bound extraction and reject duplicate filenames.
- Create a separate DexClassLoader with original installed APKs and extracted libs.
- Resolve libminecraftpe.so's path WITHOUT loading its native code.
- Locate com.mojang.minecraftpe.MainActivity WITHOUT class initialization;
  check that it inherits Android Activity.
- Save/export a text report and remove the private native-library cache.

Not implemented or established:

- Launching Minecraft inside this app, game Application/provider initialization,
  resources integration, game JNI initialization or native library load testing.
- Injecting into a running Minecraft process.
- Auto Swap, AutoBuy, Fast Exp, BlockTrap, VPN, or protocol edits.
- Compatibility with Minecraft 1.26.60 or the user's Android firmware.

PASS in the diagnostic means ONLY that files and class resolution succeeded.
It does not mean Minecraft can be launched, native libraries loaded, or gameplay
features used. Diagnostic preparation can take space approximately equal to the
uncompressed ARM64 libraries. The cleanup button removes the prepared cache.
Original installed APK files are not modified. No network permission is requested.
Code loading is confined to the user's installed Minecraft package in this profile.

## Build status

No APK has been built. The environment has Java 21's compiler module but no
Android SDK or Gradle. An SDK download could not run because network approval
was not granted/completed. The Android activity has not been compiled.
The pure-Java extraction component has been compiled and its tests passed.

For a complete SDK environment: JDK 17, Gradle 8.7, Android SDK Platform 35.
Set ANDROID_HOME or sdk.dir in local.properties, then:

    gradle :app:assembleDebug

Output: app/build/outputs/apk/debug/app-debug.apk
A manual GitHub Actions build is provided in .github/workflows/build.yml;
it has not been run. Gradle wrapper is not included.

## Component checks

    javac -d build/tests app/src/main/java/dev/custom/bedrockgui/GameArchiveCache.java tests/ArchiveTest.java
    java -cp build/tests ArchiveTest

The supplied test creates synthetic APKs and ELF headers. It verifies split
extraction, exact bytes, permissions, traversal filtering, repeat preparation,
duplicate rejection, wrong architecture, missing game library and cleanup.
It does not exercise a real Minecraft binary or Android class loader.

The completed test was also run on the actual uploaded libmc.so as an extraction
fixture. Only its bytes/header were read; the uploaded binary was NOT executed.
