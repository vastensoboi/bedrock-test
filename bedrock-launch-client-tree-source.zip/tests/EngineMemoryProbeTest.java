import dev.custom.bedrockgui.EngineMemoryProbe;
import java.io.*;
import java.nio.*;
import java.util.*;

public final class EngineMemoryProbeTest {
    static void check(boolean value){if(!value)throw new AssertionError();}
    static void put(byte[] bytes,int offset,long value){ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).putLong(offset,value);}
    public static void main(String[] args)throws Exception {
        long base=0x100000000L,globals=0x100000,game=0x200000,client=0x204000,player=0x208000,mode=0x20c000,stale=0x214000;
        Map<Long,byte[]> memory=new LinkedHashMap<>();
        byte[] global=new byte[64],g=new byte[7664],c=new byte[3648],p=new byte[4304],m=new byte[16];
        put(global,0,game);put(global,8,0xb400000000000000L|player);put(global,16,stale);
        put(g,0,base+0x1389f8b8L);put(g,0x100,client);put(g,0x108,0x12345678);
        put(c,0,base+0x1388fe70L);put(c,0x200,player);
        put(p,0,base+0x139f6ea0L);put(p,0x300,mode);
        put(m,0,base+0x13d22900L);put(m,8,player);
        memory.put(globals,global);memory.put(game,g);memory.put(client,c);memory.put(player,p);memory.put(mode,m);
        EngineMemoryProbe.Reader reader=(address,destination,count)->{
            for(Map.Entry<Long,byte[]> e:memory.entrySet()){
                long offset=address-e.getKey();
                if(offset>=0&&offset<=e.getValue().length-count){System.arraycopy(e.getValue(),(int)offset,destination,0,count);return true;}
            }
            throw new IOException("Unmapped/stale fixture address");
        };
        List<EngineMemoryProbe.Region> maps=Arrays.asList(
                EngineMemoryProbe.Region.parse("00100000-00100040 rw-p 00000000 00:00 0 [globals]"),
                EngineMemoryProbe.Region.parse("00200000-00220000 rw-p 00000000 00:00 0 [heap]"));
        List<String> log=new ArrayList<>();
        EngineMemoryProbe.Result result=new EngineMemoryProbe(maps,reader,base,log::add).scan(globals,globals+64);
        check(result.candidates.get("MinecraftGame")==1);check(result.candidates.get("ClientInstance")==1);
        check(result.candidates.get("LocalPlayer")==1);check(result.candidates.get("SurvivalMode")==1);
        check(result.candidates.size()==4);check(result.readFailures==1);check(!result.limited);
        check(EngineMemoryProbe.untag(0xb400000000208000L)==player);
        check(log.stream().anyMatch(s->s.contains("Link MinecraftGame+0x100 -> ClientInstance")));
        check(log.stream().anyMatch(s->s.contains("Link ClientInstance+0x200 -> LocalPlayer")));
        check(log.stream().anyMatch(s->s.contains("Link SurvivalMode+0x8 -> LocalPlayer")));
        // Exercise the actual tree layout: the client is no longer a direct
        // MinecraftGame field, and the player is only reachable through it.
        long tree=0x218000;byte[] node=new byte[72];
        put(g,0x100,0);put(g,0x980,tree);put(global,8,0);
        put(c,24,base+0x13890c20L);put(node,0,tree);node[24]=1;node[32]=2;
        put(node,40,0xb400000000000000L|(client+24));put(node,48,0);put(node,56,client);
        memory.put(tree,node);List<String> treeLog=new ArrayList<>();
        EngineMemoryProbe.Result treeResult=new EngineMemoryProbe(maps,reader,base,treeLog::add).scan(globals,globals+64);
        check(treeResult.candidates.get("ClientInstance")==1);check(treeResult.candidates.get("LocalPlayer")==1);
        check(treeResult.candidates.get("SurvivalMode")==1);check(!treeResult.limited);
        check(treeLog.stream().anyMatch(s->s.contains("Client tree key=2 node+40 -> ClientInstance")));
        byte[] dense=new byte[256*1024];
        for(int i=0;i<dense.length;i+=8)put(dense,i,0x10000000L+i);
        EngineMemoryProbe.Reader busy=(address,destination,count)->{
            if(address>=globals&&address+count<=globals+dense.length)
                System.arraycopy(dense,(int)(address-globals),destination,0,count);
            else Arrays.fill(destination,0,count,(byte)0);
            return true;
        };
        List<EngineMemoryProbe.Region> denseMaps=Arrays.asList(
                new EngineMemoryProbe.Region(globals,globals+dense.length,0,true,true,"globals"),
                new EngineMemoryProbe.Region(0x10000000L,0x10100000L,0,true,true,"heap"));
        EngineMemoryProbe.Result limited=new EngineMemoryProbe(denseMaps,busy,base,s->{}).scan(globals,globals+dense.length);
        check(limited.limited);check(limited.reads==20000);check(limited.candidates.isEmpty());
        boolean invalid=false;
        try{new EngineMemoryProbe(maps,reader,base,s->{}).scan(0,5*1024*1024L);}catch(IllegalArgumentException expected){invalid=true;}
        check(invalid);
        System.out.println("PASS: typed candidates, tagged pointers, bounded object graph, stale/unmapped reads, cycle deduplication and read budget.");
    }
}
