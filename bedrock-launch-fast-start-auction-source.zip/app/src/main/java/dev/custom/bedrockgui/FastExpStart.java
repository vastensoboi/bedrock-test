package dev.custom.bedrockgui;

/** UI-thread startup request: wait for a verified world, never re-enable after success/pause. */
public final class FastExpStart {
    private boolean requested,busy;private long next;
    public FastExpStart(boolean requested,long now){this.requested=requested;next=now+5000;}
    public boolean due(long now,boolean focus){return requested&&!busy&&focus&&now>=next;}
    public void begin(){busy=true;}
    public boolean result(long now,boolean worldReady,boolean focus){
        busy=false;
        if(!requested)return false;
        if(worldReady&&focus){requested=false;return true;}
        next=now+8000;return false;
    }
    public void cancel(){requested=false;}
}
