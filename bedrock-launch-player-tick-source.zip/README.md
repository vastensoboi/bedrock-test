# Bedrock Launch Test 0.20 — LocalPlayer update source

This is a separate test app, applicationId dev.custom.bedrocklaunchtest.
It does not overwrite the installed Minecraft or Bedrock Diagnostic app.

The test prepares installed Minecraft's base/split APKs and ARM64 libraries,
then attempts native startup and a game Activity inside this app's :game process.
This hosts the game inside its own process. Version 0.18 adds an experimental
Fast Exp implementation through an independent native tick bridge, disabled by
default. It checks for XP bottles and attempts useItem on the engine tick. It
has not yet been executed on-device. Auto Buy and Block Trap remain unavailable.
No libVHax.so is loaded. See the 0.18 section for ABI, controls and validation.

Implemented startup attempt:

1. Extract game native libraries using the previously tested extraction component.
2. Create a separate DexClassLoader through AppComponentFactory for the game Activity.
3. Initialize declared game Application/provider classes (static initialization
   only; full foreign Application/provider lifecycle is NOT emulated).
4. Preload known game native dependencies and libminecraftpe.so from that loader.
5. Load the small libmc.so forwarding shim.
6. Attach game resources with ResourcesLoader/ResourcesProvider public APIs.
7. Instantiate a host Activity subclass whose real MainActivity superclass is
   supplied by the installed game's DEX at runtime, and call its onCreate.
8. Write stage markers and Java failures to an app-private journal. After native
   crashes the host can show available historical process-exit reasons.

This version uses public class-loader/component/resource APIs and does not
modify private pathList/nativeLibraryDirectories fields.

## Crucial limitations

The user's device logs confirm native library loading, resource resolution,
game onCreate returning and Activity resume. The process then exits with
SIGABRT (signal 6). Version 0.5's own-UID log identifies a CheckJNI method/receiver
mismatch in pgs::JniHelperImpl::InitializeImpl. In 0.8 the user confirmed the
main menu with a screenshot and reported entering a world, then a crash after
breaking a block. After installing 0.9 the user reports breaking blocks without
another crash. The user confirmed icon dragging and menu interaction work in 0.11. The new categorized layout in 0.12 still needs a device test.
The copied Application/provider static initialization does not reproduce all
Android startup behavior. Game callbacks, resources, identity, storage, auth,
provider registration, dynamic features or native dependencies can still fail.
Compatibility beyond the observed menu and world interaction is unverified.
Returning from onCreate does not prove successful gameplay or menu rendering.
This app does not disable licensing checks or change the installed game.

The game runs with the host app's UID, package identity and private storage;
it does not inherit the original app's grants, private files or login state.
Application class loading and library preloading occur during factory startup;
a slow or blocked native initializer may time out or crash the :game process.
The current device test is world interaction stability after successful menu
startup. Login and joining a server are not needed for this test.

## Native shim origin

app/src/main/jniLibs/arm64-v8a/libmc.so is the exact 4.64 KiB binary supplied by
this session's user, not a newly built independent shim. Its ELF/functions were
statically inspected before packaging. It forwards native entry points to the
real libminecraftpe.so via dlopen/dlsym and was not executed in the development
workspace. This binary is used only to test the observed startup bridge.
A readable independent reconstruction was produced separately in mc-forwarder.c.
This prototype does not claim authorship of the supplied binary.

The game-api-stub module is a compile-only class declaration and MUST NOT be
packaged in the APK. The cloud workflow checks that the stub is absent from DEX.

## Checks performed here

- Parsed syntax of all Java sources.
- Compiled and ran extraction-component tests: split extraction, unchanged bytes,
  read-only files, path filtering, duplicates, invalid ELF and cleanup.
- Checked manifest component paths, compile-only dependency and shim identity.

Android SDK remains unavailable locally. Earlier builds were compiled through
GitHub Actions and tested by the user. The new 0.20 Android changes have not yet
been compiled or tested on-device. A workflow supplies the Android build and
APK packaging checks.

## Device test after a successful APK build

1. Install Bedrock Launch Test alongside the existing diagnostic app and game.
2. Open it and tap «Тест запуска Minecraft».
3. If the game opens, report whether the title screen actually appears.
4. If it fails/closes, return, tap «Показать журнал запуска», then «Сохранить журнал».
5. If the test process is still running, «Остановить тестовый процесс игры» stops
   only this app's own :game process. It does not kill the installed game process.

## Building

JDK 17, Android SDK Platform 35, Gradle 8.7. SDK path via ANDROID_HOME,
ANDROID_SDK_ROOT or local.properties sdk.dir.

    gradle :app:assembleDebug

Minimum Android version is 11 / API 30. Target SDK remains 34; compile SDK 35
supplies the public APIs used. Testing on Android 17 is still required.

Public Android API references:
- https://developer.android.com/reference/android/app/AppComponentFactory
- https://developer.android.com/reference/android/content/res/loader/ResourcesProvider

## Device observations and resource fix (0.4)

The user's S24 Ultra / Android 17 / Minecraft 1.26.60.4 log confirms successful
loading of the eight game native libraries and the mc shim. The initial hosted
Activity failed because the host framework theme was not AppCompat-compatible.
The original game Activity theme is now applied before super.onCreate.
The next device log confirms the theme was resolved as AppTheme.SplashScreen;
startup then failed with Resource ID #0x0 in initAccessibilityDisclosurePopup.

0.4 adds a Resources subclass that retries unresolved game/host-name lookups
against com.mojang.minecraftpe. It does not override Android package/UID identity,
replace successful lookups, redirect framework/other-package names, or skip the
accessibility dialog. Remapped and missing lookups are recorded (up to 32 keys).
The next device log confirms all three accessibility popup resource names now
resolve to game resource IDs, onCreate returns and the Activity resumes. The
process then exits with reason=2, status=6. This establishes progress past the
earlier Java resource exception, not successful game startup.

## Native crash diagnostics (0.5)

The startup behavior is unchanged from 0.4. Version 0.5 adds evidence collection
for the observed SIGABRT rather than guessing a native fix:

- Before launch, start logcat filtered to this application's own UID. Keep at
  most 2 MiB in app-private storage, stop after 60 seconds, and include the last
  128 KiB in the saved report. No READ_LOGS permission is requested. Android may
  deny access or omit system/debuggerd records; the log is not guaranteed to
  contain the native crash.
- For matching historical game-process exits after the last launch, request
  ApplicationExitInfo.getTraceInputStream(). Android may provide no trace.
- When available, parse selected Android tombstone protobuf fields (8 MiB limit)
  to show the abort message, signal, cause and up to 40 crashing-thread frames.
  ANR traces are not passed to this native protobuf parser.
- Display version 0.5 in the main screen and export bedrock-launch-0.5.txt.

The native report parser passed a pure-Java test with an abort message, Unicode,
signal, thread backtrace, unknown fields and truncated/invalid protobuf input.
Java source syntax parsing passed; this does not substitute for Android builds.

After installing the 0.5 APK, perform one launch attempt, wait for the failure,
return and use «Сохранить журнал». Root and a separate Minecraft APK upload
are not required for this diagnostic step.

References:
- https://developer.android.com/reference/android/app/ApplicationExitInfo#getTraceInputStream()
- https://android.googlesource.com/platform/system/core/+/refs/heads/master/debuggerd/proto/tombstone.proto

## Context loader JNI compatibility (0.6)

The provided bedrock-launch-0.5.txt contains the exact fatal message:

    JNI DETECTED ERROR IN APPLICATION: can't call java.lang.ClassLoader
    dev.custom.bedrockgui.HostedGameActivity.getClassLoader()
    on instance of android.app.Application

The aborting native stack includes pgs::JniHelperImpl::InitializeImpl,
pgs::JniHelper::Initialize and Pgs_initialize. Native code attempts to reuse a
method ID resolved on the game Activity with an Application receiver. An
Activity-declared override is invalid for that receiver.

0.6 removes HostedGameActivity's getClassLoader/getResources/getAssets overrides.
The existing attached base Context still supplies game resources and its loader.
The host Application now returns the shared game loader once prepared, so SDK
lookups through Application can resolve the same classes. The loader reference
is volatile for cross-thread visibility. No JNI check is disabled.

Before game onCreate, a guard records getClassLoader's declaring class, verifies
that the Application is an instance of that class, and verifies both contexts
return the prepared game loader. A mismatch stops with a Java journal entry
instead of deliberately proceeding into the already observed native abort.

The new Android code requires a fresh GitHub build and device test. This change
addresses the observed mismatch; further startup failures remain possible.

## Explicit Play Games initialization (0.7)

The provided bedrock-launch-0.6.txt confirms the loader compatibility guard:

    owner=android.content.ContextWrapper applicationCompatible=true
    activityLoader=true applicationLoader=true

Game onCreate returns and the Activity resumes. The next native abort has a
different cause: a pending IllegalStateException from PlayGames.getAchievementsClient
stating that PlayGamesSdk has not been initialized. Loading the provider class
in NativeStartup does not invoke PlayGamesInitProvider.onCreate and therefore
does not initialize the SDK.

0.7 calls the public static PlayGamesSdk.initialize(android.content.Context)
method reflectively from the game class loader, on the main thread before
super.onCreate. It receives the attached host Application. A successful return
is logged and the call is not repeated on Activity recreation in the same
process. Reflection/initialization failures are included in the existing Java
failure journal before native game startup, rather than swallowed.

This is targeted SDK initialization, not full emulation of foreign providers or
the original Application lifecycle. No second Play Games SDK is bundled, no
account sign-in is explicitly requested, and no game application ID, package
identity or signing certificate is spoofed. Google authentication and game
services under the host package are not verified. An SDK initialization return
does not establish that the game menu or login works.

The API signature and provider's normal initialization role were checked against
Google's reference:
https://developers.google.com/android/reference/com/google/android/gms/games/PlayGamesSdk

Java source syntax checks pass. The new Android build and device test remain
necessary; the runtime trace must establish whether this resolves the observed
SDK initialization exception and what the next startup stage does.

## Firebase initialization and Messaging components (0.8)

The user's bedrock-launch-0.7.txt confirms PlayGamesSdk.initialize returns,
game onCreate returns and the Activity resumes. The subsequent abort reports
a pending IllegalStateException: default FirebaseApp is not initialized in
dev.custom.bedrocklaunchtest:game. Its Java stack goes through
FirebaseMessaging.getInstance and NotificationListenerService.retrieveDeviceToken.

0.8 calls FirebaseApp.initializeApp(Context) from the installed game's SDK via
reflection before game onCreate. It passes the Activity's context with attached
game resources, so FirebaseOptions can read the game's actual string resources.
Using only the host Application for this call would omit those resource values.
No configuration values are invented or printed in the stage journal.

The host manifest declares Firebase's ComponentDiscoveryService metadata for
FirebaseMessagingRegistrar, FirebaseInstallationsRegistrar and TransportRegistrar,
matching the standard Firebase component discovery format and the supplied VHax
manifest. This service declaration is used for metadata lookup; the launcher
does not start it. The SDK classes still come from the installed game, not a
second bundled Firebase dependency.

The preflight checks for a non-null default FirebaseApp and calls the same
FirebaseMessaging.getInstance entry point that failed in 0.7. Each stage is
logged. A reflective Java error is preserved by the existing Activity journal.
The helper is skipped after successful initialization on Activity recreation.

This prepares the in-process SDK; it does not establish successful notification
token registration or implement complete incoming push handling under the host
package. The original game still controls its notification-token request.

References checked:
- https://github.com/firebase/firebase-android-sdk/blob/master/firebase-common/src/main/java/com/google/firebase/FirebaseApp.java
- https://github.com/firebase/firebase-android-sdk/blob/master/firebase-components/src/main/java/com/google/firebase/components/ComponentDiscovery.java
- https://firebase.google.com/docs/reference/android/com/google/firebase/FirebaseOptions

Java source syntax and Firebase manifest entries were checked locally.
Android compilation, SDK initialization and game rendering still require the
GitHub build and the user's device test. No working game menu is claimed.

The new root-level Build latest launch test workflow chooses the highest
versionCode among root bedrock-launch ZIPs for this applicationId. It accepts
download suffixes such as (1), ignores older app versions and rejects different
archives with the same highest versionCode. Future source updates with a higher
versionCode can reuse that workflow without adding another workflow file.

## World test and longer crash capture (0.9)

The user's 0.8 log confirms successful Play Games and Firebase initialization.
It records SecurityException from MainActivity.acquireMulticast because the
host lacks android.permission.CHANGE_WIFI_MULTICAST_STATE. 0.9 declares this
permission for the game's multicast lock; the game's network behavior is
otherwise unchanged. Android's process exit record says reason=2, status=6,
but provides no tombstone. The log continues after the Wi-Fi exception and
does not contain the fatal native diagnostic. It does not prove that Wi-Fi
caused the later crash or that breaking a block was its direct cause.

The old capture ended within its 60-second limit while the world was loading.
0.9 records own-UID logcat for up to 20 minutes. Two rotating segments of at
most 2 MiB each retain recent bytes instead of stopping when full. Export uses
the last 256 KiB across both segments and reports capture state. A new capture
replaces the previous one; obsolete reader threads cannot append to the new
capture. Exit records now include timestamps and elapsed time since launch.
Android can still restrict logcat or omit native diagnostics.

RollingLogTest checks file-size bounds, multiple rotations, cross-file tails,
latest error retention, reopening and reset. It passed locally. Java source
syntax and the permission manifest are checked; the Android build/device test
remain necessary. This is a permission correction and a diagnostic improvement,
not a confirmed fix for the block interaction crash.

Public API reference:
https://developer.android.com/reference/android/net/wifi/WifiManager.MulticastLock

## Initial menu (0.10)

The previously tested 0.9 source ZIP is retained separately as
bedrock-launch-world-source.zip. 0.10 keeps its launch, permissions and capture
behavior and adds GameMenu after the game's onCreate returns.

- A GUI button opens the module panel. Dragging moves the button; its normalized
  position is saved in the host app's preferences and clamped after resizing.
- The panel closes through its close button or a tap on the backdrop.
- With the panel closed, the root overlay does not consume empty-space touches.
  With it open, the backdrop captures outside taps so they do not reach the game.
- The initial module list is empty. There are no decorative gameplay toggles.
- Future Java modules can be registered on the UI thread through
  GameMenu.addToggle(id, title, description, callback). They start disabled.
  User toggles call the supplied callback with the requested enabled state.
  If it throws, the switch reverts and the error is logged. Active callbacks
  receive a disable request during menu disposal.
- The menu uses the Activity's own window. It adds no SYSTEM_ALERT_WINDOW
  permission. It does not override the Activity's Context accessors.
- A menu construction failure is logged separately and does not deliberately
  finish the otherwise created game Activity.

This supplies a native Android UI extension point, not a JavaScript interpreter
or a port of earlier scripts. Gameplay modules still need actual implementations.

Java source syntax and ZIP/version selection are checked locally. The Android
build and manual device checks must verify visibility above the game surface,
opening/closing, dragging, position restoration, and world controls after closing.

## Menu icon and close behavior (0.11)

The user confirmed the 0.10 menu renders, but reported unwanted closing on
outside taps and an apparently static icon. Their requested behavior is a
draggable icon that toggles the menu, with the close button still available.

- The backdrop now consumes outside taps without closing the menu.
- The GUI icon stays visible when the panel opens. Its elevation and child
  order keep it above the backdrop and panel; its automatic state animator is
  disabled so pressing it cannot lower it beneath the panel.
- A short tap on the icon toggles the panel. The close button also closes it.
- Drag gestures retain the active pointer, use raw pointer coordinates, request
  that ancestors do not intercept the gesture, and suppress the tap after a drag.
  Pointer handoff and cancellation are handled without toggling the panel.
- Layout changes now use the latest in-memory normalized position instead of
  repeatedly reloading the last saved preferences during movement. The final
  position is persisted when a drag ends.

These changes address the reported behavior in code. Java syntax is checked;
Android compilation and a device test must establish actual touch behavior.
No new gameplay modules are added in this version.


## kulich menu and categories (0.12)

The user confirmed the 0.11 interaction fix and requested a circular kulich
button, movable categorized menu, Target and Utility sections, and Auto Buy,
Block Trap and Fast Exp entries under Utility.

0.12 supplies an oval drawable with equal 68 dp dimensions for the kulich icon.
Both icon and main panel can be dragged, with separate normalized positions
stored in preferences. The main panel moves by its header. The icon toggles
visibility; outside taps are consumed without dismissing the menu.

The wide layout follows the reference's three areas: categories, module list,
and module details. Narrow windows put categories in a row above list/details.
Russian category names are Таргет and Вспомогательные функции. The three
requested module entries are registered in Utility in the requested order;
Target is initially empty. Selecting an entry shows its description and status.

Gameplay status: the requested three entries have no game handlers yet. Their
switches are disabled and the UI explicitly says Не подключён к игре. No-op
callbacks are not registered. The current project hosts the game and Android UI;
it exposes no inventory/world/tick or packet API equivalent to the earlier JS
scripts. Auto Buy, Block Trap and Fast Exp gameplay behavior is unfinished.

Future implementations can bind a real handler with addToggle using catalog
IDs auto_buy, block_trap and fast_exp. The existing callback overload remains
available, plus one accepting category IDs target or utility. Unknown IDs create
new entries; existing catalog IDs acquire a handler. New handlers start disabled.
Module disposal requests disabling any active real handlers.

Java syntax, manifest and source ZIP selection are checked locally. Android
compilation and on-device UI tests remain necessary. The earlier working 0.11
source archive is retained as bedrock-launch-menu-fix-source.zip.


## Resizable window and no close button (0.13)

The user requested removing the close button and changing menu size by dragging
a corner. The header now only contains the brand and movement hint. Closing is
through the always-visible round kulich icon; outside taps still do not close.

A 48 dp wide touch area marked with ◢ in the bottom-right footer resizes the
window by raw pointer movement. The top-left corner is held fixed during the
resize. Growth is limited to available screen space; minimum dimensions are
360 by 264 dp where the viewport permits. Smaller windows use the compact
category row and scrolling module/detail areas. Dimensions are saved as viewport
ratios, separately from the icon and panel positions, on pointer release or
cancellation. Resizing supports pointer handoff and blocks parent interception.

This changes window bounds, not game rendering scale or gameplay modules.
Java syntax, manifest and ZIP selection are checked. Device tests still need
to verify shrink/grow, switching layout, reopening, and persistence after restart.


## Read-only engine binding probe (0.14)

The supplied native library has been fully reassembled and statically analyzed.
The next step needs evidence from live game objects. 0.14 adds a diagnostic
button in the Fast Exp details card: Проверить подключение. It starts a single
background check in the hosted game process and writes its result to the launch
journal. The gameplay switch stays disabled.

Before probing, GameEngineProbe verifies the exact library size (342231392)
and SHA-256 4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4.
An unknown library is rejected. It resolves the loaded base from /proc/self/maps,
including canonical-path equivalence for /data/user/0 and /data/data aliases.
It opens only /proc/self/mem in read-only mode. Android may deny this access;
that case is recorded rather than using another process, permissions or a
write-based fallback.

EngineMemoryProbe scans the known library data/BSS range and follows pointer
fields only in recognized structural candidates. Vptr profiles come from the
statically analyzed library. ClientInstance, MinecraftGame and LocalPlayer
read sizes come from inspected allocation sites (3648, 7664 and 4304 bytes).
Other recognized types are read only far enough to inspect their vptr or the
minimal known GameMode field range. Readable mapping bounds are checked before
reads; stale/unmapped read failures are handled. Tagged ARM64 pointers are
normalized. Repeated addresses are deduplicated.

Limits: 4 MiB root range, four-second scan deadline, 20000 reads, 30000 distinct
pointer candidates, 64 recognized object candidates, 96 reported links. Hashing
is outside the scan deadline. No game virtual function is called, no hooks or
memory writes are performed, and neither current-item selection nor throw
behavior is claimed. Finding a matching vptr identifies a structural candidate,
not proof that the object is current or safe to invoke.

The existing menu, resize behavior and SDK initialization are preserved. In a
single-player world, select Utility → Fast Exp → Проверить подключение, wait,
then return to the launcher and save bedrock-launch-0.14.txt. A result from the
main menu alone may not contain a LocalPlayer candidate.

EngineMemoryProbeTest passed against synthetic process mappings and memory:
typed graph traversal, tagged pointers, stale/unmapped reads, deduplication,
links, scan range rejection and read-budget enforcement. Java syntax is checked.
Android compilation and on-device read permissions/results are still unverified.


## Client container and clearer unavailable state (0.15)

The user's 0.14 screenshot and log confirm exact library SHA-256 match,
successful own-process memory reads, one MinecraftGame candidate and no read
failures. ClientInstance and LocalPlayer are not found by following only fields
that directly reference a recognized object. The disabled Enable switch confused
the user; unavailable entries now display their state without an inert switch.
Only a registered real gameplay handler exposes an Enable switch. Fast Exp still
has the diagnostic action and is not implemented as a gameplay module yet.

Additional static inspection of the exact library identifies the client
container rooted at MinecraftGame+0x980. The code at 0x9cdd280..0x9cdd4d8 uses
left/right links at node offsets 0/8, a byte key at 32, and allocates 72-byte
nodes. It stores interface pointers at 40/48 and the owning client pointer at
56. The probe now walks this container for recognized MinecraftGame candidates.
It checks readable/writable bounds, color byte, matching ClientInstance vptrs,
cycles, a 64-node tree cap and the existing global read/deadline limits before
following child nodes. All reads remain read-only. No virtual method is called.

The existing unit fixture now includes a client reachable only through that
container, a tagged secondary-interface pointer normalized to its owning client,
and a cycle. It confirms traversal to ClientInstance, LocalPlayer and SurvivalMode
in synthetic memory. These test results do not establish the live layout: the
new 0.15 run must confirm it in the user's world.

The next device action is still Utility → Fast Exp → Проверить подключение,
then exporting bedrock-launch-0.15.txt. Existing launch/menu behavior is retained.

## Entity registry player lookup (0.16)

The user's 0.15 log confirms one MinecraftGame and one ClientInstance through
the client tree, with no failed reads. No direct LocalPlayer field was found,
including probes after world spawn. Static inspection of the exact library's
ClientInstance virtual slot 31 (0x9b7f610) shows a weak entity reference at +576.
The resolution path checks the registry's sparse entity generation, then the
local-player component (key 0xacb47b38) and actor-pointer component (0x85b93800).
Actor pointers are stored in pages of 128 entries; sparse pages hold 2048 entries.

The read-only probe now follows that path without calling native code. It bounds
the hash buckets/nodes, handles collisions and cycles, checks sparse generations,
requires the exact LocalPlayer vptr, and verifies the constructor's client
back-reference at LocalPlayer+3240. It rereads the entity reference and sparse
indices before reporting a verified player binding. An entity replaced during
the probe is rejected. These checks do not retain or lock an object for later
gameplay calls; a future native bridge must acquire it on the game thread.

Synthetic tests cover a player reachable only through this registry, nonzero
sparse/dense pages, colliding hash keys, stale generations, missing marker,
incorrect client back-reference, cyclic hash links, invalid bucket length and
an entity replaced while being read. They pass locally. The new lookup has not
yet been compiled with the Android SDK or confirmed on the user's device.

This version does not read the selected inventory item or invoke use/place.
Fast Exp, Block Trap and Auto Buy remain unavailable. The old userscripts
require their original client's player/inventory/network API; they cannot run
unchanged in this app. The supplied VHax list contains BlockIn (surround self),
not a separate Block Trap module for trapping another player.

Upload bedrock-launch-player-source.zip in the repository root and run the
existing Build latest launch test workflow. It selects versionCode 15 / 0.16.
In a loaded single-player world: Utility → Fast Exp → Проверить подключение,
then export bedrock-launch-0.16.txt. The useful new journal entry is
"Player binding verified" or a specific reason the registry path was rejected.


## Held inventory item (0.17)

The user's 0.16 device log confirms three successful entity-registry player
bindings without read failures. It also finds PlayerInventory at player+1424,
Inventory at player+3144, two ItemStack candidates and GameMode. The two raw
ItemStack candidates are not assumed to be the held stack.

The new reader follows the native held-item getter at 0x10202190: PlayerInventory
selected index +16, suspended flag +176, backing container +184. It requires the
known Inventory vptr and emulates only the read-only slot lookup at 0x10084910:
the vector at +320/+328 contains 152-byte ItemStacks. It accepts hotbar indices
0..8, checks vector bounds/alignment, exact stack type, and reads count at +34.
The item handle at stack+8 points to an Item pointer (native instructions at
0x10770e0c..0x10770e18). Matching the ExperiencePotionItem vptr identifies XP
bottles; other nonempty items receive a generic description, not an invented
name. A missing live handle is rejected for a nonempty stack.

Before reporting, it compares the entity, inventory pointer, selected slot,
flag, vector, stack header and item handle again. A changed snapshot is rejected.
No game method is invoked and no memory is written. Fast Exp remains unavailable.

Synthetic tests pass for slot 9 with 64 XP bottles, another item, empty stack,
suspended inventory, invalid hotbar index, malformed vector and a slot changing
during the read. Android compilation and device verification are pending.

Upload bedrock-launch-held-item-source.zip and use the existing Build latest
launch test workflow (versionCode 16 / 0.17). In a loaded world select XP bottles,
then Utility → Fast Exp → Проверить подключение. Repeat after changing hotbar
slot/item; export bedrock-launch-0.17.txt. The display should match the selected
slot, XP-bottle type and quantity. These are diagnostic snapshots, not a native
ownership lock or a gameplay implementation.


## Native Fast Exp attempt (0.18)

The user's 0.17 report confirms slot 1, 64 XP bottles and the exact
ExperiencePotionItem vptr with no read failures. This release adds a new,
independent NDK library, kulichbridge. It does not load libVHax.so.

After the existing exact-file SHA check and a successful player probe, the
bridge validates the client vptr and four GameMode/SurvivalMode function
pointers. It replaces only virtual slot 10 in their live process vtables,
retaining and forwarding to each original tick. The shared RELRO page is
made writable for the two atomic pointer updates and restored read-only.
Installed Minecraft APK/library files are not modified. Hooks remain installed
until this app's game process exits; disabling only stops module actions.

On an original game tick, while enabled, the bridge resolves that tick's mode
and player, verifies client/mode backlinks, rereads the current selected
inventory slot and requires an exact nonempty ExperiencePotionItem. It checks
the suspended inventory flag and the item/slot snapshot again. At most once
per 150 ms it calls that mode's slot-12 implementation with the live ItemStack
and flag false. The original tick always runs first. No Java worker calls the
native game method directly. Other Item subclasses are rejected.

ARM64 evidence: GameMode tick 0x100a0ad8 and SurvivalMode tick 0x100a14b8 use
their this pointer and return void. Slot 12 is 0x100a0060 / 0x100a142c; the base
implementation takes an ItemStack pointer in x1 and flag in w2, and returns
a boolean in w0. The use path ultimately calls the item's virtual use routine.
This is a reconstructed internal ABI, not a public game API. Execution of this
new bridge has NOT been validated on the device. Return-true and call counters
are recorded separately; calls alone do not establish consumed XP bottles.

The Java UI heartbeat grants a 1200-ms native action lease only while the menu
is closed, Activity resumed and window focused. Opening kulich immediately
withdraws the lease; onPause disables the module. It starts disabled, never
persists enabled state, and the catalog switch is registered only after native
installation succeeds. Lifecycle cleanup disables actions. The native snapshot
guards do not determine every game-native screen/container state; this first
experiment should be tested standing in an ordinary loaded single-player world.

NDK 27.0.12077973 and CMake 3.22.1 are configured through AGP, ARM64 only, with
static libc++. The standalone source workflow explicitly installs both. The
existing archive workflow's Gradle build can install these SDK packages using
the SDK manager licenses accepted by setup-android. The first native build may
take longer. Android compilation still runs in GitHub Actions, not locally.

Validation here: the Java reader tests pass; 24 Java files syntax-parse; the
native selection guard compiles/runs on the host for tagged pointer preservation, XP type/count/slot,
suspension, ownership, malformed vectors, mismatched function profile and a
concurrent slot change. fast_exp.cpp passes host C++ syntax checking with a
minimal JNI declaration shim; that check does NOT validate Android JNI headers,
ARM64 code generation, hook publication, game-thread behavior or item-use ABI.
Those remain device/build checks. The supplied 4752-byte libmc.so is unchanged.

Device test: build/install 0.18, enter a throwaway single-player world, select
XP bottles and run Проверить подключение. If preparation succeeds the Fast Exp
switch appears. Enable it, close kulich using its round icon, and observe XP
bottle use. Reopen kulich to pause, disable the module, and use Статус Fast Exp.
The journal reports ticks, useItem calls, returnedTrue, last slot and count.
If ticks remains zero, no native use call is made. Save bedrock-launch-0.18.txt
regardless of outcome. Auto Buy and Block Trap are still unimplemented.


## Tick interval and execution diagnostics (0.19)

The user's 0.18 screenshot shows enabled=1, ticks=1, useItem calls=1,
returnedTrue=0 and 64 XP bottles. This does not establish whether useItem
returned false or never returned; 0.18 did not count completed calls. It also
does not establish a repeating tick source. The non-throwing issue is unresolved
without the device log/continued counter observations. No alternative native
entry point or argument is guessed in this update.

The menu adds a persisted interval slider from 1 to 10 GameMode ticks, default 3.
The 150-ms wall-clock throttle is removed. A pure cadence counter now spaces
calls by the selected number of valid local-player ticks. Other modes do not
advance or reset this counter. Pause, disable and reconfiguration reset cadence.
The first call after a reset is due immediately once the tick-source preflight
has observed at least three local callbacks, with gaps no greater than 250 ms.
The warmup resets after longer gaps, pause or reconfiguration. A single setup callback cannot
trigger another native attempt. This preflight does not establish that an
internal use call is safe or that callbacks arrive at 20 Hz.

Status now includes local/valid ticks, rejected reads, last rejection reason,
interval, completed calls and an inFlight flag, with Russian explanations in
the menu. A completed false result can be distinguished from a still-running
native call. Guards remain XP-only; no native method/ABI has been changed to
force acceptance. Callback/update discovery and actual XP throwing remain
pending device diagnosis. Block Trap and Auto Buy are unchanged.

Host tests verify exact cadence for all intervals 1..10, reset, interval changes
and clamping, plus the existing native item checks and a rejection reason.
C++ syntax checks and Java syntax parsing pass locally. Android build/device
execution have not been performed here.

Build via the existing archive workflow, versionCode 18 / version 0.19. Select
XP bottles, set an interval, enable and close kulich for five seconds, then open
Статус Fast Exp and export bedrock-launch-0.19.txt. The existing 0.18 journal
is also useful for diagnosing the original failed or unfinished use call.


## LocalPlayer update source (0.20)

The user's 0.19 log contains 106 exported status lines, all with ticks=0,
useItem calls=0 and inFlight=0. The held XP stack is correctly identified and
interval changes from 3 to 1 are applied. Therefore the current action pipeline
never runs after the original GameMode update. The old source cannot be treated
as a live periodic callback on this device/build. It did not count wrapper entry
separately, so the log alone cannot distinguish no entry from no original return.

This version removes the GameMode/SurvivalMode vtable tick replacements entirely.
It installs one replacement at LocalPlayer primary vptr 0x139f6ea0, slot 25,
original function 0xaf5e460. Static evidence in the exact supplied ARM64 file:
the function processes local-player state, writes a counter at player+3248,
and calls the corresponding base Player slot 25 at 0x101f10fc (BL at
0xaf5e560). It uses the player this pointer and its normal return does not
establish a scalar result. These are internal ABI observations, not proof of
live callback frequency. The new callback source must still be device-tested.

The wrapper increments entered before forwarding to the original update,
then increments ticks after it returns. Only afterwards does it read the live
GameMode pointer at player+2568 and dispatch module processing. It preserves
top-byte tags for native arguments. Reading after the original avoids retaining
a mode that the original update replaced. An absent/unreadable mode yields no
module action. useItem, XP checks, leases, lifecycle behavior, cadence 1..10
and the three-callback warmup remain unchanged. No GameMode vtable is modified.
The UI now says the bridge is installed instead of declaring gameplay readiness.

Host tests cover forwarding order, a GameMode replaced by the original update,
null/unreadable modes and tagged player/mode arguments, alongside prior interval
and held-item checks. C++ host syntax and Java syntax checks pass. Android NDK
compilation and execution on the phone remain pending. This release does not
claim that XP throwing is fixed until the device shows repeated callbacks and
actual projectiles. No Block Trap or Auto Buy behavior was added.

Build the source ZIP with the existing Build latest launch test workflow:
versionCode 19 / versionName 0.20. In the world select XP bottles, run the probe,
enable Fast Exp and close kulich for five seconds. Observe actual bottle use,
then open the menu, disable the module and export bedrock-launch-0.20.txt.
entered=0 means the selected wrapper was not reached; entered>0/ticks=0 means
an original update has not returned; ticks>0 with no calls is distinguished by
localTicks/reason/validTicks. Calls/returnedTrue still do not prove projectiles.
