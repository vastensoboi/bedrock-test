import dev.custom.bedrockgui.*;
public final class InventoryGridTest {
    static void check(boolean v){if(!v)throw new AssertionError();}
    static void reject(SlotGrid g,float x,float y){try{new InventoryGrid(g,x,y);throw new AssertionError();}catch(IllegalArgumentException expected){}}
    public static void main(String[] args){
        SlotGrid chest=new SlotGrid(27,1280,591,442.5f,150,836.9f,150,442.5f,199.4f);
        InventoryGrid inv=new InventoryGrid(chest,442.5f,328);
        check(inv.point(0)[0]==442.5f&&inv.point(0)[1]==328);
        check(Math.abs(inv.point(26)[0]-836.9f)<0.1&&Math.abs(inv.point(26)[1]-426.8f)<0.1);
        reject(chest,442.5f,200);reject(chest,700,328);reject(chest,442.5f,550);reject(chest,Float.NaN,328);
        try{inv.point(27);throw new AssertionError();}catch(IllegalArgumentException expected){}
        System.out.println("PASS: explicit player-inventory origin, 27-slot destination geometry, out-of-panel/shape/NaN/index guards");
    }
}
