# Phone evidence in 0.46; scheduling update in 0.47

The 0.46 report contains state=3 replies with matching request IDs -3, -5,
-13, -21, -33, -47, -57 and -61, each reply=0. No matching-lot purchase was
attempted. Actual visual refresh still requires user confirmation. Queued
commands canceled before execution show state=5/request=0; two transient
state=4/reason=2 rejections cause rereads, not reuse of changed tokens.

0.47 changes only Java scan scheduling/matcher allocations/maps parsing.
Response correlation, native descriptors/code profiles, game-thread execution,
live validation and uncertain-purchase handling remain unchanged. Reading can
use the remaining refresh delay, but never overlaps a pending native action.

# Native container bridge 0.46

Verified phone evidence from 0.45: request -3, Cereal RequestData at +8 ID,
action variant 1 (Place), count 1, source container byte 7 / slot 49 /
server network ID 13, destination container byte 29 / slot 9 / ID 0.
Padding bytes and pointers in the capture are not replayed. Variants preserve
index 0; the destination descriptor uses actual empty-stack ID 0, not -1.

Corrected details from further disassembly:
- ItemStackNetManagerClient +16 is LocalPlayer, confirmed constructor caller
  0xaf5ca88. +8 is feature-enabled; LocalPlayer +2592 owns the tagged manager.
- Scope wrapper ctor 0x10858744 checks open-request state, then calls begin
  0x1008e788 with selector 0. Dtor 0x10858794 ends via 0x1008e948 and queues data.
- Manager apply 0x1008fa6c consumes a unique action only on validated success.
  Use native operator new 0x135d38f0 and Place ctor 0x10856fe0. Scope byte size 16,
  action allocation 96, descriptors 40. Native destructor slot 1 frees rejection.
- A fresh scope allocates the request and decrements the game request counter;
  no custom counter is introduced. Flush 0x1008f834 runs on the original game
  thread, after scope closure. Requests never execute on Java worker/UI threads.
- Response decoder is virtual slot 16 at 0xdba72a0. Generic reader slot 9 and
  wrapper 17 both call slot 16. getId alone occurs before decode on the phone,
  explaining the 0.45 stable=0 response. The ARM64 forwarding shim preserves
  x8 (indirect result), x0/x1 and q0-q3, plus frame/link state and unwind data.
- ResponseInfo stride 48, result byte 0, typed request ID integer +16. Replies
  correlate by exact negative ID. Nonzero reply status is recorded, not equated
  to purchase failure/success; validate actual auction/inventory effects.

The native guard rechecks current window/node/vector, source item/tag/count,
current net-ID type/value, empty player inventory target, preview/back tags and
manager ownership before engine invocation. A queued ID must still match on tick.
MTE tags on the manager are preserved when calling native methods; memory reads
strip tags only for pread. Native function prefixes are pinned to the exact
342231392-byte game library / SHA-256 already checked by GameEngineProbe.

Tests verify guard rejection, real descriptor shape, fresh IDs, tagged manager,
request/response snapshots and reply rows. Source syntax and ARM64 assembly are
verified locally; runtime native ABI/engine calls await phone validation.

## Earlier investigation

# Exact-build container transaction investigation

Game SHA-256: 4e7f97ecf1989edfaa7ca4805acc907a63bd4c56f1b1965079b2c47f63e3a7c4.
This document records verified disassembly, not a completed action sender.

## Confirmed

- ItemStackRequestPacket vptr 0x13b13840, getId slot 2 function 0xc644e78:
  mov w0,#147; ret. Response vptr 0x13b9cd18, getId 0xdba64b8 returns 148.
- Request packet ctor 0xc644df0, vector at +48/+56/+64. RequestData stride 72
  confirmed by destructor 0xc64b094 and conversion 0xc649818.
- RequestData action vector +16/+24/+32, cereal action-variant stride 104
  confirmed by conversion 0xc649818. The recorder copies raw first-row and
  first-action data; no claim of decoded stack IDs is made.
- Response payload vector +48, response record stride 48 from request-manager
  response application 0x1008fd20. A getId observation may happen before
  deserialization; it is never treated as an acceptance acknowledgement.
- ItemStackRequestActionTake vptr 0x13dafa08. Native constructor 0x10856f3c
  receives (this, count, sourceSlotInfo, destinationSlotInfo); allocation size 96
  confirmed by callers 0xd39bb48, 0x10134cbc and 0x10136f64.
- Source/destination SlotInfo: first 13 bytes copied, net-ID variant at +16.
  Action source slot byte +28, destination slot byte +68. These are native
  object layouts, not a declaration that a zero-filled structure is valid.
- ItemStack net-ID variant at +128, discriminator +144. Copy from +128 is
  visible in 0x1016e2b4..0x1016e2d0; prediction code 0x1008cc54 confirms +144.
- LocalPlayer +2592 owns ItemStackNetManagerClient vptr 0x13d21c98, 14 slots.
  Native player update calls its flush 0x1008f834 at 0xaf5ee5c.
- Scoped action owner helpers: ctor 0x10858744, dtor 0x10858794,
  add action 0x108587cc delegates to manager 0x1008fa6c. That manager validates
  the action and uses current request context +96 before consuming ownership.
  Calling it with an invented request context is not valid.

## Current implementation

libkulichtransactions installs pass-through hooks on only the two getId vtable
entries after verifying the exact original targets, two ARM64 instructions and
read-only game mappings. The forwarding function has the confirmed integer
return ABI. No packet is rewritten, created, replayed or sent. Recording is
explicit and bounded to a 16-sample ring; own-memory reads use pread, no direct
untrusted dereferences. Original targets remain available after publication.

## Required next evidence

A genuine manual refresh transfer on the target phone, with Auto Buy and
Fast Exp disabled, establishes actual request fields and response observations.
Capture request count, raw RequestData/action and correlation details before
building a live native action bridge. Do not guess container full-name dynamic
fields, variant alternatives, request context ownership, request IDs or cursor
state. Native construction and context lifetime must be verified before sending.
The current ProtoHax script's take-to-cursor operation is the intended semantic
reference, but its JavaScript packet API is not present in the launcher.
