package dev.custom.bedrockgui;
import java.util.*;
public final class PearlPredictionTest {
    static void check(boolean value){if(!value)throw new AssertionError();}
    static void near(double a,double b){check(Math.abs(a-b)<.00001);}
    static double[] identity(){return new double[]{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};}
    static String matrixCamera(double[] view,boolean includeNear){
        StringBuilder csv=new StringBuilder("10,20,30,45,120,90,2");for(double value:view)csv.append(',').append(value);if(includeNear)csv.append(",0.5");return csv.toString();
    }
    static void renderCamera(){
        PearlPrediction.Vec origin=new PearlPrediction.Vec(10,20,30),ahead=new PearlPrediction.Vec(10,20,20);
        double[] view=identity();
        // Render camera looks down -Z. Its view takes precedence over pose angles,
        // which alone cannot represent render effects such as roll or bob.
        PearlPrediction.Camera camera=new PearlPrediction.Camera(origin,45,120,90,2,view,.5);
        check(camera.valid()&&camera.hasRenderView());
        PearlPrediction.Point point=PearlPrediction.project(ahead,camera,1000,500);near(point.x,500);near(point.y,250);
        point=PearlPrediction.project(new PearlPrediction.Vec(15,20,20),camera,1000,500);near(point.x,625);near(point.y,250);
        check(PearlPrediction.project(new PearlPrediction.Vec(10,20,30.1),camera,1000,500)==null);
        check(PearlPrediction.project(new PearlPrediction.Vec(10,20,29.51),camera,1000,500)==null);
        check(PearlPrediction.project(new PearlPrediction.Vec(10,20,29.4),camera,1000,500)!=null);
        // The renderer supplies its aspect, even if the overlay dimensions differ.
        PearlPrediction.Camera square=new PearlPrediction.Camera(origin,0,0,90,1,view,.5);
        point=PearlPrediction.project(new PearlPrediction.Vec(15,20,20),square,1000,500);near(point.x,750);
        // Column-major view-space translation moves both axes for render bob.
        view[12]=1;view[13]=-.5;
        camera=new PearlPrediction.Camera(origin,0,0,90,2,view,.5);view[12]=99;
        point=PearlPrediction.project(ahead,camera,1000,500);near(point.x,525);near(point.y,262.5);
        // Camera takes a defensive snapshot of the matrix rather than retaining it.
        near(PearlPrediction.project(ahead,camera,1000,500).x,525);
        double[] roll=new double[]{0,1,0,0,-1,0,0,0,0,0,1,0,0,0,0,1};
        camera=new PearlPrediction.Camera(origin,0,0,90,2,roll,.5);
        point=PearlPrediction.project(new PearlPrediction.Vec(11,20,20),camera,1000,500);near(point.x,500);near(point.y,225);
        String legacy="0|0,0,0,0,0,90|";
        check(!PearlPrediction.parse(legacy,1000).camera.hasRenderView());
        String extended="0|"+matrixCamera(identity(),true)+"|";
        PearlPrediction.Frame frame=PearlPrediction.parse(extended,1000);check(frame!=null&&frame.camera.hasRenderView());near(frame.camera.nearPlane,.5);
        point=PearlPrediction.project(ahead,frame.camera,1000,500);near(point.x,500);near(point.y,250);
        frame=PearlPrediction.parse("0|"+matrixCamera(identity(),false)+"|",1000);check(frame!=null);near(frame.camera.nearPlane,.05);
        for(String invalid:new String[]{extended.replace(",90,2,",",0,2,"),extended.replace(",90,2,",",90,0,"),extended.replace(",0.5|",",-1|"),extended.replace(",0.5|",",NaN|"),"0|"+matrixCamera(new double[16],true)+"|",legacy.replace(",90|",",90,2|")})check(PearlPrediction.parse(invalid,1000)==null);
        for(double fov:new double[]{1,179})check(new PearlPrediction.Camera(origin,0,0,fov,2,identity(),.05).valid());
    }
    static void clippedSegments(){
        PearlPrediction.Point[] points=PearlPrediction.clipSegment(new PearlPrediction.Point(-1000000,200),new PearlPrediction.Point(1000000,200),1000,500);
        check(points!=null);near(points[0].x,0);near(points[1].x,1000);near(points[0].y,200);
        points=PearlPrediction.clipSegment(new PearlPrediction.Point(250,-800),new PearlPrediction.Point(250,800),1000,500);check(points!=null);near(points[0].y,0);near(points[1].y,500);
        check(PearlPrediction.clipSegment(new PearlPrediction.Point(-100,200),new PearlPrediction.Point(-10,300),1000,500)==null);
        check(PearlPrediction.clipSegment(new PearlPrediction.Point(Double.NaN,0),new PearlPrediction.Point(10,10),1000,500)==null);
        check(PearlPrediction.clipSegment(new PearlPrediction.Point(1,1),new PearlPrediction.Point(10,10),0,500)==null);
        points=PearlPrediction.clipSegment(new PearlPrediction.Point(10,10),new PearlPrediction.Point(10,10),1000,500);check(points!=null);near(points[0].x,10);near(points[1].y,10);
    }
    static void feedStates(){
        check(PearlPrediction.feedStatus("Pearl Prediction: enabled=1 frames=5 pearls=0 reason=0").equals("Ожидаю бросок жемчуга"));
        check(PearlPrediction.feedStatus("enabled=1 frames=0 pearls=0 reason=0").contains("обновление игрового мира"));
        check(PearlPrediction.feedStatus("enabled=1 frames=5 pearls=2 reason=0").equals("Жемчугов найдено: 2"));
        check(PearlPrediction.feedStatus("enabled=1 frames=5 pearls=0 reason=4").contains("камеру"));
        check(PearlPrediction.feedStatus("enabled=1 frames=5 pearls=0 reason=5").contains("лимит"));
        check(PearlPrediction.feedStatus("enabled=1 frames=5 pearls=0 reason=7").contains("данные полёта"));
        check(PearlPrediction.feedStatus("enabled=0 frames=5 pearls=2 reason=0").equals("Выключен"));
        check(PearlPrediction.feedStatus(null).equals("Прогноз включён; ожидаю данные"));
    }
    public static void main(String[] args){
        PearlPrediction.Pearl pearl=new PearlPrediction.Pearl(1,0,new PearlPrediction.Vec(0,2,0),new PearlPrediction.Vec(1,1,0),.1,.9,-1);
        List<PearlPrediction.Vec> arc=PearlPrediction.simulate(pearl,3);check(arc.size()==4);near(arc.get(1).x,1);near(arc.get(1).y,3);near(arc.get(2).x,1.9);near(arc.get(2).y,3.8);near(arc.get(3).x,2.71);near(arc.get(3).y,4.42);
        check(Double.isNaN(PearlPrediction.secondsToLanding(pearl,0)));
        PearlPrediction.Pearl collision=new PearlPrediction.Pearl(1,1,pearl.position,pearl.velocity,.1,.9,2.5);arc=PearlPrediction.simulate(collision,30);check(arc.size()==4);near(arc.get(3).x,2.305);near(PearlPrediction.secondsToLanding(collision,25),.1);
        PearlPrediction.Camera c=new PearlPrediction.Camera(new PearlPrediction.Vec(0,0,0),0,0,90);
        PearlPrediction.Point p=PearlPrediction.project(new PearlPrediction.Vec(0,0,10),c,1000,500);near(p.x,500);near(p.y,250);
        p=PearlPrediction.project(new PearlPrediction.Vec(10,0,10),c,1000,500);near(p.x,750);near(p.y,250);
        check(PearlPrediction.project(new PearlPrediction.Vec(0,0,-1),c,1000,500)==null);
        c=new PearlPrediction.Camera(new PearlPrediction.Vec(0,0,0),0,-90,90);p=PearlPrediction.project(new PearlPrediction.Vec(10,0,0),c,1000,500);near(p.x,500);near(p.y,250);
        c=new PearlPrediction.Camera(new PearlPrediction.Vec(0,0,0),30,0,90);p=PearlPrediction.project(new PearlPrediction.Vec(0,-5,8.6602540378),c,1000,500);near(p.x,500);near(p.y,250);
        c=new PearlPrediction.Camera(new PearlPrediction.Vec(0,0,0),0,0,0);check(PearlPrediction.project(new PearlPrediction.Vec(0,0,10),c,1000,500)==null);p=PearlPrediction.topDown(new PearlPrediction.Vec(1,0,10),c,100,100,2);near(p.x,102);near(p.y,80);
        String snapshot="20|0,0,0,0,0,0|7,0,0,2,0,1,1,0,0.1,0.9,-1";
        PearlPrediction.Frame frame=PearlPrediction.parse(snapshot,1000);check(frame!=null&&frame.capturedAt==980&&frame.pearls.size()==1);check(frame.fresh(1480)&&!frame.fresh(1481));
        // Match the native snapshot bound: a fast pearl must not hide all the
        // other trajectories merely because its speed exceeds vanilla's.
        check(PearlPrediction.parse(snapshot.replace(",1,1,0,0.1",",16,1,0,0.1"),1000)!=null);
        frame=PearlPrediction.parse(snapshot.replace(",1,1,0,0.1",",65,1,0,0.1"),1000);check(frame!=null&&frame.pearls.isEmpty()&&frame.discardedPearls==1);
        check(PearlPrediction.parse("0|0,0,0,0,0,90|",1000).pearls.isEmpty());
        for(String invalid:new String[]{"",snapshot.replace("20|","501|")})check(PearlPrediction.parse(invalid,1000)==null);
        for(String invalid:new String[]{snapshot.replace("0.9","1.1"),snapshot.replace("7,0","7,4"),snapshot.replace("-1","NaN")}){
            frame=PearlPrediction.parse(invalid,1000);check(frame!=null&&frame.pearls.isEmpty()&&frame.discardedPearls==1);
        }
        frame=PearlPrediction.parse(snapshot+";7,0,0,2,0,1,1,0,0.1,0.9,-1",1000);check(frame!=null&&frame.pearls.size()==1&&frame.discardedPearls==1);
        frame=PearlPrediction.parse(snapshot+";malformed;9,1,0,2,0,NaN,1,0,0.1,0.9,-1;10,1,0,2,0,1,1,0,0.1,0.9,-1",1000);check(frame!=null&&frame.pearls.size()==2&&frame.discardedPearls==2);
        check(PearlPrediction.parse(null,1000)==null);
        renderCamera();clippedSegments();feedStates();
        System.out.println("PASS: bounded pearl arcs and supplied ETA; camera projection, viewport clipping, independent malformed pearls, native feed states and honest fallback");
    }
}
