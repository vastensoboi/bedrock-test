#pragma once
#include "aim_combat.h"
namespace kulich_aim {
inline bool stableAimAngles(Vec eye,const Box& box,Angles view,Angles& desired){
 Vec centre=aimPoint(box,false);
 if(angles(eye,centre,view.yaw,desired))return true;
 // An exactly overlapping eye/chest has no unique direction; keeping the
 // validated camera pose avoids dropping/reacquiring a valid target.
 if(std::isfinite(view.pitch)&&std::isfinite(view.yaw)&&
    std::hypot(std::hypot(centre.x-eye.x,centre.z-eye.z),centre.y-eye.y)<1e-6){desired=view;return true;}
 return false;
}
// Keep a stable view within the chest instead of chasing tiny changes of the
// exact centre point. Acquisition is still sharp; target identity resets hold.
class AimStability {
 A actor=0;uint32_t entity=0xffffffffU;bool quiet=false,contact=false;
 static bool hits(Vec eye,Angles view,const Box& box,double range){
  double p=view.pitch*CAMERA_RAD,y=view.yaw*CAMERA_RAD;Vec hit{};
  return rayHitVector(eye,{-std::sin(y)*std::cos(p),-std::sin(p),std::cos(y)*std::cos(p)},box,range,hit);
 }
 static Box torso(const Box& box,bool retained){
  Box inner=box;double fraction=retained?.70:.60;
  for(int i:{0,2}){double c=(double(box.lo[i])+box.hi[i])*.5,h=(box.hi[i]-box.lo[i])*fraction*.5;inner.lo[i]=float(c-h);inner.hi[i]=float(c+h);}
  double h=box.hi[1]-box.lo[1];inner.lo[1]=float(box.lo[1]+h*(retained?.45:.50));inner.hi[1]=float(box.lo[1]+h*(retained?.75:.70));
  return inner;
 }
public:
 void reset(){actor=0;entity=0xffffffffU;quiet=contact=false;}
 bool holding()const{return quiet;}
 bool overlapping()const{return contact;}
 Angles apply(A address,uint32_t id,Vec eye,const Box& box,Angles view,Angles desired,double range){
  bool changed=actor!=address||entity!=id;
  if(changed){reset();actor=address;entity=id;}
  if(!valid(box)||!std::isfinite(view.pitch)||!std::isfinite(view.yaw)){quiet=contact=false;return desired;}
  Vec centre=aimPoint(box,false);double gap=std::hypot(centre.x-eye.x,centre.z-eye.z);
  contact=std::isfinite(gap)&&gap<=(contact?.45:.35);
  if(contact){
   // atan2 near x=z=0 otherwise changes yaw by 180 degrees as bodies cross.
   // Keep the existing view when it already hits; never synthesize an attack.
   if(!changed&&hits(eye,view,box,range)){quiet=true;return view;}
   desired.yaw=view.yaw;
   desired.pitch=float(std::fmax(-89.9,std::fmin(89.9,-std::atan2(centre.y-eye.y,std::fmax(.35,gap))/CAMERA_RAD)));
   quiet=false;return desired;
  }
  if(!changed&&hits(eye,view,torso(box,quiet),range)){quiet=true;return view;}
  quiet=false;return desired;
 }
};
}
