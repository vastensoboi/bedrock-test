package dev.custom.bedrockgui;
import java.util.*;
public final class AutoBuyMatcherTest {
    static void check(boolean b){if(!b)throw new AssertionError();}
    static AutoBuyMatcher.Verdict lot(String name,String price,String kind,Map<Integer,Integer> ench,String...extra){
        List<String> lore=new ArrayList<>(Arrays.asList("  §fИгрок: §bTestSeller", "  §fЦена: §b"+price+"$"));Collections.addAll(lore,extra);
        return AutoBuyMatcher.evaluate(name,lore,1,kind,ench,AutoBuyDefaultRules.rules());
    }
    public static void main(String[] args){
        Map<Integer,Integer> none=Collections.emptyMap();AutoBuyMatcher.Verdict v;
        v=lot("§c§lСфера Виверны","120,000","",none);check(v.candidate&&!v.accepted&&v.price==120000&&v.limit==58500);
        check(lot("Сфера Виверны","58,500","",none).accepted);
        check(!lot("Сфера Виверны","58,501","",none).accepted);
        v=lot("Талисман Ориона","400,000","",none);check(!v.accepted&&v.limit==180000);
        check(lot("Талисман Ориона","180,000","",none).accepted);
        check(!lot("Сфера Виверны","1.50","",none).accepted);
        check(!lot("Сфера Полубога","1,000.000","",none).accepted);
        check(lot("Сфера Полубога","1 000 000","",none).accepted);
        check(!lot("Сфера Виверны цербер","1,000","",none).accepted);
        check(!lot("Талисман Ориона","100","book",none).accepted);
        v=lot("Меч Властелина","390,000","sword",Map.of(9,7),"Иссушение","Крит");check(v.accepted);
        check(!lot("Меч Властелина","390,000","sword",Map.of(9,6),"Иссушение","Крит").accepted);
        check(!lot("Меч Властелина","390,000","sword",Map.of(9,7),"Иссушение").accepted);
        check(!lot("Меч Властелина","390,000","",Map.of(9,7),"Иссушение","Крит").accepted);
        check(lot("Меч Властелина","390,000","sword",none,"Острота VII","Иссушение","Крит").accepted);
        check(!lot("Талисман Ориона","100","",none,"Цена: 200$").accepted);
        check(!AutoBuyMatcher.evaluate("Талисман Ориона",List.of("Цена: 100$"),1,"",none,AutoBuyDefaultRules.rules()).accepted);
        check(!lot("Талисман Карателя","100","",none).accepted); // no default market price
        check(!lot("Следующая страница","100","",none).candidate);
        check(lot("§cСФЕРА §lВИВЕРНЫ","58,500","",none).accepted);
        check(!lot("Сфера Виверны","100","",none,"§cСФИНКС").accepted);
        check(!lot("Другой предмет","100","",none,"Сфера Виверны").candidate);
        List<AutoBuyMatcher.Rule> formatted=List.of(new AutoBuyMatcher.Rule("§cПРОБА","test","",100,1,100,new String[]{},new int[]{},new String[]{},0));
        check(AutoBuyMatcher.evaluate("Проба",List.of("§fЦена: §a100$","§fИгрок: §bSeller"),1,"",none,formatted).accepted);
        check(!AutoBuyMatcher.evaluate("Другое",List.of("Цена: 100$","Игрок: Seller"),1,"",none,formatted).candidate);
        long[] limits={3000000,58500,180000,1100000,7200000,0,1800000,900000,390000,261000,261000,261000,261000,1000000,3000000,450000,225000};
        List<AutoBuyMatcher.Rule> defaults=AutoBuyDefaultRules.rules();check(defaults.size()==limits.length);
        for(int i=0;i<limits.length;i++)check(defaults.get(i).priceLimit(1)==limits[i]);
        check(defaults.get(1).priceLimit(2)==60000&&defaults.get(1).priceLimit(0)==0);
        check(AutoBuyMatcher.evaluate("Сфера Виверны",List.of("Цена: 60000$","Игрок: Seller"),2,"",none,defaults).accepted);
        check(!AutoBuyMatcher.evaluate("Сфера Виверны",List.of("Цена: 60001$","Игрок: Seller"),2,"",none,defaults).accepted);
        check(!lot("Сфера Полубога","3000001","",none).accepted);
        check(lot("Сфера Полубога","3000000","",none).accepted);
        check(!lot("Шлем Властелина","261000","",Map.of(0,5),"Броненосец","Поглощение").accepted);
        check(lot("Шлем Властелина","261000","armor",Map.of(0,5),"Броненосец","Поглощение").accepted);
        System.out.println("PASS: real report price examples/limits, grouping/boundaries, stop words/books, typed weapon + NBT/text enchants, missing/duplicate metadata, missing market and footer exclusion");
    }
}
