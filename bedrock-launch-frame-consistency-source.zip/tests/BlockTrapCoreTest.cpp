#include "../app/src/main/cpp/block_trap_core.h"
#include <cassert>
#include <iostream>
#include <set>
#include <tuple>
using namespace kulich_trap;
Actor player(A address,uint32_t entity,float x,float y,float z){
 Actor actor{};actor.address=address;actor.entity=entity;
 actor.box={{x-.3f,y,z-.3f},{x+.3f,y+1.8f,z+.3f},.6f,1.8f};return actor;
}
bool contains(const std::vector<Cell>& cells,Cell find){return std::find(cells.begin(),cells.end(),find)!=cells.end();}
int main(){
 Actor local=player(0x1000,1,-2.5f,64,.5f),target=player(0x2000,2,.5f,64,.5f);
 std::vector<Actor> players{local,target};
 auto cells=proposals(local,target,players);assert(cells.size()==13);
 assert(contains(cells,{-1,64,0})&&contains(cells,{1,65,0})&&contains(cells,{0,66,0}));
 std::set<std::tuple<int,int,int>> unique;
 int32_t previousY=INT32_MIN;
 for(Cell cell:cells){
  assert(valid(cell)&&!intersects(cell,local.box)&&!intersects(cell,target.box));
  assert(unique.emplace(cell.x,cell.y,cell.z).second&&cell.y>=previousY);previousY=cell.y;
  auto neighbors=supports(cell);assert(neighbors[0].face==1&&neighbors[5].face==0);
  for(const Support& support:neighbors){assert(destination(support)==cell);Vec hit=hitPoint(support);assert(valid(hit));}
 }
 assert(intersects({0,64,0},target.box)&&!intersects({0,66,0},target.box));
 Box touching={{0,64,0},{1,66,1},1,2};assert(!intersects({1,64,0},touching)&&!intersects({0,66,0},touching));
 // Standing across a negative grid boundary must not place through a shoulder.
 target=player(0x2000,2,-.1f,64,-.1f);cells=proposals(local,target,{local,target});
 assert(contains(cells,{-1,66,-1})&&contains(cells,{0,66,0}));
 for(Cell cell:cells)assert(!intersects(cell,target.box)&&!intersects(cell,local.box));
 // All other players block proposals, including friends and unselected players.
 Actor friendPlayer=player(0x3000,3,1.5f,64,.5f);target=player(0x2000,2,.5f,64,.5f);
 cells=proposals(local,target,{local,target,friendPlayer});assert(!contains(cells,{1,64,0})&&!contains(cells,{1,65,0}));
 assert(proposals(local,target,{local,target},2).size()==2&&proposals(local,target,{local,target},0).empty());
 Actor malformed=friendPlayer;malformed.box.lo[0]=NAN;assert(proposals(local,target,{malformed}).empty());
 Actor huge=target;huge.box.hi[0]=huge.box.lo[0]+5;assert(proposals(local,huge,{}).empty());
 // Face centres and block face direction agree at an exact reach boundary.
 Support support{{0,63,0},1};Vec hit=hitPoint(support);assert(hit.x==.5&&hit.y==64&&hit.z==.5);
 assert(reachable({.5,68,.5},support,4)&&!reachable({.5,68.01,.5},support,4));
 assert(!reachable({NAN,68,.5},support,4)&&!reachable(hit,{{0,0,0},6},4));
 assert(!valid(destination({{INT32_MAX,0,0},5}))&&!valid(destination({{0,0,0},6})));
 // Retain a selected enemy, but never retain a newly added friend or reused ID.
 TargetLock lock;Actor chosen{};Actor near=player(0x4000,4,-1.5f,64,.5f);
 auto notFriend=[&](const Actor& p){return p.entity!=3;};
 assert(chooseTarget(local,{friendPlayer,target},4,lock,chosen,notFriend)&&chosen.entity==2);
 assert(chooseTarget(local,{near,target},4,lock,chosen,notFriend)&&chosen.entity==2);
 auto onlyNear=[](const Actor& p){return p.entity==4;};
 assert(chooseTarget(local,{near,target},4,lock,chosen,onlyNear)&&chosen.entity==4);
 Actor reused=near;reused.entity=5;assert(chooseTarget(local,{reused,target},4,lock,chosen,notFriend)&&chosen.entity==5);
 assert(!chooseTarget(local,{friendPlayer},4,lock,chosen,notFriend)&&lock.address==0);
 Actor boundary=player(0x5000,6,1.5f,64,.5f);
 assert(chooseTarget(local,{boundary},4,lock,chosen,notFriend));
 boundary.box.lo[0]+=.01f;boundary.box.hi[0]+=.01f;assert(!chooseTarget(local,{boundary},4,lock,chosen,notFriend));
 Actor maximum=player(0x6000,7,2.5f,64,.5f);assert(chooseTarget(local,{maximum},5,lock,chosen,notFriend));
 assert(!chooseTarget(local,{target},5.1,lock,chosen,notFriend));
 std::vector<Actor> tooMany(MAX_PLAYERS+1,target);assert(proposals(local,target,tooMany).empty()&&!chooseTarget(local,tooMany,4,lock,chosen,notFriend));
 // Cadence has no time-based catch-up burst and resets on a changed setting.
 Cadence cadence;assert(cadence.due(3)&&!cadence.due(3)&&!cadence.due(3)&&cadence.due(3));
 assert(cadence.due(2)&&!cadence.due(2)&&cadence.due(2));cadence.reset();assert(cadence.due(100)&&!cadence.due(100));
 std::cout<<"PASS: bounded trap columns/roof, negative-grid AABB safety, all-player collision exclusion, support faces/reach, stable non-friend target and tick cadence\n";
}
