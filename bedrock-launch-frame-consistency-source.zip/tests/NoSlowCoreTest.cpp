#include "../app/src/main/cpp/no_slow_core.h"
#include <cassert>
#include <vector>
#include <iostream>
using namespace kulich_noslow;
struct Memory {
 static constexpr A root=0x200000,tag=0xb400000000000000ULL;std::vector<unsigned char> bytes=std::vector<unsigned char>(0x40000);A next=root+0x10000;
 template<class T>void put(A at,T value){at=plain(at);assert(at>=root&&at-root+sizeof value<=bytes.size());std::memcpy(bytes.data()+at-root,&value,sizeof value);}
 A alloc(size_t n){A out=next;next=(next+n+7)&~A(7);assert(next-root<bytes.size());return out;}
 bool operator()(A at,void* out,size_t n){at=plain(at);if(at<root||at-root>bytes.size()||n>bytes.size()-(at-root))return false;std::memcpy(out,bytes.data()+at-root,n);return true;}
};
A storage(Memory& m,uint32_t id,unsigned stride){
 A pool=m.alloc(104),vector=m.alloc(8),sparse=m.alloc(8192),pages=m.alloc(8),payload=m.alloc(128*stride);
 std::fill(m.bytes.begin()+sparse-Memory::root,m.bytes.begin()+sparse-Memory::root+8192,255);
 m.put(pool+8,vector);m.put(pool+16,vector+8);m.put(vector,sparse);m.put(sparse+(id&2047)*4,id&0xfffc0000U);
 m.put(pool+80,pages);m.put(pool+88,pages+8);m.put(pool+96,pages+8);m.put(pages,payload|Memory::tag);return pool;
}
int main(){
 Memory m;constexpr A base=0x10000000,client=Memory::root+0x1000,registry=Memory::root+0x3000,actorAddress=Memory::root+0x5000,adapter=Memory::root+0x7000,idPointer=Memory::root+0x8000;constexpr uint32_t id=0x40001;
 uint32_t keys[]{OWNER,SHAPE,ROTATION,HEAD,MODIFIER,MOVE_INPUT,GAMEPLAY};unsigned strides[]{8,32,16,8,4,100,80};A pools[7]{};
 for(int i=0;i<7;i++)pools[i]=storage(m,id,strides[i]);
 A buckets=m.alloc(64),nodes=m.alloc(7*32);for(int i=0;i<8;i++)m.put<int64_t>(buckets+i*8,-1);
 for(int i=0;i<7;i++){int64_t prev=-1;m(buckets+(keys[i]&7)*8,&prev,8);m.put(nodes+i*32,prev);m.put(nodes+i*32+8,keys[i]);m.put(nodes+i*32+16,pools[i]);m.put<int64_t>(buckets+(keys[i]&7)*8,i);}
 m.put(registry+96,buckets);m.put(registry+104,buckets+64);m.put(registry+120,nodes);m.put(registry+128,nodes+7*32);
 A entityPages=m.alloc(8),entitySparse=m.alloc(8192);m.put(registry+216,entityPages);m.put(registry+224,entityPages+8);m.put(entityPages,entitySparse);m.put(entitySparse+(id&2047)*4,(id&0xfffc0000U)|1);
 m.put(client,base+0x1388fe70ULL);m.put(client+576,std::array<A,3>{registry,Memory::root+0x9000,id});m.put(adapter,base+ADAPTER_TABLE);m.put(adapter+8,registry);m.put(idPointer,id);
 m.put(actorAddress,base+0x139f6ea0ULL);m.put(actorAddress+8,registry);m.put(actorAddress+16,registry+40);m.put(actorAddress+24,id);m.put(actorAddress+3240,client);
 m.put(component(m,pools[0],id,8),actorAddress|Memory::tag);A shape=component(m,pools[1],id,32),rotation=component(m,pools[2],id,16);
 m.put(actorAddress+560,shape);m.put(actorAddress+568,rotation);m.put(shape,Box{{-.3f,0,-.3f},{.3f,1.8f,.3f},.6f,1.8f});m.put(rotation,Angles{});
 A factor=taggedComponent(m,pools[4],id,4);m.put(factor,.2f);
 auto lookup=[&](Binding& b){return resolve(m,base,client,adapter,idPointer,b);};
 Binding bind{};assert(lookup(bind)&&bind.payload==factor&&bind.entity==id&&std::abs(bind.factor-.2f)<1e-6);
 bool failWrite=false;int calls=0,writes=0;float forward=1,side=.5f;
 auto write=[&](A at,float value){assert(at==factor);if(failWrite)return false;writes++;m.put(at,value);return true;};
 auto original=[&](){calls++;float scale=0;assert(m(plain(factor),&scale,4));forward*=scale*scale;side*=scale*scale;};
 assert(invoke(m,write,lookup,original,true));assert(calls==1&&writes==2&&forward==1&&side==.5f);float restored=0;m(plain(factor),&restored,4);assert(restored==.2f);
 forward=1;side=.5;writes=0;assert(!invoke(m,write,lookup,original,false)&&writes==0&&std::abs(forward-.04f)<1e-6);
 m.put(idPointer,id+1);forward=1;assert(!invoke(m,write,lookup,original,true)&&std::abs(forward-.04f)<1e-6);m.put(idPointer,id);
 failWrite=true;assert(!invoke(m,write,lookup,original,true));failWrite=false;
 auto changing=[&](){calls++;m.put(factor,.6f);};assert(invoke(m,write,lookup,changing,true));m(plain(factor),&restored,4);assert(restored==.6f); // don't overwrite engine changes
 m.put(factor,.2f);bool threw=false;try{invoke(m,write,lookup,[](){throw 7;},true);}catch(int){threw=true;}m(plain(factor),&restored,4);assert(threw&&restored==.2f);
 m.put(factor,NAN);assert(!lookup(bind));m.put(factor,.2f);m.put(adapter+8,registry+8);assert(!lookup(bind));m.put(adapter+8,registry);
 assert(resolve(m,base,client,adapter,0,bind)); // bulk path still patches only the locally bound entity
 m.put(actorAddress+3240,client+8);assert(!lookup(bind));
 std::cout<<"PASS: scoped item-use factor, original movement dispatch once, restore, local/entity/registry/tag guards, disabled/write-failed/engine-changed/exception paths\n";
}
