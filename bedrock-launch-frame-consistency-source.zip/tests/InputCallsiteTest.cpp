#include "../app/src/main/cpp/input_callsite_core.h"
#include <cassert>
#include <iostream>
int main(){
 using namespace kulich_callsite;
 constexpr uint64_t base=0x10000000,sp=0xb400000000100000ULL,lr=base+RETURN_OFFSET;
 assert(fresh(base,sp+PACKET_STACK_OFFSET,lr,sp));
 assert(!fresh(base,sp+PACKET_STACK_OFFSET,lr+4,sp));
 assert(!fresh(base,sp+PACKET_STACK_OFFSET+8,lr,sp));
 assert(!fresh(base,sp+PACKET_STACK_OFFSET,lr,sp+16));
 assert(!fresh(base,sp+PACKET_STACK_OFFSET,lr,sp+1));
 assert(!fresh(base,(sp&0x00ffffffffffffffULL)+PACKET_STACK_OFFSET,lr,sp));
 assert(!fresh(0,sp+PACKET_STACK_OFFSET,lr,sp));
 assert(!fresh(UINT64_MAX,sp+PACKET_STACK_OFFSET,lr,sp));
 assert(!fresh(base,119,lr,UINT64_MAX));
 assert(!fresh(base,PACKET_STACK_OFFSET,lr,0));
 std::cout<<"PASS: exact native constructor callsite, caller stack, allocation tags and overflow guards\n";
}
