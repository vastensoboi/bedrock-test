#include "transaction_trace_core.h"
#include <jni.h>
#include <atomic>
#include <mutex>
#include <string>
#include <cstdio>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cerrno>
namespace {
using kulich_trace::Address;
using GetId=int(*)(void*);
std::atomic<GetId> requestOriginal{nullptr},responseOriginal{nullptr};
std::atomic<bool> recording{false};std::atomic<uint64_t> seen{0},skipped{0};
std::mutex installLock,samplesLock;Address installedBase=0;int memory=-1;
std::array<kulich_trace::Sample,16> samples{};size_t total=0;std::string installFailure;
bool read(Address at,void* out,size_t n){
 at=kulich_trace::untag(at);if(memory<0||at<4096||n>4096||at>0x00ffffffffffffffULL-n)return false;
 ssize_t result;do{result=pread(memory,out,n,static_cast<off_t>(at));}while(result<0&&errno==EINTR);
 return result==static_cast<ssize_t>(n);
}
void observe(void* packet,int id){
 if(!recording.load(std::memory_order_relaxed))return;
 seen.fetch_add(1,std::memory_order_relaxed);
 std::unique_lock<std::mutex> lock(samplesLock,std::try_to_lock);if(!lock.owns_lock()){skipped++;return;}
 auto sample=kulich_trace::capture(read,reinterpret_cast<Address>(packet),id);
 // Bounded ring; no disk logging, allocation or mutation of game packets.
 if(total){const auto& prior=samples[(total-1)%samples.size()];if(prior.id==sample.id&&prior.valid==sample.valid&&prior.rows==sample.rows&&prior.row==sample.row&&prior.action==sample.action)return;}
 samples[total++%samples.size()]=sample;
}
int requestId(void* self){auto original=requestOriginal.load(std::memory_order_acquire);observe(self,147);return original(self);}
int responseId(void* self){auto original=responseOriginal.load(std::memory_order_acquire);observe(self,148);return original(self);}
bool originalMapping(Address page,size_t size){
 FILE* f=fopen("/proc/self/maps","r");if(!f)return false;
 char line[2048],perms[5];unsigned long long lo,hi;bool found=false;
 while(fgets(line,sizeof(line),f))if(sscanf(line,"%llx-%llx %4s",&lo,&hi,perms)==3&&page>=lo&&page+size<=hi){
  found=perms[0]=='r'&&perms[1]=='-'&&perms[2]=='-'&&std::string(line).find("/libminecraftpe.so")!=std::string::npos;break;
 }
 fclose(f);return found;
}
std::string install(Address base){
 std::lock_guard<std::mutex> guard(installLock);
 if(installedBase)return installedBase==base?installFailure:"Library base changed";
 if(memory<0)memory=open("/proc/self/mem",O_RDONLY|O_CLOEXEC);
 if(memory<0)return "Cannot read own memory";
 const Address entries[]={base+0x13b13840+16,base+0x13b9cd18+16};
 const Address functions[]={base+0xc644e78,base+0xdba64b8};
 const Address replacements[]={reinterpret_cast<Address>(&requestId),reinterpret_cast<Address>(&responseId)};
 long size=sysconf(_SC_PAGESIZE);if(size<=0)return "Invalid page size";
 Address pages[2]{};
 for(int i=0;i<2;i++){
  Address fn=0;uint32_t code[2]{};pages[i]=entries[i]-entries[i]%size;
  if(!read(entries[i],&fn,8)||kulich_trace::untag(fn)!=functions[i]||!read(fn,code,sizeof(code))||code[0]!=(0x52800000U|((147U+i)<<5))||code[1]!=0xd65f03c0U)return "Packet vtable/getId profile mismatch";
  if(entries[i]+8>pages[i]+size||!originalMapping(pages[i],size))return "Unexpected packet vtable mapping";
 }
 // Both pages must be writable before publishing either replacement.
 if(mprotect(reinterpret_cast<void*>(pages[0]),size,PROT_READ|PROT_WRITE))return "Cannot update request vtable";
 if(mprotect(reinterpret_cast<void*>(pages[1]),size,PROT_READ|PROT_WRITE)){
  mprotect(reinterpret_cast<void*>(pages[0]),size,PROT_READ);return "Cannot update response vtable";
 }
 requestOriginal.store(reinterpret_cast<GetId>(functions[0]),std::memory_order_release);responseOriginal.store(reinterpret_cast<GetId>(functions[1]),std::memory_order_release);
 for(int i=0;i<2;i++)__atomic_store_n(reinterpret_cast<Address*>(entries[i]),replacements[i],__ATOMIC_RELEASE);
 bool failed=false;for(int i=0;i<2;i++)if(mprotect(reinterpret_cast<void*>(pages[i]),size,PROT_READ)){
  __atomic_store_n(reinterpret_cast<Address*>(entries[i]),functions[i],__ATOMIC_RELEASE);mprotect(reinterpret_cast<void*>(pages[i]),size,PROT_READ);failed=true;
 }
 // Do not erase forwarding targets: another thread may have already entered.
 installedBase=base;installFailure=failed?"Protection restore failed; recording disabled":"";return installFailure;
}
std::string report(){
 std::lock_guard<std::mutex> guard(samplesLock);
 std::string out="Inventory transaction trace: recording="+std::to_string(recording.load())+" calls="+std::to_string(seen.load())+" skipped="+std::to_string(skipped.load())+"\n";
 size_t start=total>samples.size()?total-samples.size():0;
 for(size_t i=start;i<total;i++)out+=kulich_trace::describe(samples[i%samples.size()])+"\n";
 return out+"Observation only: no requests generated, replayed or acknowledged by this bridge.";
}
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_TransactionTrace_install(JNIEnv* env,jclass,jlong base){
 auto error=install(static_cast<Address>(base));return env->NewStringUTF(error.c_str());
}
extern "C" JNIEXPORT void JNICALL Java_dev_custom_bedrockgui_TransactionTrace_record(JNIEnv*,jclass,jboolean value){
 recording.store(false);if(value){std::lock_guard<std::mutex> guard(samplesLock);total=0;seen=0;skipped=0;}recording.store(value);
}
extern "C" JNIEXPORT jstring JNICALL Java_dev_custom_bedrockgui_TransactionTrace_snapshot(JNIEnv* env,jclass){auto value=report();return env->NewStringUTF(value.c_str());}
