package dev.custom.bedrockgui;
import java.nio.charset.StandardCharsets;
public final class TargetHudDataTest {
    private static String snapshot(String name,String hp,long age){StringBuilder hex=new StringBuilder();for(byte b:name.getBytes(StandardCharsets.UTF_8))hex.append(String.format("%02x",b&255));return age+"|"+hp+"|"+hex;}
    private static TargetHudData full(String name,String hp,String max){return TargetHudData.parse(snapshot(name,hp,0)+"|"+max+"|0|15|15|15");}
    private static void check(boolean value){if(!value)throw new AssertionError();}
    public static void main(String[] args){
        TargetHudData t=TargetHudData.parse(snapshot("§a[Властелин] Steve_1\n20 ♥","18.5",200));
        check(t!=null&&t.name.equals("Steve_1")&&t.rank.equals("Властелин")&&t.hp==20&&t.hpFromNameTag);
        check(t.displayName.equals("§a[Властелин] Steve_1")&&t.normalizedNick().equals("steve_1"));
        t=TargetHudData.parse(snapshot("Alex","nan",0));check(t.name.equals("Alex")&&t.rank.equals("Не указана")&&Float.isNaN(t.hp));
        check(t.healthLabel().equals("?")&&t.healthSource().equals("HP недоступно"));
        t=TargetHudData.parse(snapshot("","20",10));check(t.name.equals("Имя недоступно")&&t.normalizedNick().isEmpty());
        check(TargetHudData.parse(snapshot("Alex","20",5001))==null);
        check(TargetHudData.parse("0|20|zz")==null&&TargetHudData.parse("0|20|a")==null);
        check(TargetHudData.parse(snapshot("Alex","Infinity",0))==null&&TargetHudData.parse(snapshot("Alex","-1",0))==null);
        check(TargetHudData.parse("")==null&&TargetHudData.parse(null)==null);
        t=TargetHudData.parse(snapshot("[VIP] Alex","15",200)+"|20|5|12|15");check(t!=null&&t.maxHp==20&&t.actualCps==12&&t.configuredCps==15&&t.state==5);
        check(t.rank.equals("VIP")&&t.name.equals("Alex")&&t.healthLabel().equals("15/20")&&t.healthSource().equals("HP клиента"));
        check(TargetHudData.parse(snapshot("Alex","15",0)+"|20|5|12|41")==null);
        t=TargetHudData.parse(snapshot("Alex","15",0)+"|20|0|39|40|39");check(t!=null&&t.configuredMinCps==39&&t.configuredCps==40&&t.actualCps==39);
        t=TargetHudData.parse(snapshot("Alex","15",0)+"|20|0|20|20|20");check(t!=null&&t.configuredMinCps==20&&t.configuredCps==20);
        check(TargetHudData.parse(snapshot("Alex","15",0)+"|20|0|20|20|21")==null);
        check(TargetHudData.parse(snapshot("Alex","15",0)+"|20|0|20|20|0")==null);
        // A server nametag may contain the real health while remote attributes
        // remain at their initial full-health value. Never display the latter.
        t=full("§6Властелин\n§fSteve_1\n§c7/18 ♥","18","18");
        check(t!=null&&t.hp==7&&t.maxHp==18&&t.healthLabel().equals("7/18")&&t.hpFromNameTag);
        check(t.displayName.equals("§6Властелин\n§fSteve_1")&&t.rank.equals("Властелин")&&t.name.equals("Steve_1"));
        check(t.rawNameTag.endsWith("7/18 ♥")&&t.healthSource().equals("HP из подписи"));
        t=full("§c[VIP] §aAlex §r7❤/18","18","18");check(t.hp==7&&t.maxHp==18&&t.name.equals("Alex")&&t.rank.equals("VIP"));
        t=full("§bТитан Alex\n❤ 7,5 / 18","18","18");check(t.hp==7.5&&t.maxHp==18&&t.healthLabel().equals("7.5/18"));
        t=full("Alex\nHP: 7.25/18","18","18");check(t.hp==7.25&&t.maxHp==18);
        t=full("Alex\n7 ❤","18","18");check(t.hp==7&&t.maxHp==18&&t.hpFromNameTag);
        t=full("Alex\n♥ 7","18","18");check(t.hp==7&&t.maxHp==18&&t.hpFromNameTag);
        t=full("Alex\n0/18","18","18");check(t.hp==0&&t.healthLabel().equals("0/18"));
        t=full("Alex\n20/100","18","18");check(t.healthLabel().equals("20/100"));
        t=full("Alex\n7/18","nan","nan");check(t.hp==7&&t.maxHp==18&&t.hpFromNameTag);
        t=full("[VIP] Alex\n18/18 ♥\n7/18 ❤","18","18");check(t.hp==7&&t.maxHp==18);
        // Invalid values do not fabricate health or strip unknown server text.
        for(String invalid:new String[]{"19/18 ♥","-1/18","7/0","7/-18","Infinity/18","7/18x"}){
            t=full("Alex\n"+invalid,"nan","nan");check(t!=null&&Float.isNaN(t.hp)&&!t.hpFromNameTag&&t.displayName.contains(invalid));
        }
        t=full("§lВластелин\nAlex\n§7Клан: Солнце","18","18");check(t.displayName.contains("Клан: Солнце")&&t.normalizedNick().equals("alex"));
        t=full("VIP Alex OtherNick","18","18");check(t.normalizedNick().isEmpty()&&t.displayName.equals("VIP Alex OtherNick"));
        t=full("[VIP]","18","18");check(t.normalizedNick().isEmpty());
        t=TargetHudData.parse(snapshot("Alex","15",0)+"|20|8|0|15|15");check(t!=null&&t.state==8);
        t=TargetHudData.parse(snapshot("Alex","15",0)+"|20|9|0|15|15");check(t!=null&&t.state==9);
        check(TargetHudData.parse(snapshot("Alex","15",0)+"|20|10|0|15|15")==null);
        System.out.println("PASS: target HUD UTF-8/rank/multiline names, explicit server HP over attributes, source/unknown health, CPS/friend states and malformed snapshots");
    }
}
