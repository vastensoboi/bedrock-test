package dev.custom.bedrockgui;

/** Calibrated chest coordinates in the current Activity decor, independent of memory offsets. */
public final class SlotGrid {
    public final int slots,width,height;public final float x,y,dx,dy;
    public SlotGrid(int slots,int width,int height,float x,float y,float rightX,float rightY,float nextX,float nextY){
        this.slots=slots;this.width=width;this.height=height;
        // Minecraft's chest cells are square. Estimate the step over eight
        // columns, instead of multiplying one noisy vertical tap by 5 rows.
        this.x=(x+nextX)/2f;dx=(rightX-this.x)/8f;dy=dx;
        this.y=(y+rightY+nextY-dx)/3f;
        float measuredY=nextY-y;
        if((slots!=27&&slots!=54)||width<=0||height<=0||!Float.isFinite(this.x)||!Float.isFinite(this.y)||
                !Float.isFinite(dx)||!Float.isFinite(measuredY)||!Float.isFinite(rightY)||!Float.isFinite(nextX)||
                dx<8||measuredY/dx<0.7f||measuredY/dx>1.3f||Math.abs(rightY-y)>dx*0.4f||Math.abs(nextX-x)>dx*0.4f||
                this.x<dx/3||this.y<dy/3||this.x+8*dx>width-dx/3||this.y+(slots/9-1)*dy>height-dy/3)
            throw new IllegalArgumentException("Точки не образуют сетку слотов. Повтори настройку.");
    }
    public boolean fits(int slots,int width,int height){return this.slots==slots&&this.width==width&&this.height==height;}
    public float[] point(int slot){if(slot<0||slot>=slots)throw new IllegalArgumentException("Нет такого слота");return new float[]{x+(slot%9)*dx,y+(slot/9)*dy};}
}
