package dev.custom.bedrockgui;

import android.content.Context;

/** Initializes the installed game's Firebase SDK in the hosted game process. */
public final class GameFirebase {
    private static boolean initialized;
    private GameFirebase() {}

    public static void prepare(Context gameContext) throws ReflectiveOperationException {
        if (initialized) return;
        GameRuntime.log("Services: initializing Firebase from game resource context");
        Class<?> app = Class.forName("com.google.firebase.FirebaseApp", true, GameRuntime.loader);
        // The one-argument public initializer reads options from this Context
        // before storing its Application context. Passing the host Application
        // here would lose the game's google_app_id and other string resources.
        Object instance = app.getMethod("initializeApp", Context.class).invoke(null, gameContext);
        if (instance == null)
            throw new IllegalStateException("Firebase initialization returned null: game Firebase resource options were not found");
        Object defaultApp = app.getMethod("getInstance").invoke(null);
        if (defaultApp != instance)
            throw new IllegalStateException("Firebase default app identity check failed");
        GameRuntime.log("Services: Firebase default app initialized");
        // Verify the exact SDK entry point used by NotificationListenerService
        // before the native thread tries it with no Java exception handling.
        Class<?> messaging = Class.forName("com.google.firebase.messaging.FirebaseMessaging", true, GameRuntime.loader);
        if (messaging.getMethod("getInstance").invoke(null) == null)
            throw new IllegalStateException("Firebase Messaging component is unavailable");
        initialized = true;
        GameRuntime.log("Services: FirebaseMessaging.getInstance returned");
    }
}
