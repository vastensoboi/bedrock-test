#pragma once
#include "aim_core.h"
#include "own_frame_trace.h"
#include <sstream>
#include <iomanip>

namespace kulich_input {
using namespace kulich_aim;
constexpr A PACKET=0x13b95240ULL,SENDER=0x13b3ac00ULL,SEND=0xcc8934cULL;
constexpr uint32_t PASSENGER=0x98e40c0eU,REPLAY=0x9fc78512U;
struct Key {
 A client=0,registry=0,actor=0,history=0;uint32_t entity=0xffffffffU;
};
inline bool same(const Key& a,const Key& b){return a.client==b.client&&a.registry==b.registry&&a.actor==b.actor&&a.history==b.history&&a.entity==b.entity;}
struct Identity {Key key{};A sender=0;bool footKnown=false,onFoot=false;A actorTagged=0;};
inline bool same(const Identity& a,const Identity& b){return same(a.key,b.key)&&a.sender==b.sender&&a.footKnown==b.footKnown&&a.onFoot==b.onFoot&&a.actorTagged==b.actorTagged;}
template<class Read>bool identity(Read& source,A base,A client,A sender,Identity& out){
 out={};client=plain(client);sender=plain(sender);bool readable=true;
 auto read=[&](A at,void* bytes,size_t count){bool ok=source(plain(at),bytes,count);readable=readable&&ok;return ok;};
 if(!base||pointer(read,client)!=base+0x1388fe70ULL)return false;
 A weak[3]{};if(!read(client+576,weak,sizeof weak)||plain(weak[0])<4096||plain(weak[1])<4096)return false;
 A registry=plain(weak[0]);uint32_t entity=uint32_t(weak[2]);auto v=view(read,registry);
 A owner=component(read,v.owners,entity,8),actorTagged=0;Actor actor{};
 if(!owner||!read(owner,&actorTagged,8)||!kulich_aim::actor(read,base,v,actorTagged,true,actor)||actor.entity!=entity||pointer(read,actor.address+3240)!=client)return false;
 A actualSender=pointer(read,actor.address+1984);
 if(!actualSender||(sender&&sender!=actualSender)||pointer(read,actualSender)!=base+SENDER)return false;
 A replay=component(read,pool(read,registry,REPLAY),entity,32),history=0;
 if(!replay||!read(replay+8,&history,8)||plain(history)<4096||(plain(history)&7))return false;
 A passengerPool=pool(read,registry,PASSENGER);
 bool footKnown=passengerPool!=0,onFoot=footKnown&&sparse(read,passengerPool+8,entity)<0;
 if(!readable)return false;
 // Keep the history allocation tag in the identity, even though reads use
 // stripped addresses. Reallocation at the same address must not match.
 out={{client,registry,actor.address,history,entity},actualSender,footKnown,onFoot,actorTagged};return true;
}
struct Data {
 std::array<float,3> position{},delta{};uint64_t tick=0;
};
inline bool same(const Data& a,const Data& b){return a.tick==b.tick&&!std::memcmp(a.position.data(),b.position.data(),12)&&!std::memcmp(a.delta.data(),b.delta.data(),12);}
template<class Read>bool data(Read& read,A base,A packet,Data& out){
 out={};packet=plain(packet);Data value{};
 if(pointer(read,packet)!=base+PACKET||!read(packet+56,value.position.data(),12)||!read(packet+72,value.delta.data(),12)||!read(packet+168,&value.tick,8))return false;
 for(float f:value.position)if(!std::isfinite(f)||std::abs(f)>32000000.f)return false;
 for(float f:value.delta)if(!std::isfinite(f)||std::abs(f)>64000000.f)return false;
 out=value;return true;
}
struct Sample {Identity owner{};Data value{};kulich_frame::Trace trace{};};
inline kulich_frame::Key frameKey(const Key& key){return {key.client,key.registry,key.actor,key.history,key.entity};}
inline kulich_frame::Pose framePose(const Data& value){return {value.position,value.delta};}
inline bool attachTrace(Sample& sample,const kulich_frame::Trace& trace){
 // Failed provenance does not invalidate the independently captured packet.
 // Clock/actor disagreements remain attached as evidence; coherence is reported
 // separately from the binding to this exact submitted packet.
 const bool matches=kulich_frame::compatible(trace,frameKey(sample.owner.key),sample.value.tick,framePose(sample.value));
 sample.trace=matches?trace:kulich_frame::Trace{};return matches;
}
template<class Read>bool capture(Read& read,A base,A client,A sender,A packet,Sample& out){
 out={};Identity a{},b{};Data first{},second{};
 // Reject all other packet classes before traversing the actor graph.
 if(pointer(read,plain(packet))!=base+PACKET||!identity(read,base,client,sender,a)||!data(read,base,packet,first)||
    !identity(read,base,client,sender,b)||!same(a,b)||!data(read,base,packet,second)||!same(first,second))return false;
 out={a,first};return true;
}
template<class Read>bool captureFromProducer(Read& read,A base,A client,A sender,A packet,A producerActor,Sample& out){
 out={};Sample captured{};
 // A Loopback sender can serve several actors. Matching that sender and packet
 // class does not prove this native producer belongs to the local actor.
 // Keep the full allocation tag; an untagged or reallocated alias is not proof.
 if(plain(producerActor)<4096||!capture(read,base,client,sender,packet,captured)||
    captured.owner.actorTagged!=producerActor)return false;
 out=captured;return true;
}
enum class Match {Unavailable,NoRecord,DifferentBinding,ZeroTick,Vehicle,SourceUnknown,Riding,Ambiguous,Expired,Exact};
struct Comparison {
 Match state=Match::Unavailable;Data sent{};std::array<double,3> positionError{},deltaError{};
 int64_t ageMs=-1;uint64_t submissions=0,onSubmissions=0;int hundredths=100;bool mixedFactor=false;
 kulich_frame::Trace trace{};
};
struct Frame {
 Sample sample{};int64_t first=-1,last=-1;uint64_t submissions=0,onSubmissions=0;
 int hundredths=100;bool ambiguous=false,mixedFactor=false;
 // Keep later known origins without replacing the first captured trace.
 uint8_t knownOrigins=0;
};
inline uint8_t knownOrigin(const kulich_frame::Trace& trace){
 if(!trace.known)return 0;
 switch(trace.origin){
  case kulich_frame::Origin::Ordinary:return 1;
  case kulich_frame::Origin::Extra:return 2;
  case kulich_frame::Origin::Unexpected:return 4;
  default:return 0;
 }
}
struct Span {
 int64_t first=-1,last=-1;uint64_t firstTick=0,lastTick=0,submissions=0,unique=0;
 void add(int64_t when,uint64_t tick,bool fresh){
  if(first<0){first=when;firstTick=tick;}last=when;lastTick=tick;++submissions;if(fresh)++unique;
 }
};
struct Book {
 std::array<Frame,128> frames{};size_t next=0,size=0;Key key{};bool bound=false,phase=false,phaseKnown=false;
 A actorTagged=0;
 uint64_t submissions=0,duplicates=0,conflicts=0,resets=0;Span on{},off{};
 void clearFrames(){frames={};next=size=0;phaseKnown=false;on={};off={};}
 void add(int64_t when,bool active,int factor,const Sample& sample){
  if(when<0)return;
  Sample retained=sample;attachTrace(retained,sample.trace);
  const uint8_t origin=knownOrigin(retained.trace);
  factor=active?(factor<100?100:factor>200?200:factor):100;
  if(!bound||!same(key,retained.owner.key)||actorTagged!=retained.owner.actorTagged){
   clearFrames();key=retained.owner.key;actorTagged=retained.owner.actorTagged;bound=true;++resets;
  }
  Frame* found=nullptr;
  for(size_t i=0;i<size;++i)if(frames[i].sample.value.tick==retained.value.tick){found=&frames[i];break;}
  if(!found&&size){const Frame& latest=frames[(next+frames.size()-1)%frames.size()];
   if(retained.value.tick<latest.sample.value.tick){clearFrames();++resets;}
  }
  if(!phaseKnown||phase!=active){phase=active;phaseKnown=true;(active?on:off)={};}
  bool fresh=found==nullptr;(active?on:off).add(when,retained.value.tick,fresh);++submissions;
  if(found){
   ++duplicates;found->last=when;++found->submissions;if(active)++found->onSubmissions;
   found->mixedFactor=found->mixedFactor||found->hundredths!=factor;
   if(!same(found->sample.value,retained.value)||found->sample.owner.footKnown!=retained.owner.footKnown||found->sample.owner.onFoot!=retained.owner.onFoot||
      (origin&&found->knownOrigins&&!(origin&found->knownOrigins))){
    if(!found->ambiguous)++conflicts;
    found->ambiguous=true;
   }
   found->knownOrigins|=origin;
   return;
  }
  frames[next]={retained,when,when,1,active?1U:0U,factor,false,false,origin};
  next=(next+1)%frames.size();if(size<frames.size())++size;
 }
 Comparison compare(const Key& owner,uint64_t tick,int64_t when,uint8_t context,
                    const std::array<float,3>& position,const std::array<float,3>& delta)const{
  Comparison result{};
  if(context!=0){result.state=Match::Vehicle;return result;}
  if(tick==0){result.state=Match::ZeroTick;return result;}
  if(!bound){result.state=Match::NoRecord;return result;}
  if(!same(key,owner)){result.state=Match::DifferentBinding;return result;}
  const Frame* frame=nullptr;for(size_t i=0;i<size;++i)if(frames[i].sample.value.tick==tick){frame=&frames[i];break;}
  if(!frame){result.state=Match::NoRecord;return result;}
  result.sent=frame->sample.value;result.submissions=frame->submissions;result.onSubmissions=frame->onSubmissions;
  result.trace=frame->sample.trace;
  result.hundredths=frame->hundredths;result.mixedFactor=frame->mixedFactor;
  if(frame->ambiguous){result.state=Match::Ambiguous;return result;}
  if(!frame->sample.owner.footKnown){result.state=Match::SourceUnknown;return result;}
  if(!frame->sample.owner.onFoot){result.state=Match::Riding;return result;}
  if(frame->first<0||when<frame->last||when-frame->first>10000){result.state=Match::Expired;return result;}
  result.state=Match::Exact;result.ageMs=when-frame->first;
  for(size_t i=0;i<3;++i){result.positionError[i]=double(position[i])-result.sent.position[i];result.deltaError[i]=double(delta[i])-result.sent.delta[i];}
  return result;
 }
};
inline const char* name(Match state){
 switch(state){
  case Match::NoRecord:return "no-record";case Match::DifferentBinding:return "different-binding";
  case Match::ZeroTick:return "zero-tick-no-reference";case Match::Vehicle:return "vehicle-excluded";
  case Match::SourceUnknown:return "source-context-unknown";case Match::Riding:return "riding-excluded";
  case Match::Ambiguous:return "conflicting-submissions";case Match::Expired:return "expired";
  case Match::Exact:return "same-input-tick";default:return "unavailable";
 }
}
inline void describe(std::ostream& out,const Comparison& value){
 out<<" submittedComparison="<<name(value.state);
 if(value.state!=Match::Exact)return;
 out<<std::setprecision(std::numeric_limits<float>::max_digits10)
  <<" submittedPos=("<<value.sent.position[0]<<","<<value.sent.position[1]<<","<<value.sent.position[2]<<")"
  <<" submittedDelta=("<<value.sent.delta[0]<<","<<value.sent.delta[1]<<","<<value.sent.delta[2]<<")"
  <<" serverMinusSubmittedPos=("<<value.positionError[0]<<","<<value.positionError[1]<<","<<value.positionError[2]<<")"
  <<" serverMinusSubmittedDelta=("<<value.deltaError[0]<<","<<value.deltaError[1]<<","<<value.deltaError[2]<<")"
  <<" submissionAgeMs="<<value.ageMs<<" submissionsForTick="<<value.submissions<<" timerOnSubmissionsForTick="<<value.onSubmissions
  <<" submittedMultiplierHundredths="<<(value.mixedFactor?"mixed":std::to_string(value.hundredths));
 out<<" submittedFrame{";kulich_frame::describe(out,value.trace);out<<'}';
}
inline void describeSpan(std::ostream& out,const char* label,const Span& value){
 out<<" "<<label<<"Submissions="<<value.submissions<<" "<<label<<"UniqueFrames="<<value.unique;
 if(value.unique>1&&value.last>value.first){
  out<<" "<<label<<"ObservedFramesPerSecond="<<std::setprecision(6)<<double(value.unique-1)*1000/double(value.last-value.first);
  if(value.lastTick>=value.firstTick)out<<" "<<label<<"TickAdvancePerSecond="<<double(value.lastTick-value.firstTick)*1000/double(value.last-value.first);
 }
}
inline std::string describe(const Book& book){
 std::ostringstream out;out<<"submissions="<<book.submissions<<" duplicates="<<book.duplicates<<" conflictingTicks="<<book.conflicts
  <<" observationResets="<<book.resets<<" retained="<<book.size;
 describeSpan(out,"lastOnRun",book.on);describeSpan(out,"lastOffRun",book.off);return out.str();
}
}
