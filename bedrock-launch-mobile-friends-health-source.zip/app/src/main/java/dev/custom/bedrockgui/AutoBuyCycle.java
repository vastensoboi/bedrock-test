package dev.custom.bedrockgui;

import java.util.*;

/** Deterministic auction policy. All prices are server currency, never real money. */
public final class AutoBuyCycle {
    public static final long REFRESH_INTERVAL_MS=300;
    // Private snapshot of the fixed defaults: do not allocate 17 rules for each stack.
    private static final List<AutoBuyMatcher.Rule> DEFAULT_RULES=AutoBuyDefaultRules.rules();
    public static final class Lot {
        public final int slot,count;public final long item,tag;public final String name,kind;
        public final List<String> lore;public final Map<Integer,Integer> ench;public final AutoBuyMatcher.Verdict verdict;
        public Lot(int slot,int count,long item,long tag,String name,String kind,List<String> lore,Map<Integer,Integer> ench){
            this.slot=slot;this.count=count;this.item=item;this.tag=tag;this.name=name;this.kind=kind;
            this.lore=Collections.unmodifiableList(new ArrayList<>(lore));this.ench=Collections.unmodifiableMap(new TreeMap<>(ench));
            verdict=AutoBuyMatcher.evaluate(name,lore,count,kind,ench,DEFAULT_RULES);
        }
        public String itemKey(){return item+"|"+name+"|"+ench;}
        public String offerKey(){return itemKey()+"|"+count+"|"+verdict.seller+"|"+verdict.price;}
        public boolean sameOffer(Lot other){return other!=null&&item!=0&&verdict.accepted&&other.verdict.accepted&&offerKey().equals(other.offerKey());}
        public boolean control(String label){return name.replaceAll("§.","").trim().equalsIgnoreCase(label);}
    }
    public static final class Snapshot {
        public final int slots;public final Map<Integer,Lot> lots;public final Map<String,Integer> inventory;
        public final int skippedLots;
        public final boolean complete,space;public final Object handle;
        public Snapshot(int slots,Map<Integer,Lot> lots,Map<String,Integer> inventory,boolean complete,boolean space,Object handle){
            this(slots,lots,inventory,complete,space,handle,0);
        }
        public Snapshot(int slots,Map<Integer,Lot> lots,Map<String,Integer> inventory,boolean complete,boolean space,Object handle,int skippedLots){
            this.slots=slots;this.lots=Collections.unmodifiableMap(new TreeMap<>(lots));this.inventory=Collections.unmodifiableMap(new HashMap<>(inventory));
            this.complete=complete;this.space=space;this.handle=handle;this.skippedLots=skippedLots;
        }
        public Lot at(int slot){return lots.get(slot);}
    }
    public enum Kind { WAIT, REFRESH, OPEN, BUY, RETURN, STOP }
    public static final class Action {
        public final Kind kind;public final int slot;public final String message;
        Action(Kind kind,int slot,String message){this.kind=kind;this.slot=slot;this.message=message;}
    }
    private enum Phase { SEARCH, CONFIRM, RESULT, RETURNING, STOP }
    private long unreadableSince=-1;
    private Action awaitSnapshot(long now){
        if(unreadableSince<0)unreadableSince=now;
        if(now-unreadableSince>=2500){due=now+300;return new Action(Kind.WAIT,-1,"Нет стабильных данных аукциона. Ожидаю открытый список лотов");}
        due=now+150;return new Action(Kind.WAIT,-1,"Жду стабильный снимок аукциона");
    }
    private Phase phase=Phase.SEARCH;private long due,deadline;private Lot selected;private int before,requests;
    private final Set<String> attempted=new HashSet<>();
    public void suspendTime(long elapsed){
        if(elapsed<=0)return;
        if(due>0)due+=elapsed;if(deadline>0)deadline+=elapsed;if(unreadableSince>=0)unreadableSince+=elapsed;
    }
    public boolean openingInterrupted(){
        if(phase!=Phase.CONFIRM)return false;
        if(selected!=null)attempted.remove(selected.offerKey());
        phase=Phase.SEARCH;selected=null;due=0;return true;
    }
    public long pollAfter(){return due;}
    /** Read fresh lots during the remaining refresh delay, after the server reply.
     * next() still enforces due, so a faster read cannot send an early request.
     * Only refresh may overlap the delay; purchase/receipt waits remain unchanged. */
    public long refreshReadAfter(long now,long previousReadMs){
        if(phase!=Phase.SEARCH)return Math.max(now+20,due);
        long advance=Math.max(0,Math.min(previousReadMs,REFRESH_INTERVAL_MS)-25);
        return Math.max(now+20,due-advance);
    }
    private Action stop(String message){phase=Phase.STOP;return new Action(Kind.STOP,-1,message);}
    public Action next(Snapshot s,long now){
        if(phase==Phase.STOP)return new Action(Kind.STOP,-1,"Auto Buy остановлен");
        if(now<due)return new Action(Kind.WAIT,-1,"Ожидание ответа сервера");
        if(phase==Phase.RESULT){
            if(s!=null&&s.complete&&s.inventory.getOrDefault(selected.itemKey(),0)>=before+selected.count){
                requests++;phase=Phase.SEARCH;due=now+1500;
                if(s.slots==27){
                    if(!selected.sameOffer(s.at(13))||s.at(16)==null||!s.at(16).control("Вернуться"))return stop("Предмет получен. Вернись в список аукциона вручную");
                    phase=Phase.RETURNING;deadline=now+5000;
                    return new Action(Kind.RETURN,16,"Предмет получен. Возвращаюсь к списку лотов");
                }
                return new Action(Kind.WAIT,-1,"Предмет появился в инвентаре. Подтверждено покупок: "+requests);
            }
            if(now>=deadline)return stop("Запрос покупки отправлен, получение предмета не подтверждено. Проверь инвентарь; повторной покупки не будет");
            return new Action(Kind.WAIT,-1,"Проверяю получение предмета");
        }
        if(phase==Phase.RETURNING){
            if(s!=null&&s.complete&&s.slots==54){phase=Phase.SEARCH;due=now+500;return new Action(Kind.WAIT,-1,"Аукцион открыт. Продолжаю подбор");}
            if(now>=deadline)return stop("Предмет получен, но список аукциона не открылся. Повторного нажатия не будет");
            return new Action(Kind.WAIT,-1,"Жду список лотов");
        }
        if(phase==Phase.CONFIRM){
            if(s==null||!s.complete){if(now>=deadline)return stop("Окно покупки не прочитано");return new Action(Kind.WAIT,-1,"Жду окно покупки");}
            if(s.slots!=27){
                if(now>=deadline){
                    // A listing can disappear between selection and server processing.
                    // No BUY was submitted: resume only in the verified auction list.
                    // Keep the offer in attempted, so it cannot be repeatedly opened.
                    if(s.slots==54){phase=Phase.SEARCH;selected=null;due=now+REFRESH_INTERVAL_MS;return new Action(Kind.WAIT,-1,"Лот не открылся. Продолжаю поиск других предложений");}
                    return stop("Окно покупки не открылось");
                }
                return new Action(Kind.WAIT,-1,"Жду окно покупки");
            }
            Lot buy=s.at(10),back=s.at(16),preview=s.at(13);
            if(buy==null||!buy.control("Купить")||back==null||!back.control("Вернуться")||!selected.sameOffer(preview))
                return stop("Окно покупки не совпало с выбранным лотом. Покупка отменена");
            if(!s.space)return stop("Нет свободной ячейки в инвентаре");
            before=s.inventory.getOrDefault(selected.itemKey(),0);phase=Phase.RESULT;deadline=now+8000;due=now+700;
            return new Action(Kind.BUY,10,"Подтверждение: "+selected.name+" за "+selected.verdict.price+" у "+selected.verdict.seller);
        }
        if(s==null||!s.complete)return awaitSnapshot(now);
        if(s.slots!=54){due=now+300;return new Action(Kind.WAIT,-1,"Ожидаю возвращения в список аукциона");}
        if(!s.space)return stop("Нет свободной ячейки в инвентаре");
        if(s.at(49)==null||!s.at(49).control("Обновить"))return awaitSnapshot(now);
        unreadableSince=-1;
        for(Lot lot:s.lots.values())if(lot.slot<45&&lot.item!=0&&lot.verdict.accepted&&!attempted.contains(lot.offerKey())){
            selected=lot;attempted.add(lot.offerKey());phase=Phase.CONFIRM;deadline=now+5000;due=now+650;
            return new Action(Kind.OPEN,lot.slot,"Лот: слот="+lot.slot+" / "+lot.name+" / "+lot.verdict.price);
        }
        due=now+REFRESH_INTERVAL_MS;return new Action(Kind.REFRESH,49,"Подходящих лотов нет. Обновляю аукцион");
    }
}
