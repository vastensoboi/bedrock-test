# Local acceleration in 0.71

This module changes three verified local-player paths in the supplied exact
Minecraft 1.26.60.4 ARM64 binary. The global VariableTickRateComponent hash
`0x65be8945` belongs to a GlobalWrite system and is not a local-player clock.
It is never written. Repeating LocalPlayer::normalTick is also avoided: that
would repeat inventory, effects and callbacks without proving movement steps.

## Movement

MovementSpeedComponent `0x1268662e` is a four-byte float, read by native getter
`0x10192e04` and written at `0x10192ed4`. GroundTravelType adapters
`0x13acfbc0` / bulk `0xc1aea20` and `0x13acfc40` / bulk `0xc1b07c8` consume it.
WaterTravel adapter `0x13b458e8` / bulk `0xcdc3f44` also consumes it. Their
single-entity virtual entries are native no-ops, so no replacement is needed
there. A temporary local-only input multiplier leaves generated travel output
intact and restores only the same live unchanged input component.

PlayerAirSpeed adapter `0x13b424a8`, bulk `0xcd51628` and single `0xcd51e00`,
writes the MobTravelComponent `0x39cf8d64` (stride40) speed at+12 before travel
uses it. Require the player and air markers, exclude ground, and accept only
the native fresh `.02` / sprint `.026` values before scaling. Preserve the
resulting output. A nesting guard prevents nested bulk/single reapplication.
This accelerates movement control, not gravity or falling time.

## Item use

ItemInUseComponent `0x05b90aef` has stride16 and a signed remaining counter
at+8. ItemUseTickDurationSystem adapters are movement `0x13aca718` with bulk
`0xc128648`, single `0xc128af0`, and ordinary `0x13aca798` with bulk
`0xc129214`, single `0xc129564`. The movement phase requires
ActorMovementTickNeeded `0x94154cce` and ItemInUseTicksDuringMovement
`0x9b80c0c9`; the ordinary phase requires ActorTickNeeded `0x2744aa41` and
excludes the movement-use marker.

The native decrement at `0xc12884c..0xc128858` and `0xc12964c..0xc129658`
subtracts one and stores only a nonnegative result. The multiplier adds
fractional local progress before that decrement while keeping at least one
tick for native completion. Player::normalTick at `0x101f1f88` observes zero
and retains responsibility for completion. Foreign and excluded-phase calls
do not clear the current use's fractional credit. Identity, use-state or
counter discontinuities and disabled/configuration epochs reset it.

## Swing animation

LocalPlayer primary vtable slot144 is `0xaf5f724`; its call at `0xaf5f918`
enters Mob animation update `0xfa85d14`. Active is byte+1077, hand is byte+1076
and the cycle is int+1032. Duration `0xfa8364c(this, hand)` retains the game's
effect-dependent duration. Extra fractional cycle progress is capped below
the duration; the original callback computes interpolation/phase+1028 and
handles the natural end. No swing is created when inactive, and no attack or
network acknowledgement is synthesized.

## Installation and evidence

The native module replaces ten callback pointers across their read-only data
pages after code, vtable entry and mapping checks. Every original executes
once. Failed protection restoration disables effects and attempts rollback;
pass-through callbacks keep valid original pointers if rollback is prevented.
Only current client/registry/entity/generation bindings are writable and MTE
allocation tags are retained on native arguments and writes. Heartbeat expiry
and configuration changes reset per-thread progress without a catch-up burst.

Status reports ground/water/air modifications, extra use ticks and swing
updates separately. These counters prove local callback activity, not server
acceptance. Nevertime compatibility and freedom from server corrections have
not been tested or established. Other game timers and remote actors retain
their native callbacks and values.
