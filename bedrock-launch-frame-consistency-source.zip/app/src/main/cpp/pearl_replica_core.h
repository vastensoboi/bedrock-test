#pragma once
#include "pearl_native_core.h"

// Throwable::lerpMotion (101bc0c8) explicitly supports a missing Projectile
// component: 101bc1e0..1f4 writes the incoming motion to StateVector+24.
// Client replicas can therefore be real visible pearls without the server
// simulation component. Their observed positions are a trail, not a guessed
// gravity/drag prediction. Throwable stores owner UID at+944 (101bbfa0,
// getter101bc48c), initialized to zero by ctor101bb91c.
namespace kulich_pearl {
struct Replica {
 uint32_t id=0;int owner=-1;A actor=0,state=0;
 Vector position{},previous{},velocity{};
};
struct ReplicaStats {unsigned pages=0,slots=0,types=0,valid=0,rejected=0;};
template<class Read> bool replica(Read& read,A base,const View& v,A address,
                                 bool localKnown,int64_t localUid,Replica& out){
 std::array<A,4> header{},again{};uint32_t entity=0;address=plain(address);
 if(!identity(read,base,v,address,PEARL_VTABLE,header,entity))return false;
 // The ordinary predictive path owns actors with actual simulation data.
 // Never publish a second record of the same actor with fictitious physics.
 if(v.projectiles&&kulich_aim::component(read,v.projectiles,entity,760))return false;
 A state=kulich_aim::component(read,v.states,entity,sizeof(State));State value{},second{};
 int64_t owner=0,currentOwner=0;
 if(!state||kulich_aim::pointer(read,address+552)!=state||
    !read(state,&value,sizeof value)||!valid(value)||!read(address+944,&owner,8))return false;
 if(!read(address,again.data(),sizeof again)||header!=again||
    kulich_aim::sparse(read,v.registry+216,entity)<0||
    kulich_aim::component(read,v.states,entity,sizeof(State))!=state||
    kulich_aim::pointer(read,address+552)!=state||
    !read(state,&second,sizeof second)||std::memcmp(&value,&second,sizeof value)||
    !read(address+944,&currentOwner,8)||currentOwner!=owner)return false;
 A slot=kulich_aim::component(read,v.owners,entity,8);unsigned char removed=1;
 if(!slot||kulich_aim::pointer(read,slot)!=address||!read(address+617,&removed,1)||removed)return false;
 int classification=localKnown&&localUid!=0&&owner!=0&&owner!=-1?(owner==localUid?0:1):-1;
 out={entity,classification,address,state,value.position,value.previous,value.velocity};return true;
}

class ReplicaScanner {
 struct Ref {A actor=0;uint32_t id=0;};
 A registry=0;size_t cursor=0;std::vector<Ref> cached;
public:
 void reset(){registry=0;cursor=0;cached.clear();}
 template<class Read> bool collect(Read& read,A base,A root,A local,
                                  std::vector<Replica>& out,ReplicaStats& stats){
  out.clear();stats={};root=plain(root);
  if(registry!=root){reset();registry=root;}
  View v=view(read,root);if(!v.owners||!v.states)return false;
  int64_t uid=0;bool known=localUniqueId(read,base,v,local,uid);
  std::vector<Ref> retained;
  for(const Ref& ref:cached){
   Replica value{};
   if(replica(read,base,v,ref.actor,known,uid,value)&&value.id==ref.id){out.push_back(value);retained.push_back(ref);}
  }
  cached.swap(retained);
  size_t kept=cached.size();
  A bounds[3]{},again[3]{};
  if(!read(v.owners+80,bounds,sizeof bounds))return !out.empty();
  A begin=plain(bounds[0]),end=plain(bounds[1]),capacity=plain(bounds[2]);
  if(!begin||end<begin||capacity<end||(end-begin)%8||(end-begin)/8>128)return !out.empty();
  size_t pages=size_t((end-begin)/8);if(!pages)return true;
  // Two bounded pages per frame: always inspect the newest payload page for
  // freshly appended projectiles, plus one round-robin page for recycled
  // slots. Cached live pearls are sampled every frame independently.
  std::array<size_t,2> selected{pages-1,cursor++%pages};std::array<A,128> values{};
  for(size_t n=0;n<selected.size()&&out.size()<MAX_PEARLS;n++){
   if(n&&selected[n]==selected[0])continue;
   A page=kulich_aim::pointer(read,begin+selected[n]*8);
   if(!page||!read(page,values.data(),sizeof values))continue;
   ++stats.pages;
   for(A raw:values){
    ++stats.slots;A address=plain(raw);
    if(!address||std::any_of(cached.begin(),cached.end(),[&](const Ref& p){return p.actor==address;})||
       kulich_aim::pointer(read,address)!=base+PEARL_VTABLE)continue;
    ++stats.types;Replica value{};
    if(!replica(read,base,v,address,known,uid,value)){++stats.rejected;continue;}
    if(out.size()>=MAX_PEARLS)break;
    out.push_back(value);cached.push_back({value.actor,value.id});
   }
  }
  // A changed page vector only invalidates newly discovered references. Every
  // retained observation was independently type/generation/state validated.
  if(!read(v.owners+80,again,sizeof again)||std::memcmp(bounds,again,sizeof bounds)){
   out.resize(kept);cached.resize(kept);
  }
  stats.valid=unsigned(out.size());return true;
 }
};

inline double replicaDistance2(Vector a,Vector b){double x=double(a.x)-b.x,y=double(a.y)-b.y,z=double(a.z)-b.z;return x*x+y*y+z*z;}
struct ObservedTrail {uint32_t id=0;int owner=-1;A actor=0;std::vector<Vector> points;int64_t seenAt=0;};
class TrailBook {
 A registry=0;int64_t previous=-1;std::vector<ObservedTrail> entries;
public:
 static constexpr size_t MAX_POINTS=64;static constexpr int64_t LINGER_MS=750;
 void reset(){registry=0;previous=-1;entries.clear();}
 void observe(A root,const std::vector<Replica>& observations,int64_t at){
  if(at<0)return;
  if(registry!=root||at<previous){reset();registry=root;}
  previous=at;
  entries.erase(std::remove_if(entries.begin(),entries.end(),[&](const ObservedTrail& p){return at-p.seenAt>LINGER_MS;}),entries.end());
  for(const Replica& value:observations){
   if(!finite(value.position,32000000)||!finite(value.previous,32000000))continue;
   auto found=std::find_if(entries.begin(),entries.end(),[&](const ObservedTrail& p){return p.id==value.id&&p.actor==value.actor;});
   if(found==entries.end()){
    if(entries.size()>=MAX_PEARLS){
     auto oldest=std::min_element(entries.begin(),entries.end(),[](const ObservedTrail& a,const ObservedTrail& b){return a.seenAt<b.seenAt;});
     entries.erase(oldest);
    }
    entries.push_back({value.id,value.owner,value.actor,{},at});found=entries.end()-1;
   }
   if(!found->points.empty()&&(at-found->seenAt>250||replicaDistance2(found->points.back(),value.position)>64))found->points.clear();
   found->owner=value.owner;found->seenAt=at;
   if(found->points.empty()&&replicaDistance2(value.previous,value.position)<64&&replicaDistance2(value.previous,value.position)>1e-8)found->points.push_back(value.previous);
   if(found->points.empty()||replicaDistance2(found->points.back(),value.position)>1e-8)found->points.push_back(value.position);
   if(found->points.size()>MAX_POINTS)found->points.erase(found->points.begin(),found->points.begin()+long(found->points.size()-MAX_POINTS));
  }
 }
 const std::vector<ObservedTrail>& trails()const{return entries;}
};
}
