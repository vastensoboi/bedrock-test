package dev.custom.bedrockgui;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Set only the content log file option in this launcher's own game settings. */
public final class GameLogOptions {
    private static final String RELATIVE="games/com.mojang/minecraftpe/options.txt";
    private static final int LIMIT=512*1024;
    private GameLogOptions() {}

    public static String enable(File data,File files,File[] external)throws IOException {
        List<File> bases=new ArrayList<>();bases.add(data);
        if(files!=null)bases.add(files);
        if(external!=null)for(File root:external)if(root!=null)bases.add(root);
        Set<Path> selected=new LinkedHashSet<>();
        for(File base:bases){
            Path path=ownedPath(base);
            if(Files.exists(path,LinkOption.NOFOLLOW_LINKS))selected.add(path);
        }
        if(selected.isEmpty())selected.add(ownedPath(data));
        int changed=0;
        for(Path path:selected)if(enableFile(path))changed++;
        return "Content log setup: content_log_file=1; settings="+selected.size()+"; changed="+changed;
    }

    private static Path ownedPath(File base)throws IOException {
        if(base==null)throw new IOException("Нет каталога данных лаунчера");
        File root=base.getCanonicalFile(),file=new File(root,RELATIVE);
        if(!file.getAbsoluteFile().equals(file.getCanonicalFile()))
            throw new IOException("Ссылка в пути настроек Minecraft");
        return file.toPath();
    }

    private static boolean enableFile(Path path)throws IOException {
        boolean existed=Files.exists(path,LinkOption.NOFOLLOW_LINKS);
        if(existed&&(!Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS)||Files.size(path)>LIMIT))
            throw new IOException("Неподдерживаемый файл настроек Minecraft");
        byte[] original=existed?Files.readAllBytes(path):new byte[0];
        if(original.length>LIMIT)throw new IOException("Файл настроек вырос во время чтения");
        String text=new String(original,StandardCharsets.UTF_8);
        boolean bom=text.startsWith("\ufeff");if(bom)text=text.substring(1);
        String newline=text.contains("\r\n")?"\r\n":"\n";
        String[] lines=text.split("(?<=\n)",-1);
        StringBuilder result=new StringBuilder(bom?"\ufeff":"");boolean found=false;
        for(String line:lines){
            String plain=line.replaceFirst("[\\r\\n]+$","");
            if(plain.startsWith("content_log_file:")){
                String ending=line.substring(plain.length());
                result.append("content_log_file:1").append(ending);found=true;
            }else result.append(line);
        }
        if(!found){
            if(result.length()>0&&result.charAt(result.length()-1)!='\n')result.append(newline);
            result.append("content_log_file:1").append(newline);
        }
        byte[] updated=result.toString().getBytes(StandardCharsets.UTF_8);
        if(Arrays.equals(original,updated))return false;
        Files.createDirectories(path.getParent());
        Path backup=path.resolveSibling("options.txt.kulich-before-content-log");
        if(existed&&!Files.exists(backup,LinkOption.NOFOLLOW_LINKS))Files.copy(path,backup);
        Path temporary=Files.createTempFile(path.getParent(),"kulich-log-",".tmp");
        try{
            Files.write(temporary,updated);
            try{Files.move(temporary,path,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException error){Files.move(temporary,path,StandardCopyOption.REPLACE_EXISTING);}
        }finally{Files.deleteIfExists(temporary);}
        return true;
    }
}
