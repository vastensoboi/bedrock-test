declare module "@kulich/api" {
  type Setting = {type: "number"; def: number; min?: number; max?: number} | {type: "boolean"; def: boolean};
  type Schema = Record<string, Setting>;
  interface ModuleContext<S extends Schema> {
    readonly apiVersion: 1;
    options: {[K in keyof S]: {value: S[K] extends {type: "boolean"} ? boolean : number}};
    readonly capabilities: Readonly<{auction: false; packets: false; inventory: false; fastExp: true}>;
    log(message: string): void;
    onEnable(callback: () => void): void;
    onDisable(callback: () => void): void;
    /** ui_tick is a menu timer (~400 ms), not a Minecraft simulation tick. */
    on(event: "enable" | "disable" | "ui_tick", callback: () => void): void;
    readonly fastExp: {
      isReady(): boolean;
      /** Requires the native bridge to have been prepared by the Fast Exp module. */
      setEnabled(enabled: boolean): void;
      setInterval(ticks: number): void;
      status(): string;
    };
  }
  export function defineModule<S extends Schema>(
    meta: {id: string; name?: string; description?: string},
    settings: S,
    setup: (ctx: ModuleContext<S>) => void
  ): void;
}
